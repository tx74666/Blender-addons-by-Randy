"""Explicit existing-loop marks and safe rest-joint alignment.

There are no handlers, timers or geometry writes here. Stored coordinates are
display data; only Mark and Align inspect the current mesh. Alignment always
verifies the live loops and reference before starting the bone transaction.
The four non-thumb chains use their fixed root-to-tip internal line. Thumb
joints follow the existing curved bone path instead. Loop planes determine
longitudinal positions; off-center loop centroids never bend a straight finger.
"""
import json
import math

from mathutils import Vector
from mathutils.kdtree import KDTree

from . import finger_bank as bank, finger_chain as chain
from . import finger_definition as definition, finger_detect as detect
from . import finger_internal as internal, finger_range as ranges
from . import finger_symmetry as symmetry, finger_targets as targets

PROPERTY = 'character_designer_finger_loop_marks'
VERSION = 1
PAIR_WARNING = 'Sync both hands with Mirror Selected Region.'
EPS = 1e-6


def _saved(obj):
    try:
        value = json.loads(obj.get(PROPERTY, '{}'))
        return value if isinstance(value, dict) else {}
    except (ValueError, TypeError):
        return {}


def records(obj, key):
    """Read small persistent marker records; never inspect mesh data."""
    value = _saved(obj).get(key, {})
    return value if isinstance(value, dict) else {}


def effective_key(obj, key, mirror):
    """Reuse a complete opposite mark pair only for an unmarked mirrored side.

    This reads small metadata only. It does not claim that reflected guides are
    actual selected edges on the other hand, and never fills a partial pair.
    """
    if not mirror: return key
    saved = _saved(obj)
    active = saved.get(key, {})
    if active: return key
    mate_key = key[:-1]+('R' if key[-1] == 'L' else 'L')
    mate = saved.get(mate_key, {})
    if isinstance(mate, dict) and all(isinstance(mate.get(str(i)), dict) for i in (1, 2)):
        return mate_key
    return key


def points(obj, key, *, saved=None):
    """Return open ordered polylines in mesh-local space for cached drawing."""
    result = {}
    marked = records(obj, key) if saved is None else saved.get(key, {}) if isinstance(saved, dict) else {}
    if not isinstance(marked, dict): return result
    for number, record in marked.items():
        if number not in {'1', '2'} or not isinstance(record, dict): continue
        coordinates = record.get('coordinates', ())
        try:
            path = tuple(tuple(float(v) for v in point) for point in coordinates)
            if len(path) < 4 or any(len(p) != 3 or not all(map(math.isfinite, p)) for p in path): continue
            result[int(number)] = path
        except (TypeError, ValueError):
            continue
    return result


def _active(context):
    obj = bank.active_object(context)
    if obj is None: raise ValueError('Capture this finger first.')
    if obj.library or obj.override_library or not obj.is_editable:
        raise ValueError('Use a local editable character mesh.')
    return obj, obj.character_designer_finger_bank.active


def _reference(obj, key, reader):
    slot = obj.character_designer_finger_bank.slots.get(key)
    if not slot or not slot.guide.record:
        raise ValueError('Capture this finger first.')
    if slot.error: raise ValueError(slot.error)
    if not slot.guide.confirmed or not slot.guide.use_basis:
        raise ValueError('Confirm this finger Basis reference first.')
    record = definition._validate_mesh(obj, json.loads(slot.guide.record), True, reader=reader)
    if not record.get('body'):
        raise ValueError('Recapture this finger reference first.')
    return record


def _ring(obj, bm, reference, vertices):
    """Accept an entire transverse ring of this finger, never a side strip."""
    ids = {v.index for v in vertices}
    rows = reference['body']['rings']
    matches = [i for i, row in enumerate(rows) if set(row) == ids]
    if len(matches) != 1:
        raise ValueError('Select one complete loop on the active finger and side.')
    if matches[0] in (0, len(rows)-1):
        raise ValueError('Choose an internal joint loop; root and tip stay fixed.')
    if any(v.hide for v in vertices):
        raise ValueError('Unhide the complete marked loop first.')
    return matches[0]


def _section(vertices):
    """Area centroid and normal of the marked cross section."""
    points = [v.co.copy() for v in vertices]
    anchor = sum(points, Vector())/len(points)
    normal = sum(((a-anchor).cross(b-anchor) for a, b in
                  zip(points, points[1:]+points[:1])), Vector())
    if normal.length <= EPS*EPS: raise ValueError('The loop section is collapsed.')
    normal.normalize()
    terms = [((a-anchor).cross(b-anchor).dot(normal), (anchor+a+b)/3)
             for a, b in zip(points, points[1:]+points[:1])]
    area = sum(weight for weight, _ in terms)
    if abs(area) <= EPS*EPS: raise ValueError('The loop section is collapsed.')
    return sum((point*weight for weight, point in terms), Vector())/area, normal


def _center(vertices):
    return _section(vertices)[0]


def _marker(obj, key, vertices, reference):
    center, normal = _section(vertices)
    root, tip = map(Vector, (reference['body']['root'], reference['body']['tip']))
    axis = tip-root
    fraction = (center-root).dot(axis)/axis.length_squared
    if not 0 < fraction < 1:
        raise ValueError('Choose an internal joint loop; root and tip stay fixed.')
    return dict(version=VERSION, key=key, basis_key=definition._basis_name(obj),
                ids=[v.index for v in vertices], coordinates=[list(v.co) for v in vertices],
                center=list(center), normal=list(normal), fraction=fraction)


def _plane_hit(path, marker):
    """Unique path/section intersection, plus its distance from the root."""
    center, normal = Vector(marker['center']), Vector(marker['normal'])
    lengths = [(b-a).length for a, b in zip(path, path[1:])]
    total = sum(lengths)
    tolerance = max(EPS, total*1e-6)
    if total <= tolerance or normal.length <= EPS:
        raise ValueError('The bone path or marked cross section is collapsed.')
    normal.normalize()
    hits, distance = [], 0.
    for a, b, length in zip(path, path[1:], lengths):
        if length <= tolerance:
            raise ValueError('The bone path contains a collapsed segment.')
        start, end = (a-center).dot(normal), (b-center).dot(normal)
        denominator = start-end
        if abs(denominator) <= tolerance:
            if abs(start) <= tolerance and abs(end) <= tolerance:
                raise ValueError('A marked loop follows a bone segment; choose a transverse loop.')
        else:
            fraction = start/denominator
            slack = tolerance/length
            if -slack <= fraction <= 1+slack:
                fraction = max(0., min(1., fraction))
                hit = a.lerp(b, fraction)
                position = distance+length*fraction
                if not hits or (hit-hits[-1][0]).length > tolerance:
                    hits.append((hit, position/total))
        distance += length
    if len(hits) != 1:
        raise ValueError('The marked loop must cross the internal bone path once.')
    point, fraction = hits[0]
    if not tolerance/total < fraction < 1-tolerance/total:
        raise ValueError('The marked joints must stay between the fixed root and tip.')
    return point, fraction


def _joint_nodes(key, nodes, markers):
    """Place joints on the internal line, or preserve Thumb's curved path."""
    thumb = key.split('.')[0] == 'THUMB'
    path = nodes if thumb else [nodes[0], nodes[-1]]
    hits = [_plane_hit(path, marker) for marker in markers]
    if hits[1][1]-hits[0][1] <= 1e-5:
        raise ValueError('Select both joint loops and mark them again.')
    proposed = [nodes[0].copy(), hits[0][0], hits[1][0], nodes[-1].copy()]
    if thumb:
        scale = sum((b-a).length for a, b in zip(nodes, nodes[1:]))
        tolerance = scale*scale*1e-7
        for before, after in zip(chain._turns(nodes), chain._turns(proposed)):
            if before.length > tolerance and (after.length <= tolerance or before.dot(after) <= 0):
                raise ValueError('These marks would flatten or reverse the thumb bend; choose other loops.')
    return proposed


def mark(context, number):
    """Replace one explicit mark without modifying mesh, selection or bones."""
    if number not in (1, 2): raise ValueError('Choose joint mark 1 or 2.')
    obj, key = _active(context)
    if (context.mode != 'EDIT_MESH' or context.edit_object != obj or
            len(context.objects_in_mode_unique_data) != 1):
        raise ValueError('Select one complete edge loop in Mesh Edit Mode.')
    if definition._key_name(obj) != definition._basis_name(obj):
        raise ValueError('Select Basis before marking rest-joint loops.')
    with definition.FrameReader() as reader:
        bm = reader.snapshot(obj, definition._basis_name(obj))
        selected = [edge for edge in bm.edges if edge.select and not edge.hide]
        vertices = ranges.ordered_loop(selected)
        reference = _reference(obj, key, reader)
        _ring(obj, bm, reference, vertices)
        result = _marker(obj, key, vertices, reference)
    saved = _saved(obj)
    previous = saved.get(key, {})
    marks = dict(previous) if isinstance(previous, dict) else {}
    marks[str(number)] = result
    saved[key] = marks
    obj[PROPERTY] = json.dumps(saved, separators=(',', ':'))
    return result


def _selected_loops(edges):
    """Split only the selected edges, then require complete disjoint cycles."""
    remaining = set(edges)
    if not remaining: raise ValueError('Select one or two complete joint loops.')
    linked = {}
    for edge in edges:
        for vertex in edge.verts: linked.setdefault(vertex, set()).add(edge)
    loops = []
    while remaining:
        pending, component = [min(remaining, key=lambda edge: edge.index)], set()
        while pending:
            edge = pending.pop()
            if edge not in remaining: continue
            remaining.remove(edge)
            component.add(edge)
            for vertex in edge.verts: pending.extend(linked[vertex] & remaining)
        loops.append(ranges.ordered_loop(component))
        if len(loops) > 2: raise ValueError('Select at most two joint loops on this finger.')
    return loops


def _same_loop(first, second):
    """Compare small saved coordinates, independent of index or cycle order."""
    a, b = [list(map(Vector, record.get('coordinates', ()))) for record in (first, second)]
    if len(a) != len(b) or not a: return False
    hits = [[i for i, q in enumerate(b) if (p-q).length <= EPS] for p in a]
    return all(len(values) == 1 for values in hits) and len({values[0] for values in hits}) == len(a)


def _merge_marks(previous, incoming):
    """One click stores a root-to-tip pair without requiring named joint slots."""
    if len(incoming) == 2:
        result = list(incoming)
    else:
        result = []
        for name in ('1', '2'):
            if name not in previous: continue
            record = previous[name]
            if (not isinstance(record, dict) or not isinstance(record.get('fraction'), (float, int))
                    or not math.isfinite(record['fraction']) or not 0 < record['fraction'] < 1):
                raise ValueError('Select both joint loops and mark them again.')
            try:
                duplicate = any(_same_loop(record, other) for other in result)
            except (ValueError, TypeError):
                raise ValueError('Select both joint loops and mark them again.') from None
            if not duplicate: result.append(record)
        new = incoming[0]
        try: matches = [i for i, record in enumerate(result) if _same_loop(record, new)]
        except (ValueError, TypeError):
            raise ValueError('Select both joint loops and mark them again.') from None
        if matches:
            result[matches[0]] = new
        elif len(result) < 2:
            result.append(new)
        else:
            distances = [abs(record['fraction']-new['fraction']) for record in result]
            if abs(distances[0]-distances[1]) <= 1e-5:
                raise ValueError('This loop is equally close to both marks; select both intended loops.')
            result[0 if distances[0] < distances[1] else 1] = new
    result.sort(key=lambda record: record['fraction'])
    if len(result) == 2 and result[1]['fraction']-result[0]['fraction'] <= 1e-5:
        raise ValueError('Select two distinct joint loops with space between them.')
    return {str(i+1): record for i, record in enumerate(result)}


def mark_selected(context):
    """Mark one or two existing loops; assign internal order automatically.

    A new single loop joins one prior mark or replaces the nearest of a pair.
    Selecting both intended loops always replaces the pair unambiguously. All
    selected components must pass before any saved marker metadata is changed.
    """
    obj, key = _active(context)
    if (context.mode != 'EDIT_MESH' or context.edit_object != obj or
            len(context.objects_in_mode_unique_data) != 1):
        raise ValueError('Select one or two complete edge loops in Mesh Edit Mode.')
    if definition._key_name(obj) != definition._basis_name(obj):
        raise ValueError('Select Basis before marking rest-joint loops.')
    with definition.FrameReader() as reader:
        bm = reader.snapshot(obj, definition._basis_name(obj))
        loops = _selected_loops([edge for edge in bm.edges if edge.select and not edge.hide])
        reference = _reference(obj, key, reader)
        incoming = []
        for vertices in loops:
            _ring(obj, bm, reference, vertices)
            incoming.append(_marker(obj, key, vertices, reference))
        saved = _saved(obj)
        previous = saved.get(key, {})
        result = _merge_marks(previous if isinstance(previous, dict) else {}, incoming)
    saved[key] = result
    obj[PROPERTY] = json.dumps(saved, separators=(',', ':'))
    return result


def clear(context, number=None):
    """Forget the active side's marks only; no mesh or bone change."""
    obj, key = _active(context)
    if number is not None and number not in (1, 2): raise ValueError('Choose joint mark 1 or 2.')
    saved = _saved(obj)
    if number is None: saved.pop(key, None)
    elif isinstance(saved.get(key), dict):
        saved[key].pop(str(number), None)
        if not saved[key]: saved.pop(key)
    if saved: obj[PROPERTY] = json.dumps(saved, separators=(',', ':'))
    elif PROPERTY in obj: del obj[PROPERTY]


def clear_digit(obj, digit):
    """Used when the owning Basic Setup is explicitly cleared."""
    saved = _saved(obj)
    for side in ('L', 'R'): saved.pop(digit+'.'+side, None)
    if saved: obj[PROPERTY] = json.dumps(saved, separators=(',', ':'))
    elif PROPERTY in obj: del obj[PROPERTY]


def _recover(bm, record, number):
    message = 'A marked loop changed; mark that loop again.'
    try:
        ids, coordinates = record['ids'], list(map(Vector, record['coordinates']))
        if len(ids) != len(coordinates) or len(ids) < 4: raise ValueError(message)
        if not all(isinstance(i, int) and i >= 0 for i in ids): raise ValueError(message)
        exact = all(i < len(bm.verts) and (bm.verts[i].co-p).length <= EPS
                    for i, p in zip(ids, coordinates))
        if not exact:
            # Index changes elsewhere are harmless. Coordinate recovery is
            # explicit and rejects ambiguous coincident vertices.
            tree = KDTree(len(bm.verts))
            for v in bm.verts: tree.insert(v.co, v.index)
            tree.balance()
            hits = [tree.find_range(p, EPS) for p in coordinates]
            if any(len(values) != 1 for values in hits): raise ValueError(message)
            ids = [values[0][1] for values in hits]
        if len(set(ids)) != len(ids): raise ValueError(message)
        vertices = [bm.verts[i] for i in ids]
        edges = [bm.edges.get((a, b)) for a, b in zip(vertices, vertices[1:]+vertices[:1])]
        if any(edge is None or edge.hide for edge in edges): raise ValueError(message)
        ranges.ordered_loop(edges)
        return vertices
    except (KeyError, TypeError, IndexError) as exc:
        raise ValueError(message) from exc


def _certify(obj, rig, reference, nodes, bm):
    """Verify every proposed rest segment inside the current finger volume."""
    body = reference['body']
    volume = internal.Volume(bm, body)
    transform = obj.matrix_world.inverted() @ rig.matrix_world
    points = [transform @ Vector(p) for p in nodes]
    margin = max(body['length']*1e-6, min(body['radius']*.02, body['length']*.001))
    for p in points[1:-1]:
        if not volume.inside(p) or volume.distance(p) < margin:
            raise ValueError('A marked joint is outside the captured finger interior.')
    for i, (a, b) in enumerate(zip(points, points[1:])):
        length = (b-a).length
        if length < max(EPS, body['length']*1e-5):
            raise ValueError('The marked loops would collapse a bone segment.')
        start, end = a.copy(), b.copy()
        for which, endpoint in ((0, a), (1, b)):
            boundary = i == 0 and which == 0 or i == len(points)-2 and which == 1
            distance = volume.distance(endpoint)
            if boundary and distance is not None and distance <= margin*1.1:
                inset = endpoint.lerp(b if which == 0 else a, min(.01, margin*2/length))
                if not volume.inside(inset):
                    raise ValueError('A fixed chain endpoint points outside the finger.')
                if which == 0: start = inset
                else: end = inset
        if volume.certify((start, end), margin*.5) is None:
            raise ValueError('A planned bone segment leaves the finger interior.')


def align(context):
    """Move existing joint junctions to marks, then atomically refresh bindings."""
    obj, key = _active(context)
    owner, rig = targets.owner(context)
    if owner != obj: raise ValueError('Use the captured Body mesh for this Main Rig.')
    key = effective_key(obj, key, rig.data.use_mirror_x)
    symmetry.guard_rig(rig)
    if definition._key_name(obj) != definition._basis_name(obj):
        raise ValueError('Select Basis before aligning rest joints.')
    marked = records(obj, key)
    if not all(isinstance(marked.get(str(i)), dict) for i in (1, 2)):
        raise ValueError('Mark two joint loops first.')
    plan = dict(obj=obj, rig=rig, keys=[], chains=[])
    with definition.FrameReader() as reader:
        bm = reader.snapshot(obj, definition._basis_name(obj))
        reference = _reference(obj, key, reader)
        current = []
        for number in (1, 2):
            old = marked[str(number)]
            if old.get('basis_key') != definition._basis_name(obj) or old.get('key') != key:
                raise ValueError('A marked loop reference changed; mark that loop again.')
            vertices = _recover(bm, old, number)
            _ring(obj, bm, reference, vertices)
            current.append(_marker(obj, key, vertices, reference))
        if current[1]['fraction']-current[0]['fraction'] <= 1e-5:
            raise ValueError('Select both joint loops and mark them again.')
        candidates = targets.index(rig)
        source = targets.resolve(obj, rig, key, candidates)
        if len(source) != 3:
            raise ValueError('Two joint marks need an existing three-bone finger chain.')
        original_nodes = chain._nodes(source)
        to_mesh = obj.matrix_world.inverted() @ rig.matrix_world
        mesh_nodes = [to_mesh @ point for point in original_nodes]
        proposed = _joint_nodes(key, mesh_nodes, current)
        transform = rig.matrix_world.inverted() @ obj.matrix_world
        nodes = [transform @ point for point in proposed]
        nodes[0], nodes[-1] = original_nodes[0], original_nodes[-1]
        _certify(obj, rig, reference, nodes, bm)
        plan['keys'].append(key)
        plan['chains'].append(dict(key=key, names=[b.name for b in source], nodes=nodes,
                                   expected=chain._rest(source)))
        if rig.data.use_mirror_x:
            mate_key = key[:-1]+('R' if key[-1] == 'L' else 'L')
            try:
                other_reference = _reference(obj, mate_key, reader)
                try: detect.vertex_map(bm, reference['body'], other_reference['body'], bank.plane(obj))
                except ValueError:
                    bank._mirrored_ring_surface(bm, reference['body'], other_reference['body'], bank.plane(obj))
            except ValueError as exc:
                raise ValueError(PAIR_WARNING) from exc
            other = targets.resolve(obj, rig, mate_key, candidates)
            if len(other) != 3: raise ValueError('Both finger chains need three existing bones.')
            mirror = targets.reflection(obj, rig)
            other_nodes = chain._nodes(other)
            tolerance = max(EPS, reference['body']['length']*1e-6)
            if any((mirror @ p-q).length > tolerance for p, q in
                   ((nodes[0], other_nodes[0]), (nodes[-1], other_nodes[-1]))):
                raise ValueError('Match the two bone-chain roots and tips before mirrored alignment.')
            other_nodes[1:3] = [mirror @ p for p in nodes[1:3]]
            _certify(obj, rig, other_reference, other_nodes, bm)
            plan['keys'].append(mate_key)
            plan['chains'].append(dict(key=mate_key, names=[b.name for b in other], nodes=other_nodes,
                                       expected=chain._rest(other)))
    return chain._run(context, plan)
