"""Small Hair-page workflow for strand discovery and native bone control."""

import hashlib
import importlib

import bpy
from bpy.props import EnumProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup

from .hair_bones_topology import HairTopologyError, select_strands, selected_strands
from .hair_bones_rig import HairBonesRigError, build_hair_bones
from .ui_constants import SIDEBAR_CATEGORY, UI_PAGE_HAIR, active_ui_page


def _groups():
    return importlib.import_module(__package__ + ".hair_bones_groups")


def _variants():
    return importlib.import_module(__package__ + ".hair_bones_variants")


def _source(context):
    obj = context.active_object
    if obj:
        source = _variants().source_for(obj)
        if source:
            return source
        try:
            source = _groups().source_from_context(context)
            if source:
                return source
        except ValueError:
            pass
    settings = _settings(context)
    return settings.source if settings else None


_ENUM_ITEMS = {}
_ENUM_STRINGS = {}


def _enum_item(identifier, label, description=""):
    # Blender retains dynamic-enum strings. Hold their storage for the module's
    # RNA lifetime, and keep numeric values stable when versions are reordered.
    values = tuple(_ENUM_STRINGS.setdefault(value, value) for value in (identifier, label, description))
    number = 0 if identifier == "NONE" else int(hashlib.sha256(identifier.encode()).hexdigest()[:7], 16) + 1
    return (*values, 0, number)


def _variant_items(self, context):
    source = _source(context) if context else self.source
    collections = _variants().variants_for(source) if source else ()
    _ENUM_ITEMS["variants"] = [_enum_item("NONE", "Choose Version" if collections else "No generated versions")]
    _ENUM_ITEMS["variants"].extend(_enum_item(collection.name, collection.name, "Show this independent result")
                                   for collection in collections)
    return _ENUM_ITEMS["variants"]


def _settings(context):
    return getattr(context.window_manager, "character_designer_hair_bones", None)


def _mesh_edit(context):
    obj = context.active_object
    return obj is not None and obj.type == "MESH" and context.mode == "EDIT_MESH"


def _source_edit(context):
    return _mesh_edit(context) and _variants().source_for(context.active_object) is context.active_object


def _report(operator, context, message, *, error=False):
    settings = _settings(context)
    if settings:
        settings.last_message = message
    operator.report({"ERROR" if error else "INFO"}, message)


class CharacterDesignerHairBonesState(PropertyGroup):
    source: PointerProperty(type=bpy.types.Object, name="Source Mesh", options={"SKIP_SAVE"})
    active_variant: EnumProperty(name="Version", items=_variant_items)
    bone_count: IntProperty(
        name="Bones per Chain",
        description="Number of bones in each strand's independent chain",
        default=4,
        min=1,
        max=12,
    )
    last_message: StringProperty(options={"SKIP_SAVE"})


class CHARACTERDESIGNER_OT_select_hair_strands(Operator):
    bl_idname = "character_designer.select_hair_strands"
    bl_label = "Select Hair Strands"
    bl_description = (
        "Find long hair strips up to their root junctions. Selected vertices limit "
        "the search; deselect all to search the visible mesh"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _source_edit(context)

    def execute(self, context):
        try:
            obj, plans = select_strands(context)
            _groups().capture_plans(obj, plans)
            _settings(context).source = obj
        except (ValueError, RuntimeError) as exc:
            _report(self, context, str(exc), error=True)
            return {"CANCELLED"}
        count = len(plans)
        _report(self, context, f"Captured {count} hair strand{'s' if count != 1 else ''}. Generate New Version to create an independent chain for each strand.")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_hair_build_version(Operator):
    bl_idname = "character_designer.hair_build_version"
    bl_label = "Generate New Version"
    bl_description = "Build all captured strands with both Mirror sides and one chain per central strand; preserve previous versions"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _source(context) is not None

    def execute(self, context):
        try:
            settings = _settings(context)
            source = _source(context)
            settings.source = source
            # The source may be hidden while a previous result is in Pose Mode.
            obj, plans = _groups().build_plans(context, source=source)
            result = _variants().build_variant(context, obj, plans, bone_count=settings.bone_count)
            settings.active_variant = result["collection"].name
        except (ValueError, RuntimeError) as exc:
            _report(self, context, str(exc), error=True)
            return {"CANCELLED"}
        _report(self, context, f'Created {len(result["chains"])} chains in {result["collection"].name}.')
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_hair_show_source(Operator):
    bl_idname = "character_designer.hair_show_source"
    bl_label = "Edit Source"
    bl_description = "Return to the original hair mesh and hide generated versions"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            _variants().show_source(context, _source(context))
        except (ValueError, RuntimeError) as exc:
            _report(self, context, str(exc), error=True)
            return {"CANCELLED"}
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_hair_show_version(Operator):
    bl_idname = "character_designer.hair_show_version"
    bl_label = "Show Version"
    bl_description = "Show the chosen result and select its controls"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            collection = bpy.data.collections.get(_settings(context).active_variant)
            _variants().show_variant(context, collection)
        except (ValueError, RuntimeError) as exc:
            _report(self, context, str(exc), error=True)
            return {"CANCELLED"}
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_hair_clear_groups(Operator):
    bl_idname = "character_designer.hair_clear_groups"
    bl_label = "Recapture Strands"
    bl_description = "Clear the saved strand capture; keep existing guides and generated versions"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            source = _source(context)
            _variants().show_source(context, source)
            _groups().clear_groups(source)
            bpy.ops.mesh.select_all(action="DESELECT")
        except (ValueError, RuntimeError) as exc:
            _report(self, context, str(exc), error=True)
            return {"CANCELLED"}
        _report(self, context, "Choose the new source strands, then Select Hair Strands to capture them.")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_generate_hair_bones(Operator):
    bl_idname = "character_designer.generate_hair_bones"
    bl_label = "Generate Hair Bones"
    bl_description = (
        "Create and bind a connected bone chain for each selected hair strand, "
        "then select the controls in Pose Mode"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _mesh_edit(context) and _settings(context) is not None

    def execute(self, context):
        try:
            obj, plans = selected_strands(context)
            result = build_hair_bones(
                context, obj, plans, bone_count=_settings(context).bone_count,
            )
        except (HairTopologyError, HairBonesRigError, RuntimeError) as exc:
            _report(self, context, str(exc), error=True)
            return {"CANCELLED"}
        count = len(result["chains"])
        action = "Created" if result["created"] else "Selected"
        _report(self, context, f"{action} {count} hair chain{'s' if count != 1 else ''}. Rotate the selected bones in Pose Mode.")
        return {"FINISHED"}


class CHARACTERDESIGNER_PT_hair_bones(Panel):
    bl_label = "Hair Bones"
    bl_idname = "CHARACTERDESIGNER_PT_hair_bones"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = SIDEBAR_CATEGORY

    @classmethod
    def poll(cls, context):
        return active_ui_page(context) == UI_PAGE_HAIR

    def draw(self, context):
        layout = self.layout
        settings = _settings(context)
        if settings is None:
            return
        source = _source(context)
        if source:
            layout.label(text=f"Source: {source.name}", icon="OUTLINER_OB_MESH")
        layout.label(text="One independent chain per strand.")
        layout.operator("character_designer.select_hair_strands", icon="RESTRICT_SELECT_OFF")
        try:
            strands = _groups().captured_strand_count(source) if source else 0
        except (ValueError, RuntimeError) as exc:
            layout.label(text=str(exc), icon="ERROR")
            strands = 0
        if strands:
            if any(mod.type == "MIRROR" for mod in source.modifiers):
                layout.label(text=f"{strands} captured strands")
                layout.label(text="Mirror: both sides + center", icon="MOD_MIRROR")
            else:
                layout.label(text=f"{strands} strands / {strands} chains")
            layout.prop(settings, "bone_count")
            layout.operator("character_designer.hair_build_version", icon="BONE_DATA")
        if source and _variants().variants_for(source):
            layout.prop(settings, "active_variant")
            row = layout.row(align=True)
            row.operator("character_designer.hair_show_version", text="Show Version")
            row.operator("character_designer.hair_show_source", text="Edit Source")
            active = context.active_object
            if active and active.get(_variants().SOURCE_KEY) is source:
                collection = next((item for item in active.users_collection
                                   if item.get(_variants().VERSION_KEY) == 1), None)
                mesh = collection.get(_variants().MESH_KEY) if collection else None
                try:
                    record = _variants().rig._read_records(mesh) if mesh else None
                except ValueError:
                    record = None
                if record:
                    layout.label(text=f'{len(record["chains"])} generated chains')
                    if record.get("mirrors") and record.get("mirror_layout") != "BEFORE_ARMATURE_X":
                        layout.label(text="Old version: half-side controls", icon="INFO")
                        layout.label(text="Generate a new version to update.")
        elif source and context.active_object != source:
            layout.operator("character_designer.hair_show_source", text="Edit Source", icon="EDITMODE_HLT")
        if source is not None and _groups().GROUPS_KEY in source:
            layout.operator("character_designer.hair_clear_groups", text="Recapture Strands", icon="FILE_REFRESH")
        if _source_edit(context):
            layout.label(text="Select a tip to limit the search.", icon="INFO")
            layout.label(text="Deselect all to find visible strands.")
        elif context.mode == "POSE":
            layout.label(text="Rotate hair bones in Pose Mode.", icon="INFO")
            layout.label(text="Mesh Edit Mode to add more strands.")
        else:
            layout.label(text="Select hair in Mesh Edit Mode.", icon="INFO")


HAIR_BONES_CLASSES = (
    CharacterDesignerHairBonesState,
    CHARACTERDESIGNER_OT_select_hair_strands,
    CHARACTERDESIGNER_OT_generate_hair_bones,
    CHARACTERDESIGNER_OT_hair_build_version,
    CHARACTERDESIGNER_OT_hair_show_source,
    CHARACTERDESIGNER_OT_hair_show_version,
    CHARACTERDESIGNER_OT_hair_clear_groups,
    CHARACTERDESIGNER_PT_hair_bones,
)
