"""Session export queue for explicitly assigned Unity animation FBXs."""

from dataclasses import dataclass
import json
from pathlib import Path
import tempfile

import bpy
from bpy.props import CollectionProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, PropertyGroup

from . import animation_stable_fbx as stable
from .animation_worklist_queue import QueueItem, SerialQueue, SYNC


class CharacterDesignerAnimationExportRoute(PropertyGroup):
    motion_key: StringProperty()
    rig: PointerProperty(type=bpy.types.Object)
    action: PointerProperty(type=bpy.types.Action)
    slot: IntProperty()
    filepath: StringProperty(subtype='FILE_PATH')
    guid: StringProperty()

    @classmethod
    def register(cls):
        bpy.types.Scene.character_designer_animation_export_routes = CollectionProperty(type=cls)

    @classmethod
    def unregister(cls):
        del bpy.types.Scene.character_designer_animation_export_routes


@dataclass(frozen=True)
class Motion:
    scene: object
    rig: object
    action: object
    slot: int
    name: str
    motion_key: str = ''
    record: object = None

    @property
    def key(self):
        if self.motion_key:
            return f'{self.scene.session_uid}:{self.motion_key}'
        return f'{self.rig.session_uid}:{self.action.session_uid}:{self.slot}'


@dataclass
class Entry:
    motion: Motion
    error: str = ''


_queues = {}
_feedback = {}
_batch = None


def running():
    return _batch is not None


def _entries(scene):
    return _queues.get(scene.session_uid, {})


def _managed(scene, row, rig, action, slot, record):
    settings = scene.character_designer_animation_worklist
    if getattr(row, 'composition_json', '') or getattr(row, 'application_role', ''):
        raise ValueError('Use the linked Composition export for this motion.')
    item_key = getattr(row, 'work_item_id', '') or row.clip_key
    key = json.dumps([settings.workspace_identity or settings.workspace_path, item_key], ensure_ascii=False)
    return Motion(scene, rig, action, slot, row.name, key, record)


def _selected_motion(context):
    from . import animation, animation_export, animation_neutral_motion, animation_playback_range
    from . import animation_worklist_edit_scene as edit_scene
    from .animation_worklist_ui import _selected

    home, row = edit_scene.selected_motion(context)
    if home is not None:
        if row is None and context.scene == home:
            active = animation_playback_range.active_record(home)
            if active is not None and active.clip_key == animation_neutral_motion.ROW.clip_key:
                row = animation_neutral_motion.ROW
        if row is None:
            raise ValueError('Select a motion in the Animation Library.')
        record = edit_scene.mapping_record(home, row)
        if record and record.state == 'READY' and record.controller_action:
            return _managed(home, row, record.target, record.controller_action, record.controller_slot, record)
        if context.scene != home and getattr(row, 'custom_action', None) is not None:
            return _managed(context.scene, row, row.rig, row.custom_action, row.custom_slot, row)
        raise ValueError('Open or prepare this motion in the Animation Library first.')
    settings = context.scene.character_designer_animation_worklist
    if settings.workspace_path:
        row = _selected(settings)
        if row is None or row.side != 'CUSTOM':
            raise ValueError('Select an editable motion in the Animation Library.')
        return _managed(context.scene, row, row.rig, row.custom_action, row.custom_slot, row)
    rig = animation._target(context)
    ad = rig.animation_data if rig is not None else None
    if ad is None or ad.action is None:
        raise ValueError('Select an Action in the Animation Library.')
    return Motion(context.scene, rig, ad.action, animation_export._slot(rig, ad.action), ad.action.name)


def _validate_motion(motion):
    from . import animation_composition, animation_composition_local, animation_controller_edit
    from . import animation_pose_test, animation_preview_session, body_original_mode, unity_animation

    rig, action = motion.rig, motion.action
    if (rig is None or action is None or rig.library or action.library or action.override_library
            or action.asset_data or rig.mode == 'EDIT' or motion.scene.objects.get(rig.name) != rig
            or not any(slot.handle == motion.slot and slot.target_id_type == 'OBJECT' for slot in action.slots)):
        raise ValueError('The queued character, editable Action, or Object slot is unavailable.')
    record = motion.record
    if record is not None:
        if hasattr(record, 'controller_action'):
            if record.state != 'READY':
                raise ValueError('The queued controller motion is no longer ready.')
            current = (record.target, record.controller_action, record.controller_slot)
        else:
            current = (record.rig, record.custom_action, record.custom_slot)
        if current != (rig, action, motion.slot):
            raise ValueError('The working Action changed. Add its current version to the queue.')
    if animation_controller_edit.pending(motion.scene):
        raise ValueError('Finish preparing the character motion before exporting.')
    if (animation_preview_session.SESSION in rig or unity_animation.active_preview(rig)
            or animation_pose_test.active(rig) or body_original_mode.active(rig)
            or rig.data.pose_position == 'REST'
            or animation_composition.active(rig) or animation_composition_local.session(rig)
            or 'character_designer_rigging_session_v1' in rig):
        raise ValueError('Finish the open preview, Rigging edit, or Composition before exporting this motion.')


def _route(motion):
    for route in motion.scene.character_designer_animation_export_routes:
        if route.rig != motion.rig or route.motion_key != motion.motion_key:
            continue
        if motion.motion_key or (route.action == motion.action and route.slot == motion.slot):
            return route
    return None


def add(context):
    motion = _selected_motion(context)
    _validate_motion(motion)
    entries = _queues.setdefault(context.scene.session_uid, {})
    entry = entries.get(motion.key)
    if entry is None or (entry.motion.action, entry.motion.rig, entry.motion.slot) != (
            motion.action, motion.rig, motion.slot):
        entries[motion.key] = Entry(motion)
    _feedback.pop(context.scene.session_uid, None)


def _assign_destination(motion, filepath):
    _validate_motion(motion)
    path, guid, _ = stable.asset(bpy.path.abspath(filepath))
    settings = motion.scene.character_designer_animation_worklist
    if settings.model_file and Path(bpy.path.abspath(settings.model_file)).resolve() == path:
        raise ValueError('Choose the animation FBX. This is the workspace character model.')
    route = _route(motion)
    if any(other != route and other.filepath and Path(other.filepath).resolve() == path
           for scene in bpy.data.scenes for other in scene.character_designer_animation_export_routes):
        raise ValueError('This Unity FBX is already assigned to another motion.')
    if route is None:
        route = motion.scene.character_designer_animation_export_routes.add()
        route.motion_key, route.rig = motion.motion_key, motion.rig
        if not motion.motion_key:
            route.action, route.slot = motion.action, motion.slot
    route.filepath, route.guid = str(path), guid


@dataclass
class Batch:
    queue: SerialQueue
    scene: object
    window: object
    entries: dict
    job: object = None
    temporary: object = None
    destination: object = None
    reported_failures: int = 0


def _redraw():
    from .animation import _redraw as redraw
    redraw()


def begin(context):
    global _batch
    from .animation import _link_idle
    from .animation_original_inputs_ui import original_inputs_live

    entries = _entries(context.scene)
    if not entries:
        raise ValueError('Add at least one animation to the Export Queue.')
    if context.window is None or not _link_idle() or original_inputs_live(context):
        raise ValueError('Finish the current animation operation before exporting.')
    queue = SerialQueue(SYNC, (QueueItem(key) for key in entries), continue_on_failure=True)
    _batch = Batch(queue, context.scene, context.window, entries)
    registered = bpy.app.timers.is_registered(_poll)
    try:
        bpy.app.timers.register(_poll, first_interval=.05)
    except Exception:
        _batch = None
        if not registered and bpy.app.timers.is_registered(_poll):
            bpy.app.timers.unregister(_poll)
        raise
    for entry in entries.values():
        entry.error = ''
    _feedback.pop(context.scene.session_uid, None)


def _export_range(motion):
    from .animation_export_inputs import _curves

    if motion.action.use_frame_range or len(motion.action.slots) == 1:
        return tuple(motion.action.frame_range)
    ranges = [curve.range() for curve in _curves(motion.action, motion.slot)
              if not curve.mute and (curve.keyframe_points or curve.sampled_points)]
    if not ranges:
        raise ValueError('The queued Object slot has no keyed frame range.')
    return min(start for start, _ in ranges), max(end for _, end in ranges)


def _start(batch, attempt):
    from . import animation_export, animation_playback_range
    from .animation_loop_timing import is_loop

    motion = batch.entries[attempt.key].motion
    _validate_motion(motion)
    route = _route(motion)
    if route is None:
        raise ValueError('Assign an existing Unity FBX for this motion.')
    destination = stable.pin(route.filepath, route.guid)
    if any(other != route and other.filepath and Path(other.filepath).resolve() == destination.path
           for scene in bpy.data.scenes for other in scene.character_designer_animation_export_routes):
        raise ValueError('This Unity FBX is assigned to more than one motion.')
    if not batch.queue.record_fingerprint(attempt.token, destination):
        raise RuntimeError('The export queue lost its active item.')
    temporary = tempfile.TemporaryDirectory(prefix='cdesigner-unity-queue-')
    try:
        start, end = _export_range(motion)
        loop = (animation_playback_range.record_loop(motion.record)
                if motion.record is not None and hasattr(motion.record, 'controller_action')
                else is_loop(motion.action))
        layer = next((layer for layer in motion.scene.view_layers if layer.objects.get(motion.rig.name) == motion.rig), None)
        if layer is None:
            raise ValueError('The queued character is outside the available view layers.')
        with bpy.context.temp_override(window=batch.window, scene=motion.scene, view_layer=layer):
            job = animation_export.begin_export(bpy.context, motion.rig, motion.action,
                Path(temporary.name) / 'animation.fbx', frame_start=start, frame_end=end,
                loop=bool(motion.action.use_cyclic or loop), action_slot=motion.slot)
    except Exception:
        temporary.cleanup()
        raise
    batch.job, batch.temporary, batch.destination = job, temporary, destination


def _dispose(batch):
    from . import animation_export
    try:
        if batch.job is not None and animation_export.active_job() is batch.job:
            animation_export.cancel_export(batch.job)
    finally:
        if batch.temporary is not None:
            batch.temporary.cleanup()
        batch.job = batch.temporary = batch.destination = None


def _complete(batch):
    from . import animation_export

    attempt = batch.queue.running
    try:
        result = animation_export.poll_export(batch.job)
        if result is None:
            return
        stable.publish(batch.destination, result['filepath'], result['fbx_sha256'])
    except Exception as error:
        batch.queue.complete(attempt.token, success=False, message=str(error) or type(error).__name__)
    else:
        batch.queue.complete(attempt.token, success=True, result=str(batch.destination.path), published=True)
        batch.entries.pop(attempt.key, None)
    _dispose(batch)


def _poll():
    from .animation import _link_idle

    batch = _batch
    if batch is None:
        return None
    try:
        if batch.window not in tuple(bpy.context.window_manager.windows) or batch.window.scene != batch.scene:
            cancel()
        elif batch.job is not None:
            _complete(batch)
        elif _link_idle(include_collection=False):
            batch.queue.tick(lambda attempt: _start(batch, attempt))
        failures = batch.queue.failures
        for failure in failures[batch.reported_failures:]:
            batch.entries[failure.key].error = failure.message
        batch.reported_failures = len(failures)
    except (ReferenceError, ValueError, RuntimeError, OSError):
        cancel()
    if _batch is batch and not batch.queue.busy:
        _finish(batch)
    _redraw()
    return .25 if _batch is batch else None


def _finish(batch):
    global _batch
    queue = batch.queue
    try:
        message = f'Exported {len(queue.succeeded_keys)} / {queue.total} to Unity.'
        if queue.failures:
            message += f' {len(queue.failures)} failed.'
        if queue.cancel_message:
            message += ' ' + queue.cancel_message
        _feedback[batch.scene.session_uid] = message
    except ReferenceError:
        pass
    _batch = None


def cancel():
    batch = _batch
    if batch is None:
        return

    def stop_worker(attempt):
        try:
            _dispose(batch)
        except (RuntimeError, OSError) as error:
            message = 'Export stopped. ' + str(error)
        else:
            message = 'Export cancelled.'
        batch.queue.acknowledge_cancel(attempt.token, message=message)

    batch.queue.cancel(stop_worker)
    if not batch.queue.busy and not batch.queue.cancel_message:
        batch.queue.cancel_message = 'Export cancelled.'
    if not batch.queue.busy:
        _finish(batch)
        if bpy.app.timers.is_registered(_poll):
            bpy.app.timers.unregister(_poll)


def stop():
    global _batch
    if _batch is not None:
        _dispose(_batch)
        _batch = None
    if bpy.app.timers.is_registered(_poll):
        bpy.app.timers.unregister(_poll)
    _queues.clear()
    _feedback.clear()


class CHARACTERDESIGNER_OT_edit_animation_export_queue(Operator):
    bl_idname = 'character_designer.edit_animation_export_queue'
    bl_label = 'Edit Animation Export Queue'
    bl_options = {'INTERNAL'}

    operation: EnumProperty(items=(
        ('ADD', 'Add Selected', 'Queue the selected working animation'),
        ('REMOVE', 'Remove', 'Remove this motion from the queue'),
        ('CLEAR', 'Clear Queue', 'Clear the temporary queue'),
        ('EXPORT', 'Export Queue to Unity', 'Update the assigned Unity animation FBXs'),
        ('CANCEL', 'Cancel', 'Cancel the batch and keep unpublished items'),
    ), options={'HIDDEN'})
    key: StringProperty(options={'HIDDEN'})

    @classmethod
    def description(cls, _context, properties):
        return cls.bl_rna.properties['operation'].enum_items[properties.operation].description

    def execute(self, context):
        try:
            if self.operation == 'CANCEL':
                cancel()
            elif running():
                raise ValueError('Wait for the Export Queue to finish or cancel it.')
            elif self.operation == 'ADD':
                add(context)
            elif self.operation == 'REMOVE':
                _entries(context.scene).pop(self.key, None)
            elif self.operation == 'CLEAR':
                _queues.pop(context.scene.session_uid, None)
                _feedback.pop(context.scene.session_uid, None)
            elif self.operation == 'EXPORT':
                begin(context)
        except (ValueError, OSError, RuntimeError, ReferenceError) as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        _redraw()
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_set_animation_export_destination(Operator):
    bl_idname = 'character_designer.set_animation_export_destination'
    bl_label = 'Set Unity Animation FBX'
    bl_description = 'Choose the existing animation FBX to update when exporting this motion'
    bl_options = {'INTERNAL', 'UNDO'}

    key: StringProperty(options={'HIDDEN'})
    scene_uid: StringProperty(options={'HIDDEN'})
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default='*.fbx', options={'HIDDEN'})

    def invoke(self, context, _event):
        entry = _entries(context.scene).get(self.key)
        if entry is None or running():
            return {'CANCELLED'}
        self.scene_uid = str(context.scene.session_uid)
        route = _route(entry.motion)
        self.filepath = route.filepath if route is not None else ''
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        entry = _entries(context.scene).get(self.key)
        if str(context.scene.session_uid) != self.scene_uid or entry is None or running():
            return {'CANCELLED'}
        try:
            _assign_destination(entry.motion, self.filepath)
        except (ValueError, OSError, RuntimeError, ReferenceError) as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        entry.error = ''
        _redraw()
        return {'FINISHED'}


def _button(layout, operation, title, icon, *, key=''):
    operator = layout.operator(CHARACTERDESIGNER_OT_edit_animation_export_queue.bl_idname, text=title, icon=icon)
    operator.operation, operator.key = operation, key


def draw(layout, context, *, enabled=True):
    from .animation import _link_idle
    from .animation_physics_ui import wrapped_label

    entries = _entries(context.scene)
    box = layout.box()
    title = box.row(align=True)
    title.label(text='Export Queue', icon='EXPORT')
    if entries and not running():
        _button(title, 'CLEAR', 'Clear', 'TRASH')
    if _batch is not None and _batch.scene == context.scene:
        queue = _batch.queue
        progress = box.row(align=True)
        done = len(queue.succeeded_keys) + len(queue.failures)
        progress.label(text=f'Exporting {min(done + 1, queue.total)} / {queue.total}')
        _button(progress, 'CANCEL', '', 'X')
    for key, entry in entries.items():
        row = box.row(align=True)
        row.enabled = enabled and not running()
        row.operator_context = 'INVOKE_DEFAULT'
        row.label(text=entry.motion.name, icon='ACTION')
        try:
            route = _route(entry.motion)
        except ReferenceError:
            route = None
        destination = row.operator(CHARACTERDESIGNER_OT_set_animation_export_destination.bl_idname,
                                   text='Set FBX…' if route is None else '', icon='FILEBROWSER')
        destination.key = key
        _button(row, 'REMOVE', '', 'X', key=key)
        if entry.error:
            wrapped_label(box, context, entry.error, icon='ERROR')
            if 'capture export base pose' in entry.error.casefold():
                rig, action = entry.motion.rig, entry.motion.action
                ad = rig.animation_data if rig is not None else None
                if (action is not None and ad is not None and ad.action == action
                        and ad.action_slot_handle == entry.motion.slot):
                    capture = box.row()
                    capture.enabled = enabled and _link_idle()
                    operator = capture.operator('character_designer.animation_export_base_pose', icon='POSE_HLT')
                    operator.rig_name, operator.action_name = rig.name, action.name
    feedback = _feedback.get(context.scene.session_uid)
    if feedback:
        box.label(text=feedback)
    elif not entries:
        box.label(text='Add motions from the Animation Library.')
    export = box.row()
    export.enabled = enabled and bool(entries) and _link_idle()
    export.scale_y = 1.3
    _button(export, 'EXPORT', 'Export Queue to Unity', 'EXPORT')


def draw_add(layout):
    row = layout.row()
    row.enabled = not running()
    _button(row, 'ADD', 'Add Selected to Queue', 'ADD')


CLASSES = (
    CharacterDesignerAnimationExportRoute,
    CHARACTERDESIGNER_OT_edit_animation_export_queue,
    CHARACTERDESIGNER_OT_set_animation_export_destination,
)
