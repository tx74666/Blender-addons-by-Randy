"""Setup is deliberately separate from animation Controls."""
import bpy
import textwrap
import math
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, PointerProperty, IntProperty, StringProperty
from bpy.types import PropertyGroup, Operator
from . import body_calibration as service

def _redraw(_self, context):
    if context and context.window_manager:
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D': area.tag_redraw()

_AXES = [('X','+X Right',''),('NX','-X Left',''),('Y','+Y Back',''),('NY','-Y Forward',''),
         ('Z','+Z Up',''),('NZ','-Z Down',''),('VECTOR','Custom vector','Armature-local XYZ')]


class CharacterDesignerBodyCalibration(PropertyGroup):
    tab: EnumProperty(items=[('SETUP', 'Setup', ''), ('CONTROLS', 'Controls', '')])
    part: EnumProperty(items=[(p, p.title(), '') for p in service.PARTS],update=_redraw)
    preset: EnumProperty(items=[('DEFAULT', 'Default', 'Character local: elbows back, knees forward, palms down'),
                               ('CUSTOM', 'Custom', 'Candidate settings only; use Apply to change Rest')],update=_redraw)
    show_directions: BoolProperty(name='Show Directions', default=False, update=_redraw)
    show_details: BoolProperty(name='Details', default=False, update=_redraw)
    last_error: StringProperty(options={'HIDDEN','SKIP_SAVE'})
    last_error_signature: StringProperty(options={'HIDDEN','SKIP_SAVE'})
    arm_axis: EnumProperty(name='Elbow direction',items=_AXES,default='Y',update=_redraw)
    leg_axis: EnumProperty(name='Knee direction',items=_AXES,default='NY',update=_redraw)
    arm_direction: FloatVectorProperty(name='Elbow target (local)', default=(0, 1, 0), size=3)
    leg_direction: FloatVectorProperty(name='Knee target (local)', default=(0, -1, 0), size=3)
    allow_bend: BoolProperty(name='Allow small bone length change', default=False)
    minimum_bend: FloatProperty(name='Minimum bend (degrees)', default=5, min=1, max=15)
    max_shift: FloatProperty(name='Max joint shift / chain length', default=.1, min=0, max=.5)
    max_length: FloatProperty(name='Max length change / bone length', default=.005, min=0, max=.05)
    pole_distance: FloatProperty(name='Pole distance / chain length', default=.75, min=.25, max=3)
    include_arms: BoolProperty(name='Arms', default=True)
    include_legs: BoolProperty(name='Legs', default=True)
    include_fingers: BoolProperty(name='Validate existing fingers', default=True)
    palm_side: EnumProperty(items=[('L','Left',''),('R','Right','')],options={'HIDDEN'})
    palm_reference: EnumProperty(items=[('AUTO','Saved / A-pose','Keep existing references, otherwise use the A-pose plane'),
        ('PLANE','A-pose plane','A linked plane following each hand long axis'),('MESH','Mesh reference','One chosen palm drives both hands')],default='AUTO',update=_redraw)
    palm_tilt: FloatProperty(name='Palm tilt',subtype='ANGLE',default=0,min=-math.pi,max=math.pi,update=_redraw)
    palm_plane_flip: BoolProperty(name='Reverse palm side',default=False,update=_redraw)
    palm_object: PointerProperty(name='Palm mesh', type=bpy.types.Object, poll=lambda self,obj: obj.type == 'MESH')
    palm_face: IntProperty(name='Face index', default=0, min=0)
    palm_flip: BoolProperty(name='Reverse palm arrow')
    palm_acknowledged: BoolProperty(name='I checked the palm side', default=False)


class CHARACTERDESIGNER_OT_body_calibration(Operator):
    bl_idname = 'character_designer.body_calibration'
    bl_label = 'Body Calibration'
    bl_options = {'REGISTER','UNDO'}
    action: EnumProperty(items=[(p,p.title(),'') for p in ('PREVIEW','APPLY','CONFIRM','PALM','LOCATE','PLANE_REF','MESH_REF')])
    acknowledge: BoolProperty(name='I reviewed the displacement and bone length changes', default=False)
    signature: StringProperty(options={'HIDDEN','SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return bool(context.object and context.object.type == 'ARMATURE' and context.mode in {'OBJECT','POSE','EDIT_ARMATURE'})

    @classmethod
    def description(cls, context, properties):
        return {'PREVIEW':'Show the current bones and the dashed calibration candidate. Does not change Rest.',
                'APPLY':'Apply the reviewed candidate to Rest. Undo with Ctrl Z; current pose is never cleared.',
                'CONFIRM':'Confirm this applied calibration for Generate.',
                'LOCATE':'Select bones with local pose offsets in Pose Mode. Does not clear pose, animation or Rest.',
                'PALM':'Use the explicitly confirmed palm side.'}.get(properties.action,'Body Calibration')

    def invoke(self, context, event):
        try:
            rig = context.object
            p = service.plan(context,rig,service.settings(rig).part)
            if self.action == 'APPLY' and p['needs_acknowledgment']:
                self.signature = p['signature']
                self.acknowledge = False
                return context.window_manager.invoke_props_dialog(self, width=470)
        except (ValueError,RuntimeError,KeyError,TypeError) as exc:
            self.report({'WARNING'},str(exc))
            return {'CANCELLED'}
        return self.execute(context)

    def draw(self, context):
        s = service.settings(context.object)
        p = service.plan(context,context.object,s.part)
        self.layout.label(text='The candidate exceeds the suggested micro-adjustment range.')
        _metrics(self.layout,p)
        self.layout.prop(self,'acknowledge')

    def execute(self, context):
        rig = context.object
        s = service.settings(rig)
        try:
            if self.action == 'PREVIEW':
                s.show_directions = True
                service.preview(context,rig,s.part)
            elif self.action == 'LOCATE': service.select_pose_blockers(context,rig,s.part)
            elif self.action == 'PALM':
                from . import body_calibration_hands
                body_calibration_hands.capture_pair(context,rig,s.palm_object,s.palm_face,s.palm_flip,s.palm_acknowledged)
                s.palm_acknowledged = False
            elif self.action in {'PLANE_REF','MESH_REF'}:
                s.palm_reference='PLANE' if self.action=='PLANE_REF' else 'MESH'
                s.show_directions=True
            elif self.action == 'CONFIRM': service.confirm(context,rig,s.part)
            else:
                if self.signature and self.signature != service.plan(context,rig,s.part)['signature']:
                    raise ValueError('Candidate changed while confirmation was open; preview again.')
                service.apply(context,rig,s.part,acknowledge=self.acknowledge)
            for window in context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D': area.tag_redraw()
            s.last_error = ''
            s.last_error_signature = ''
            return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError,IndexError) as exc:
            s.last_error = str(exc)
            s.last_error_signature = service.status(context,rig,s.part).get('plan',{}).get('signature','')
            s.show_details = True
            self.report({'WARNING'},str(exc))
            return {'CANCELLED'}


def _metrics(layout, plan):
    for item in plan['limbs']:
        if 'shift' not in item: continue
        angle = item['direction_error_degrees']
        layout.label(text=f"{item['side']}: bend {item.get('bend_degrees',0):.2f} deg; move {item['shift']:.3g}")
        layout.label(text=f"Bend-plane direction error: {'unstable' if angle is None else f'{angle:.2f} deg'}")
        a,b = item['length_changes']
        if max(abs(a),abs(b)) > 1e-6:
            layout.label(text=f'Length change: {a:+.2%} / {b:+.2%}')


def draw(layout, context):
    rig = context.object
    if rig is None or rig.type != 'ARMATURE':
        layout.label(text='Select the character armature.', icon='INFO')
        return True
    s = service.settings(rig)
    layout.prop(s, 'tab', expand=True)
    if s.tab == 'CONTROLS':
        return False
    layout.prop(s, 'preset', expand=True)
    layout.prop(s, 'show_directions', icon='HIDE_OFF' if s.show_directions else 'HIDE_ON')
    items = {part:service.status(context,rig,part) for part in service.PARTS}
    item = items[s.part]
    p = item.get('plan')
    issue = service.apply_readiness(context,rig,p['changes']) if p and not p['errors'] and not p['skipped'] else None
    names = {'UNSET':'Setup','READY':'Ready','CONFIRMED':'Confirmed','REVIEW':'Review','ERROR':'Check','SKIPPED':'Skipped'}
    for part in service.PARTS:
        row = layout.row(align=True)
        row.prop_enum(s, 'part', part)
        state = items[part]['state']
        row.label(text='Pose' if part==s.part and issue and issue['code']=='POSE' else names[state],
                  icon='CHECKBOX_HLT' if state=='CONFIRMED' else 'CHECKBOX_DEHLT')
    box = layout.box()
    if s.part in {'ARMS', 'LEGS'}:
        box.prop(s, 'include_' + s.part.lower())
        if s.preset == 'CUSTOM':
            axis = 'arm_axis' if s.part == 'ARMS' else 'leg_axis'
            box.prop(s,axis)
            if getattr(s,axis) == 'VECTOR': box.prop(s, 'arm_direction' if s.part == 'ARMS' else 'leg_direction')
            for name in ('allow_bend', 'minimum_bend', 'max_shift', 'max_length', 'pole_distance'):
                box.prop(s, name)
    if s.part == 'FINGERS':
        box.prop(s, 'include_fingers')
    if s.part == 'HANDS':
        from . import body_calibration_hands as hands
        box.label(text='Both hands linked' if hands.linked(rig) else 'Saved palm references',icon='LINKED')
        mode=hands.mode(rig)
        row=box.row(align=True)
        row.operator('character_designer.body_calibration',text='A-pose Plane',depress=mode=='PLANE').action='PLANE_REF'
        row.operator('character_designer.body_calibration',text='Mesh Reference',depress=mode=='MESH').action='MESH_REF'
        if mode=='PLANE':
            box.prop(s,'palm_tilt')
            box.prop(s,'palm_plane_flip')
        elif s.palm_reference=='AUTO':
            box.label(text='Choose Mesh Reference to replace.')
        else:
            box.prop(s,'palm_object')
            box.prop(s,'palm_face')
            box.prop(s,'palm_flip')
            box.prop(s,'palm_acknowledged')
            box.operator('character_designer.body_calibration',text='Use for Both Hands').action='PALM'
    if issue:
        warning = box.column(align=True)
        warning.label(text=issue['message'],icon='ERROR')
        if issue['bones']:
            warning.label(text=issue['bones'][0] + (f" (+{len(issue['bones'])-1})" if len(issue['bones'])>1 else ''))
        if issue['code']=='POSE':
            warning.operator('character_designer.body_calibration',text='Select Posed Bones',icon='RESTRICT_SELECT_OFF').action='LOCATE'
    elif item['state']=='ERROR':
        message = 'Choose a palm reference' if 'palm:' in item['message'] and 'undefined' in item['message'] else s.part.title()+' needs review'
        if 'reference is pending' in item['message']:message='Use for Both Hands to accept this reference'
        box.label(text=message,icon='ERROR')
    elif s.last_error and s.last_error_signature == (p or {}).get('signature',''):
        box.label(text='Apply needs attention; see Details',icon='ERROR')
    row = box.row(align=True)
    row.operator('character_designer.body_calibration',text='Preview',icon='HIDE_OFF').action='PREVIEW'
    apply_row = row.row(align=True)
    apply_row.enabled = bool(p and not p['errors'] and not issue and not p['skipped'] and
                             service.record(rig).get('previews',{}).get(s.part)==p['signature'])
    apply_row.operator('character_designer.body_calibration',text='Apply Calibration').action='APPLY'
    row = box.row()
    row.enabled = item['state'] in {'READY','CONFIRMED'}
    row.operator('character_designer.body_calibration',text='Confirm',icon='CHECKMARK').action='CONFIRM'
    if s.part=='HANDS':
        row=box.row()
        row.enabled=item['state'] in {'READY','CONFIRMED'} and context.mode in {'OBJECT','POSE'}
        row.operator('character_designer.forearm_twist_start',text='Forearm Twist Setup',icon='DRIVER_ROTATIONAL_DIFFERENCE')
    box.prop(s,'show_details',text='Details',icon='TRIA_DOWN' if s.show_details else 'TRIA_RIGHT',emboss=False)
    if s.show_details:
        details = box.column(align=True)
        details.label(text='Solid: current · Dashed: candidate')
        details.label(text='Axes and distances: armature local')
        if p: _metrics(details,p)
        if s.part=='HANDS':
            details.label(text='X: up/down · Y: twist · Z: sideways')
            details.label(text='Forearm Twist uses the forearm axis.')
            for frame in (p or {}).get('limbs',[]):
                details.label(text=f"{frame['side']}: hand / forearm {frame['axis_difference_degrees']:.2f} deg")
        message = issue['detail'] if issue else s.last_error if s.last_error_signature==(p or {}).get('signature','') and s.last_error else item['message']
        for line in textwrap.wrap(message,34): details.label(text=line)
        if s.last_error and s.last_error != message and s.last_error_signature==(p or {}).get('signature',''):
            for line in textwrap.wrap(s.last_error,34): details.label(text=line)
        details.label(text='Undo Apply: Ctrl Z')
        if rig.mode=='EDIT': details.label(text='Pose is rechecked when Apply runs.')
    return True


def register():
    if not hasattr(bpy.types.Object, 'character_designer_body_calibration'):
        bpy.utils.register_class(CharacterDesignerBodyCalibration)
        bpy.utils.register_class(CHARACTERDESIGNER_OT_body_calibration)
        bpy.types.Object.character_designer_body_calibration = PointerProperty(type=CharacterDesignerBodyCalibration)
    from . import body_calibration_overlay
    body_calibration_overlay.register()


def unregister():
    from . import body_calibration_overlay
    body_calibration_overlay.unregister()
    if hasattr(bpy.types.Object, 'character_designer_body_calibration'):
        del bpy.types.Object.character_designer_body_calibration
        bpy.utils.unregister_class(CHARACTERDESIGNER_OT_body_calibration)
        bpy.utils.unregister_class(CharacterDesignerBodyCalibration)
