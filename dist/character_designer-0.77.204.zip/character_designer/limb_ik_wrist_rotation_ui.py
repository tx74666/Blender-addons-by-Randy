"""Explicit IK and pose reset commands. Blender owns the Pose Mode transform shortcuts."""

import bpy
from bpy.props import EnumProperty
from bpy.types import Operator


def _limb():
    from . import limb_ik
    return limb_ik


def _backend():
    from . import limb_ik_wrist_rotation
    return limb_ik_wrist_rotation


def _owned_wrist(pose_bone):
    """Cheap tags only; the service authenticates the complete live graph."""
    try:
        armature = pose_bone.id_data
        if armature.type != 'ARMATURE':
            return False
        limb = _limb()
        owner = armature.data.get(limb.ARMATURE_ID_KEY)
        return bool(owner and limb._owned(pose_bone.bone, owner, role='HAND_IK'))
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


class CHARACTERDESIGNER_OT_limb_ik_clear_wrist_rotation(Operator):
    bl_idname = 'character_designer.limb_ik_clear_wrist_rotation'
    bl_label = 'Reset IK Wrist Rotation'
    bl_description = 'Match each IK wrist to its hand orientation in Edit Mode. Pose Mirror includes both hands.'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if getattr(context, 'mode', None) != 'POSE':
            return False
        try:
            selected = context.selected_pose_bones or ()
            return any(_owned_wrist(pb) for pb in selected)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            return False

    def execute(self, context):
        try:
            selected = tuple(context.selected_pose_bones or ())
            wrists = tuple(pb for pb in selected if _owned_wrist(pb))
            if (getattr(context, 'mode', None) != 'POSE'
                    or any(pb.id_data != getattr(context, 'object', None) for pb in selected)):
                self.report({'WARNING'}, 'Choose one or both generated IK wrists and controls on the same rig.')
                return {'CANCELLED'}
            if len(wrists) not in (1, 2):
                self.report({'WARNING'}, 'Choose one or both generated IK wrists.')
                return {'CANCELLED'}
            if len(selected) != len(wrists):
                companions = tuple(pb for pb in selected if pb not in wrists)
                from . import controller_transform_clear
                controller_transform_clear.reset_mixed_rotation(context, wrists, companions)
            elif len(wrists) == 1:
                _backend().reset_wrist_neutral(context, target=wrists[0])
            else:
                _backend().reset_wrist_neutral(context, targets=wrists)
        except Exception as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        self.report({'INFO'}, 'Reset selected rotations.' if len(selected) != len(wrists)
                    else 'Reset wrist rotation to neutral.')
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_reset_selected_pose_chains(Operator):
    bl_idname = 'character_designer.reset_selected_pose_chains'
    bl_label = 'Reset Selected Chains'
    bl_description = ('Return the selected native limb, spine or finger chains to their current Rest-based '
                      'neutral pose, keeping animation and unselected controller inputs')
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        try:
            rig = getattr(context, 'object', None)
            return (getattr(context, 'mode', None) == 'POSE' and rig is not None
                    and rig.type == 'ARMATURE' and bool(context.selected_pose_bones))
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            return False

    def execute(self, context):
        try:
            from . import body_pose_reset, natural_pose_clear
            if natural_pose_clear.body_selected(context):
                natural_pose_clear.clear_body(context)
                self.report({'INFO'}, 'Restored the original pose with Stable IK/FK.')
                return {'FINISHED'}
            result = body_pose_reset.reset_selected(context, context.object)
        except Exception as error:
            self.report({'WARNING'}, str(error))
            return {'CANCELLED'}
        self.report({'INFO'}, f"Reset {len(result['chains'])} selected chains; animation keys kept.")
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_clear_body_transform_channel(Operator):
    bl_idname = 'character_designer.clear_body_transform_channel'
    bl_label = 'Clear Body Control Transform'
    bl_description = 'Clear this channel on the selected body controls'
    bl_options = {'UNDO'}

    channel: EnumProperty(items=(('LOCATION', 'Location', ''), ('SCALE', 'Scale', '')))

    @classmethod
    def poll(cls, context):
        from . import natural_pose_clear
        return natural_pose_clear.body_selected(context)

    def execute(self, context):
        operator = bpy.ops.pose.loc_clear if self.channel == 'LOCATION' else bpy.ops.pose.scale_clear
        return operator('EXEC_DEFAULT', False)


CLASSES = (CHARACTERDESIGNER_OT_limb_ik_clear_wrist_rotation,
           CHARACTERDESIGNER_OT_reset_selected_pose_chains,
           CHARACTERDESIGNER_OT_clear_body_transform_channel)


def register():
    from . import natural_bind_mode
    added = []
    try:
        for cls in CLASSES:
            if not cls.is_registered:
                bpy.utils.register_class(cls)
                added.append(cls)
        natural_bind_mode.register()
    except Exception:
        for cls in reversed(added):
            bpy.utils.unregister_class(cls)
        raise


def unregister():
    from . import natural_bind_mode
    natural_bind_mode.unregister()
    for cls in reversed(CLASSES):
        if cls.is_registered:
            bpy.utils.unregister_class(cls)
