"""Clear a mixed selection of native controls and compensated IK wrists together."""

import bpy


_ROTATION_FIELDS = ('rotation_euler', 'rotation_quaternion', 'rotation_axis_angle')
# Blender's native pose.rot_clear also clears these six Bendy Bone inputs.
_BEND_FIELDS = ('bbone_rollin', 'bbone_rollout', 'bbone_curveinx', 'bbone_curveinz',
                'bbone_curveoutx', 'bbone_curveoutz')


def _native_rotation_snapshot(rig, companions):
    affected = {pb.name: pb for pb in companions}
    if rig.pose.use_mirror_x:
        for pb in companions:
            other = rig.pose.bones.get(bpy.utils.flip_name(pb.name))
            if other is not None:
                affected[other.name] = other
    from . import limb_ik as limb
    owner = rig.data.get(limb.ARMATURE_ID_KEY)
    snapshot, paths = [], set()
    for pb in affected.values():
        if (pb.bone.get(limb.OWNER_KEY) == limb.OWNER_VALUE and not limb._owned(pb.bone, owner)
                or pb.bone.get(limb.ROLE_KEY) == 'HAND_IK'):
            raise ValueError(f'{pb.name}: ambiguous or overlapping wrist ownership; no rotation was reset.')
        rotation = {field: tuple(getattr(pb, field)) for field in _ROTATION_FIELDS}
        rotation.update((field, getattr(pb, field)) for field in _BEND_FIELDS)
        paths.update(pb.path_from_id(field) for field in rotation)
        snapshot.append((pb, rotation))
    if any(curve.data_path in paths for curve in getattr(rig.animation_data, 'drivers', ())):
        raise ValueError('A driver controls a selected or mirrored rotation input; no rotation was reset.')
    return snapshot


def _restore_native_rotations(context, snapshot):
    for pb, rotation in snapshot:
        for field, saved in rotation.items():
            value = getattr(pb, field)
            if (tuple(value) if field in _ROTATION_FIELDS else value) != saved:
                setattr(pb, field, saved)
    context.view_layer.update()


def _clear_native_companions(context, rig, companions):
    # The native operator iterates actual selected pose channels in every
    # posing armature. A Python context override cannot narrow its write set.
    names = {pb.name for pb in companions}
    excluded = [pb for pb in rig.pose.bones if pb.select and pb.name not in names]
    try:
        for pb in excluded:
            pb.select = False
        if {pb.name for pb in context.selected_pose_bones or ()} != names:
            raise ValueError('The selected controls changed before clearing rotation.')
        if bpy.ops.pose.rot_clear('EXEC_DEFAULT', False) != {'FINISHED'}:
            raise ValueError('Blender could not clear the selected control rotations.')
    finally:
        for pb in excluded:
            pb.select = True
    context.view_layer.update()


def reset_mixed_rotation(context, wrists, companions):
    rig = context.object
    if any(obj != rig for obj in context.objects_in_mode):
        raise ValueError('Use Pose Mode on one armature for a mixed wrist and control reset.')
    if context.scene.tool_settings.use_keyframe_insert_auto:
        raise ValueError('Turn off Auto Key for a mixed wrist and control reset, or reset the wrists separately.')
    snapshot = _native_rotation_snapshot(rig, companions)
    from . import limb_ik_wrist_rotation as backend
    request = {'target': wrists[0]} if len(wrists) == 1 else {'targets': wrists}
    plan = backend.prepare_wrist_neutral(context, **request)
    try:
        _clear_native_companions(context, rig, companions)
        # The wrist service refreshes the native/FK reference at apply time:
        # a selected parent has now reached its own cleared rotation.
        backend.apply_wrist_neutral(context, plan)
    except Exception:
        _restore_native_rotations(context, snapshot)
        raise
