"""Hair-page workflow for independent chains on the original character mesh."""

import importlib

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup

from . import hair_bones_rig as rig
from . import hair_strand_list_ui as strand_list_ui
from .hair_bones_topology import select_strands
from .ui_constants import SIDEBAR_CATEGORY, rig_page_active


def _groups():
    return importlib.import_module(__package__ + ".hair_bones_groups")


def _variants():
    return importlib.import_module(__package__ + ".hair_bones_variants")


def _binding():
    return importlib.import_module(__package__ + ".hair_bones_binding")


def _setup():
    return importlib.import_module(__package__ + ".character_setup")


def _source(context):
    from . import hair_resegment_ui
    current = hair_resegment_ui.current_source(context)
    if current is not None:
        return current
    obj = context.active_object
    if obj:
        if obj.type == "ARMATURE":
            pose_bone = getattr(context, "active_pose_bone", None)
            bone = pose_bone.bone if pose_bone else getattr(context, "active_bone", None)
            if bone and bone.get(rig.OWNER_KEY) == rig.OWNER_VALUE:
                source = bone.get(rig.SOURCE_KEY)
                if isinstance(source, bpy.types.Object) and source.type == "MESH":
                    return _variants().source_for(source)
        source = _variants().source_for(obj)
        if source:
            return source
        try:
            source = _groups().source_from_context(context)
            if source:
                return source
        except ValueError:
            pass
    settings = _settings(context)
    source = (settings.source if settings else None) or _setup().role_source(context, "HAIR")
    if source is not None or obj is None or obj.type != "ARMATURE":
        return source
    # A reopened character can have a Body control active and no saved HAIR
    # role. Resolve only a unique visible Hair mesh owned by this rig.
    candidates = [candidate for candidate in context.view_layer.objects
                  if candidate.type == "MESH" and candidate.get(rig.RIG_KEY) == obj
                  and rig.RECORD_KEY in candidate and candidate.visible_get()]
    return candidates[0] if len(candidates) == 1 else None


def _settings(context):
    return getattr(context.window_manager, "character_designer_hair_bones", None)


def _mesh_edit(context):
    obj = context.active_object
    return obj is not None and obj.type == "MESH" and context.mode == "EDIT_MESH"


def _source_edit(context):
    return _mesh_edit(context) and _variants().source_for(context.active_object) is context.active_object


def _armature_poll(self, obj):
    return obj.type == "ARMATURE"


def _report(operator, context, message, *, error=False):
    settings = _settings(context)
    if settings:
        settings.last_message = message
    operator.report({"ERROR" if error else "INFO"}, message)


def _bind(operator, context):
    try:
        settings = _settings(context)
        source = _source(context)
        obj, plans = _groups().build_plans(context, source=source)
        result = _binding().bind_hair(context, obj, plans, bone_count=settings.bone_count,
                                      armature=_setup().preferred_rig(context))
        settings.source = obj
        _setup().remember_asset(context, obj, "HAIR")
    except (ValueError, RuntimeError) as exc:
        _report(operator, context, str(exc), error=True)
        return {"CANCELLED"}
    _report(operator, context,
            f'Bound {len(result["chains"])} independent hair chains to {result["armature"].name} / {result["parent_bone"]}.')
    return {"FINISHED"}


class CharacterDesignerHairBonesState(PropertyGroup):
    source: PointerProperty(type=bpy.types.Object, name="Source Mesh", options={"SKIP_SAVE"})
    target_armature: PointerProperty(
        type=bpy.types.Object, name="Character Rig", poll=_armature_poll,
        description="Optional override; otherwise use the saved Main Rig or detect the character automatically",
    )
    show_attachment_override: BoolProperty(
        name='Show Rig Override', default=False,
        description='Show an optional rig override; normally use Main Rig from Character Setup',
    )
    bone_count: IntProperty(
        name="Bones per Chain",
        description="Number of bones in each strand's independent chain",
        default=4,
        min=1,
        max=12,
    )
    last_message: StringProperty(options={"SKIP_SAVE"})
    list_items: CollectionProperty(type=strand_list_ui.CharacterDesignerHairStrandListItem, options={"SKIP_SAVE"})
    list_filter: EnumProperty(name="Category", items=strand_list_ui.FILTER_ITEMS, default="ALL", options={"SKIP_SAVE"})
    list_active_index: IntProperty(default=0, min=0, options={"SKIP_SAVE"})
    list_anchor_key: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    list_anchor_filter: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    show_tools: BoolProperty(name='Advanced', default=False, options={'SKIP_SAVE'})
    list_assign_group: EnumProperty(name="Assign Category", items=strand_list_ui.GROUP_ITEMS, default="UNASSIGNED", options={"SKIP_SAVE"})
    list_pin: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    list_pose_position: StringProperty(options={"SKIP_SAVE"})



class CHARACTERDESIGNER_OT_select_hair_strands(Operator):
    bl_idname = "character_designer.select_hair_strands"
    bl_label = "Select Hair Strands"
    bl_description = (
        "Find all visible hair strands up to their root junctions, regardless of "
        "the current selection; keep the head cap anchored to Head when binding"
    )
    bl_options = {"REGISTER", "UNDO"}
    use_selected: BoolProperty(
        name="Only Strands at Selected Tips",
        description="Limit discovery to strands touching selected visible vertices",
        default=False, options={"SKIP_SAVE"},
    )
    replace_capture: BoolProperty(
        name="Refresh Strand Capture",
        description="Replace the saved strand capture after validating the current mesh",
        default=False, options={"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return _source_edit(context)

    def execute(self, context):
        try:
            if self.use_selected:
                from .hair_bones_topology import _edit
                _, bm = _edit(context)
                if not any(vertex.select and not vertex.hide for vertex in bm.verts):
                    raise ValueError("Select a tip or strand vertex first, or use Select All Hair Strands.")
            obj, plans = select_strands(context, respect_selection=self.use_selected)
            _groups().capture_plans(obj, plans, replace=self.replace_capture)
            _settings(context).source = obj
            _setup().remember_asset(context, obj, "HAIR")
        except (ValueError, RuntimeError) as exc:
            _report(self, context, str(exc), error=True)
            return {"CANCELLED"}
        count = len(plans)
        _report(self, context, f"Captured {count} hair strand{'s' if count != 1 else ''}.")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_hair_bind_to_character(Operator):
    bl_idname = "character_designer.hair_bind_to_character"
    bl_label = "Bind Hair to Character"
    bl_description = "Bind the original hair mesh to independent chains parented to the character's head, including both Mirror sides and central strands"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _source(context) is not None and _settings(context) is not None

    def execute(self, context):
        return _bind(self, context)


class CHARACTERDESIGNER_OT_hair_remove_binding(Operator):
    bl_idname = "character_designer.hair_remove_binding"
    bl_label = "Remove Hair Binding"
    bl_description = "Remove this tool's hair binding and restore the original hair mesh's binding state"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        source = _source(context)
        return source is not None and _binding().is_bound(source)

    def execute(self, context):
        try:
            source = _source(context)
            result = _binding().remove_hair_binding(context, source)
            _settings(context).source = source
        except (ValueError, RuntimeError) as exc:
            _report(self, context, str(exc), error=True)
            return {"CANCELLED"}
        removed = result["removed_bones"]
        count = removed if isinstance(removed, int) else len(removed)
        _report(self, context, f"Removed {count} hair bones. The original hair mesh is preserved.")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_hair_cleanup_generated_copies(Operator):
    bl_idname = "character_designer.hair_cleanup_generated_copies"
    bl_label = "Cleanup Generated Copies"
    bl_description = "Delete this source's old generated hair copies and their dedicated rigs; keep the original mesh and character armature"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        source = _source(context)
        return source is not None and bool(_variants().variants_for(source))

    def execute(self, context):
        try:
            source = _source(context)
            from . import hair_resegment_ui
            source = hair_resegment_ui.source_before_switch(context, source)
            result = _binding().remove_generated_copies(context, source)
            _settings(context).source = source
        except (ValueError, RuntimeError) as exc:
            _report(self, context, str(exc), error=True)
            return {"CANCELLED"}
        meshes = result["removed_meshes"]
        rigs = result["removed_rigs"]
        mesh_count = meshes if isinstance(meshes, int) else len(meshes)
        rig_count = rigs if isinstance(rigs, int) else len(rigs)
        _report(self, context, f"Removed {mesh_count} generated hair copies and {rig_count} dedicated rigs.")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_hair_show_source(Operator):
    bl_idname = "character_designer.hair_show_source"
    bl_label = "Edit Source"
    bl_description = "Return to the original hair mesh and hide old generated copies"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            source = _source(context)
            from . import hair_resegment_ui
            source = hair_resegment_ui.source_before_switch(context, source)
            if any(c.get(_variants().MODE_KEY) == 'RESEGMENTED' for c in _variants().variants_for(source)):
                hair_resegment_ui.service().show_original(context, source, edit=True)
            else:
                _variants().show_source(context, source)
            _settings(context).source = source
        except (ValueError, RuntimeError) as exc:
            _report(self, context, str(exc), error=True)
            return {"CANCELLED"}
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_hair_clear_groups(Operator):
    bl_idname = "character_designer.hair_clear_groups"
    bl_label = "Recapture Strands"
    bl_description = "Clear the saved strand capture; keep the mesh, existing bones and guides"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        try:
            source = _source(context)
            _variants().show_source(context, source)
            _groups().clear_groups(source)
            _settings(context).source = source
            bpy.ops.mesh.select_all(action="DESELECT")
        except (ValueError, RuntimeError) as exc:
            _report(self, context, str(exc), error=True)
            return {"CANCELLED"}
        _report(self, context, "Choose the new source strands, then Select Hair Strands to capture them.")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_generate_hair_bones(Operator):
    """Redirect the old script entry point to the character binding workflow."""
    bl_idname = "character_designer.generate_hair_bones"
    bl_label = "Bind Hair to Character"
    bl_description = "Bind the original hair mesh to independent bone chains on the character armature"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _source(context) is not None and _settings(context) is not None

    def execute(self, context):
        return _bind(self, context)


class CHARACTERDESIGNER_PT_hair_bones(Panel):
    bl_label = 'Hair Strands & Binding'
    bl_idname = "CHARACTERDESIGNER_PT_hair_bones"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = SIDEBAR_CATEGORY
    bl_parent_id = 'CHARACTERDESIGNER_PT_rig_sections'
    bl_order = 10

    @classmethod
    def poll(cls, context):
        return rig_page_active(context, 'HAIR')

    def draw(self, context):
        layout = self.layout
        from . import hair_resegment_ui
        settings = _settings(context)
        if settings is None:
            return
        source = _source(context)
        try:
            already_bound = bool(source and (_binding().is_bound(source) or hair_resegment_ui.is_version(source)))
        except (ValueError, RuntimeError) as error:
            layout.label(text=str(error), icon='ERROR')
            already_bound = False
        if already_bound:
            strand_list_ui.draw_browser(layout, context, source, True)
            layout.prop(settings, 'show_tools', text='Advanced',
                        icon='TRIA_DOWN' if settings.show_tools else 'TRIA_RIGHT', emboss=False)
            if settings.show_tools:
                tools = layout.column(align=True)
                tools.label(text=source.name, icon='OUTLINER_OB_MESH')
                hair_resegment_ui.draw_versions(tools, context, source, True)
                if not _source_edit(context):
                    tools.operator('character_designer.hair_show_source', text='Edit Source', icon='EDITMODE_HLT')
                if not hair_resegment_ui.is_version(source):
                    row = tools.row()
                    row.alert = True
                    row.operator('character_designer.hair_remove_binding', icon='UNLINKED')
                if _variants().variants_for(source):
                    row = tools.row()
                    row.alert = True
                    row.operator('character_designer.hair_cleanup_generated_copies', icon='TRASH')
            return
        if source:
            layout.label(text=f"Source: {source.name}", icon="OUTLINER_OB_MESH")
        capture_error = None
        version = hair_resegment_ui.is_version(source)
        try:
            if version:
                strands = len(rig._read_records(source)['chains'])
            else:
                strands = _groups().captured_strand_count(source) if source else 0
        except (ValueError, RuntimeError) as exc:
            capture_error = str(exc)
            strands = 0
        if not version:
            capture = layout.operator("character_designer.select_hair_strands",
                                      text="Refresh Hair Strands" if capture_error else "Select Hair Strands",
                                      icon="FILE_REFRESH" if capture_error else "RESTRICT_SELECT_OFF")
            capture.use_selected = False
            capture.replace_capture = bool(capture_error)
        if capture_error:
            layout.label(text="Refresh strands before binding.", icon="ERROR")
        try:
            bound = (_binding().is_bound(source) or hair_resegment_ui.is_version(source)) if source else False
        except (ValueError, RuntimeError) as exc:
            layout.label(text=str(exc), icon="ERROR")
            bound = False
        if source:
            target = None
            try:
                preferred = _setup().preferred_rig(context)
                if version:
                    target = source.get(rig.RIG_KEY)
                    head = rig._read_records(source)['parent']
                else:
                    target, head = _binding().resolve_target(context, source, armature=preferred)
                if bound and not version and preferred is not None:
                    desired = _setup().bone_mapping_status(context, 'HEAD', armature=preferred)
                    if preferred != target or desired['name'] != head:
                        layout.label(text='Character Setup differs; existing hair is unchanged.', icon='INFO')
            except (ValueError, RuntimeError) as exc:
                if not capture_error:
                    layout.label(text=str(exc), icon="ERROR")
            if strands:
                layout.label(text=f"{strands} strands")
            settings_row = layout.row()
            settings_row.prop(settings, "bone_count")
            row = layout.row()
            row.enabled = bool(strands) and target is not None and not bound
            row.operator("character_designer.hair_bind_to_character", icon="BONE_DATA")
            hair_resegment_ui.draw_versions(layout, context, source, bound)
            strand_list_ui.draw_browser(layout, context, source, bound)
            if bound and not hair_resegment_ui.is_version(source):
                remove_row = layout.row()
                remove_row.alert = True
                remove_row.operator("character_designer.hair_remove_binding", icon="UNLINKED")
            if _variants().variants_for(source):
                cleanup_row = layout.row()
                cleanup_row.alert = True
                cleanup_row.operator("character_designer.hair_cleanup_generated_copies", icon="TRASH")
            if not _source_edit(context):
                layout.operator("character_designer.hair_show_source", text="Edit Source", icon="EDITMODE_HLT")


HAIR_BONES_CLASSES = strand_list_ui.ITEM_CLASSES + (
    CharacterDesignerHairBonesState,
    CHARACTERDESIGNER_OT_select_hair_strands,
    CHARACTERDESIGNER_OT_generate_hair_bones,
    CHARACTERDESIGNER_OT_hair_bind_to_character,
    CHARACTERDESIGNER_OT_hair_remove_binding,
    CHARACTERDESIGNER_OT_hair_cleanup_generated_copies,
    CHARACTERDESIGNER_OT_hair_show_source,
    CHARACTERDESIGNER_OT_hair_clear_groups,
    CHARACTERDESIGNER_PT_hair_bones,
)

from .hair_resegment_ui import CLASSES as _RESEGMENT_CLASSES
HAIR_BONES_CLASSES += _RESEGMENT_CLASSES + strand_list_ui.CLASSES
