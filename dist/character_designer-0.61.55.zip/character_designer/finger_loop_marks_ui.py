"""Small saved loop guides: explicit updates, retained GPU batches, no mesh monitor."""
import bpy
from bpy.app.handlers import persistent
from bpy.props import EnumProperty
from bpy.types import Operator

from . import finger_bank as bank, finger_definition_ui as guides
from . import finger_loop_marks as marks

_cache = {}
_handles = []
_COLORS = {1: (1., .12, .08, 1.), 2: (.08, .4, 1., 1.)}
_ERRORS = (ValueError, RuntimeError, ReferenceError, KeyError, IndexError, TypeError)


def _mirror(context):
    rig = context.scene.character_designer_setup.rig
    return bool(rig and rig.data.use_mirror_x)


def refresh(context):
    """Load tiny saved polylines on a user action, never inspect geometry."""
    obj = bank.active_object(context)
    if obj is None: return
    pointer, raw = obj.as_pointer(), obj.get(marks.PROPERTY, '')
    matrix = bank.plane(obj)
    reflection_key = tuple(tuple(row) for row in matrix)
    previous = _cache.get(pointer)
    if previous and previous['raw'] == raw and previous['data'] == obj.data and previous['plane'] == reflection_key:
        return
    entries = {}
    saved = marks._saved(obj)
    for key in saved:
        if key not in {digit+'.'+side for digit in bank.detect.DIGITS for side in ('L', 'R')}: continue
        groups = []
        for number, path in marks.points(obj, key).items():
            # Retain independent segments; GPU upload occurs once per new mark.
            lines = tuple(p for pair in zip(path, path[1:]+path[:1]) for p in pair)
            groups.append((lines, _COLORS[number]))
        if groups: entries[key] = dict(groups=groups, batches=None, source=key)
    # Opposite lines are target guides, not claims that an existing opposite
    # edge was marked. Align still validates real pairing before moving bones.
    from mathutils import Matrix, Vector
    reflection = matrix.inverted() @ Matrix.Diagonal((-1., 1., 1., 1.)) @ matrix
    for key, entry in tuple(entries.items()):
        mate = key[:-1]+('R' if key[-1] == 'L' else 'L')
        if mate in saved or not all(str(i) in saved[key] for i in (1, 2)): continue
        groups = [(tuple(tuple(reflection @ Vector(point)) for point in points), color)
                  for points, color in entry['groups']]
        entries[mate] = dict(groups=groups, batches=None, source=key)
    _cache[pointer] = dict(obj=obj, data=obj.data, raw=raw, plane=reflection_key, entries=entries)
    while len(_cache) > 16: _cache.pop(next(iter(_cache)))
    if entries and not _handles and not bpy.app.background:
        _handles.append(bpy.types.SpaceView3D.draw_handler_add(_draw, (), 'WINDOW', 'POST_VIEW'))
    guides._tag_redraw()


def visible(context=None):
    """Only constant-size RNA state and cached buffers are read during drawing."""
    context = context or bpy.context
    if not guides.overlays_enabled(context): return ()
    obj = bank.active_object(context)
    if obj is None: return ()
    cached = _cache.get(obj.as_pointer())
    if not cached or cached['data'] != obj.data or not obj.visible_get(): return ()
    # These are explicitly saved guide locations. Mesh editing never launches a
    # rebuild; Align validates the current loops before any bone can move.
    state = obj.character_designer_finger_bank
    side = bank.display_side(state)
    mirror = _mirror(context)
    return tuple((obj, cached['entries'][key])
                 for key in (digit+'.'+side for digit in bank.selected_digits(state))
                 if key in cached['entries'] and (mirror or cached['entries'][key]['source'] == key))


def _draw():
    entries = visible()
    if not entries: return
    import gpu
    from gpu_extras.batch import batch_for_shader
    depth = gpu.state.depth_test_get()
    width = gpu.state.line_width_get()
    blend = gpu.state.blend_get()
    try:
        gpu.state.depth_test_set('NONE')
        gpu.state.line_width_set(3)
        gpu.state.blend_set('ALPHA')
        for obj, entry in entries:
            if entry['batches'] is None:
                shader = gpu.shader.from_builtin('UNIFORM_COLOR')
                entry['batches'] = shader, [(batch_for_shader(shader, 'LINES', {'pos': points}), color)
                                            for points, color in entry['groups']]
            shader, batches = entry['batches']
            with gpu.matrix.push_pop():
                gpu.matrix.multiply_matrix(obj.matrix_world)
                shader.bind()
                for batch, color in batches:
                    shader.uniform_float('color', color)
                    batch.draw(shader)
    finally:
        gpu.state.depth_test_set(depth)
        gpu.state.line_width_set(width)
        gpu.state.blend_set(blend)


class CHARACTERDESIGNER_OT_finger_loop_marks(Operator):
    bl_idname = 'character_designer.finger_loop_marks'
    bl_label = 'Finger Loop Marks'
    bl_options = {'REGISTER', 'UNDO'}
    action: EnumProperty(items=[(key, label, '') for key, label in (
        ('MARK_1', 'Mark Joint 1'), ('MARK_2', 'Mark Joint 2'),
        ('ALIGN', 'Align Joints to Marks'), ('CLEAR', 'Clear Loop Marks'))])

    @classmethod
    def description(cls, context, props):
        if props.action.startswith('MARK_'):
            return ('Remember the selected existing edge loop as a red/blue joint guide. '
                    'Re-mark if this loop is moved or removed. No geometry or weights are changed')
        if props.action == 'ALIGN':
            return ('Place joints at the marked cross sections. Four fingers stay on their root-to-tip axis; '
                    'thumb follows its curved chain. Keep root, tip and Roll. '
                    'Armature X Mirror also moves the existing opposite chain')
        return 'Forget the saved loop guides on this side; keep the mesh and bones'

    def execute(self, context):
        obj = bank.active_object(context)
        try:
            if self.action.startswith('MARK_'):
                number = int(self.action[-1])
                marks.mark(context, number)
                message = f'Joint {number} loop marked.'
            elif self.action == 'CLEAR':
                marks.clear(context)
                message = ''
            else:
                result = marks.align(context)
                message = f"Aligned joints in {result['chains']} chain(s). Root, tip and Roll kept."
                from . import finger_bone_tools
                finger_bone_tools.invalidate(context)
            if obj: obj.character_designer_finger_bank.bone_status = message
            refresh(context)
            if message: self.report({'INFO'}, message)
            return {'FINISHED'}
        except _ERRORS as exc:
            if obj: obj.character_designer_finger_bank.bone_status = str(exc)
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}


def draw_controls(layout, context):
    obj = bank.active_object(context)
    if obj is None: return
    state = obj.character_designer_finger_bank
    slot = state.slots.get(state.active)
    if not slot or not slot.guide.record: return
    # Panel state reads metadata only; geometry is checked by explicit actions.
    stored = marks.records(obj, marks.effective_key(obj, state.active, _mirror(context)))
    row = layout.row(align=True)
    row.enabled = context.mode == 'EDIT_MESH'
    row.operator('character_designer.finger_loop_marks', text='1 · Red',
                 depress='1' in stored).action = 'MARK_1'
    row.operator('character_designer.finger_loop_marks', text='2 · Blue',
                 depress='2' in stored).action = 'MARK_2'
    row = layout.row(align=True)
    apply = row.row(align=True)
    apply.enabled = '1' in stored and '2' in stored
    apply.operator('character_designer.finger_loop_marks', text='Align Joints to Marks').action = 'ALIGN'
    clear = row.row(align=True)
    clear.enabled = bool(stored)
    clear.operator('character_designer.finger_loop_marks', text='', icon='X').action = 'CLEAR'


@persistent
def _reset(*_):
    _cache.clear()


@persistent
def _restore(*_):
    _reset()
    if getattr(bpy.context, 'scene', None) is not None:
        refresh(bpy.context)


CLASSES = (CHARACTERDESIGNER_OT_finger_loop_marks,)


def register_runtime():
    for handlers in (bpy.app.handlers.load_pre, bpy.app.handlers.undo_pre, bpy.app.handlers.redo_pre):
        if _reset not in handlers: handlers.append(_reset)
    for handlers in (bpy.app.handlers.load_post, bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _restore not in handlers: handlers.append(_restore)
    # Blender deliberately hides scene/data while enabling an add-on. Mark and
    # load actions (and the completed reload) populate these display records.
    if getattr(bpy.context, 'scene', None) is not None:
        refresh(bpy.context)


def unregister_runtime():
    _reset()
    for handle in _handles: bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
    _handles.clear()
    for handlers in (bpy.app.handlers.load_pre, bpy.app.handlers.undo_pre, bpy.app.handlers.redo_pre):
        if _reset in handlers: handlers.remove(_reset)
    for handlers in (bpy.app.handlers.load_post, bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _restore in handlers: handlers.remove(_restore)
