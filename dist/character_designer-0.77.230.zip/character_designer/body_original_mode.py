"""Persistent native Body/Hair/Dress display with direct native body posing."""
import json
import math
from dataclasses import dataclass
from functools import lru_cache

import bpy
from bpy.props import EnumProperty
from . import bone_display as display, bone_collections as groups, limb_ik, limb_ik_fk as match
from . import control_pose_assets as poses
from . import skirt_original_mode as dress_pose

SESSION = 'character_designer_body_original_mode_v1'
DISPLAY_REFS = 'character_designer_original_display_refs_v1'
DISPLAY_OWNER = 'character_designer_original_display_owner_v1'
_CHANNELS = ('location', 'rotation_euler', 'rotation_quaternion', 'rotation_axis_angle', 'scale')
_LOCKS = ('lock_rotation', 'lock_rotation_w', 'lock_rotations_4d')
_REST_FIELDS = frozenset(('matrix', 'length', 'parent', 'connected', 'inherit_scale',
                          'inherit_rotation', 'local_location'))
_REST_RELATIONS = ('parent', 'connected', 'inherit_scale', 'inherit_rotation', 'local_location')
_REST_LENGTH_EPSILON = 1e-6
_REST_MATRIX_EPSILON = 2e-6
_PAINT_SESSION_MESSAGE = 'Return to Controls on the Weight page before editing the original pose.'


def active(rig):
    return bool(rig and rig.type == 'ARMATURE' and SESSION in rig)


def _require_no_paint_session(context, rig):
    from . import weight_paint_entry
    if weight_paint_entry.owns_rig(rig):
        raise ValueError(_PAINT_SESSION_MESSAGE)


def _weight_page(context):
    from .ui_constants import active_ui_page, UI_PAGE_WEIGHT
    return active_ui_page(context) == UI_PAGE_WEIGHT


def _weight_execute(context, rig, action):
    """Weight-page labels address the painting session, never formal Original."""
    from . import weight_paint_entry as paint
    if active(rig):
        raise ValueError('Choose Controls on the Rig page to finish Original before using weight painting.')
    owned = paint.owns_rig(rig)
    current = paint.phase(context) if owned else None
    painting = action == 'ORIGINAL' or (action == 'TOGGLE' and current != 'PAINT')
    if painting:
        paint.show_painting(context, rig=rig)
        return 'Painting. Use Controls to preview the pose.'
    if owned:
        paint.show_controls(context, rig=rig, repair_legacy_display=True)
        return 'Pose preview. Use Original to continue painting.'
    if paint.native_painting(context):
        raise ValueError('Choose Original to start a painting session before previewing Controls, or End Native Painting.')
    if context.mode not in {'OBJECT', 'POSE'}:
        raise ValueError('Finish the current edit before showing Controls.')
    display.show_controls(context, rig)
    return 'Controls shown.'


def _draw_weight_switch(layout, context, rig):
    from . import weight_paint_entry as paint
    owned = paint.owns_rig(rig)
    local = owned and paint.active(context, rig=rig)
    current = paint.phase(context) if local else None
    formal = active(rig)
    native = paint.native_painting(context)
    temporary = display.view_mode(rig) if not owned and not formal else None
    supported = context.mode in {'OBJECT', 'POSE', 'PAINT_WEIGHT'}
    row = layout.row(align=True)
    row.enabled = supported and (not owned or local)
    painting = row.row(align=True)
    in_paint = current == 'PAINT' and context.mode == 'PAINT_WEIGHT'
    painting.enabled = not formal and not temporary and not in_paint
    paint_operator = ('character_designer.resume_weight_paint'
                      if owned else 'character_designer.paint_weights')
    painting.operator(paint_operator, text='Original Bones', icon='WPAINT_HLT', depress=in_paint)
    controls = row.row(align=True)
    if owned or native:
        controls.operator('character_designer.preview_weight_pose', text='Controls')
    else:
        controls.operator('character_designer.body_original_mode', text='Controls',
                          depress=not formal and not temporary and context.mode == 'POSE').action = 'CONTROLS'
    if formal or temporary:
        layout.label(text='Return to Controls before painting.', icon='INFO')
    elif owned and not local:
        layout.label(text='Return to the painting Scene and View Layer.', icon='INFO')


@dataclass(frozen=True)
class _SessionRestPlan:
    """Pure saved JSON fields only; no current/native identity or passed proof."""
    bones: tuple
    rest: tuple


def _valid_rest_entry(entry):
    def numeric(value):
        return type(value) in (int, float) and math.isfinite(value)

    if not isinstance(entry, dict) or set(entry) != _REST_FIELDS:
        return False
    matrix = entry['matrix']
    return (numeric(entry['length']) and entry['length'] >= 0
            and (entry['parent'] is None or isinstance(entry['parent'], str))
            and isinstance(entry['inherit_scale'], str) and bool(entry['inherit_scale'])
            and all(type(entry[key]) is bool for key in ('connected', 'inherit_rotation', 'local_location'))
            and isinstance(matrix, (list, tuple)) and len(matrix) == 4
            and all(isinstance(row, (list, tuple)) and len(row) == 4
                    and all(numeric(value) for value in row) for row in matrix))


@lru_cache(maxsize=1)
def _compile_session_rest_plan(raw):
    """Compile only fully valid saved text, with immutable detached contents.

    Malformed/unusual text returns to the ordinary validator so its live-bone
    checks and exception order remain authoritative. This does not authenticate
    the current rig or permit reusing any previous successful native check.
    """
    try:
        saved = json.loads(raw)
        if (type(saved) is not dict or type(saved.get('version')) is not int
                or saved['version'] != 1):
            return None
        bones, rest = saved.get('bones'), saved.get('rest')
        if (type(bones) is not list
                or any(type(name) is not str or not name for name in bones)
                or len(bones) != len(set(bones)) or type(rest) is not dict or not rest
                or any(type(name) is not str or not name for name in rest)
                or any(not _valid_rest_entry(entry) for entry in rest.values())):
            return None
        rows = tuple((name, tuple((field, tuple(tuple(row) for row in value)
                                      if field == 'matrix' else value)
                                 for field, value in entry.items()))
                     for name, entry in rest.items())
        return _SessionRestPlan(tuple(bones), rows)
    except (ValueError, TypeError, KeyError, OverflowError):
        return None


def _materialize_session_rest_plan(plan):
    """Return fresh caller-owned containers; never expose shared mutable JSON."""
    return {'version': 1, 'bones': list(plan.bones),
            'rest': {name: {field: [list(row) for row in value] if field == 'matrix' else value
                            for field, value in fields} for name, fields in plan.rest}}


def _validate_session_rest(rig, saved=None, current=None):
    """Read-only proof of this session's native Rest, allowing float roundtrips.

    Mesh coordinates are deliberately absent. A real Rest edit is not accepted
    by replacing the saved baseline, restoring bones, or removing the session.
    ``saved`` and ``current`` may be reused within one synchronous operation.
    """
    plan = None
    if saved is None:
        if not active(rig):
            raise ValueError('Choose Original before checking its saved skeleton.')
        try:
            raw = rig[SESSION]
            # Explicit caller-supplied current/saved records keep the complete
            # ordinary schema path. Only fresh live reads consume this plan.
            if current is None and type(raw) is str:
                plan = _compile_session_rest_plan(raw)
            saved = (_materialize_session_rest_plan(plan) if plan is not None
                     else json.loads(raw))
        except (ValueError, TypeError) as exc:
            raise ValueError('The saved Original session is invalid; recover its saved file.') from exc
    if (not isinstance(saved, dict) or type(saved.get('version')) is not int
            or saved['version'] != 1):
        raise ValueError('The saved Original session schema is unsupported; recover its saved file.')
    stored_bones = saved.get('bones')
    old = saved.get('rest')
    if (not isinstance(stored_bones, list)
            or any(not isinstance(name, str) or not name for name in stored_bones)
            or len(stored_bones) != len(set(stored_bones)) or not isinstance(old, dict)
            or not old or any(not isinstance(name, str) or not name for name in old)):
        raise ValueError('The saved Original skeleton record is invalid; recover its saved file.')
    actual_bones = sorted(rig.data.bones.keys())
    if stored_bones != actual_bones:
        removed = sorted(set(stored_bones) - set(actual_bones))
        added = sorted(set(actual_bones) - set(stored_bones))
        detail = ', '.join((['removed ' + ', '.join(removed[:3])] if removed else [])
                           + (['added ' + ', '.join(added[:3])] if added else []))
        raise ValueError('Original bone inventory changed' + (': ' + detail if detail else '')
                         + '. Keep Original and undo an unintended bone rename/add/remove before returning.')
    live_record = current is None
    current = poses.native_rest(rig) if live_record else current
    if not isinstance(current, dict) or any(not isinstance(name, str) or not name for name in current):
        raise ValueError('The current Original Rest record is invalid; keep Original and inspect the skeleton.')
    if set(old) != set(current):
        changed = sorted(set(old).symmetric_difference(current))
        raise ValueError('Original native bone ownership changed'
                         + (': ' + ', '.join(changed[:3]) if changed else '')
                         + '. Keep Original and restore the intended ownership before returning.')

    for name, previous in old.items():
        now = current[name]
        if plan is None and not _valid_rest_entry(previous):
            raise ValueError(f'Original Rest record is invalid or non-finite at {name}; keep Original and inspect that bone.')
        # Native RNA supplies the current field types. Equal records already
        # prove its finite coordinates against the validated saved values;
        # avoid a second matrix walk on the ordinary no-edit return. Explicit
        # supplied records retain their complete schema and finite checks.
        if live_record and previous == now:
            continue
        if not _valid_rest_entry(now):
            raise ValueError(f'Original Rest record is invalid or non-finite at {name}; keep Original and inspect that bone.')
        relations = [key for key in _REST_RELATIONS if previous[key] != now[key]]
        length_error = abs(previous['length'] - now['length'])
        matrix_error = max(abs(a-b) for first, second in zip(previous['matrix'], now['matrix'])
                           for a, b in zip(first, second))
        if relations or length_error > _REST_LENGTH_EPSILON or matrix_error > _REST_MATRIX_EPSILON:
            detail = ', '.join(relations + ([f'length difference {length_error:.6g}']
                                          if length_error > _REST_LENGTH_EPSILON else [])
                              + ([f'Rest matrix difference {matrix_error:.6g}']
                                 if matrix_error > _REST_MATRIX_EPSILON else []))
            raise ValueError(f'Native Rest changed at {name} ({detail}). Keep Original; undo an unintended bone edit, '
                             'or resync the controls to the new Rest before returning. Mesh recalibration cannot repair this change.')
    return current


@lru_cache(maxsize=1)
def _native_records(raw):
    """Cache only immutable names by exact saved text, never Blender objects."""
    saved = json.loads(raw)
    records = saved.get('native_groups')
    if records is None:
        # Previous sessions did not capture Hair or Dress display transactions.
        records = {'BODY': {'0': saved['names']}, 'HAIR': {}, 'DRESS': {}}
    return tuple((role, tuple((key, tuple(names)) for key, names in targets.items()))
                 for role, targets in records.items())


def _native_groups(context, rig):
    if active(rig):
        refs = rig.get(DISPLAY_REFS, {})
        result = {}
        for role, targets in _native_records(rig[SESSION]):
            result[role] = {}
            for key, names in targets:
                target = rig if key == '0' else refs.get(key)
                if target is None:
                    raise ValueError('An Original display rig is missing; restore it before switching to Controls.')
                result[role][target] = set(names)
        return result
    original = rig.data.collections_all.get('Original')
    return {'BODY': {rig: set(original.bones.keys())} if original else {},
            'HAIR': display._native_targets(context, rig, 'HAIR'),
            'DRESS': display._native_targets(context, rig, 'DRESS')}


def _targets_visible(targets):
    if any(not display._object_visible(rig) for rig, names in targets.items() if names):
        return False
    bones = [(rig, rig.data.bones.get(name)) for rig, names in targets.items() for name in names]
    return bool(bones) and all(bone is not None
        and not getattr(rig.pose.bones[bone.name], 'hide', bone.hide)
        and (not bone.collections or any(c.is_visible_effectively for c in bone.collections))
        for rig, bone in bones)


def group_visible(context, rig, role):
    return _targets_visible(_native_groups(context, rig)[role])


def _remember_object_visibility(rig, targets):
    """Extend an older active session only when it explicitly reveals a rig."""
    if not active(rig):
        return
    raw = rig[SESSION]
    saved = json.loads(raw)
    refs = rig.get(DISPLAY_REFS, {})
    changed = False
    for target in targets:
        if target == rig:
            view = saved['display']
        else:
            key = next((key for key, obj in refs.items() if obj == target), None)
            if key is None or target.get(DISPLAY_OWNER) != rig:
                raise ValueError('An Original display rig was removed or reassigned; undo that edit before returning.')
            view = saved.get('extra_display', {}).get(key)
            if view is None:
                raise ValueError('The saved Original dress display is missing; recover its saved file.')
        display._check_object_restore(target, view)
        if 'object_visibility' not in view:
            view['object_visibility'] = display._object_snapshot(target)
            changed = True
    if changed:
        rig[SESSION] = json.dumps(saved, separators=(',', ':'))


def _set_native_view(context, rig, native_groups, role='ALL', *, toggle=False, complete=True,
                     _original_pose=None):
    targets = {}
    for part in native_groups.values() if role == 'ALL' else (native_groups[role],):
        for target, names in part.items():
            targets.setdefault(target, set()).update(names)
    for target, names in targets.items():
        display._editable(target, _original_pose=_original_pose)
        if set(names) - set(target.data.bones.keys()):
            raise ValueError('Original display bones were removed; undo that edit before switching views.')
    visible = not _targets_visible(targets) if toggle else True
    checkpoint = display._checkpoint(targets)
    raw = rig.get(SESSION)
    try:
        if visible:
            _remember_object_visibility(rig, targets)
        for target, names in targets.items():
            if visible and names:
                display._reveal_object(target)
            if target.data.show_bone_custom_shapes:
                target.data.show_bone_custom_shapes = False
            if target.data.display_type != 'OCTAHEDRAL':
                target.data.display_type = 'OCTAHEDRAL'
            visible_collections = set()
            if visible:
                for name in names:
                    for collection in target.data.bones[name].collections:
                        while collection is not None:
                            visible_collections.add(collection.name)
                            collection = collection.parent
            if role == 'ALL':
                for collection in target.data.collections_all:
                    if collection.is_solo:
                        collection.is_solo = False
                    show = collection.name in visible_collections
                    if collection.is_visible != show:
                        collection.is_visible = show
                for bone in target.data.bones:
                    display._set_hidden(target, bone, bone.name not in names or not visible)
            elif visible:
                for collection in target.data.collections_all:
                    if collection.name in visible_collections and not collection.is_visible:
                        collection.is_visible = True
            for name in names:
                bone = target.data.bones[name]
                if role != 'ALL':
                    display._set_hidden(target, bone, not visible)
                if visible:
                    if bone.hide_select:
                        bone.hide_select = False
        if complete:
            display._completed(rig)
    except Exception:
        if raw is not None:
            rig[SESSION] = raw
        display._rollback(checkpoint)
        raise


def show_group(context, rig, role):
    _require_no_paint_session(context, rig)
    if not active(rig):
        raise ValueError('Choose Original in Bone Display first.')
    from . import body_original_owner as owner
    capability = owner.pose_capability(context, rig)
    saved = _require(context, rig, _original_pose=capability)
    _ensure_dress_editable(context, rig, saved, _original_pose=capability)
    native_groups = _native_groups(context, rig)
    if not any(native_groups[role].values()):
        raise ValueError('This character has no original bones in that group.')
    _set_native_view(context, rig, native_groups, role, toggle=True,
                     _original_pose=capability)


def _extra_views(rig, saved):
    result = []
    refs = rig.get(DISPLAY_REFS, {})
    for key, view in saved.get('extra_display', {}).items():
        target = refs.get(key)
        if target is None or target.get(DISPLAY_OWNER) != rig:
            raise ValueError('An Original display rig was removed or reassigned; undo that edit before returning.')
        display._editable(target)
        if saved.get('extra_bones', {}).get(key) != sorted(target.data.bones.keys()):
            raise ValueError('The skirt skeleton changed in Original; undo that edit before returning.')
        result.append((target, view))
    return result


def _update(context, rig):
    match._update(context, rig)


def _pose(rig, names=None):
    if names is None:
        names = poses.native_rest(rig)
    return {name: rig.pose.bones[name].matrix.copy() for name in names}


def _session_pose_edits(saved, desired):
    """Compare with the settled Original pose, including inherited dependencies."""
    entered = saved['entered_pose']
    if (type(entered) is not dict or set(entered) != set(desired)
            or any(not isinstance(rows, list) or len(rows) != 4
                   or any(not isinstance(row, list) or len(row) != 4
                          or any(type(value) not in (int, float) or not math.isfinite(value)
                                 for value in row) for row in rows)
                   for rows in entered.values())
            or any(not limb_ik._matrix_is_finite(matrix) for matrix in desired.values())):
        raise ValueError('The saved Original entry pose is invalid; keep the current Original edit.')
    return {name for name in desired if poses._difference(desired[name], entered[name]) > 1e-7}


def _channels(rig):
    from . import skirt_rig
    # The Body transfer restores its saved controls. Shared Dress channels remain
    # independent artist edits, as they were on the former separate armature.
    return {pb.name: {'mode': pb.rotation_mode,
                     'channels': {key: list(getattr(pb, key)) for key in _CHANNELS},
                     'ik_fk': pb.get('ik_fk')}
            for pb in rig.pose.bones if not pb.bone.get(skirt_rig.OWNER_KEY)}


def _restore_channels(rig, state):
    for name, entry in state.items():
        pb = rig.pose.bones[name]
        if pb.rotation_mode != entry['mode']:
            pb.rotation_mode = entry['mode']
        for key, values in entry['channels'].items():
            if tuple(getattr(pb, key)) != tuple(values):
                setattr(pb, key, values)
        if entry['ik_fk'] is not None and pb.get('ik_fk') != entry['ik_fk']:
            pb['ik_fk'] = entry['ik_fk']


def _locks(rig, names):
    return {name: {key: list(value) if hasattr(value, '__len__') else value
                   for key in _LOCKS for value in (getattr(rig.pose.bones[name], key),)}
            for name in names}


def _restore_locks(rig, state):
    for name, fields in state.items():
        for key, value in fields.items():
            current = getattr(rig.pose.bones[name], key)
            same = tuple(current) == tuple(value) if hasattr(current, '__len__') else current == value
            if not same:
                setattr(rig.pose.bones[name], key, value)


def _owned_sources(rig, names):
    """Resolve exact validated ownership records, never prefixes or proximity."""
    from . import torso_controls, spine_ik_fk, eye_controls, root_control, foot_controls
    inventory = limb_ik._validate_inventory(rig)
    if any(match.VERSION_KEY not in rig.pose.bones[entry['target'].name].bone for entry in inventory['rigs'].values()):
        raise ValueError('Update this legacy Body setup before using Original mode.')
    # The inventory just validated these exact constraints and all extensions.
    # Reuse that result inside this read-only preflight, without a lifetime cache.
    entries = {(pb.name, con.name): con for pb, con, _record in inventory['records']
               if pb.name in names}
    records = [module.get_record(rig) for module in (torso_controls, spine_ik_fk, eye_controls, root_control)]
    records.extend(foot_controls.records(rig).values())
    for record in records:
        for entry in record['constraints'] if record else ():
            if entry['owner'] in names:
                entries[(entry['owner'], entry['name'])] = rig.pose.bones[entry['owner']].constraints[entry['name']]
    return [{'bone': bone, 'name': name, 'type': con.type, 'mute': con.mute}
            for (bone, name), con in sorted(entries.items())]


def _resolve(rig, entries):
    result = []
    for entry in entries:
        pb = rig.pose.bones.get(entry['bone'])
        con = pb.constraints.get(entry['name']) if pb else None
        if con is None or con.type != entry['type']:
            raise ValueError('An Original mode constraint was changed or removed; undo that edit before returning.')
        result.append((con, entry))
    return result


def _verify(rig, desired):
    errors = {name: poses._difference(matrix, rig.pose.bones[name].matrix) for name, matrix in desired.items()}
    worst = max(errors, key=errors.get)
    if not all(limb_ik._matrix_is_finite(rig.pose.bones[name].matrix) for name in desired) or errors[worst] > 4e-4:
        raise ValueError(f'Original mode could not preserve {worst} ({errors[worst]:.4g}); the switch was rolled back.')
    return errors[worst]


def _bake_sources(context, rig, desired, entries):
    changed = {entry['bone'] for entry in entries}
    # convert_local_to_pose respects unusual inheritance flags and connected parents;
    # the PoseBone.matrix setter does not reliably reproduce these native frames.
    # Every native parent already has a captured target frame. Compute all local
    # bases from those frames before assignment, instead of reevaluating the whole
    # character (and bound meshes) after every single bone. Non-native parents use
    # the current evaluated frame; bounded extra passes handle those dependencies.
    bones = [rig.pose.bones[name] for name in desired]
    for _attempt in range(4):
        bases = []
        for pb in bones:
            if pb.name not in changed and any(not con.mute for con in pb.constraints):
                continue
            kwargs = {'parent_matrix': desired.get(pb.parent.name, pb.parent.matrix),
                      'parent_matrix_local': pb.parent.bone.matrix_local} if pb.parent else {}
            basis = pb.bone.convert_local_to_pose(desired[pb.name], pb.bone.matrix_local, invert=True, **kwargs)
            if poses._difference(pb.matrix_basis, basis) > 1e-7:
                bases.append((pb, basis))
        if not bases:
            break
        for pb, basis in bases:
            pb.matrix_basis = basis
        _update(context, rig)
        if max(poses._difference(rig.pose.bones[name].matrix, matrix) for name, matrix in desired.items()) < 3e-5:
            break


def _require(context, rig, *, _original_pose=None):
    _require_no_paint_session(context, rig)
    from . import forearm_twist
    display._editable(rig, _original_pose=_original_pose)
    preview = forearm_twist._SESSION
    if preview is not None and preview.get('armature') == rig:
        raise ValueError('Confirm or cancel the Forearm preview before switching Original or Controls.')
    if context.mode not in {'OBJECT', 'POSE'}:
        raise ValueError('Finish the current edit or weight session, then switch Original in Object or Pose Mode.')
    if rig.override_library or rig.name not in context.view_layer.objects:
        raise ValueError('Choose a local character rig in this view layer.')
    if context.scene.get('character_designer_weight_workspace_v1', {}).get('rig') == rig:
        raise ValueError('Legacy weight workspace recovery is pending; reopen the file in its original view layer before continuing.')
    if active(rig):
        saved = json.loads(rig[SESSION])
        display._check_object_restore(rig, saved['display'])
        for target, view in _extra_views(rig, saved):
            display._check_object_restore(target, view)
        return saved
    return None


def enter(context, rig):
    _require_no_paint_session(context, rig)
    from . import forearm_twist, body_original_owner as owner
    capability = owner.pose_capability(context, rig, entering=True)
    with forearm_twist.defer_runtime(context, flush_on_exit=False) as refresh:
        entered = _enter(context, rig, refresh, _original_pose=capability)
    if entered:
        # The Original transaction has fully published and verified its native
        # editing state. Only now may an explicit saved Automatic choice resume
        # its separate owned PHYS layer; refusal keeps the completed mode.
        display._apply_pending_physics(context, rig)
    return entered


def _enter(context, rig, refresh, *, _original_pose=None):
    from . import animation_pose_test
    if animation_pose_test.natural_active(rig):
        raise ValueError('Choose Pose to finish the static Rest test before changing Original/Controls mode.')
    from . import body_original_owner as owner
    _require(context, rig, _original_pose=_original_pose)
    if _original_pose is not None:
        # Every matcher must remain verification-only for its existing drivers.
        match._require_existing_switches(rig)
    if active(rig):
        raise ValueError('This rig is already in Original mode.')
    original = rig.data.collections_all.get('Original')
    if original is None or original.get(groups.GROUP_KEY) != 'Original':
        raise ValueError('Organize this character\'s Bone Collections first.')
    names = set(original.bones.keys())
    if not names or any(rig.data.bones[name].get(limb_ik.OWNER_KEY) in limb_ik.GENERATED_CONTROL_OWNERS for name in names):
        raise ValueError('Original must contain the native character bones only.')
    entries = _owned_sources(rig, names)
    native_groups = _native_groups(context, rig)
    rigs = list(dict.fromkeys([rig] + [target for part in native_groups.values() for target in part]))
    for target in rigs:
        display._editable(target, _original_pose=_original_pose)
        display_owner = target.get(DISPLAY_OWNER)
        if display_owner and active(display_owner):
            raise ValueError('An attached dress is already in another Original display session.')
    if rig.animation_data:
        prefixes = tuple(rig.pose.bones[name].path_from_id() + '.' + prop for name in names for prop in _CHANNELS)
        if any(not curve.mute and curve.data_path.startswith(prefixes) for curve in rig.animation_data.drivers):
            raise ValueError('A native transform driver still controls Original; preserve or adjust that driver before direct posing.')
    from . import skirt_wiggle
    skirt_wiggle.suspend_for_rig(context, rig, reason='Original editing paused automatic Dress motion.')
    _update(context, rig)
    dress_entries = dress_pose.prepare(context, rig, _original_pose=_original_pose)
    dress_checkpoint = dress_pose.checkpoint(context, rig, dress_entries)
    rest = poses.native_rest(rig)
    desired = _pose(rig, rest)
    before = _channels(rig)
    checkpoint = display._checkpoint(display._affected(context, rig))
    ctx = limb_ik._capture_context(context, rig)
    locks = _locks(rig, names)
    saved = None
    try:
        owner.install_pose_session(_original_pose)
        # Recover a legacy display-only isolation before starting this explicit session.
        display.restore_view(rig, _original_pose=_original_pose)
        saved = {'version': 1, 'rest': rest, 'bones': sorted(rig.data.bones.keys()),
                 'names': sorted(names), 'constraints': entries, 'channels': before, 'locks': locks,
                 'dress_edit': dress_entries,
                 'display': display._snapshot(rig),
                 'native_groups': {role: {str(rigs.index(target)): sorted(bones)
                                          for target, bones in part.items()}
                                   for role, part in native_groups.items()},
                 'extra_display': {str(i): display._snapshot(target) for i, target in enumerate(rigs) if i},
                 'extra_bones': {str(i): sorted(target.data.bones.keys()) for i, target in enumerate(rigs) if i},
                 'pose': {name: [list(row) for row in matrix] for name, matrix in desired.items()}}
        if _original_pose is not None:
            saved['pose_only_owner'] = owner.pose_session_fields(_original_pose)
        rig[SESSION] = json.dumps(saved, separators=(',', ':'))
        rig[DISPLAY_REFS] = {str(i): target for i, target in enumerate(rigs) if i}
        for target in rigs[1:]:
            target[DISPLAY_OWNER] = rig
        if context.mode != 'POSE' or context.view_layer.objects.active != rig:
            limb_ik._mode_set(context, rig, 'POSE')
        for con, entry in _resolve(rig, entries):
            con.mute = True
        _update(context, rig)
        _bake_sources(context, rig, desired, entries)
        _verify(rig, desired)
        dress_pose.enter(context, rig, dress_entries)
        saved['entered_channels'] = _channels(rig)
        rig[SESSION] = json.dumps(saved, separators=(',', ':'))
        _set_native_view(context, rig, native_groups, complete=False,
                         _original_pose=_original_pose)
        for bone in rig.data.bones:
            if bone.name in names:
                if bone.hide_select:
                    bone.hide_select = False
                pb = rig.pose.bones[bone.name]
                if any(pb.lock_rotation):
                    pb.lock_rotation = (False, False, False)
                if pb.lock_rotation_w:
                    pb.lock_rotation_w = False
                if pb.lock_rotations_4d:
                    pb.lock_rotations_4d = False
        groups._FRAME_CACHE.pop(rig.as_pointer(), None)
        display._completed(rig, update=False)
        refresh()
        dress_pose.verify(context, rig, dress_entries)
        if _original_pose is not None:
            owner._check_pose_capability(_original_pose, rig)
        # The bake can round untouched matrices by ~1e-6. Keep its settled pose
        # separately from the pre-bake target so that later edits do not rematch
        # unrelated limbs just to remove that existing float32 difference.
        saved['entered_pose'] = {name: [list(row) for row in matrix]
                                 for name, matrix in _pose(rig, rest).items()}
        rig[SESSION] = json.dumps(saved, separators=(',', ':'))
    except Exception:
        for con, entry in _resolve(rig, entries):
            con.mute = entry['mute']
        _restore_channels(rig, before)
        _restore_locks(rig, locks)
        dress_pose.rollback(context, dress_checkpoint)
        display._rollback(checkpoint)
        for target in rigs[1:]:
            target.pop(DISPLAY_OWNER, None)
        rig.pop(DISPLAY_REFS, None)
        rig.pop(SESSION, None)
        owner.restore_pose_session(_original_pose)
        limb_ik._restore_context(context, rig, ctx)
        _update(context, rig)
        refresh()
        raise
    return {'bones': len(names), 'constraints': len(entries)}


def ensure_dress_editable(context, rig):
    """Explicitly upgrade a saved display-only Original session, never on draw."""
    _require_no_paint_session(context, rig)
    from . import body_original_owner as owner
    capability = owner.pose_capability(context, rig)
    saved = _require(context, rig, _original_pose=capability)
    return _ensure_dress_editable(context, rig, saved, _original_pose=capability)


def _ensure_dress_editable(context, rig, saved, *, _original_pose=None):
    """Reuse the preflight's parsed state only within its synchronous operation."""
    if saved is None:
        return False
    raw = rig[SESSION]
    if 'dress_edit' in saved:
        dress_pose.validate_active(context, rig, saved['dress_edit'])
        return False
    _update(context, rig)
    entries = dress_pose.prepare(context, rig, _original_pose=_original_pose)
    checkpoint = dress_pose.checkpoint(context, rig, entries)
    try:
        dress_pose.enter(context, rig, entries)
        saved['dress_edit'] = entries
        rig[SESSION] = json.dumps(saved, separators=(',', ':'))
        display._completed(rig, update=False)
    except Exception:
        dress_pose.rollback(context, checkpoint)
        rig[SESSION] = raw
        raise
    return True


def leave(context, rig):
    _require_no_paint_session(context, rig)
    from . import forearm_twist, body_original_owner
    def transfer(finalize=None, *, _original_pose=None):
        with forearm_twist.defer_runtime(context, flush_on_exit=False) as refresh:
            return _leave(context, rig, refresh, finalize=finalize,
                          _original_pose=_original_pose)
    returned = body_original_owner.run_return(context, rig, transfer)
    if returned:
        # run_return has now finalized its complete Body/Dress transaction.
        # Deferred physics choices are separate operations and cannot roll
        # back, or run inside, that authenticated Original return.
        display._apply_pending_physics(context, rig)
    return returned


def _leave(context, rig, refresh, *, finalize=None, _original_pose=None):
    from . import animation_pose_test
    if animation_pose_test.natural_active(rig):
        raise ValueError('Choose Pose to finish the static Rest test before changing Original/Controls mode.')
    from . import body_rest_resync as resync, body_original_owner as owner
    saved = _require(context, rig, _original_pose=_original_pose)
    if not active(rig):
        return False
    if _original_pose is not None:
        # This path never adapts historical or freshly edited native Rest.
        owner._check_pose_capability(_original_pose, rig)
        from . import forearm_original_inventory
        # Original deliberately pauses its authenticated source constraints.
        # Validate that exact saved mute view without toggling native RNA.
        match._require_existing_switches(rig, inventory=forearm_original_inventory.validate(rig))
    plan = None
    try:
        rest = _validate_session_rest(rig, saved)
    except ValueError:
        if _original_pose is not None:
            raise
        # Prove the complete old graph before accepting only supported native
        # Direct geometry edits. The plan never restores or re-planes Rest.
        plan = resync.prepare(context, rig, saved)
        if plan is None:
            raise
        rest = plan['rest']
        if 'dress_edit' not in saved:
            raise ValueError('Update the saved Original Dress session before adapting edited Rest.')
    _ensure_dress_editable(context, rig, saved, _original_pose=_original_pose)
    session_raw = rig[SESSION]
    relations = _resolve(rig, saved['constraints'])
    extra_views = _extra_views(rig, saved)
    _update(context, rig)
    desired = _pose(rig, rest)
    current_channels = _channels(rig)
    pose_edits = (_session_pose_edits(saved, desired)
                  if plan is None and 'entered_pose' in saved else None)
    # These consecutive reads share one exact proof. It must not cross the
    # native update below or any Body/Dress mutation in the transfer.
    dress_targets = dress_pose._resolve(context, rig, saved['dress_edit'])
    dress_desired = dress_pose.capture(context, rig, saved['dress_edit'], targets=dress_targets)
    dress_checkpoint = dress_pose.checkpoint(context, rig, saved['dress_edit'], targets=dress_targets)
    edited = (plan is not None or bool(pose_edits)
              or any(current_channels[name] != saved['entered_channels'][name] for name in desired))
    checkpoint = (current_channels, display._snapshot(rig), _locks(rig, saved['names']),
                  [(con, con.mute) for con, _entry in relations],
                  [(con, float(con.pole_angle)) for pb in rig.pose.bones
                   for con in pb.constraints if con.type == 'IK'],
                  match._leg_pole_metadata(rig))
    extra_checkpoint = [(target, display._snapshot(target)) for target, _view in extra_views]
    with owner.pose_return_checkpoint(_original_pose, checkpoint):
        try:
            _restore_channels(rig, saved['channels'])
            _restore_locks(rig, saved['locks'])
            for con, entry in relations:
                con.mute = entry['mute']
            _update(context, rig)
            forced = resync.apply(context, rig, saved, plan)
            limb_ik._validate_inventory(rig)
            changed = {name for name in desired if poses._difference(desired[name], rig.pose.bones[name].matrix) > 1e-7}
            if pose_edits is not None:
                changed.intersection_update(pose_edits)
            changed.update(forced)
            if plan is not None and all(current_channels[name] == saved['entered_channels'][name]
                                        for name in desired if name not in forced):
                # Geometry edits in one limb must not rematch untouched limbs just
                # because the Original bake rounded a native matrix by ~1e-6.
                # In particular, matching an unchanged arm repositions its Pole
                # along the same bend ray, changing an artist's controller layout.
                # Authored poses outside this region retain the full match route;
                # all native poses and bound surfaces still undergo final checks.
                changed = set(forced)
            if changed and edited:
                poses._match(context, rig, desired, changed, preserve_modes=True,
                             sync_controls=plan is None,
                             precise_limbs=plan['keys'] if plan else (),
                             _pose_only_owner=_original_pose is not None)
                _update(context, rig)
            # Returning without native edits may still restore a historical Pole
            # offset behind the body. Repair the existing leg controls, not Rest.
            if _original_pose is None:
                match.repair_leg_poles(context, rig, desired_pose=desired)
            else:
                match._repair_original_leg_poles(context, rig, desired_pose=desired,
                                                 _original_pose=_original_pose)
            _verify(rig, desired)
            dress_pose.leave(context, rig, saved['dress_edit'], desired=dress_desired)
            display._restore(rig, saved['display'])
            for target, view in extra_views:
                display._restore(target, view)
            rig.pop(SESSION)
            groups._FRAME_CACHE.pop(rig.as_pointer(), None)
            # Pose-only return restores the artist's exact saved display. Mode
            # matching preserves the saved IK/FK modes; normalizing membership
            # here would replace that layout and create new FK display records.
            if _original_pose is None:
                groups._frame_visibility(context.scene, objects=(rig,),
                                          _original_pose=_original_pose)
            display._completed(rig, update=False)
            refresh()
            dress_pose.verify(context, rig, saved['dress_edit'], desired=dress_desired)
            resync.verify(context, rig, plan)
            resync.commit(rig, plan)
            owner.finish_pose_session(_original_pose)
            if finalize is not None:
                finalize()
            for target, _view in extra_views:
                target.pop(DISPLAY_OWNER, None)
            rig.pop(DISPLAY_REFS, None)
        except Exception:
            channels, view, locks, mutes, pole_angles, pole_metadata = checkpoint
            _restore_channels(rig, channels)
            _restore_locks(rig, locks)
            for con, muted in mutes:
                con.mute = muted
            for con, angle in pole_angles:
                con.pole_angle = angle
            match._restore_leg_pole_metadata(rig, pole_metadata)
            dress_pose.rollback(context, dress_checkpoint)
            display._restore(rig, view)
            for target, extra_view in extra_checkpoint:
                display._restore(target, extra_view)
            rig[SESSION] = session_raw
            owner.restore_pose_session(_original_pose)
            resync.rollback(context, rig, plan)
            _update(context, rig)
            refresh()
            resync.restore_correctives(plan)
            raise
    return True


class CHARACTERDESIGNER_OT_body_original_mode(bpy.types.Operator):
    bl_idname = 'character_designer.body_original_mode'
    bl_label = 'Original'
    bl_description = 'Switch Body, Hair and Dress between original bones and saved controls while preserving pose and Dress corrections'
    bl_options = {'REGISTER', 'UNDO'}
    action: EnumProperty(items=(('TOGGLE', 'Toggle', ''),
                               ('ORIGINAL', 'Original', 'Show native Body, Hair and Dress bones'),
                               ('CONTROLS', 'Controls', 'Return to the saved controls and preserve the pose')),
                         default='TOGGLE')

    @classmethod
    def poll(cls, context):
        try:
            from . import weight_paint_entry
            rig = display.character_rig(context)
            return (rig is not None and context.mode in {'OBJECT', 'POSE'}
                    and not weight_paint_entry.owns_rig(rig))
        except (ValueError, ReferenceError):
            return False

    def execute(self, context):
        try:
            rig = display.character_rig(context)
            _require_no_paint_session(context, rig)
            if context.mode not in {'OBJECT', 'POSE'}:
                raise ValueError('Finish the current edit or native painting before switching Original or Controls.')
            running = active(rig)
            requested = self.action == 'ORIGINAL' or (self.action == 'TOGGLE' and not running)
            if requested:
                if not running:
                    enter(context, rig)
                else:
                    ensure_dress_editable(context, rig)
                self.report({'INFO'}, 'Original bones shown. Choose Controls in Bone Display to return.')
            else:
                completed_return = False
                if running:
                    leave(context, rig)
                    completed_return = True
                elif display.view_mode(rig):
                    display.restore_view(rig)
                    completed_return = True
                try:
                    display.ensure_controls_selectable(context, rig)
                except (ValueError, RuntimeError, KeyError, TypeError, ReferenceError) as exc:
                    # The authenticated Original return has already completed.
                    # A separate display refusal must not misreport it as failed.
                    if not completed_return:
                        raise
                    self.report({'WARNING'}, f'Controls restored; current pose kept. Selection repair: {exc}')
                    return {'FINISHED'}
                self.report({'INFO'}, 'Controls restored; current pose kept.')
            return {'FINISHED'}
        except (ValueError, RuntimeError, KeyError, TypeError, ReferenceError) as exc:
            message = str(exc)
            if 'A saved Main Rig recovery data block was removed.' in message:
                message = ('This file is missing saved Main Rig recovery references; Original is currently unavailable. '
                           'Original Bones on the Weight page is still available for painting. Details: ' + message)
            self.report({'WARNING'}, message)
            return {'CANCELLED'}


def draw(layout, context):
    rig = display.character_rig(context)
    if rig is None:
        return False
    running = active(rig)
    native_view = display.view_mode(rig)
    from . import weight_paint_entry
    painting = weight_paint_entry.owns_rig(rig)
    if _weight_page(context) or painting:
        _draw_weight_switch(layout, context, rig)
        return running
    row = layout.row(align=True)
    row.enabled = context.mode in {'OBJECT', 'POSE'} and not painting
    original = row.row(align=True)
    original.enabled = running or bool(rig.data.collections_all.get('Original'))
    original.operator('character_designer.body_original_mode', text='Edit Original Pose',
                      depress=running).action = 'ORIGINAL'
    controls = row.row(align=True)
    controls.enabled = running or bool(groups.body_collection(rig)) or display.view_mode(rig) is not None
    controls.operator('character_designer.body_original_mode', text='Controls',
                      depress=not running and native_view is None).action = 'CONTROLS'
    if running:
        layout.label(text='Edit the current pose; return to Controls before keying animation.', icon='INFO')
    reset = layout.row(align=True)
    reset.enabled = context.mode == 'POSE' and not painting
    reset.operator('character_designer.reset_selected_pose_chains', text='Reset Selected Chains')
    return running


class CHARACTERDESIGNER_OT_clear_dress_corrections(bpy.types.Operator):
    bl_idname = 'character_designer.clear_dress_corrections'
    bl_label = 'Clear Dress Corrections'
    bl_description = 'Remove local Dress original pose corrections while retaining curve and physics controls'
    bl_options = {'REGISTER', 'UNDO'}
    scope: EnumProperty(items=(('SELECTED', 'Selected Bones', 'Clear selected Dress original bones'),
                               ('ALL', 'All Dress Bones', 'Clear all Dress local corrections')),
                        default='SELECTED')

    @classmethod
    def poll(cls, context):
        try:
            rig = display.character_rig(context)
            return rig is not None and not active(rig) and context.mode in {'OBJECT', 'POSE'}
        except (ValueError, ReferenceError):
            return False

    def execute(self, context):
        try:
            rig = display.character_rig(context)
            count = dress_pose.clear(context, rig, selected_only=self.scope == 'SELECTED')
            display._completed(rig, update=False)
            self.report({'INFO'}, f'Cleared {count} Dress local corrections.')
            return {'FINISHED'}
        except (ValueError, RuntimeError, KeyError, TypeError, ReferenceError) as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}


BODY_ORIGINAL_CLASSES = (CHARACTERDESIGNER_OT_body_original_mode,
                         CHARACTERDESIGNER_OT_clear_dress_corrections)
