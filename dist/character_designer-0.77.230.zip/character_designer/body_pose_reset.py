"""Explicit regional native-neutral posing, without editing Rest or animation.

Selections resolve through the same authenticated Body records as Pose capture.
The target is the current native Rest in its current unselected parent space,
as in Spine Reset and Base Pose, rather than an old captured artist pose.
"""


def resolve_scope(selected, regions):
    """Pure policy: every selected public/native input must name one exact region.

    Overlap may select the same region more than once. An ambiguous public
    input, unknown bone or empty selection refuses the complete request.
    """
    selected = tuple(selected)
    if not selected:
        raise ValueError('Select a native Body chain or its public control before Reset Selected Chains.')
    resolved = set()
    for name in selected:
        matches = [key for key, item in regions.items() if name in item['inputs']]
        if len(matches) != 1:
            raise ValueError(f'{name}: choose only supported public limb, spine or finger chains; nothing was reset.')
        resolved.add(matches[0])
    names = {name for key in resolved for name in regions[key]['native']}
    if not names:
        raise ValueError('The selection has no authenticated native Body chain.')
    return tuple(sorted(resolved)), tuple(sorted(names))


def _regions(rig, inventory):
    from . import control_pose_capture as capture, limb_ik_fk as match
    from . import torso_controls, spine_ik_fk
    body = capture._body_names(rig, inventory)
    regions = {}
    for key, entry in inventory['rigs'].items():
        native = set(match.pose_names(entry))
        inputs = set(native)
        inputs.update(entry[field].name for field in ('target', 'pole', 'heel') if entry.get(field))
        foot = entry.get('foot_controls')
        if foot:
            inputs.update(foot[field] for field in ('roll', 'toe_control') if foot.get(field))
        regions['/'.join(key)] = dict(native=native, inputs=inputs)
    torso, spine = torso_controls.get_record(rig), spine_ik_fk.get_record(rig)
    if torso:
        native = set(torso['sources'])
        inputs = native | set(torso['controls'].values()) | {torso['bend']}
        if spine:
            if set(spine['sources']) != native:
                raise ValueError('The spine and torso records disagree; no chain was reset.')
            inputs.update((spine['chest'], spine['shape']))
        regions['SPINE'] = dict(native=native, inputs=inputs)
    fingers = capture._finger_names(rig, inventory)
    # A finger is the exact connected native descendant branch below its hand.
    # No spelling, proximity, opposite-side or whole-hand fallback is used.
    for name in fingers:
        root = rig.data.bones[name]
        visited = set()
        while root.parent and root.parent.name in fingers:
            if root.name in visited or fingers[root.parent.name] != fingers[name]:
                raise ValueError('The saved finger ancestry is ambiguous; no chain was reset.')
            visited.add(root.name)
            root = root.parent
        key = 'FINGER/' + root.name
        item = regions.setdefault(key, dict(native=set(), inputs=set()))
        item['native'].add(name)
        item['inputs'].add(name)
    if any(not item['native'].issubset(body) for item in regions.values()):
        raise ValueError('A reset chain lies outside the managed native Body; nothing was changed.')
    return regions


def _admit(context, rig):
    from . import control_pose_blend as blend, animation_pose_test as test
    from . import body_original_mode as original, body_original_owner as owner
    from . import weight_paint_entry as paint, limb_ik_wrist_rotation as wrist
    from . import animation_physics
    if (context.object is not rig or context.mode not in {'OBJECT', 'POSE'}
            or context.scene.objects.get(rig.name) is not rig
            or context.view_layer.objects.get(rig.name) is not rig):
        raise ValueError('Reset chains on this character in its own Scene and View Layer.')
    if context.scene.tool_settings.use_keyframe_insert_auto:
        raise ValueError('Turn off Auto Key before Reset Selected Chains; animation keys are retained.')
    if paint.owns_rig(rig) or paint.native_painting(context):
        raise ValueError('Return to Controls before resetting the selected chains.')
    if test.active(rig) or test.natural_active(rig):
        raise ValueError('Finish the Base/Rest Pose test before resetting selected chains.')
    pose_only = blend._owner(context, rig)
    wrist._physics_idle(context, rig, animation_physics)
    cap = None
    if original.active(rig):
        cap = owner.pose_capability(context, rig)
        saved = original._require(context, rig, _original_pose=cap)
        original._validate_session_rest(rig, saved)
        relations = original._resolve(rig, saved['constraints'])
        if not all(con.mute for con, _entry in relations):
            raise ValueError('The Original constraints are not fully paused; no chain was reset.')
    return pose_only, cap


def _raw(rig):
    from . import control_pose_assets as poses
    return {pb.name: (pb.rotation_mode, {key: tuple(getattr(pb, key)) for key in poses._TRANSFORMS})
            for pb in rig.pose.bones}


def _restore_unrelated(rig, before, allowed):
    for name, (mode, channels) in before.items():
        if name in allowed:
            continue
        pb = rig.pose.bones[name]
        if pb.rotation_mode != mode:
            pb.rotation_mode = mode
        for field, value in channels.items():
            if tuple(getattr(pb, field)) != value:
                setattr(pb, field, value)


def _allowed(rig, inventory, keys, names):
    from . import torso_controls, spine_ik_fk
    result = set(names)
    for key, entry in inventory['rigs'].items():
        if '/'.join(key) not in keys:
            continue
        for field in ('target', 'pole', 'heel', 'solver_target', 'mch_upper', 'mch_lower', 'ori_upper', 'ori_lower'):
            bone = entry.get(field)
            if bone is not None:
                result.add(bone.name)
        foot = entry.get('foot_controls')
        if foot:
            result.update(foot['bones'].values())
    if 'SPINE' in keys:
        for module in (torso_controls, spine_ik_fk):
            record = module.get_record(rig)
            if record:
                result.update(record['bones'].values())
    return result


def _desired_region(rig, inventory, keys, names, desired):
    """Carry free descendants, stopping at another independently controlled chain.

    As with Reset Spine Pose, unselected limb controller inputs remain exact;
    an IK hand anchored outside the spine is not implicitly moved with it.
    """
    from . import limb_ik_fk as match, torso_controls
    controlled = {name for entry in inventory['rigs'].values() for name in match.pose_names(entry)}
    torso = torso_controls.get_record(rig)
    if torso:
        controlled.update(torso['sources'])
    wanted = set(names)
    for name in sorted(desired, key=lambda n: len(rig.pose.bones[n].parent_recursive)):
        parent = rig.data.bones[name].parent
        if name not in controlled and parent is not None and parent.name in wanted:
            wanted.add(name)
    return {name: matrix for name, matrix in desired.items() if name in wanted}


def _guard_drivers(rig, allowed, owned=()):
    # Native influence/IK drivers remain validated by the inventory. Artist
    # transform and custom-property drivers on this reset's inputs cannot be
    # overwritten by a neutral-pose request.
    prefixes = tuple(rig.pose.bones[name].path_from_id() for name in allowed)
    for curve in getattr(rig.animation_data, 'drivers', ()):
        if (curve.data_path, curve.array_index) in owned:
            continue
        for prefix in prefixes:
            if (curve.data_path.startswith(prefix + '.') and
                    curve.data_path[len(prefix):].startswith(('.location', '.rotation_', '.scale'))
                    or curve.data_path.startswith(prefix + '[')):
                raise ValueError('An artist driver controls this chain; no channels were reset.')


def _preserved_state(context, rig):
    from . import control_pose_blend as blend, control_pose_assets as poses
    from . import body_original_mode as original
    return (blend._binding(rig), blend._worklist_binding(context, rig),
            blend._pose_test_binding(rig), blend._drivers(rig), blend._drivers(rig.data),
            poses.native_rest(rig), rig.get(original.SESSION),
            tuple(value for row in rig.matrix_world for value in row),
            context.scene.frame_current, context.scene.frame_subframe,
            context.scene.tool_settings.use_keyframe_insert_auto,
            tuple((pb.name, tuple(pb.lock_location), tuple(pb.lock_rotation), pb.lock_rotation_w,
                   pb.lock_rotations_4d, tuple(pb.lock_scale)) for pb in rig.pose.bones))


def reset_selected(context, rig):
    """Reset complete selected chains; Original entry itself never invokes this.

    Original retains its exact session checkpoint, so Controls return owns the
    ordinary match of the edited result. Controls synchronizes both current
    and dormant IK/FK inputs while retaining the existing mode and animation.
    """
    from mathutils import Matrix
    from . import control_pose_assets as poses, control_pose_capture as capture
    from . import forearm_original_inventory, limb_ik_fk as match
    from . import body_original_mode as original, body_original_owner as owner
    from . import forearm_twist, bone_collections, bone_display
    pose_only, cap = _admit(context, rig)
    inventory = forearm_original_inventory.validate(rig)
    match._require_existing_switches(rig, inventory=inventory)
    regions = _regions(rig, inventory)
    selected = tuple(pb.name for pb in (context.selected_pose_bones or ())
                     if pb.id_data is rig)
    if any(pb.id_data is not rig for pb in (context.selected_pose_bones or ())):
        raise ValueError('The selection includes another rig; nothing was reset.')
    keys, names = resolve_scope(selected, regions)
    capture._validate_channels(rig, names, inventory)
    allowed = set(names) if original.active(rig) else _allowed(rig, inventory, keys, names)
    owned_drivers = {(driver['path'], driver['index'])
                     for key, entry in inventory['rigs'].items() if '/'.join(key) in keys
                     for driver in (entry.get('foot_controls') or {}).get('drivers', ())}
    _guard_drivers(rig, allowed, owned_drivers)
    values = {name: {'location': dict(enumerate((0., 0., 0.))),
                     'rotation_quaternion': dict(enumerate((1., 0., 0., 0.))),
                     'scale': dict(enumerate((1., 1., 1.)))} for name in names}
    metadata = dict(version=1, source_object=rig.name, source_slot='OB' + rig.name,
                    rest=poses.native_rest(rig), scope='SELECTED', names=list(names), include_fingers=True)
    match._update(context, rig)
    desired = _desired_region(rig, inventory, keys, names, poses.desired_pose(rig, values, metadata))
    before, preserved = _raw(rig), _preserved_state(context, rig)
    layout, display = bone_collections.snapshot_layout(rig), bone_display._snapshot(rig)
    with forearm_twist.defer_runtime(context, flush_on_exit=False) as refresh:
        try:
            with poses._transaction(context, rig):
                if original.active(rig):
                    for name in names:
                        rig.pose.bones[name].matrix_basis = Matrix.Identity(4)
                else:
                    # Remove the selected foot's authored pivot offsets before
                    # matching, rather than hiding Roll/Heel in target offsets.
                    for key, entry in inventory['rigs'].items():
                        if '/'.join(key) not in keys:
                            continue
                        foot = entry.get('foot_controls')
                        controls = {foot[field] for field in ('roll', 'toe_control')
                                    if foot and foot.get(field)}
                        if entry.get('heel') is not None:
                            controls.add(entry['heel'].name)
                        for name in controls:
                            rig.pose.bones[name].matrix_basis = Matrix.Identity(4)
                    if 'SPINE' in keys:
                        from . import torso_controls, spine_ik_fk
                        for module in (torso_controls, spine_ik_fk):
                            record = module.get_record(rig)
                            if record:
                                for name in record['bones'].values():
                                    rig.pose.bones[name].matrix_basis = Matrix.Identity(4)
                    match._update(context, rig)
                    changed = set(names) | {name for name in desired
                        if poses._difference(desired[name], rig.pose.bones[name].matrix) > 1e-7}
                    poses._match(context, rig, desired, changed, preserve_modes=True,
                                 sync_controls=True, precise_limbs=tuple(key for key in inventory['rigs']
                                     if '/'.join(key) in keys), _pose_only_owner=pose_only)
                _restore_unrelated(rig, before, allowed)
                # Reset is a pose operation; it does not change selectable
                # policy, managed collection layout, Original or other views.
                bone_collections.restore_layout(rig, layout)
                bone_display._restore(rig, display)
                match._update(context, rig)
                match._verify(rig, desired)
                if _preserved_state(context, rig) != preserved:
                    raise ValueError('Chain reset changed protected animation, Rest or session ownership; no changes kept.')
                after = _raw(rig)
                if any(after[name] != state for name, state in before.items() if name not in allowed):
                    raise ValueError('Chain reset could not retain an unrelated raw pose; no changes kept.')
                forearm_original_inventory.validate(rig)
                if cap is not None:
                    owner._check_pose_capability(cap, rig)
                refresh()
        except Exception:
            refresh()
            raise
    return dict(chains=keys, bones=names, original=original.active(rig), keyed=False)
