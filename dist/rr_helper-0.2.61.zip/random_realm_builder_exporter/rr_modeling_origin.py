import bmesh
import bpy
import math
from array import array
from mathutils import Matrix, Vector


def selected_mesh_objects_for_modeling_origin(context):
    if context is None:
        return []

    if getattr(context, "mode", "") == "EDIT_MESH":
        objects = list(getattr(context, "objects_in_mode", []) or [])
        if not objects and getattr(context, "edit_object", None) is not None:
            objects = [context.edit_object]
    else:
        objects = list(getattr(context, "selected_objects", []) or [])

    return [obj for obj in objects if obj is not None and obj.type == "MESH"]


def selected_edit_objects_for_modeling_origin(context):
    if context is None or getattr(context, "mode", "") not in {"EDIT_MESH", "EDIT_CURVE"}:
        return []

    objects = list(getattr(context, "objects_in_mode", []) or [])
    if not objects and getattr(context, "edit_object", None) is not None:
        objects = [context.edit_object]
    return [obj for obj in objects if obj is not None and obj.type in {"MESH", "CURVE"}]


def selected_empty_objects_for_modeling_origin(context):
    if context is None or getattr(context, "mode", "") != "OBJECT":
        return []
    objects = list(getattr(context, "selected_objects", []) or [])
    return objects if objects and all(obj.type == "EMPTY" for obj in objects) else []


def modeling_empty_origin_selection(context):
    """Resolve movers and a read-only active target, never selection-list order."""
    if context is None or getattr(context, "mode", "") != "OBJECT":
        return [], None
    objects = list(getattr(context, "selected_objects", []) or [])
    empties = [obj for obj in objects if obj.type == "EMPTY"]
    if not empties:
        return [], None
    if len(empties) == len(objects):
        return empties, None
    active = getattr(context, "active_object", None)
    if active is not None and active in objects and active.type != "EMPTY" and len(objects) == len(empties) + 1:
        return empties, active
    return [], None


def modeling_object_origin_selection(context):
    """Ordinary Object Mode geometry uses the 3D Cursor, without an active target."""
    if context is None or getattr(context, "mode", "") != "OBJECT":
        return []
    objects = list(getattr(context, "selected_objects", []) or [])
    if not objects or any(
        obj is None or obj.type not in {"MESH", "CURVE"} or obj.data is None
        for obj in objects
    ):
        return []
    return objects


def _origin_matrix_is_finite(matrix):
    return all(math.isfinite(value) for row in matrix for value in row)


def _origin_matrix_matches(actual, expected):
    return all(
        math.isclose(a, b, rel_tol=2.0e-5, abs_tol=2.0e-4)
        for actual_row, expected_row in zip(actual, expected)
        for a, b in zip(actual_row, expected_row)
    )


def _origin_parent_depth(obj):
    depth = 0
    parent = obj.parent
    while parent is not None:
        depth += 1
        parent = parent.parent
    return depth


def _origin_references_selected_object(owner, selected):
    for prop in owner.bl_rna.properties:
        if prop.type == "POINTER" and prop.identifier != "rna_type":
            value = getattr(owner, prop.identifier, None)
            if isinstance(value, bpy.types.Object) and value in selected:
                return True
    return False


def _origin_nodes_reference_selected_object(tree, selected, seen):
    if tree is None or tree in seen:
        return False
    seen.add(tree)
    sockets = list(tree.interface.items_tree)
    for node in tree.nodes:
        if _origin_references_selected_object(node, selected):
            return True
        sockets.extend(node.inputs)
        sockets.extend(node.outputs)
        if _origin_nodes_reference_selected_object(getattr(node, "node_tree", None), selected, seen):
            return True
    return any(
        isinstance(value := getattr(socket, "default_value", None), bpy.types.Object) and value in selected
        for socket in sockets
    )


def _origin_modifier_references_selected_object(modifier, selected):
    if _origin_references_selected_object(modifier, selected):
        return True
    if modifier.type != "NODES":
        return False
    try:
        values = modifier.values()
    except TypeError:
        # A node group with no modifier inputs can have no ID-property storage.
        values = ()
    if any(isinstance(value, bpy.types.Object) and value in selected for value in values):
        return True
    return _origin_nodes_reference_selected_object(modifier.node_group, selected, set())


_ORIGIN_STABLE_CONSTRAINT_TYPES = {
    "LIMIT_LOCATION", "LIMIT_ROTATION", "LIMIT_SCALE", "LIMIT_DISTANCE",
    "COPY_LOCATION", "COPY_ROTATION", "COPY_SCALE", "COPY_TRANSFORMS",
    "CHILD_OF", "TRACK_TO", "DAMPED_TRACK", "LOCKED_TRACK",
    "TRANSFORM", "MAINTAIN_VOLUME", "FLOOR", "STRETCH_TO",
}


def _origin_constraint_object_references(owner):
    for prop in owner.bl_rna.properties:
        if prop.identifier == "rna_type":
            continue
        if prop.type == "POINTER":
            value = getattr(owner, prop.identifier, None)
            if isinstance(value, bpy.types.Object):
                yield value
        elif prop.type == "COLLECTION":
            for item in getattr(owner, prop.identifier):
                yield from _origin_constraint_object_references(item)


def _origin_constraint_dependency_is_unsafe(obj, selected, inverse_owners, seen):
    if obj in selected:
        return True
    if obj in seen:
        return False
    seen.add(obj)
    # Drivers can read arbitrary data, including scripted access with no RNA
    # variable. Keep this conservative instead of guessing their dependencies.
    if obj.animation_data and obj.animation_data.drivers:
        return True
    if obj.parent is not None:
        if obj.parent_type != "OBJECT":
            return True
        # This edge is compensated exactly, unlike a constraint's target edge.
        if obj not in inverse_owners and _origin_constraint_dependency_is_unsafe(
            obj.parent, selected, inverse_owners, seen
        ):
            return True
    for constraint in obj.constraints:
        if constraint.type not in _ORIGIN_STABLE_CONSTRAINT_TYPES:
            return True
        for target in _origin_constraint_object_references(constraint):
            if _origin_constraint_dependency_is_unsafe(target, selected, inverse_owners, seen):
                return True
    return False


def _origin_file_has_drivers():
    # A scripted driver can read arbitrary channels without an RNA variable.
    # Include data and embedded shader trees, not only object transforms.
    for prop in bpy.data.bl_rna.properties:
        if prop.type != "COLLECTION":
            continue
        for block in getattr(bpy.data, prop.identifier):
            for owner in (block, getattr(block, "node_tree", None)):
                animation = getattr(owner, "animation_data", None)
                if animation and animation.drivers:
                    return True
    return False


def _origin_constraint_uses_world_owner(constraint):
    # Replacing parent-inverse translation with Location preserves the matrix
    # fed into a WORLD constraint. A LOCAL/CUSTOM constraint can instead read
    # the edited channels, even when its current output happens to look fixed.
    return (constraint.type in _ORIGIN_STABLE_CONSTRAINT_TYPES
            and constraint.owner_space == "WORLD")


def _origin_constraint_reads_world_target(constraint, obj):
    # Only ordinary world target edges have this guarantee. Keep custom-space
    # and collection/unknown references conservative rather than assuming that
    # every object pointer has the same space semantics as `target`.
    return (constraint.type in _ORIGIN_STABLE_CONSTRAINT_TYPES
            and getattr(constraint, "target", None) == obj
            and getattr(constraint, "target_space", None) == "WORLD"
            and getattr(constraint, "space_object", None) != obj)


def _origin_child_channel_rebase_offsets(objects, protected_objects=()):
    candidates = set(objects) - set(protected_objects)
    if not candidates or _origin_file_has_drivers():
        return {}
    # A part can supply local channels to a different object or bone. WORLD
    # readers remain valid because the target world matrix is preserved;
    # LOCAL/CUSTOM and unsupported readers must keep their target's channels.
    blocked = set()
    for owner in bpy.data.objects:
        constraint_owners = [owner]
        if owner.pose is not None:
            constraint_owners.extend(owner.pose.bones)
        for constraint_owner in constraint_owners:
            for constraint in constraint_owner.constraints:
                for target in candidates.intersection(_origin_constraint_object_references(constraint)):
                    if not _origin_constraint_reads_world_target(constraint, target):
                        blocked.add(target)
        for modifier in owner.modifiers:
            for candidate in candidates - blocked:
                if _origin_modifier_references_selected_object(modifier, {candidate}):
                    blocked.add(candidate)

    offsets = {}
    for obj in candidates - blocked:
        animation = obj.animation_data
        if (obj.parent is None or obj.parent.type != "EMPTY" or obj.parent_type != "OBJECT"
                or any(not _origin_constraint_uses_world_owner(constraint) for constraint in obj.constraints)
                or not obj.is_editable
                or obj.is_property_readonly("location")
                or obj.is_property_readonly("matrix_parent_inverse")
                or (animation and (animation.action or animation.nla_tracks or animation.drivers))):
            continue
        inverse = obj.matrix_parent_inverse.copy()
        if not all(_origin_matrix_is_finite(matrix) for matrix in (
            inverse, obj.matrix_world, obj.matrix_basis,
        )):
            continue
        try:
            offset = inverse.to_3x3().inverted() @ inverse.translation
        except ValueError:
            continue
        if all(math.isfinite(value) for value in offset):
            offsets[obj] = offset
    return offsets


def _origin_channel_normalization_watch_objects(objects):
    # Include sibling/world readers and their descendants, not just the edited
    # children. Their evaluated geometry can reveal a dependency which a matrix
    # check alone would miss (for example an object-space geometry operation).
    watched = set(objects)
    pending = list(objects)
    while pending:
        obj = pending.pop()
        for child in obj.children:
            if child not in watched:
                watched.add(child)
                pending.append(child)
        for owner in bpy.data.objects:
            if owner in watched:
                continue
            constraint_owners = [owner]
            if owner.pose is not None:
                constraint_owners.extend(owner.pose.bones)
            referenced = any(
                obj in _origin_constraint_object_references(constraint)
                for constraint_owner in constraint_owners for constraint in constraint_owner.constraints
            ) or any(_origin_modifier_references_selected_object(modifier, {obj})
                     for modifier in owner.modifiers)
            if referenced:
                watched.add(owner)
                pending.append(owner)
    return watched


def normalize_empty_child_origin_channels(context, objects, *, protected_objects=()):
    """Absorb safe parent offsets into Location without moving child geometry.

    Only the inverse's translation is removed. Its full linear transform,
    including shear, stays intact; no rotation/scale decomposition is needed.
    Existing compensated children can be repaired with this helper as well.
    """
    context.view_layer.update()
    offsets = _origin_child_channel_rebase_offsets(objects, protected_objects)
    if not offsets:
        return 0
    previous = {obj: (obj.location.copy(), obj.matrix_parent_inverse.copy(), obj.matrix_world.copy())
                for obj in offsets}
    watched = _origin_channel_normalization_watch_objects(offsets)
    world_matrices = {obj: obj.matrix_world.copy() for obj in watched | set(context.scene.objects)}
    depsgraph = context.evaluated_depsgraph_get()
    geometry = {obj: _origin_evaluated_geometry(obj, depsgraph) for obj in watched}
    try:
        for obj, offset in offsets.items():
            inverse = obj.matrix_parent_inverse.copy()
            inverse.translation = Vector()
            obj.location += offset
            obj.matrix_parent_inverse = inverse
        context.view_layer.update()
        for obj, world in world_matrices.items():
            if not _origin_matrix_matches(obj.matrix_world, world):
                raise RuntimeError(f"{obj.name}: unable to preserve its position while normalizing Location.")
        depsgraph = context.evaluated_depsgraph_get()
        for obj, expected in geometry.items():
            if not _origin_geometry_matches(_origin_evaluated_geometry(obj, depsgraph), expected):
                raise RuntimeError(f"{obj.name}: unable to preserve its evaluated geometry while normalizing Location.")
    except Exception:
        for obj, (location, inverse, _) in previous.items():
            obj.location = location
            obj.matrix_parent_inverse = inverse
        context.view_layer.update()
        raise
    return len(offsets)


def _origin_evaluated_geometry(obj, depsgraph):
    if obj.type not in {"MESH", "CURVE", "SURFACE", "FONT"}:
        return None
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh()
    if mesh is None:
        return None
    try:
        coordinates = array("f", [0.0]) * (3 * len(mesh.vertices))
        edges = array("i", [0]) * (2 * len(mesh.edges))
        loops = array("i", [0]) * len(mesh.loops)
        faces = array("i", [0]) * len(mesh.polygons)
        mesh.vertices.foreach_get("co", coordinates)
        mesh.edges.foreach_get("vertices", edges)
        mesh.loops.foreach_get("vertex_index", loops)
        mesh.polygons.foreach_get("loop_total", faces)
        return coordinates, edges, loops, faces
    finally:
        evaluated.to_mesh_clear()


def _origin_geometry_matches(actual, expected):
    if actual is None or expected is None:
        return actual is expected
    return (len(actual[0]) == len(expected[0]) and actual[1:] == expected[1:]
            and all(math.isclose(a, b, rel_tol=2.0e-5, abs_tol=2.0e-4)
                    for a, b in zip(actual[0], expected[0])))


def _apply_empty_origin(context, obj, target):
    old_world = obj.matrix_world.copy()
    child_inverses = {child: child.matrix_parent_inverse.copy() for child in obj.children}
    delta = target - old_world.translation
    if obj.parent is not None:
        parent_space = obj.parent.matrix_world @ obj.matrix_parent_inverse
        delta = parent_space.inverted().to_3x3() @ delta
    # Change location alone: decomposing matrix_world can lose shear beneath a
    # rotated, non-uniformly scaled parent or alter rotation/delta channels.
    obj.location += delta
    context.view_layer.update()
    compensation = obj.matrix_world.inverted() @ old_world
    for child, parent_inverse in child_inverses.items():
        # Keep each child's local transform and animation channels unchanged.
        child.matrix_parent_inverse = compensation @ parent_inverse
    context.view_layer.update()


def apply_empty_origins_to_cursor(context, objects):
    target = context.scene.cursor.location.copy()
    if not all(math.isfinite(value) for value in target):
        raise RuntimeError("The 3D Cursor position is not finite.")
    return apply_empty_origins_to_point(context, objects, target)


def apply_empty_origins_to_point(context, objects, target, *, protected_objects=()):
    target = Vector(target)
    if not all(math.isfinite(value) for value in target):
        raise RuntimeError("The target origin position is not finite.")
    context.view_layer.update()
    objects = sorted(objects, key=_origin_parent_depth)
    selected = set(objects)
    affected = set(objects)
    inverse_owners = set()
    for obj in objects:
        affected.update(object_descendants(obj))
        inverse_owners.update(obj.children)
    # A separately selected target may depend on the Empty through constraints,
    # drivers or modifiers. Include it in the same preflight/rollback contract.
    affected.update(protected_objects)

    # Child constraints can retain their inputs: compensation preserves the
    # product parent.matrix_world @ matrix_parent_inverse, and local channels.
    # Reject actual dependencies on a moving origin, not every constrained part.
    for obj in affected:
        if obj.parent is not None and obj.parent_type != "OBJECT":
            raise RuntimeError(f"{obj.name}: only ordinary object parenting is supported.")
        if obj.parent is not None and obj.parent.type == "CURVE" and obj.parent.data.use_path:
            raise RuntimeError(f"{obj.name}: curve path parenting is not supported.")
        animation = obj.animation_data
        if (obj in selected and obj.constraints) or (animation and animation.drivers):
            raise RuntimeError(f"{obj.name}: constraints or drivers prevent keeping parts in place.")
        if obj not in selected and _origin_constraint_dependency_is_unsafe(
            obj, selected, inverse_owners, set()
        ):
            raise RuntimeError(f"{obj.name}: a constraint or driver depends on a moving Empty, or uses an unsupported constraint.")
        for modifier in obj.modifiers:
            if _origin_modifier_references_selected_object(modifier, selected):
                raise RuntimeError(f"{obj.name}: modifier '{modifier.name}' uses this Empty; moving it could change the geometry.")
        if not all(_origin_matrix_is_finite(matrix) for matrix in (
            obj.matrix_world, obj.matrix_basis, obj.matrix_parent_inverse,
        )):
            raise RuntimeError(f"{obj.name}: invalid transform.")
        if obj in selected or obj in inverse_owners:
            if not obj.is_editable or obj.is_property_readonly("matrix_parent_inverse"):
                raise RuntimeError(f"{obj.name}: the object is read-only.")
        if obj not in selected:
            continue
        if obj.instance_type != "NONE" or obj.instance_collection is not None:
            raise RuntimeError(f"{obj.name}: collection instances cannot move independently of their contents.")
        if animation and (animation.action or animation.nla_tracks):
            raise RuntimeError(f"{obj.name}: an animated Empty cannot be repositioned independently.")
        if obj.is_property_readonly("location"):
            raise RuntimeError(f"{obj.name}: location is read-only.")
        try:
            obj.matrix_world.inverted()
            if obj.parent is not None:
                (obj.parent.matrix_world @ obj.matrix_parent_inverse).inverted()
        except ValueError as exc:
            raise RuntimeError(f"{obj.name}: zero scale or a singular transform prevents repositioning.") from exc

    original_world = {obj: obj.matrix_world.copy() for obj in affected}
    original_locations = {obj: obj.location.copy() for obj in selected | inverse_owners}
    original_inverses = {obj: obj.matrix_parent_inverse.copy() for obj in inverse_owners}
    depsgraph = context.evaluated_depsgraph_get()
    original_geometry = {obj: _origin_evaluated_geometry(obj, depsgraph)
                         for obj in affected if obj not in selected}
    try:
        for obj in objects:
            _apply_empty_origin(context, obj, target)
        # Finish all selected Empty moves first. Static independent children
        # can show useful local positions, including WORLD-only constrained
        # parts. Animated/local-dependent parts retain their compensation.
        normalize_empty_child_origin_channels(
            context, inverse_owners, protected_objects=selected | set(protected_objects),
        )
        for obj, matrix in original_world.items():
            expected = matrix.copy()
            if obj in selected:
                expected.translation = target
            if not _origin_matrix_matches(obj.matrix_world, expected):
                raise RuntimeError(f"{obj.name}: unable to preserve the assembly transforms.")
        depsgraph = context.evaluated_depsgraph_get()
        for obj, geometry in original_geometry.items():
            if not _origin_geometry_matches(_origin_evaluated_geometry(obj, depsgraph), geometry):
                raise RuntimeError(f"{obj.name}: unable to preserve the evaluated geometry.")
    except Exception:
        for obj, location in original_locations.items():
            obj.location = location
        for obj, parent_inverse in original_inverses.items():
            obj.matrix_parent_inverse = parent_inverse
        context.view_layer.update()
        raise
    return len(objects)


def _origin_evaluated_world_geometry(obj, depsgraph):
    geometry = _origin_evaluated_geometry(obj, depsgraph)
    if geometry is None:
        return None
    coordinates, edges, loops, faces = geometry
    world = obj.evaluated_get(depsgraph).matrix_world
    # Compare the visible geometry in world space: moving the origin necessarily
    # changes local coordinates, including the output of safe ordinary modifiers.
    world_coordinates = array("f", [0.0]) * len(coordinates)
    for offset in range(0, len(coordinates), 3):
        x, y, z = coordinates[offset:offset + 3]
        for axis in range(3):
            row = world[axis]
            world_coordinates[offset + axis] = row[0] * x + row[1] * y + row[2] * z + row[3]
    return world_coordinates, edges, loops, faces


def _origin_data_coordinates(data):
    """Exact coordinate backup for a checked single-user commit and rollback."""
    mesh_coordinates = None
    point_coordinates = []
    if isinstance(data, bpy.types.Mesh):
        mesh_coordinates = array("f", [0.0]) * (3 * len(data.vertices))
        data.vertices.foreach_get("co", mesh_coordinates)
    else:
        for spline in data.splines:
            for point in spline.bezier_points:
                for attribute in ("co", "handle_left", "handle_right"):
                    point_coordinates.append((point, attribute, tuple(getattr(point, attribute))))
            for point in spline.points:
                point_coordinates.append((point, "co", tuple(point.co)))
    keys = getattr(data, "shape_keys", None)
    if keys is not None:
        for block in keys.key_blocks:
            for point in block.data:
                for attribute in ("co", "handle_left", "handle_right"):
                    if hasattr(point, attribute):
                        point_coordinates.append((point, attribute, tuple(getattr(point, attribute))))
    return mesh_coordinates, point_coordinates


def _origin_update_data(data):
    if isinstance(data, bpy.types.Mesh):
        data.update()
    else:
        data.update_tag()


def _origin_restore_data_coordinates(data, backup):
    mesh_coordinates, point_coordinates = backup
    if mesh_coordinates is not None:
        data.vertices.foreach_set("co", mesh_coordinates)
    for point, attribute, coordinates in point_coordinates:
        setattr(point, attribute, coordinates)
    _origin_update_data(data)


def _origin_commit_object_data(obj, original_data, staged_data, transform):
    """Keep an editable single-user datablock's identity after staging succeeds."""
    obj.data = original_data
    original_data.transform(transform, shape_keys=True)
    _origin_update_data(original_data)


def _origin_remove_staged_data(data):
    if data.users == 0:
        collection = bpy.data.meshes if isinstance(data, bpy.types.Mesh) else bpy.data.curves
        collection.remove(data)


def _origin_check_dependent_drivers(objects):
    selected_ids = set(objects)
    for obj in objects:
        selected_ids.add(obj.data)
        if getattr(obj.data, "shape_keys", None) is not None:
            selected_ids.add(obj.data.shape_keys)
    # Object/data/socket drivers can read a moved origin or translated mesh.
    # Check explicit driver references, without blocking unrelated rig drivers.
    for collection in (bpy.data.objects, bpy.data.meshes, bpy.data.curves,
                       bpy.data.shape_keys, bpy.data.node_groups, bpy.data.materials):
        for block in collection:
            for owner in (block, getattr(block, "node_tree", None)):
                animation = getattr(owner, "animation_data", None)
                if animation is None:
                    continue
                for curve in animation.drivers:
                    if any(getattr(target, "id", None) in selected_ids
                           for variable in curve.driver.variables for target in variable.targets):
                        raise RuntimeError(f"{block.name}: a driver depends on the origin or geometry being changed.")


def apply_object_origins_to_cursor(context, objects):
    """Move ordinary geometry origins while preserving visible parts atomically."""
    objects = list(objects)
    if (getattr(context, "mode", "") != "OBJECT" or not objects or any(
        obj is None or obj.type not in {"MESH", "CURVE"} or obj.data is None for obj in objects
    )):
        raise RuntimeError("Select mesh or curve objects in Object Mode to use the 3D Cursor.")
    target = context.scene.cursor.location.copy()
    if not all(math.isfinite(value) for value in target):
        raise RuntimeError("The 3D Cursor position is not finite.")
    context.view_layer.update()
    objects.sort(key=_origin_parent_depth)
    selected = set(objects)
    inverse_owners = {child for obj in objects for child in obj.children}
    watched = _origin_channel_normalization_watch_objects(objects)

    for obj in watched:
        if obj.parent is not None and obj.parent_type != "OBJECT":
            raise RuntimeError(f"{obj.name}: only ordinary object parenting is supported.")
        if obj.parent is not None and obj.parent.type == "CURVE" and obj.parent.data.use_path:
            raise RuntimeError(f"{obj.name}: curve path parenting is not supported.")
        animation = obj.animation_data
        if obj in selected:
            if obj.constraints or (animation and (animation.action or animation.nla_tracks or animation.drivers)):
                raise RuntimeError(f"{obj.name}: constraints or animation prevent moving only its origin.")
            if (not obj.is_editable or obj.is_property_readonly("location")
                    or obj.is_property_readonly("data")):
                raise RuntimeError(f"{obj.name}: the object is read-only.")
            if obj.instance_type != "NONE" or obj.instance_collection is not None:
                raise RuntimeError(f"{obj.name}: instances cannot move independently of their contents.")
            try:
                obj.matrix_world.inverted()
                if obj.parent is not None:
                    (obj.parent.matrix_world @ obj.matrix_parent_inverse).inverted()
            except ValueError as exc:
                raise RuntimeError(f"{obj.name}: zero scale or a singular transform prevents repositioning.") from exc
        elif _origin_constraint_dependency_is_unsafe(obj, selected, inverse_owners, set()):
            raise RuntimeError(f"{obj.name}: a constraint or driver depends on a moving origin, or uses an unsupported constraint.")
        if obj in inverse_owners and (not obj.is_editable or obj.is_property_readonly("matrix_parent_inverse")):
            raise RuntimeError(f"{obj.name}: the child object is read-only.")
        for modifier in obj.modifiers:
            if _origin_modifier_references_selected_object(modifier, selected):
                raise RuntimeError(f"{obj.name}: modifier '{modifier.name}' depends on a moving origin.")
        if not all(_origin_matrix_is_finite(matrix) for matrix in (
            obj.matrix_world, obj.matrix_basis, obj.matrix_parent_inverse,
        )):
            raise RuntimeError(f"{obj.name}: invalid transform.")
    _origin_check_dependent_drivers(objects)
    depsgraph = context.evaluated_depsgraph_get()
    for instance in depsgraph.object_instances:
        if instance.is_instance and instance.parent is not None:
            instancer = instance.parent.original
            if instancer in selected:
                # to_mesh() alone cannot prove that generated instances remain
                # fixed. Reject them before staging instead of losing geometry.
                raise RuntimeError(f"{instancer.name}: generated instances prevent moving only its origin.")

    original_world = {obj: obj.matrix_world.copy() for obj in watched | set(context.scene.objects)}
    original_locations = {obj: obj.location.copy() for obj in objects}
    original_inverses = {obj: obj.matrix_parent_inverse.copy() for obj in inverse_owners}
    original_data = {obj: obj.data for obj in objects}
    reusable_data = {obj for obj in objects if obj.data.users == 1 and obj.data.is_editable}
    transforms = {
        obj: Matrix.Translation(obj.matrix_world.to_3x3().inverted() @ (obj.matrix_world.translation - target))
        for obj in objects
    }
    backups = {obj: _origin_data_coordinates(obj.data) for obj in reusable_data}
    original_geometry = {obj: _origin_evaluated_world_geometry(obj, depsgraph) for obj in watched}
    staged_data = {}
    committed = set()

    def check_result():
        context.view_layer.update()
        for obj, matrix in original_world.items():
            expected = matrix.copy()
            if obj in selected:
                expected.translation = target
            if not _origin_matrix_matches(obj.matrix_world, expected):
                raise RuntimeError(f"{obj.name}: unable to preserve object and child transforms.")
        graph = context.evaluated_depsgraph_get()
        for obj, expected in original_geometry.items():
            if not _origin_geometry_matches(_origin_evaluated_world_geometry(obj, graph), expected):
                raise RuntimeError(f"{obj.name}: moving its origin changes evaluated geometry; check origin-dependent modifiers.")

    try:
        # Copies prove the complete evaluated result before touching any original
        # single-user coordinates. Shared/linked data remains untouched throughout.
        for obj in objects:
            staged_data[obj] = obj.data.copy()
            staged_data[obj].use_fake_user = False
            staged_data[obj].transform(transforms[obj], shape_keys=True)
            _origin_update_data(staged_data[obj])
            obj.data = staged_data[obj]
        for obj in objects:
            _apply_empty_origin(context, obj, target)
        check_result()
        for obj in objects:
            if obj in reusable_data:
                committed.add(obj)  # Include a partially failed transform in rollback.
                _origin_commit_object_data(obj, original_data[obj], staged_data[obj], transforms[obj])
        check_result()
    except Exception:
        for obj in objects:
            obj.data = original_data[obj]
            obj.location = original_locations[obj]
        for obj, inverse in original_inverses.items():
            obj.matrix_parent_inverse = inverse
        for obj in committed:
            _origin_restore_data_coordinates(original_data[obj], backups[obj])
        context.view_layer.update()
        for data in staged_data.values():
            _origin_remove_staged_data(data)
        raise
    for data in staged_data.values():
        _origin_remove_staged_data(data)
    return len(objects)


def mesh_selection_origin_point(obj):
    if obj is None or obj.type != "MESH" or obj.data is None or obj.mode != "EDIT":
        return None

    try:
        edit_mesh = bmesh.from_edit_mesh(obj.data)
    except (ReferenceError, RuntimeError, ValueError):
        return None

    selected_vertices = [vertex for vertex in edit_mesh.verts if vertex.select and not vertex.hide]
    if selected_vertices:
        local_point = sum((vertex.co for vertex in selected_vertices), Vector()) / len(selected_vertices)
        return obj.matrix_world @ local_point

    selected_edges = [edge for edge in edit_mesh.edges if edge.select and not edge.hide]
    if selected_edges:
        local_point = sum(
            ((edge.verts[0].co + edge.verts[1].co) * 0.5 for edge in selected_edges),
            Vector(),
        ) / len(selected_edges)
        return obj.matrix_world @ local_point

    selected_faces = [face for face in edit_mesh.faces if face.select and not face.hide]
    if selected_faces:
        local_point = sum((face.calc_center_median() for face in selected_faces), Vector()) / len(selected_faces)
        return obj.matrix_world @ local_point
    return None


def selected_curve_coordinates(obj):
    if obj is None or obj.type != "CURVE" or obj.data is None or obj.mode != "EDIT":
        return []

    coordinates = []
    for spline in obj.data.splines:
        for point in spline.bezier_points:
            if getattr(point, "hide", False):
                continue
            if point.select_control_point or point.select_left_handle or point.select_right_handle:
                # Blender commonly selects both handles with the anchor. Always resolve
                # any selection on a Bezier triple to its control point and count it once.
                coordinates.append(point.co.copy())

        for point in spline.points:
            if point.select and not getattr(point, "hide", False):
                coordinates.append(Vector(point.co[:3]))
    return coordinates


def curve_selection_origin_point(obj):
    coordinates = selected_curve_coordinates(obj)
    if not coordinates:
        return None
    local_point = sum(coordinates, Vector()) / len(coordinates)
    return obj.matrix_world @ local_point


def modeling_selection_origin_point(obj):
    if obj is None:
        return None
    if obj.type == "MESH":
        return mesh_selection_origin_point(obj)
    if obj.type == "CURVE":
        return curve_selection_origin_point(obj)
    return None


def modeling_origin_selection_label(context):
    if context is None or getattr(context, "mode", "") not in {"EDIT_MESH", "EDIT_CURVE"}:
        return ""

    if getattr(context, "mode", "") == "EDIT_CURVE":
        count = sum(
            len(selected_curve_coordinates(obj))
            for obj in selected_edit_objects_for_modeling_origin(context)
            if obj.type == "CURVE"
        )
        if count:
            suffix = "" if count == 1 else "s"
            return f"{count} curve point{suffix} selected"
        return ""

    counts = {"vertex": 0, "edge": 0, "face": 0}
    for obj in selected_mesh_objects_for_modeling_origin(context):
        try:
            edit_mesh = bmesh.from_edit_mesh(obj.data)
        except (ReferenceError, RuntimeError, ValueError):
            continue
        counts["vertex"] += sum(vertex.select and not vertex.hide for vertex in edit_mesh.verts)
        counts["edge"] += sum(edge.select and not edge.hide for edge in edit_mesh.edges)
        counts["face"] += sum(face.select and not face.hide for face in edit_mesh.faces)

    for element_name in ("face", "edge", "vertex"):
        count = counts[element_name]
        if count:
            suffix = "" if count == 1 else "s"
            return f"{count} {element_name}{suffix} selected"
    return ""


def object_descendants(obj):
    descendants = []
    stack = list(getattr(obj, "children", []) or [])
    while stack:
        child = stack.pop(0)
        descendants.append(child)
        stack.extend(list(getattr(child, "children", []) or []))
    return descendants


def apply_origin_to_mesh_object(obj, world_point):
    if obj is None or obj.type != "MESH" or obj.data is None:
        return False

    target = Vector(world_point)
    old_world = obj.matrix_world.copy()
    new_world = old_world.copy()
    new_world.translation = target

    try:
        data_transform = new_world.inverted() @ old_world
    except Exception:
        return False

    child_world_matrices = {child: child.matrix_world.copy() for child in object_descendants(obj)}
    if obj.data.users > 1:
        obj.data = obj.data.copy()
    obj.data.transform(data_transform)
    obj.data.update()
    obj.matrix_world = new_world
    for child, matrix in child_world_matrices.items():
        if child.name in bpy.data.objects:
            child.matrix_world = matrix
    return True


def apply_origin_to_curve_object(obj, world_point):
    if obj is None or obj.type != "CURVE" or obj.data is None:
        return False

    target = Vector(world_point)
    old_world = obj.matrix_world.copy()
    new_world = old_world.copy()
    new_world.translation = target

    try:
        data_transform = new_world.inverted() @ old_world
    except Exception:
        return False

    child_world_matrices = {child: child.matrix_world.copy() for child in object_descendants(obj)}
    if obj.data.users > 1:
        obj.data = obj.data.copy()
    obj.data.transform(data_transform, shape_keys=True)
    obj.data.update_tag()
    obj.matrix_world = new_world
    for child, matrix in child_world_matrices.items():
        if child.name in bpy.data.objects:
            child.matrix_world = matrix
    return True


def apply_origin_to_modeling_object(obj, world_point):
    if obj is None:
        return False
    if obj.type == "MESH":
        return apply_origin_to_mesh_object(obj, world_point)
    if obj.type == "CURVE":
        return apply_origin_to_curve_object(obj, world_point)
    return False


def mesh_bottom_origin_point(obj):
    if obj is None or obj.type != "MESH" or obj.data is None:
        return None

    mesh = obj.data
    if not mesh.polygons or not mesh.vertices:
        return None

    try:
        normal_matrix = obj.matrix_world.to_3x3().inverted().transposed()
    except Exception:
        normal_matrix = obj.matrix_world.to_3x3()

    down = Vector((0.0, 0.0, -1.0))
    candidates = []
    for polygon in mesh.polygons:
        if not polygon.vertices:
            continue

        world_normal = normal_matrix @ polygon.normal
        if world_normal.length <= 1.0e-8:
            continue
        world_normal.normalize()

        down_score = world_normal.dot(down)
        if down_score < 0.5:
            continue

        world_points = [obj.matrix_world @ mesh.vertices[index].co for index in polygon.vertices]
        center = Vector((0.0, 0.0, 0.0))
        for point in world_points:
            center += point
        center /= len(world_points)

        min_z = min(point.z for point in world_points)
        candidates.append((min_z, center.z, -down_score, polygon.index, center))

    if not candidates:
        return None

    candidates.sort(key=lambda item: (item[0], item[1], item[2], item[3]))
    return candidates[0][4]


def modeling_origin_point_for_object(obj, settings, mode=None):
    mode = mode or getattr(settings, "modeling_origin_mode", "SELECTION")
    if mode == "SELECTION":
        return modeling_selection_origin_point(obj)
    if mode == "BOTTOM":
        return mesh_bottom_origin_point(obj)
    return None


def apply_modeling_origin(context, settings, mode=None):
    mode = mode or getattr(settings, "modeling_origin_mode", "SELECTION")
    if mode == "SELECTION":
        empty_objects, target_object = modeling_empty_origin_selection(context)
        if empty_objects:
            if target_object is not None:
                context.view_layer.update()
                # Capture before moving the Empty: the target may be one of its parts.
                target = target_object.matrix_world.translation.copy()
                return apply_empty_origins_to_point(
                    context, empty_objects, target, protected_objects=(target_object,))
            return apply_empty_origins_to_cursor(context, empty_objects)
        object_objects = modeling_object_origin_selection(context)
        if object_objects:
            return apply_object_origins_to_cursor(context, object_objects)
    objects = (
        selected_edit_objects_for_modeling_origin(context)
        if mode == "SELECTION"
        else selected_mesh_objects_for_modeling_origin(context)
    )
    if not objects:
        if mode == "SELECTION":
            raise RuntimeError("Select Empty objects, then one target object last; select only Empties to use the 3D Cursor. Mesh/curve elements require Edit Mode.")
        raise RuntimeError("Select at least one mesh object.")

    selection_points = {}
    if mode == "SELECTION":
        if getattr(context, "mode", "") not in {"EDIT_MESH", "EDIT_CURVE"}:
            raise RuntimeError("Enter Edit Mode and select a mesh element or curve point.")
        selection_points = {
            obj: point
            for obj in objects
            if (point := modeling_selection_origin_point(obj)) is not None
        }
        if not selection_points:
            raise RuntimeError("Select at least one mesh element or curve point.")
    elif mode != "BOTTOM":
        raise RuntimeError(f"Unsupported origin mode: {mode}")

    active = context.view_layer.objects.active
    original_mode = active.mode if active is not None else "OBJECT"
    restore_edit_mode = getattr(context, "mode", "") in {"EDIT_MESH", "EDIT_CURVE"}
    if restore_edit_mode and bpy.ops.object.mode_set.poll():
        bpy.ops.object.mode_set(mode="OBJECT")

    try:
        applied = 0
        missing = []
        for obj in objects:
            if obj.name not in bpy.data.objects:
                continue

            world_point = selection_points.get(obj) if mode == "SELECTION" else mesh_bottom_origin_point(obj)
            if world_point is None:
                missing.append(obj.name)
                continue

            if apply_origin_to_modeling_object(obj, world_point):
                applied += 1
    finally:
        if restore_edit_mode and active is not None and active.name in bpy.data.objects:
            context.view_layer.objects.active = active
            active.select_set(True)
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode=original_mode)

    if applied <= 0:
        if mode == "SELECTION":
            raise RuntimeError("No selected mesh elements or curve points found.")
        detail = f" ({', '.join(missing[:3])})" if missing else ""
        raise RuntimeError(f"No downward bottom face found{detail}.")
    return applied


__all__ = [name for name, value in globals().items() if callable(value) and not name.startswith("_")]
