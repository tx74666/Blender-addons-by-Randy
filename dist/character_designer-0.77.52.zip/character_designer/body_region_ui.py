"""Release and rebuild one limb region without replacing the whole body rig."""
import textwrap
import bpy

from bpy.props import EnumProperty
from bpy.types import Operator, PropertyGroup


REGION_ITEMS = (
    ('LEGS', 'Both Legs', 'Both legs, including their foot controls'),
    ('LEFT_LEG', 'Left Leg', 'Left leg, including its foot controls'),
    ('RIGHT_LEG', 'Right Leg', 'Right leg, including its foot controls'),
    ('ARMS', 'Both Arms', 'Both arms, including their wrist controls'),
    ('LEFT_ARM', 'Left Arm', 'Left arm, including its wrist controls'),
    ('RIGHT_ARM', 'Right Arm', 'Right arm, including its wrist controls'),
    # Append values to keep existing saved selections unchanged.
    ('FEET', 'Both Feet', 'Foot controls only; keep the leg IK and Pole'),
    ('LEFT_FOOT', 'Left Foot', 'Left foot controls only; keep the leg IK and Pole'),
    ('RIGHT_FOOT', 'Right Foot', 'Right foot controls only; keep the leg IK and Pole'),
)
_FOOT_SIDES = {'FEET': ('L', 'R'), 'LEFT_FOOT': ('L',), 'RIGHT_FOOT': ('R',)}
_REGION_LABELS = {item[0]: item[1] for item in REGION_ITEMS}
_ERRORS = (ValueError, RuntimeError, KeyError, TypeError, ReferenceError)
_STATUS_LABELS = {
    'BOUND': 'Controls Ready',
    'RELEASED': 'Released',
    'MISSING': 'Not Built',
    'MIXED': 'Different States',
    'ERROR': 'Needs Review',
}


def _service():
    from . import body_region
    return body_region


def _foot_records(rig):
    from . import foot_controls
    return foot_controls.records(rig)


def _rebuild_feet(context, rig, sides):
    from . import foot_controls_rebuild
    return foot_controls_rebuild.rebuild(context, rig, sides=sides)


def _state(rig, region):
    if region not in _FOOT_SIDES:
        return _service().state(rig, region)
    records = _foot_records(rig)
    found = [side in records for side in _FOOT_SIDES[region]]
    return {'status': 'BOUND' if all(found) else 'MIXED' if any(found) else 'MISSING',
            'label': _REGION_LABELS[region]}


def _settings(context):
    return getattr(getattr(context, 'scene', None), 'character_designer_body_region', None)


def _ui_single_binding(rig, data):
    if getattr(data, 'users', 0) == 1:
        return True
    # Recovery ID references also count as users. Keep draw-time admission
    # cheap; the service authenticates every reference before changing data.
    if not hasattr(rig, 'get'):
        return False
    known = (rig.get('character_designer_worklist_main_restored_v1') is not None
             or rig.get('character_designer_worklist_main_session_v1') is not None
             or any(str(key).startswith('character_designer_body_region_') for key in data.keys()))
    if not known:
        return False
    bindings = [obj for obj in bpy.data.objects if obj.type == 'ARMATURE' and obj.data is data]
    return len(bindings) == 1 and bindings[0] is rig


def _editable_rig(context):
    rig = getattr(context, 'object', None)
    data = getattr(rig, 'data', None)
    return bool(
        rig is not None and getattr(rig, 'type', None) == 'ARMATURE'
        and getattr(context, 'mode', None) in {'OBJECT', 'POSE'}
        and getattr(rig, 'is_editable', False)
        and not getattr(rig, 'library', None)
        and not getattr(rig, 'override_library', None)
        and data is not None and not getattr(data, 'library', None)
        and getattr(data, 'is_editable', True)
        and _ui_single_binding(rig, data)
    )


class CharacterDesignerBodyRegionState(PropertyGroup):
    region: EnumProperty(
        name='Part',
        description='Choose the body part to rebuild or release; original bones are kept',
        items=REGION_ITEMS,
        default='LEGS',
    )


class CHARACTERDESIGNER_OT_body_region(Operator):
    bl_idname = 'character_designer.body_region'
    bl_label = 'Regional Controls'
    bl_description = 'Rebuild or release the selected part while keeping its original bones, custom shapes and the other body controls'
    bl_options = {'REGISTER', 'UNDO'}

    region: EnumProperty(name='Part', items=REGION_ITEMS, default='LEGS')
    action: EnumProperty(
        items=(
            ('RELEASE', 'Release Controls', 'Remove only the selected part\'s generated controls so its original bones can be adjusted'),
            ('BIND', 'Rebuild Controls', 'Build this released part\'s controls around the adjusted original bones'),
            ('REBUILD', 'Rebuild Controls', 'Fit this existing part\'s controls to the current pose, keeping original bones and custom shapes'),
        ),
        default='RELEASE',
    )

    @classmethod
    def poll(cls, context):
        return _editable_rig(context)

    def execute(self, context):
        if not self.poll(context):
            self.report({'WARNING'}, 'Select a local armature in Object or Pose Mode with its own armature data.')
            return {'CANCELLED'}
        try:
            if self.action == 'RELEASE':
                if self.region in _FOOT_SIDES:
                    raise ValueError('Choose a leg or arm part to release its original bones for editing.')
                _service().release(context, context.object, self.region)
                message = 'Controls released. Adjust the original bones, then rebuild this part.'
            elif self.action == 'BIND':
                if self.region in _FOOT_SIDES:
                    raise ValueError('Use Rebuild Controls for this existing foot part.')
                _service().bind(context, context.object, self.region)
                message = 'Controls rebuilt for the selected part.'
            elif self.action == 'REBUILD':
                if self.region in _FOOT_SIDES:
                    _rebuild_feet(context, context.object, _FOOT_SIDES[self.region])
                else:
                    _service().rebuild(context, context.object, self.region)
                message = 'Controls rebuilt for the selected part; custom shapes kept.'
            else:
                raise ValueError('Choose Release to Edit or Rebuild Controls.')
            self.report({'INFO'}, message)
            return {'FINISHED'}
        except _ERRORS as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}


def draw(layout, context):
    """Only read the small region record here; backend admission runs on click."""
    settings = _settings(context)
    rig = getattr(context, 'object', None)
    if settings is None or rig is None or getattr(rig, 'type', None) != 'ARMATURE':
        return
    region = settings.region
    box = layout.box()
    box.label(text='Body Part', icon='BONE_DATA')
    box.prop(settings, 'region', text='Part')
    try:
        result = _state(rig, region)
    except _ERRORS as exc:
        result = {'status': 'ERROR', 'reason': str(exc)}
    status = result.get('status', 'ERROR')
    label = result.get('label') or _REGION_LABELS.get(region, 'Selected Part')
    status_text = _STATUS_LABELS.get(status, 'Needs Review')
    icon = 'CHECKMARK' if status == 'BOUND' else 'ERROR' if status == 'ERROR' else 'INFO'
    box.label(text=f'{label}: {status_text}', icon=icon)
    row = box.row()
    row.enabled = _editable_rig(context) and status in {'BOUND', 'RELEASED'}
    rebuilding = status == 'RELEASED'
    operator = row.operator(
        'character_designer.body_region',
        text='Rebuild Controls',
        icon='ARMATURE_DATA',
    )
    operator.region = region
    operator.action = 'BIND' if rebuilding else 'REBUILD'
    if status == 'BOUND' and region not in _FOOT_SIDES:
        row = box.row()
        row.enabled = _editable_rig(context)
        operator = row.operator('character_designer.body_region',
                                text='Release to Edit', icon='UNLINKED')
        operator.region, operator.action = region, 'RELEASE'
    if status == 'RELEASED':
        box.label(text='Adjust original bones, then rebuild.')
        if getattr(context, 'mode', None) not in {'OBJECT', 'POSE'}:
            box.label(text='Finish bone editing to rebuild.', icon='INFO')
    elif status == 'BOUND':
        if region in _FOOT_SIDES:
            box.label(text='Rebuilds foot controls; keeps leg IK and Pole.')
        else:
            box.label(text='Rebuild directly; no release needed.')
            box.label(text='Release only to edit original bones.')
    elif status == 'MIXED':
        box.label(text='Select the left or right side separately.')
    elif status == 'MISSING':
        box.label(text='No existing controls to rebuild for this part.')
    reason = result.get('reason', '')
    # The older read-only state API describes only its Release action. Keep
    # appended warnings, but do not imply Release is required for Rebuild.
    release_hint = 'Release only these generated controls; keep native bones and other body regions.'
    if status == 'BOUND' and reason.startswith(release_hint):
        reason = reason[len(release_hint):].lstrip()
    for line in textwrap.wrap(reason, 36):
        box.label(text=line)
    box.label(text='Original bones and weights are kept.')
    box.label(text='Custom control shapes are kept.')


BODY_REGION_UI_CLASSES = (
    CharacterDesignerBodyRegionState,
    CHARACTERDESIGNER_OT_body_region,
)
