"""Keep the fitted sole outline in the coordinate system of its editable IK target."""
import bpy

KEY = 'character_designer_sole_target_frame_v1'


def current(bone):
    return bone.get(KEY) == 1


def capture(target):
    from . import limb_ik as limb
    donor = target.custom_shape_transform
    return (donor.name if donor else None, limb._control_visual_state(target),
            target.bone.get(limb.CONTROL_VISUAL_DEFAULT_KEY), target.bone.get(KEY))


def restore(target, saved):
    from . import limb_ik as limb
    donor, state, default, marker = saved
    target.custom_shape_transform = target.id_data.pose.bones[donor] if donor else None
    limb._apply_control_visual_state(target, state)
    for field, value in ((limb.CONTROL_VISUAL_DEFAULT_KEY, default), (KEY, marker)):
        if value is None:
            target.bone.pop(field, None)
        else:
            target.bone[field] = value


def anchor(target, end, *, previous_matrix=None):
    from . import limb_ik as limb
    donor = target.custom_shape_transform
    if donor is not None and donor != end:
        raise limb.LimbIKError(f'{target.name} uses another display reference. Keep that custom setup.')
    if donor is not None or previous_matrix is not None and previous_matrix != target.matrix:
        fields = ('custom_shape_translation', 'custom_shape_rotation_euler', 'custom_shape_scale_xyz',
                  'custom_shape_transform')
        paths = {target.path_from_id(field) for field in fields}
        animation = target.id_data.animation_data
        if (any(f.data_path in paths for action in bpy.data.actions for f in limb._fcurves_for_action(action))
                or animation and any(f.data_path in paths for f in animation.drivers)):
            raise limb.LimbIKError(f'{target.name} has animated display offsets. Keep its current outline.')
        limb._retarget_custom_shape_frame(target, None, current_reference_matrix=previous_matrix)
    if not current(target.bone):
        target.bone[KEY] = 1


def anchor_existing(context, target, end):
    """Preserve the displayed pose when changing the Blender shape dependency."""
    if current(target.bone) and target.custom_shape_transform is None:
        return
    from . import foot_controls as feet, foot_roll_hinge as hinge
    rig = target.id_data
    names = tuple(rig.pose.bones.keys())
    inputs = hinge._held_inputs(rig, names)
    pose = {p.name: p.matrix.copy() for p in rig.pose.bones}
    saved = capture(target)
    anchor(target, end)
    try:
        feet._update(context, rig)
        hinge._restore_held_inputs(context, rig, inputs, names)
        feet._verify_pose(rig, pose)
    except Exception:
        restore(target, saved)
        feet._update(context, rig)
        hinge._restore_held_inputs(context, rig, inputs, names)
        feet._verify_pose(rig, pose)
        raise
