"""Explicit controller preparation and independently retained motion editing."""

import math
import time

import bpy

_OPENING = False
_POLLING = False
_PENDING = {}
_ACTIVE_INTERVAL = .016
_CHILD_INTERVAL = .25


def _target(home, expected):
    target = home.character_designer_setup.rig
    if (home.library or home.override_library or target is None or target != expected
            or target.type != 'ARMATURE' or target.library or target.override_library
            or not target.is_editable or target.data.library or target.data.override_library
            or home.objects.get(target.name) != target or target.mode == 'EDIT'):
        raise ValueError('The controller edit needs its locally editable character in the original scene outside Edit Mode.')
    return target


def _record(home, row, *, create=True):
    records = home.character_designer_controller_motions
    identity = home.character_designer_animation_worklist.workspace_identity
    key = row.work_item_id or row.clip_key
    target = home.character_designer_setup.rig
    matches = [record for record in records if record.workspace_identity == identity
               and record.work_item_id == key and record.target == target]
    if len(matches) > 1:
        raise ValueError('This motion has multiple saved controller edits. Resolve their identity before opening it.')
    if matches:
        return matches[0]
    if not create:
        return None
    index = len(records)
    record = records.add()
    try:
        record.workspace_identity = identity
        record.work_item_id = key
        record.clip_key = row.clip_key
        record.target = target
    except Exception:
        records.remove(index)
        raise
    return record


def _publish(record, row, built):
    values = dict(source_rig=row.rig, source_action=row.custom_action, source_slot=row.custom_slot,
                  source_fingerprint=built.source_fingerprint, controller_action=built.action,
                  controller_slot=built.slot, state='READY', error='')
    previous = {key: getattr(record, key) for key in values}
    try:
        for key, value in values.items():
            setattr(record, key, value)
    except Exception as exc:
        failures = []
        for key, value in previous.items():
            try:
                setattr(record, key, value)
            except Exception as recovery:
                failures.append(str(recovery))
        if failures:
            raise RuntimeError('Controller edit publication needs recovery: ' + '; '.join(failures)) from exc
        raise


def _native(context, scene, row, message='', *, mapping_needed=False):
    from . import animation_worklist as worklist, animation_worklist_edit_scene as edit_scene
    previous_scene = context.scene
    try:
        context.window.scene = scene
        worklist.activate(context, row.item_id, 'CUSTOM')
    except Exception as exc:
        try:
            setup = getattr(previous_scene, 'character_designer_setup', None)
            if setup is not None and setup.rig is not None and edit_scene.editing_scene(previous_scene) == scene:
                return_to_character(context, previous_scene)
            elif context.window.scene != previous_scene:
                context.window.scene = previous_scene
        except Exception as recovery:
            raise RuntimeError('Native motion activation needs context recovery: ' + str(recovery)) from exc
        raise
    result = dict(state='MAPPING_NEEDED' if mapping_needed else 'NATIVE',
                  message=message or 'Original bone editing.')
    saved = worklist.state(context)
    saved.status, saved.has_error = result['message'], mapping_needed
    return result


def _return_identity(home, rig):
    from . import animation_controller_worker as worker, animation_controller_isolation as isolation
    return (home.character_designer_setup.rig, rig.data, worker._binding(rig),
            home.frame_current, home.frame_subframe,
            worker._digest(worker._value(isolation._graph(rig))))


def _restore_changed_inputs(rig, before, after):
    from . import controller_animation as controller
    if before['constraints'] != after['constraints'] or before['pose'].keys() != after['pose'].keys():
        raise ValueError('The character constraints or bone ownership changed during return.')
    def numeric(value):
        return ((type(value) in (bool, int, float) and math.isfinite(value))
                or isinstance(value, (tuple, list)) and all(numeric(item) for item in value))
    changes = []
    blocks = [(rig, before['object'], after['object'])] + [
        (rig.pose.bones[name], values, after['pose'][name]) for name, values in before['pose'].items()]
    for block, saved, current in blocks:
        if (saved['rotation_mode'] != current['rotation_mode']
                or saved['settings'].keys() != current['settings'].keys()
                or saved['properties'].keys() != current['properties'].keys()):
            raise ValueError('The character input structure changed during return.')
        for field in controller._TRANSFORMS:
            if saved[field] != current[field]:
                changes.append((block, field, saved[field], False))
        for group in ('settings', 'properties'):
            for field, value in saved[group].items():
                if value != current[group][field]:
                    if not numeric(value) or not numeric(current[group][field]):
                        raise ValueError('An unsupported character setting changed during return: ' + field)
                    changes.append((block, field, value, group == 'properties'))
    for block, field, value, custom in changes:
        if custom:
            block[field] = value
        else:
            setattr(block, field, value)


def return_to_character(context, home):
    """Preserve inputs held immediately before this switch, never a departure pose."""
    from . import animation_worklist as worklist, animation_link_source as source
    from . import animation_controller_worker as worker
    worklist._idle(context)
    rig = _target(home, home.character_designer_setup.rig)
    caller = source._context_state(context)
    identity = _return_identity(home, rig)
    before = worker._raw_packet(rig)
    try:
        context.window.scene = home
        if _return_identity(home, rig) != identity:
            raise ValueError('The character binding, frame or ownership changed during return.')
        _restore_changed_inputs(rig, before, worker._raw_packet(rig))
        context.view_layer.update()
        if _return_identity(home, rig) != identity or worker._raw_packet(rig) != before:
            raise RuntimeError('The current character inputs did not survive the native return update.')
    except Exception as exc:
        try:
            source._restore_context(context, caller, playing=False)
            if _return_identity(home, rig) == identity:
                _restore_changed_inputs(rig, before, worker._raw_packet(rig))
        except Exception as recovery:
            raise RuntimeError('Returning to the character needs recovery: ' + str(recovery)) from exc
        raise


def _activate(context, home, record):
    from . import natural_bind_mode, unity_animation as ua
    rig = _target(home, record.target)
    recovery = ''
    try:
        with natural_bind_mode.defer_expiry(rig) as transition:
            result = _activate_provisional(context, home, record)
            transition.commit()
    except natural_bind_mode.ExpiryCommitError as exc:
        recovery = str(exc)
    if not recovery:
        try:
            # The committed expiry can remove a neutral solver and restore its
            # held inputs. Evaluate the selected Action after that boundary.
            ua._set_frame(home, home.frame_current + home.frame_subframe)
            context.view_layer.update()
        except Exception as exc:
            recovery = str(exc)
    if recovery:
        message = 'The controller Action is open, but its pose refresh failed. Open this motion again. ' + recovery
        settings = home.character_designer_animation_worklist
        settings.status, settings.has_error = message, True
        return dict(state='CONTROLLER_RECOVERY', message=message)
    return result


def _activate_provisional(context, home, record):
    from .animation_local_motion_pins import assign_character_action
    from .animation_original_inputs_ui import original_inputs_live
    from . import animation_worklist as worklist, animation_composition as composition
    from . import animation_link_source as source, unity_animation as ua
    from . import controller_animation as controller
    if record.state != 'READY':
        raise ValueError('The saved controller edit is incomplete. Its Action was retained for recovery.')
    rig = _target(home, record.target)
    caller = source._context_state(context)
    saved = None
    try:
        worklist._idle(context)
        if context.scene != home:
            return_to_character(context, home)
        else:
            context.window.scene = home
        worklist._idle(context)
        if original_inputs_live(context):
            raise ValueError('Finish editing Original Rigging Inputs first.')
        if composition.active(rig):
            raise ValueError('Close Composition before switching controller Actions; both drafts are retained.')
        if ua.active_preview(rig):
            raise ValueError('Restore the unrelated Unity test preview before switching controller Actions.')
        if context.view_layer.objects.get(rig.name) != rig:
            raise ValueError('The character must be available in the current view layer.')
        start, end = map(float, record.controller_action.frame_range)
        if not math.isfinite(start) or not math.isfinite(end) or start > end:
            raise ValueError('The controller Action has an invalid frame range.')
        ad = rig.animation_data
        prior_action = ad.action if ad else None
        settings = home.character_designer_animation_worklist
        window_settings = context.window_manager.character_designer_animation
        range_fields = ('frame_start', 'frame_end', 'frame_preview_start', 'frame_preview_end', 'use_preview_range')
        saved = dict(context=source._context_state(context), ad=ad,
                     action=prior_action, slot=ad.action_slot if ad else None,
                     fake=prior_action.use_fake_user if prior_action else None,
                     animation={key: getattr(ad, key) for key in ('use_nla', 'action_blend_type', 'action_influence')} if ad else {},
                     range={key: getattr(home, key) for key in range_fields},
                     frame=home.frame_current + home.frame_subframe,
                     auto_key=home.tool_settings.use_keyframe_insert_auto,
                     hidden=rig.hide_get(), target=window_settings.target,
                     pose=controller._raw(rig, tuple(bone.name for bone in rig.pose.bones)),
                     catalog_index=settings.catalog_index,
                     status=settings.status, has_error=settings.has_error)
        ua._set_playing(context, False)
        assign_character_action(rig, record.controller_action, record.controller_slot)
        ad = rig.animation_data
        ad.use_nla, ad.action_blend_type, ad.action_influence = False, 'REPLACE', 1.0
        home.tool_settings.use_keyframe_insert_auto = False
        home.frame_start = home.frame_preview_start = math.floor(start)
        home.frame_end = home.frame_preview_end = max(math.ceil(end), home.frame_start)
        home.use_preview_range = True
        ua._set_frame(home, start)
        for selected in context.selected_objects:
            selected.select_set(False)
        rig.hide_set(False)
        rig.select_set(True)
        context.view_layer.objects.active = rig
        window_settings.target = rig
        context.view_layer.update()
        selected_index = next((i for i, row in enumerate(settings.catalog) if row.clip_key == record.clip_key), None)
        if selected_index is not None:
            settings.catalog_index = selected_index
        settings.status, settings.has_error = 'Controller editing.', False
    except Exception as exc:
        failures = []
        def restore(label, callback):
            try:
                callback()
            except Exception as recovery:
                failures.append(label + ': ' + str(recovery))
        if saved is not None:
            if saved['ad'] is None:
                restore('animation data', rig.animation_data_clear)
            else:
                restore('Action', lambda: setattr(saved['ad'], 'action', saved['action']))
                restore('Action slot', lambda: setattr(saved['ad'], 'action_slot', saved['slot']))
                for key, value in saved['animation'].items():
                    restore(key, lambda key=key, value=value: setattr(saved['ad'], key, value))
            if saved['action'] is not None:
                restore('Action retention', lambda: setattr(saved['action'], 'use_fake_user', saved['fake']))
            for key, value in saved['range'].items():
                restore(key, lambda key=key, value=value: setattr(home, key, value))
            restore('auto key', lambda: setattr(home.tool_settings, 'use_keyframe_insert_auto', saved['auto_key']))
            restore('frame', lambda: ua._set_frame(home, saved['frame']))
            restore('held character inputs', lambda: controller._restore_raw(rig, saved['pose']))
            restore('character context', lambda: source._restore_context(context, saved['context'], playing=False))
            restore('character pose evaluation', lambda: saved['context']['view_layer'].update())
            restore('character visibility', lambda: rig.hide_set(saved['hidden']))
            restore('animation target', lambda: setattr(window_settings, 'target', saved['target']))
            restore('catalog selection', lambda: setattr(settings, 'catalog_index', saved['catalog_index']))
            restore('status', lambda: setattr(settings, 'status', saved['status']))
            restore('error status', lambda: setattr(settings, 'has_error', saved['has_error']))
        restore('caller context', lambda: source._restore_context(context, caller, playing=True))
        if failures:
            raise RuntimeError('Controller motion opening needs recovery: ' + '; '.join(failures)) from exc
        raise
    return dict(state='CONTROLLER', message='Controller editing.')


def _resolve_row(context, home, clip_key):
    from . import animation_worklist as worklist, animation_worklist_edit_scene as edit_scene
    scene = edit_scene.editing_scene(home)
    if scene is None or context.window is None:
        raise ValueError('The editing scene for this workspace is unavailable.')
    if sum(row.clip_key == clip_key for row in scene.character_designer_animation_worklist.items) > 1:
        raise ValueError('This motion has multiple source work items. Resolve their identity before opening it.')
    row = edit_scene._local_row(scene, clip_key)
    if row is None:
        if not any(entry.clip_key == clip_key and entry.ready
                   for entry in home.character_designer_animation_worklist.catalog):
            raise ValueError('This motion is no longer in the prepared list.')
        previous = context.window.scene
        try:
            context.window.scene = scene
            row = worklist.add(context, clip_key, activate_new=False, prepare_controls=False)
        finally:
            if previous == home:
                return_to_character(context, home)
            elif context.window.scene != previous:
                context.window.scene = previous
    return scene, row


def open_motion(context, home, clip_key, *, asynchronous=False):
    """Open a retained controller edit or original motion; never start conversion."""
    global _OPENING
    from . import animation_worklist as worklist
    if _OPENING:
        raise RuntimeError('Finish opening the current motion before opening another controller edit.')
    _OPENING = True
    try:
        worklist._idle(context)
        scene, row = _resolve_row(context, home, clip_key)
        record = _record(home, row, create=False)
        if record is not None and record.controller_action is not None:
            return _activate(context, home, record)
        return _native(context, scene, row)
    finally:
        _OPENING = False


def _eligible_rows(home):
    """All workspace rows, independent of UI selection, search and pin filters."""
    from . import animation_worklist_edit_scene as edit_scene
    scene = edit_scene.editing_scene(home)
    if scene is None:
        return ()
    rows = []
    source_rows = scene.character_designer_animation_worklist.items
    counts = {}
    for row in source_rows:
        counts[row.clip_key] = counts.get(row.clip_key, 0) + 1
    seen = set(counts)
    for row in source_rows:
        if (row.clip_key and not _authored_row(row) and row.rig is not None
                and row.custom_action is not None and row.source_action is not None
                and counts[row.clip_key] == 1):
            rows.append(row)
    for row in home.character_designer_animation_worklist.catalog:
        if row.clip_key and not _authored_row(row) and row.ready and row.clip_key not in seen:
            rows.append(row)
            seen.add(row.clip_key)
    return tuple(rows)


def _authored_row(row):
    return bool(getattr(row, 'new_animation', False) or getattr(row, 'new_action_id', '')
                or getattr(row, 'current_rig_revision', '') or row.clip_key.startswith('new:')
                or getattr(row, 'composition_json', ''))


def missing_motions(home):
    """Known mapping failures require explicit Retry, never an automatic bulk retry."""
    rows = []
    for row in _eligible_rows(home):
        try:
            record = _record(home, row, create=False)
        except ValueError:
            continue  # Ambiguous saved edits need review, never replacement.
        if record is None or (record.controller_action is None and record.state != 'MAPPING_NEEDED'):
            rows.append(row)
    return tuple(rows)


def _queue_for_home(home):
    for key, item in _PENDING.items():
        try:
            if item['home'] == home:
                return key, item
        except ReferenceError:
            continue
    return None, None


def pending(home, clip_key=None):
    key, item = _queue_for_home(home)
    if item is None:
        return None
    queued = clip_key is not None and clip_key != item.get('clip_key')
    if queued and not any(entry['clip_key'] == clip_key for entry in item['remaining']):
        return None
    job = item.get('job')
    phase = 'Cancelling' if item['cancel_requested'] else ('Queued' if queued else (
        job['phase'] if job is not None else item['phase']))
    return dict(job_id=key, phase=phase, elapsed=max(0, int(time.monotonic() - item['started'])),
                cancelling=item['cancel_requested'], error=item.get('error', ''),
                completed=item['completed'], skipped=item['skipped'], failed=item['failed'],
                total=item['total'], name=item.get('name', ''), queued=queued)


def _enqueue(context, home, rows, *, retry=False):
    from . import animation_worklist as worklist
    import uuid
    worklist._idle(context)
    if context.window is None:
        raise ValueError('Prepare controls from an active Blender window.')
    target = _target(home, home.character_designer_setup.rig)
    entries = [dict(clip_key=row.clip_key, work_item_id=getattr(row, 'work_item_id', ''),
                    catalog_only=not hasattr(row, 'custom_action'), retry=retry, name=row.name) for row in rows]
    existing_key, existing = _queue_for_home(home)
    if existing is not None:
        if existing['cancel_requested']:
            return dict(state='PENDING', message='Wait for cancellation to finish before preparing again.', job_id=existing_key)
        if existing['target'] != target or existing['workspace'] != home.character_designer_animation_worklist.workspace_identity:
            raise ValueError('Finish or cancel the previous character preparation first.')
        queued = {entry['clip_key'] for entry in existing['remaining']} | {existing['clip_key']}
        added = [entry for entry in entries if entry['clip_key'] not in queued]
        existing['remaining'].extend(added)
        existing['total'] += len(added)
        _redraw_pending()
        return dict(state='PENDING', message='Controller preparation is queued.', job_id=existing_key)
    if not entries:
        return dict(state='READY', message='No missing controller motions to prepare.')
    key = uuid.uuid4().hex
    layer = context.view_layer if context.scene == home else home.view_layers[0]
    _PENDING[key] = dict(home=home, target=target, layer=layer, window=context.window,
                         workspace=home.character_designer_animation_worklist.workspace_identity,
                         remaining=entries, clip_key=None, name='', job=None,
                         started=time.monotonic(), phase='Queued', cancel_requested=False,
                         completed=0, failed=0, skipped=0, total=len(entries), error='')
    try:
        _start_runtime()
    except BaseException:
        _PENDING.pop(key, None)
        raise
    _redraw_pending()
    return dict(state='PENDING', message='Controller preparation queued. Completed motions stay ready to open.', job_id=key)


def prepare_motion(context, home, clip_key):
    rows = [row for row in _eligible_rows(home) if row.clip_key == clip_key]
    if len(rows) != 1:
        raise ValueError('This motion is no longer available for controller preparation.')
    record = _record(home, rows[0], create=False)
    if record is not None and record.controller_action is not None:
        if record.state != 'READY':
            raise ValueError('The saved controller edit is incomplete. Its Action was retained for recovery.')
        return dict(state='READY', message='Controllers already prepared. Open the motion to edit them.')
    return _enqueue(context, home, rows, retry=True)


def prepare_missing(context, home):
    rows = list(missing_motions(home))
    settings = context.scene.character_designer_animation_worklist
    choices = settings.items if settings.items else settings.catalog
    index = getattr(settings, 'list_cursor', settings.active_index) if settings.items else settings.catalog_index
    selected = choices[index].clip_key if 0 <= index < len(choices) else None
    rows.sort(key=lambda row: row.clip_key != selected)
    return _enqueue(context, home, rows)


def _row_for_pending(item):
    from . import animation_worklist_edit_scene as edit_scene
    home = item['home']
    if home.character_designer_animation_worklist.workspace_identity != item['workspace']:
        raise ValueError('The motion workspace changed during preparation. Its disk result was retained.')
    scene = edit_scene.editing_scene(home)
    row = edit_scene._local_row(scene, item['clip_key']) if scene is not None else None
    if (row is None or (row.work_item_id or row.clip_key) != item['work_item_id']
            or row.rig != item['source_rig'] or row.custom_action != item['source_action']
            or row.custom_slot != item['source_slot']):
        raise ValueError('The source work item changed during preparation. Its disk result was retained.')
    if (scene.render.fps, scene.render.fps_base) != item['source_timing']:
        raise ValueError('The source motion timing changed during preparation. Prepare again with its current timing.')
    _target(home, item['target'])
    return scene, row


def _start_next(context, key):
    from . import animation_controller_worker as worker
    item = _PENDING[key]
    home = item['home']
    if home.character_designer_animation_worklist.workspace_identity != item['workspace']:
        raise ValueError('The motion workspace changed before preparation started.')
    _target(home, item['target'])
    if item['clip_key'] is None:
        entry = item['remaining'].pop(0)
        item.update(clip_key=entry['clip_key'], name=entry['name'], phase='Preparing motion', entry=entry,
                    outcome=None)
        return  # Let the queued name/progress draw before import or native capture.
    entry = item['entry']
    item['phase'] = 'Importing motion'
    scene, row = _resolve_row(context, home, entry['clip_key'])
    expected_identity = entry['work_item_id'] or ('' if entry['catalog_only'] else entry['clip_key'])
    if expected_identity and (row.work_item_id or row.clip_key) != expected_identity:
        raise ValueError('The queued motion identity changed. Prepare its current entry again.')
    record = _record(home, row, create=False)
    if record is not None and record.controller_action is not None:
        if record.state != 'READY':
            raise ValueError('The saved controller edit is incomplete; its Action was retained.')
        _finish_item(key, 'SKIPPED')
        return
    if record is not None and record.state == 'MAPPING_NEEDED' and not entry['retry']:
        item['error'] = record.error
        _finish_item(key, 'MAPPING_NEEDED')
        return
    item.update(work_item_id=row.work_item_id or row.clip_key, source_rig=row.rig,
                source_action=row.custom_action, source_slot=row.custom_slot,
                source_timing=(scene.render.fps, scene.render.fps_base))
    with context.temp_override(scene=home, view_layer=item['layer']):
        item['job'] = worker.begin(bpy.context, row.rig, row.custom_action, row.custom_slot,
                                   item['target'], source_fps=scene.render.fps / scene.render.fps_base)
    item['phase'] = 'Preparing inputs'


def cancel_pending(key):
    from . import animation_controller_worker as worker
    item = _PENDING.get(key)
    if item is None:
        return
    item['cancel_requested'] = True
    item['phase'] = 'Cancelling'
    if item['job'] is not None:
        worker.request_cancel(item['job'])
    _start_runtime()
    _redraw_pending()


def _pending_error(item, error):
    job = item.get('job')
    message = str(error) + (' Worker files: ' + str(job['root']) if job is not None else '')
    item['error'], item['phase'] = message, 'Needs attention'
    try:
        settings = item['home'].character_designer_animation_worklist
        settings.status, settings.has_error = message, True
    except (ReferenceError, AttributeError):
        pass


def _finish_item(key, outcome):
    from . import animation_controller_worker as worker
    item = _PENDING[key]
    outcome = item.get('outcome') or outcome
    item['outcome'] = outcome
    job = item.get('job')
    if job is not None:
        if worker.process_running(job):
            return False
        worker.close(job)
    item['job'] = None
    if outcome in {'READY', 'SKIPPED', 'MAPPING_NEEDED', 'ERROR'}:
        field = {'READY': 'completed', 'SKIPPED': 'skipped', 'MAPPING_NEEDED': 'failed', 'ERROR': 'failed'}[outcome]
        item[field] += 1
    item.update(clip_key=None, name='', phase='Queued', outcome=None)
    if item['cancel_requested'] or not item['remaining']:
        try:
            settings = item['home'].character_designer_animation_worklist
            summary = ('Preparation cancelled. ' if item['cancel_requested'] else 'Preparation complete. ')
            summary += '%d ready, %d skipped, %d need attention.' % (item['completed'], item['skipped'], item['failed'])
            settings.status = summary + (' ' + item['error'] if item['error'] else '')
            settings.has_error = bool(item['failed'] or item['error'])
        except (ReferenceError, AttributeError):
            pass
        _PENDING.pop(key, None)
    return True


def _mapping_needed(item, error):
    _scene, row = _row_for_pending(item)
    record = _record(item['home'], row)
    if record.controller_action is not None:
        raise ValueError('An existing controller edit must be reviewed before preparing again.')
    previous = record.state, record.error
    try:
        record.state, record.error = 'MAPPING_NEEDED', str(error)
    except Exception:
        record.state, record.error = previous
        raise
    item['error'] = str(error)


def _discard_unpublished(action):
    action.use_fake_user = False
    if action.users:
        action.use_fake_user = True
        raise RuntimeError('The unbound controller result acquired another user; it was retained for recovery.')
    try:
        bpy.data.actions.remove(action)
    except Exception:
        action.use_fake_user = True
        raise


def finalize_pending(context, key):
    from . import animation_controller_worker as worker, animation_controller_mapping as mapping
    from . import animation_action_browser as browser
    item = _PENDING.get(key)
    if item is None or item['job'] is None:
        raise ValueError('This controller preparation is no longer pending.')
    if item.get('finalizing'):
        raise RuntimeError('This controller result is already being published.')
    item['finalizing'] = True
    home, job = item['home'], item['job']
    created, record, outcome = None, None, 'ERROR'
    try:
        if item['cancel_requested'] or job['cancel_requested']:
            worker.request_cancel(job)
            outcome = 'CANCELLED'
            return dict(state='CANCELLED', message='Preparation cancelled. Completed controller edits were retained.')
        scene, row = _row_for_pending(item)
        record = _record(home, row, create=False)
        if record is not None and record.controller_action is not None:
            outcome = 'SKIPPED'
            return dict(state='READY', message='The existing controller edit was retained; no result was appended.')
        with context.temp_override(scene=home, view_layer=item['layer']):
            built = worker.finish(job)
        created = built.action
        browser.classify_action(created, item['target'], role='WORK', label=row.name,
                                clip_id=row.work_item_id or row.clip_key)
        created.name = home.character_designer_animation_worklist.target_name + ' · ' + row.name + ' · Controllers'
        created.use_fake_user = True
        _row_for_pending(item)
        if item['cancel_requested'] or job['cancel_requested']:
            item['cancel_requested'] = True
            _discard_unpublished(created)
            created = None
            outcome = 'CANCELLED'
            return dict(state='CANCELLED', message='Preparation cancelled. Completed controller edits were retained.')
        record = _record(home, row)
        _publish(record, row, built)
        outcome = 'READY'
        return dict(state='READY', message='Controllers prepared. Open this motion to edit them.')
    except mapping.MappingNeeded as exc:
        try:
            _mapping_needed(item, exc)
            outcome = 'MAPPING_NEEDED'
            return dict(state='MAPPING_NEEDED', message=str(exc))
        except Exception as recovery:
            item['cancel_requested'] = True
            _pending_error(item, recovery)
            raise
    except Exception as exc:
        item['cancel_requested'] = True
        _pending_error(item, exc)
        if created is not None and (record is None or record.controller_action is None):
            _discard_unpublished(created)
        raise
    finally:
        item['finalizing'] = False
        try:
            _finish_item(key, outcome)
        except Exception as recovery:
            item['cancel_requested'] = True
            _pending_error(item, recovery)
            raise


def _redraw_pending():
    for wm in bpy.data.window_managers:
        for window in wm.windows:
            if window.screen:
                for area in window.screen.areas:
                    if area.type in {'DOPESHEET_EDITOR', 'VIEW_3D'}:
                        area.tag_redraw()


def _poll_pending():
    global _POLLING
    if _POLLING:
        return _ACTIVE_INTERVAL
    _POLLING = True
    try:
        return _poll_queues()
    finally:
        _POLLING = False


def _poll_queues():
    from . import animation_controller_worker as worker, animation_controller_mapping as mapping
    for key, item in tuple(_PENDING.items()):
        try:
            job = item.get('job')
            if job is None:
                if item['cancel_requested']:
                    _finish_item(key, 'CANCELLED')
                    continue
                window = item['window']
                if not any(candidate == window for candidate in bpy.context.window_manager.windows):
                    raise ValueError('The preparation window was closed. Prepare again from the character scene.')
                with bpy.context.temp_override(window=window):
                    _start_next(bpy.context, key)
                continue
            if item['cancel_requested'] and not job['cancel_requested']:
                worker.request_cancel(job)
            result = worker.poll(job)
            if result is None:
                continue
            if result['state'] == 'CANCELLED':
                item['cancel_requested'] = True
                _finish_item(key, 'CANCELLED')
                continue
            if result['state'] != 'EXITED':
                raise RuntimeError('The controller worker returned an unsupported completion state.')
            completed = bpy.ops.character_designer.finish_controller_motion(job_id=key)
            if completed != {'FINISHED'} and key in _PENDING and item.get('job') is job:
                raise RuntimeError('Controller result publication did not finish; the worker files were retained.')
        except mapping.MappingNeeded as exc:
            try:
                _mapping_needed(item, exc)
                _finish_item(key, 'MAPPING_NEEDED')
            except Exception as recovery:
                _pending_error(item, recovery)
                _abort_pending(key, item)
        except Exception as exc:
            _pending_error(item, exc)
            _abort_pending(key, item)
    _redraw_pending()
    if _PENDING:
        active = any(item['cancel_requested'] or item.get('job') is None
                     or item['job'].get('state') != 'RUNNING' for item in _PENDING.values())
        return _ACTIVE_INTERVAL if active else _CHILD_INTERVAL
    _remove_handlers()
    return None


def _abort_pending(key, item):
    from . import animation_controller_worker as worker
    item['cancel_requested'] = True
    try:
        if item.get('job') is not None:
            worker.request_cancel(item['job'])
        if key in _PENDING:
            _finish_item(key, 'ERROR')
    except Exception as recovery:
        # Keep the timer and owner until its child/partial append can be safely
        # released; a failed cleanup must never orphan an active process.
        _pending_error(item, recovery)


def _cancel_for_read(_unused):
    for key in tuple(_PENDING):
        try:
            cancel_pending(key)
        except Exception as exc:
            _PENDING[key]['error'] = str(exc)


def _remove_handlers():
    for name in ('load_pre', 'undo_pre', 'redo_pre'):
        handlers = getattr(bpy.app.handlers, name)
        if _cancel_for_read in handlers:
            handlers.remove(_cancel_for_read)


def _start_runtime():
    bpy.app.handlers.persistent(_cancel_for_read)
    added = []
    registered = bpy.app.timers.is_registered(_poll_pending)
    try:
        for name in ('load_pre', 'undo_pre', 'redo_pre'):
            handlers = getattr(bpy.app.handlers, name)
            if _cancel_for_read not in handlers:
                handlers.append(_cancel_for_read)
                added.append(handlers)
        if not registered:
            bpy.app.timers.register(_poll_pending, first_interval=_ACTIVE_INTERVAL, persistent=True)
    except Exception:
        for handlers in added:
            handlers.remove(_cancel_for_read)
        if not registered and bpy.app.timers.is_registered(_poll_pending):
            bpy.app.timers.unregister(_poll_pending)
        raise


def stop_runtime():
    _cancel_for_read(None)
    if not _PENDING:
        _remove_handlers()
        if bpy.app.timers.is_registered(_poll_pending):
            bpy.app.timers.unregister(_poll_pending)
