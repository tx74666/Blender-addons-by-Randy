"""One operation-local admission/capture/content proof for one or both wrists.

The guard lives only in the returned plan. Every apply rechecks fresh complete
Custom/Source contents; no proof is reused across operations or across writes.
"""

PLAN_API = 1


def _service():
    from . import limb_ik_wrist_rotation
    return limb_ik_wrist_rotation


def _proof():
    from . import limb_ik_wrist_proof
    return limb_ik_wrist_proof


def prepare(context, admission, *, mirror_allowed=False):
    service = _service()
    offset, api, _physics, rig, target, _end, _forearm, inventory, _key, _entry, _unused = admission
    animation = rig.animation_data
    action = animation.action if animation else None
    variant = _proof().prepare_variant(context, rig) if action is not None else None
    service._require(action is not None or not context.scene.tool_settings.use_keyframe_insert_auto,
                     'Choose an editable Custom Action before resetting the wrist with Auto Key.')
    capture = variant['capture'] if variant is not None else api.target._capture(context, rig)
    api.target._validate_capture(context, capture)
    return dict(transaction_api=PLAN_API, phase='prepared', context=context, api=api, offset=offset,
        rig=rig, data=rig.data, primary_target=target, inventory=inventory, validated_inventory=None,
        mirror_allowed=bool(mirror_allowed), mirror_flags=service._mirror_flags(rig),
        variant=variant, capture=capture, action=action, slot=variant['slot'] if variant is not None else None,
        frame=service._frame(context), autokey=bool(context.scene.tool_settings.use_keyframe_insert_auto),
        before_raw=service._raw(rig), object_raw=service._object_raw(rig), structure=api.pose._structure(rig),
        context_mode=context.mode, active=context.view_layer.objects.active, selected=tuple(context.selected_objects),
        affected=None, unaffected=None, sides=())


def configure(shared, sides):
    service = _service()
    service._require(shared['phase'] == 'prepared' and shared['affected'] is None
                     and len(sides) in (1, 2), 'Configure one fresh complete wrist transaction.')
    service._require(all(side['transaction'] is shared for side in sides), 'Wrist transaction ownership differs.')
    shared['sides'] = tuple(sides)
    shared['affected'] = frozenset((side['target'].name, side['rotation_path'], index)
        for side in sides for index in range(side['rotation_size']))
    if shared['action'] is not None and shared['autokey']:
        shared['unaffected'] = _proof().unaffected(shared['api'], shared['action'], shared['slot'], shared['affected'])


def _current_context(context, shared):
    service = _service()
    service._require(type(shared) is dict and shared.get('transaction_api') == PLAN_API
        and shared.get('context') is context, 'Prepare this exact current wrist operation first.')
    rig = shared['rig']
    service._require(service._frame(context) == shared['frame']
        and bool(context.scene.tool_settings.use_keyframe_insert_auto) == shared['autokey']
        and service._mirror_flags(rig) == shared['mirror_flags'],
        'The frame, Auto Key or mirror options changed after wrist preparation.')
    service._require(context.mode == shared['context_mode']
        and service._same(context.view_layer.objects.active, shared['active'])
        and len(context.selected_objects) == len(shared['selected'])
        and all(any(service._same(obj, prior) for prior in shared['selected']) for obj in context.selected_objects),
        'The wrist context or object selection changed.')


def validate(context, shared):
    service = _service()
    _current_context(context, shared)
    service._require(shared['phase'] == 'prepared' and shared['sides'], 'This wrist transaction is no longer prepared.')
    admission = service._admission(context, shared['primary_target'], mirror_allowed=shared['mirror_allowed'])
    _offset, _api, _physics, rig, _target, _end, _forearm, inventory, _key, _entry, _unused = admission
    service._require(rig is shared['rig'] and rig.data is shared['data']
        and shared['api'].pose._structure(rig) == shared['structure'], 'The wrist rig, native Rest or graph changed.')
    if shared['variant'] is not None:
        # Includes fresh full Custom/Source reads, never an old prepare digest.
        _proof().validate_variant(shared['variant'], final=True)
    else:
        service._require(not rig.animation_data or rig.animation_data.action is None,
                         'An Action became active after wrist preparation.')
    shared['api'].target._validate_capture(context, shared['capture'])
    service._unchanged_inputs(shared['sides'][0], allow_target_rotation=False)
    shared['validated_inventory'] = inventory
    shared['phase'] = 'validated'


def begin(shared):
    _service()._require(shared['phase'] == 'validated', 'Validate the complete current wrist transaction before writing.')
    shared['phase'] = 'applying'


def finish(context, shared):
    service = _service()
    _current_context(context, shared)
    service._require(shared['phase'] == 'applying', 'This wrist transaction is not applying.')
    if shared['variant'] is not None:
        # AutoKey OFF compares the entire original Custom; ON compares every
        # unaffected channel/slot plus the fully revalidated Source/owner.
        _proof().validate_variant(shared['variant'], final=not shared['autokey'])
        if shared['autokey']:
            service._require(_proof().unaffected(shared['api'], shared['action'], shared['slot'], shared['affected'])
                == shared['unaffected'], 'Wrist keying changed an unrelated native FK or Action channel.')
    shared['phase'] = 'verified'


def commit(shared):
    _service()._require(shared['phase'] == 'verified', 'Complete all wrist integrity checks before committing.')
    shared['phase'] = 'complete'
    shared['inventory'] = shared['validated_inventory'] = None
    if shared['variant'] is not None:
        shared['variant']['phase'] = 'complete'


def verify_recovery(context, shared):
    service = _service()
    _current_context(context, shared)
    if shared['variant'] is not None:
        _proof().validate_variant(shared['variant'], final=True)
    else:
        service._require(not shared['rig'].animation_data or shared['rig'].animation_data.action is None,
                         'The original no-Action wrist state did not restore.')
    shared['api'].target._validate_capture(context, shared['capture'])
    service._unchanged_inputs(shared['sides'][0], allow_target_rotation=False)
    shared['phase'] = 'rolled_back'
    shared['inventory'] = shared['validated_inventory'] = None
    if shared['variant'] is not None:
        shared['variant']['phase'] = 'rolled_back'
