"""Explicit finger rest-position plans; ordinal joints never use proximity matching.

Preview targets read only saved metadata and the short bone chain. Mesh-volume
checks and rest writes occur only in explicit Generate, Align or Relax actions.
"""
import json
import math

from mathutils import Vector

from . import finger_bank as bank, finger_definition as definition
from . import finger_internal as internal, finger_targets as targets
from . import finger_symmetry as symmetry

EPS = 1e-6
STRAIGHT = ('INDEX', 'MIDDLE', 'RING', 'PINKY')
RELAX_STATE = 'character_designer_finger_relax_state'


def _bone_collection(rig):
    from .finger_bones import _bone_collection as read
    return read(rig)


def _head(bone):
    from .finger_bones import _head as read
    return read(bone)


def _tail(bone):
    from .finger_bones import _tail as read
    return read(bone)


def _record(obj, key):
    slot = obj.character_designer_finger_bank.slots.get(key)
    if not slot or not slot.guide.record or slot.error:
        raise ValueError(f'{key}: capture/recheck Finger Basic Setup first.')
    if not slot.guide.confirmed or not slot.guide.use_basis:
        raise ValueError(f'{key}: confirm a Basis Reference before changing bone positions.')
    return json.loads(slot.guide.record)


def _rest(chain):
    return [dict(item, connected=bone.use_connect) for item, bone in zip(targets.signature(chain), chain)]


def _same_rest(a, b):
    return len(a) == len(b) and all(
        all(x[k] == y[k] for k in ('name', 'parent', 'deform', 'connected')) and
        all((Vector(x[k])-Vector(y[k])).length <= EPS for k in ('head', 'tail'))
        for x, y in zip(a, b))


def _nodes(chain):
    return [_head(chain[0])] + [_head(b) for b in chain[1:]] + [_tail(chain[-1])]


def bind(obj, rig, key, chain, recipe):
    """Capture fixed ordinal identity and depth path during explicit Prepare."""
    if len(chain) < 2:
        raise ValueError(f'{key}: at least two existing deform segments are required.')
    record = _record(obj, key)
    thumb = key.split('.')[0] == 'THUMB'
    path = _nodes(chain) if thumb else record.get('internal', {}).get('path')
    if not path or len(path) < 2:
        raise ValueError(f'{key}: capture a verified internal reference before preparing bone sync.')
    result = dict(schema=1, rig=rig.name, armature=rig.data.name, key=key,
                  names=[b.name for b in chain], expected=_rest(chain),
                  path=[list(p) for p in path], space='RIG' if thumb else 'MESH')
    recipe['chain_binding'] = result
    return result


def _bound_chain(obj, rig, recipe):
    binding = recipe.get('chain_binding')
    if not binding or binding.get('schema') != 1:
        raise ValueError('Prepare this finger again to bind fixed bone-junction identities.')
    if binding.get('rig') != rig.name or binding.get('armature') != rig.data.name:
        raise ValueError('The prepared Main Rig changed; Prepare this finger again.')
    bones = _bone_collection(rig)
    chain = [bones.get(name) for name in binding['names']]
    if any(b is None for b in chain) or not _same_rest(binding['expected'], _rest(chain)):
        raise ValueError('The bound rest chain changed; review it and Prepare again before syncing joints.')
    if any(getattr(b, 'hide', False) or getattr(b, 'lock', False) for b in chain):
        raise ValueError('A bound finger bone is hidden or locked.')
    if any(b.parent != a for a, b in zip(chain, chain[1:])):
        raise ValueError('The bound finger chain is no longer consecutive.')
    return binding, chain


def _sample(path, fraction):
    points = list(map(Vector, path))
    lengths = [(b-a).length for a, b in zip(points, points[1:])]
    length = sum(lengths)
    if length < EPS or not math.isfinite(fraction) or not 0 <= fraction <= 1:
        raise ValueError('The finger path or joint position is invalid.')
    remaining = fraction*length
    for a, b, step in zip(points, points[1:], lengths):
        if step > EPS and remaining <= step+EPS:
            return a.lerp(b, min(1., remaining/step)), (b-a)/step
        remaining -= step
    return points[-1].copy(), (points[-1]-points[-2]).normalized()


def _plane_intersection(path, point, normal):
    found = []
    for a, b in zip(path, path[1:]):
        a, b = Vector(a), Vector(b)
        da, db = (a-point).dot(normal), (b-point).dot(normal)
        if abs(da-db) < EPS:
            if abs(da) < EPS:
                raise ValueError('A bone path runs along the joint plane; the target is ambiguous.')
            continue
        t = da/(da-db)
        if -EPS <= t <= 1+EPS:
            hit = a.lerp(b, min(1., max(0., t)))
            if not any((hit-p).length <= EPS for p in found): found.append(hit)
    if len(found) != 1:
        raise ValueError('The joint plane does not meet its saved internal path exactly once.')
    return found[0]


def joint_targets(obj, rig, recipe, config):
    """Scan-free ordinal A/B and rig-local targets; no armature/mesh mutation."""
    binding, chain = _bound_chain(obj, rig, recipe)
    if len(config.joints) != len(chain)-1:
        raise ValueError('Joint marker count differs from the bound chain; Prepare/review the actual segments.')
    values = [float(j.position) for j in config.joints]
    if any(z-a <= EPS for a, z in zip(values, values[1:])):
        raise ValueError('Joint ordinals must remain in root-to-tip order; markers cannot cross.')
    path = [obj.matrix_world @ Vector(p) for p in recipe.get('path', (recipe['root'], recipe['tip']))]
    matrix = rig.matrix_world if binding['space'] == 'RIG' else obj.matrix_world
    depth = [matrix @ Vector(p) for p in binding['path']]
    inverse = rig.matrix_world.inverted()
    output = []
    for i, t in enumerate(values):
        surface, tangent = _sample(path, t)
        point = _plane_intersection(depth, surface, tangent)
        target = inverse @ point
        output.append(dict(A=chain[i].name, B=chain[i+1].name, target=target,
                           joint=i, position=t, offset=(rig.matrix_world @ _head(chain[i+1])-point).length))
    return output


def _certify_chain(obj, rig, key, nodes, bm):
    record = _record(obj, key)
    if definition._topology(bm) != record['topology']:
        record = bank.remap_record(record, bm)
    body = record.get('body')
    if not body:
        raise ValueError(f'{key}: recapture this older finger definition before bone movement.')
    volume = internal.Volume(bm, body)
    transform = obj.matrix_world.inverted() @ rig.matrix_world
    points = [transform @ Vector(p) for p in nodes]
    scale = body['length']
    margin = max(scale*1e-6, min(body['radius']*.02, scale*.001))
    for p in points[1:-1]:
        if not volume.inside(p) or volume.distance(p) < margin:
            raise ValueError(f'{key}: a planned joint leaves the captured finger interior.')
    for i, (a, b) in enumerate(zip(points, points[1:])):
        length = (b-a).length
        if length < max(EPS, scale*1e-5):
            raise ValueError(f'{key}: bone movement would collapse a segment.')
        # Original fixed ends may lie exactly on the captured cap. Permit only
        # a microscopic boundary start/end, never an external root extension.
        start, end = a.copy(), b.copy()
        for which, endpoint in ((0, a), (1, b)):
            boundary = i == 0 and which == 0 or i == len(points)-2 and which == 1
            distance = volume.distance(endpoint)
            if boundary and distance is not None and distance <= margin*1.1:
                fraction = min(.01, margin*2/length)
                inset = endpoint.lerp(b if which == 0 else a, fraction)
                if not volume.inside(inset):
                    raise ValueError(f'{key}: the fixed endpoint points outside the finger volume.')
                if which == 0: start = inset
                else: end = inset
        if volume.certify((start, end), margin*.5) is None:
            raise ValueError(f'{key}: a planned bone segment leaves the captured finger volume.')


def plans(context, entries):
    """Validate complete explicit-write plans; caller owns the mesh transaction."""
    obj, rig = targets.owner(context)
    symmetry.guard_rig(rig)
    result = dict(obj=obj, rig=rig, chains=[], keys=[])
    bm = definition._snapshot(obj, definition._basis_name(obj))
    try:
        resolved = {}
        for pair, key, recipe, mesh_plan in entries:
            if pair.name not in resolved:
                resolved[pair.name] = targets.pair(obj, rig, pair.name, targets.index(rig), bm=bm)
            chain = resolved[pair.name][key]
            slot = obj.character_designer_finger_bank.slots[key]
            definition.frame(bank.scoped(context, slot.guide), require_basis=True, require_confirmed=True)
            items = joint_targets(obj, rig, recipe, mesh_plan.get('settings', pair))
            if [b.name for b in chain] != [items[0]['A']] + [item['B'] for item in items]:
                raise ValueError('Resolved chain does not match the prepared ordinal binding.')
            nodes = [_head(chain[0])] + [item['target'] for item in items] + [_tail(chain[-1])]
            _certify_chain(obj, rig, key, nodes, bm)
            result['chains'].append(dict(key=key, names=[b.name for b in chain], nodes=nodes, expected=_rest(chain)))
            result['keys'].append(key)
    finally:
        bm.free()
    if not result['chains']: raise ValueError('No prepared finger chain was supplied for synchronization.')
    return result


def _snapshot_edit(rig):
    return {b.name: dict(head=b.head.copy(), tail=b.tail.copy(), roll=b.roll,
                        parent=b.parent.name if b.parent else None, connected=b.use_connect,
                        deform=b.use_deform) for b in rig.data.edit_bones}


def snapshot(context, plan):
    obj, rig = plan['obj'], plan['rig']
    with targets.edit_rig(context, rig): bones = _snapshot_edit(rig)
    state = obj.character_designer_finger_workflow
    return dict(bones=bones, slots={key: obj.character_designer_finger_bank.slots[key].bones for key in plan['keys']},
                recipes={p.name: p.recipe for p in state.pairs},
                relax_state=(RELAX_STATE in obj, obj.get(RELAX_STATE)))


def _restore_edit(rig, saved):
    bones = rig.data.edit_bones
    if set(saved) != set(bones.keys()):
        raise ValueError('Bone identities changed during the position transaction.')
    mirror = rig.data.use_mirror_x
    try:
        rig.data.use_mirror_x = False
        for b in bones: b.use_connect = False
        for name, item in saved.items():
            b = bones[name]
            b.parent = bones.get(item['parent']) if item['parent'] else None
            b.head, b.tail, b.roll, b.use_deform = item['head'], item['tail'], item['roll'], item['deform']
        for name, item in saved.items(): bones[name].use_connect = item['connected']
    finally:
        rig.data.use_mirror_x = mirror


def restore(context, plan, backup):
    obj, rig = plan['obj'], plan['rig']
    with targets.edit_rig(context, rig): _restore_edit(rig, backup['bones'])
    for key, value in backup['slots'].items(): obj.character_designer_finger_bank.slots[key].bones = value
    state = obj.character_designer_finger_workflow
    for name, value in backup['recipes'].items():
        if name in state.pairs: state.pairs[name].recipe = value
    present, value = backup.get('relax_state', (False, None))
    if present: obj[RELAX_STATE] = value
    elif RELAX_STATE in obj: del obj[RELAX_STATE]


def apply(context, plan, *, after_write=None):
    """Rest positions only; return changed-segment count, roll and identity intact."""
    rig = plan['rig']
    with targets.edit_rig(context, rig):
        before = _snapshot_edit(rig)
        wanted = {}
        for chain in plan['chains']:
            if len(chain['nodes']) != len(chain['names'])+1:
                raise ValueError('The planned chain has inconsistent endpoint counts.')
            current = [rig.data.edit_bones[name] for name in chain['names']]
            if chain.get('expected') and not _same_rest(chain['expected'], _rest(current)):
                raise ValueError('The rest chain changed after planning; build a new plan before writing.')
            if ((_head(current[0])-Vector(chain['nodes'][0])).length > EPS or
                    (_tail(current[-1])-Vector(chain['nodes'][-1])).length > EPS):
                raise ValueError('Bone position plans must preserve the chain root and tip.')
            for name, head, tail in zip(chain['names'], chain['nodes'], chain['nodes'][1:]):
                if name in wanted: raise ValueError('A rest bone appears in multiple chain plans.')
                wanted[name] = Vector(head), Vector(tail)
        symmetry.guard_pose(rig, list(wanted))
        changed = {name for name, (head, tail) in wanted.items() if
                   (before[name]['head']-head).length > EPS or (before[name]['tail']-tail).length > EPS}
        if not changed: return 0
        # Connected non-finger children cannot keep their rest head if their
        # parent's tail moves. Reject, rather than silently dragging them along.
        for name, item in before.items():
            if name not in wanted and item['connected'] and item['parent'] in wanted:
                if (item['head']-wanted[item['parent']][1]).length > EPS:
                    raise ValueError(f'{name}: an unrelated connected child would move.')
        mirror = rig.data.use_mirror_x
        try:
            rig.data.use_mirror_x = False
            for b in rig.data.edit_bones: b.use_connect = False
            for name, (head, tail) in wanted.items():
                b = rig.data.edit_bones[name]
                b.head, b.tail = head, tail
                b.roll = before[name]['roll']
            for name, item in before.items(): rig.data.edit_bones[name].use_connect = item['connected']
            if after_write: after_write()
            after = _snapshot_edit(rig)
            for name, item in before.items():
                actual = after[name]
                if any(actual[k] != item[k] for k in ('parent', 'connected', 'deform')) or abs(actual['roll']-item['roll']) > EPS:
                    raise ValueError('Bone rest identity or roll changed during position synchronization.')
                expected = wanted.get(name, (item['head'], item['tail']))
                if any((actual[k]-p).length > EPS for k, p in zip(('head', 'tail'), expected)):
                    raise ValueError('Bone position verification failed; no rest changes were kept.')
            rig.update_tag(refresh={'DATA'})
        except Exception:
            _restore_edit(rig, before)
            raise
        finally:
            rig.data.use_mirror_x = mirror
    return len(changed)


def commit(obj, rig, keys):
    """Accept only this explicit transaction's new rest state; keep depth paths."""
    bones = _bone_collection(rig)
    state = obj.character_designer_finger_workflow
    changed = set(keys)
    for pair in state.pairs:
        recipes = json.loads(pair.recipe or '{}')
        touched = False
        for key, recipe in recipes.items():
            if key not in changed or 'chain_binding' not in recipe: continue
            binding = recipe['chain_binding']
            chain = [bones[name] for name in binding['names']]
            binding['expected'] = _rest(chain)
            obj.character_designer_finger_bank.slots[key].bones = json.dumps({'rig': rig.name, 'chain': targets.signature(chain)})
            touched = True
        if touched: pair.recipe = json.dumps(recipes)
    # Align/Relax can precede Prepare; resolve these newly accepted chains by
    # their explicit plan identity in the caller, without refreshing any others.


def _locks(obj, rig, key, chain):
    state = obj.character_designer_finger_workflow
    pair = state.pairs.get(key.split('.')[0])
    if not pair or not pair.applied: return set()
    recipe = json.loads(pair.recipe or '{}').get(key)
    saved = json.loads(state.results or '{}').get(key)
    if not recipe or not saved:
        raise ValueError('Applied joint locks are incomplete; review the prepared results first.')
    if not saved.get('parameters', {}).get('sync_bones', getattr(pair, 'sync_bones', False)):
        return set()
    _bound_chain(obj, rig, recipe)
    rings = saved.get('plan', {}).get('rings', [])
    return {int(r['joint'])+1 for r in rings if r.get('joint', -1) >= 0 and r.get('flank') == 0}


def _turns(nodes):
    return [(b-a).cross(c-b) for a, b, c in zip(nodes, nodes[1:], nodes[2:])]


def _relaxed(nodes, locks=()):
    """Resample the existing curved polyline, independently between fixed nodes."""
    result = [p.copy() for p in nodes]
    anchors = sorted({0, len(nodes)-1, *locks})
    for a, b in zip(anchors, anchors[1:]):
        for i in range(a+1, b): result[i] = _sample(nodes[a:b+1], (i-a)/(b-a))[0]
    old, new = _turns(nodes), _turns(result)
    scale = sum((b-a).length for a, b in zip(nodes, nodes[1:]))
    tolerance = scale*scale*1e-7
    for before, after in zip(old, new):
        if before.length > tolerance and (after.length <= tolerance or before.dot(after) <= 0):
            if len(nodes) == 3: return [p.copy() for p in nodes]
            raise ValueError('Relax would remove or reverse the thumb bend; current curvature was kept.')
    return result


def _commit_plan(plan):
    obj, rig = plan['obj'], plan['rig']
    bones = _bone_collection(rig)
    for chain in plan['chains']:
        obj.character_designer_finger_bank.slots[chain['key']].bones = json.dumps(
            {'rig': rig.name, 'chain': targets.signature([bones[n] for n in chain['names']])})
    commit(obj, rig, plan['keys'])
    if plan.get('relax'):
        saved = _relax_state(obj)
        for item in plan['chains']:
            old = saved.get(item['key'], {})
            # Repeated identical Relax keeps its original curve as provenance.
            baseline = old.get('baseline') if item.get('relax_reused') else item['relax_baseline']
            saved[item['key']] = dict(rig=rig.name, armature=rig.data.name,
                                     names=item['names'], baseline=baseline,
                                     result=_rest([bones[n] for n in item['names']]))
        obj[RELAX_STATE] = json.dumps(saved)


def _run(context, plan):
    before = snapshot(context, plan)
    try:
        changed = apply(context, plan)
        _commit_plan(plan)
        return dict(changed=changed, chains=len(plan['chains']), keys=plan['keys'])
    except Exception:
        restore(context, plan, before)
        raise


def _relax_state(obj):
    try:
        value = json.loads(obj.get(RELAX_STATE, '{}'))
        return value if isinstance(value, dict) else {}
    except (ValueError, TypeError):
        return {}


def _same_relax_result(obj, rig, key, chain):
    previous = _relax_state(obj).get(key, {})
    return (previous.get('rig') == rig.name and previous.get('armature') == rig.data.name and
            previous.get('names') == [b.name for b in chain] and
            _same_rest(previous.get('result', []), _rest(chain)))


def _explicit_plan(context, digits, *, relaxing=False, hints=()):
    obj, rig = targets.owner(context)
    from . import finger_workflow as workflow
    workflow.check_source(obj, obj.character_designer_finger_workflow)
    symmetry.guard_rig(rig)
    plan = dict(obj=obj, rig=rig, chains=[], keys=[], relax=relaxing)
    bm = definition._snapshot(obj, definition._basis_name(obj))
    try:
        for digit in digits:
            chains = targets.pair(obj, rig, digit, targets.index(rig), hints, bm)
            for key, chain in chains.items():
                slot = obj.character_designer_finger_bank.slots[key]
                definition.frame(bank.scoped(context, slot.guide), require_basis=True, require_confirmed=True)
                nodes = _nodes(chain)
                locks = _locks(obj, rig, key, chain)
                reused = False
                if relaxing:
                    if len(chain) < 2:
                        raise ValueError('Thumb Relax needs at least two existing identified segments.')
                    reused = _same_relax_result(obj, rig, key, chain)
                    proposed = [p.copy() for p in nodes] if reused else _relaxed(nodes, locks)
                else:
                    root, tip = nodes[0], nodes[-1]
                    axis = tip-root
                    if axis.length < EPS: raise ValueError('The finger endpoints are collapsed.')
                    fractions = [(p-root).dot(axis)/axis.length_squared for p in nodes]
                    if any(z-a <= EPS for a, z in zip(fractions, fractions[1:])):
                        raise ValueError('The chain folds back; straight alignment would cross joints.')
                    proposed = [root+axis*t for t in fractions]
                    if any((proposed[i]-nodes[i]).length > EPS for i in locks):
                        raise ValueError('Confirmed joint positions prevent straight alignment; their positions were kept.')
                _certify_chain(obj, rig, key, proposed, bm)
                plan['chains'].append(dict(key=key, names=[b.name for b in chain], nodes=proposed, expected=_rest(chain),
                                           relax_reused=reused, relax_baseline=[list(p) for p in nodes]))
                plan['keys'].append(key)
    finally:
        bm.free()
    return plan


def align(context, digit=None, *, selected=False):
    """Align only explicit straight-finger chains; root/tip and roll stay fixed."""
    obj, rig = targets.owner(context)
    hints = []
    if selected:
        if context.object != rig or context.mode not in {'EDIT_ARMATURE', 'POSE'}:
            raise ValueError('Select existing straight-finger bones on Main Rig first.')
        hints = [b.name for b in _bone_collection(rig) if
                 (b.select if rig.mode == 'EDIT' else rig.pose.bones[b.name].select)]
        digits = [d for d in STRAIGHT if any(b.name in hints for k, chain in targets.index(rig).items()
                                          if k.split('.')[0] == d for b in chain)]
        if not digits: raise ValueError('No straight-finger chain is selected; Thumb uses Relax instead.')
    else:
        digit = digit or obj.character_designer_finger_bank.active.split('.')[0]
        digits = list(STRAIGHT) if digit == 'ALL' else [digit]
        if any(d not in STRAIGHT for d in digits):
            raise ValueError('Straight alignment excludes Thumb; use Thumb Relax to retain its curve.')
    return _run(context, _explicit_plan(context, digits, hints=hints))


def relax(context):
    """Redistribute existing thumb joints along their curve; never add segments."""
    obj, rig = targets.owner(context)
    if obj.character_designer_finger_bank.active.split('.')[0] != 'THUMB':
        raise ValueError('Make Thumb the active editing finger before Thumb Relax.')
    hints = [b.name for b in _bone_collection(rig) if
             (b.select if rig.mode == 'EDIT' else rig.pose.bones[b.name].select)] if context.object == rig else []
    return _run(context, _explicit_plan(context, ['THUMB'], relaxing=True, hints=hints))
