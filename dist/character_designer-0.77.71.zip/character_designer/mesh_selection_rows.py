"""Transient multi-row selection shared by two independent native catalogs."""
import bmesh


def _token(mesh):
    return str(getattr(mesh, 'session_uid', None) or mesh.as_pointer())


def _valid(mesh, name, prefix):
    attribute = mesh.attributes.get(name)
    return (attribute is not None and attribute.domain == 'POINT' and attribute.data_type == 'INT'
            and name.startswith(prefix) and len(name) > len(prefix))


def snapshot(rows, mesh, valid_names, active=''):
    names = set(valid_names)
    token = _token(mesh)
    current = [row for row in rows if row.mesh_token == token and row.native_name in names]
    if current:
        return {row.native_name for row in current if row.selected}
    return {active} if active in names else set()


def chosen_names(rows, mesh, prefix):
    token = _token(mesh)
    current = [row for row in rows if row.mesh_token == token and _valid(mesh, row.native_name, prefix)]
    if current:
        return tuple(row.native_name for row in current if row.selected)
    active = mesh.attributes.active
    return (active.name,) if active is not None and _valid(mesh, active.name, prefix) else ()


def choose(rows, mesh, prefix, name, extend=False):
    if not _valid(mesh, name, prefix):
        raise ValueError('Select a row from this list.')
    token = _token(mesh)
    current = [row for row in rows if row.mesh_token == token and _valid(mesh, row.native_name, prefix)]
    target = next((row for row in current if row.native_name == name), None)
    if target is None:
        raise ValueError('The selection list is out of date.')
    if extend:
        target.selected = not target.selected
    else:
        for row in current:
            row.selected = row.native_name == name
    return next(index for index, row in enumerate(rows) if row.native_name == name and row.mesh_token == token)


def rename_cache(window_manager, view_property, mesh, old, new):
    rows = getattr(window_manager, view_property, ())
    token = _token(mesh)
    for row in rows:
        if row.mesh_token == token and row.native_name == old:
            row.native_name = new


def new_row(window_manager, view_property, index_property, mesh, name, prefix):
    """Choose a newly created row without repurposing another mesh's RNA rows."""
    if not _valid(mesh, name, prefix):
        raise ValueError('Select a row from this list.')
    rows = getattr(window_manager, view_property)
    token = _token(mesh)
    for row in rows:
        if row.mesh_token == token:
            row.selected = False
    row = rows.add()
    row.native_name, row.mesh_token, row.selected = name, token, True
    setattr(window_manager, index_property, len(rows) - 1)


def select_vertices(context, mesh, names, prefix, *, select, extend=False):
    names = tuple(names)
    if not names:
        raise ValueError('Select one or more list icons first.')
    if not all(_valid(mesh, name, prefix) for name in names):
        raise ValueError('Use selections from this list only.')
    if not mesh.is_editmode:
        raise ValueError('Use Mesh Edit Mode.')
    bm = bmesh.from_edit_mesh(mesh)
    layers = [bm.verts.layers.int.get(name) for name in names]
    if any(layer is None for layer in layers):
        raise ValueError('A selection layer is missing.')
    context.tool_settings.mesh_select_mode = (True, False, False)
    bm.select_mode = {'VERT'}
    if select and not extend:
        for elements in (bm.faces, bm.edges, bm.verts):
            for element in elements:
                element.select_set(False)
    for vertex in bm.verts:
        if not vertex.hide and any(vertex[layer] != 0 for layer in layers):
            vertex.select_set(select)
    if select and not extend:
        bm.select_history.clear()
    else:
        bm.select_history.validate()
    bm.select_flush_mode()
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
