"""Saved modeling selections using Blender's native attribute catalog.

The ``Custom_`` prefix is reserved for these groups: existing POINT/INT
attributes with that prefix are also listed as groups. New groups contain
0/1 membership; deform vertex groups and painted weights are never written.
Native BMesh custom data owns catalog, membership and Edit Mode Undo together.
"""
import bmesh
from bpy.props import StringProperty
from bpy.types import Operator, UIList


PREFIX = 'Custom_'


def _mesh(context, *, edit=False):
    obj = context.active_object
    if obj is None or obj.type != 'MESH':
        raise ValueError('Select a mesh.')
    mesh = obj.data
    if (obj.library or mesh.library or obj.override_library or mesh.override_library
            or not obj.is_editable or not mesh.is_editable):
        raise ValueError('Use a local editable mesh.')
    if mesh.users != 1:
        raise ValueError('Use a mesh with single-user data.')
    if obj.mode not in {'OBJECT', 'EDIT'} or (edit and obj.mode != 'EDIT'):
        raise ValueError('Use Mesh Edit Mode.' if edit else 'Use Object or Mesh Edit Mode.')
    if obj.mode == 'EDIT' and len(context.objects_in_mode) != 1:
        raise ValueError('Edit one mesh at a time.')
    return mesh


def _is_group(attribute):
    return (attribute is not None and attribute.domain == 'POINT' and attribute.data_type == 'INT'
            and attribute.name.startswith(PREFIX) and len(attribute.name) > len(PREFIX))


def group_attributes(mesh):
    return [attribute for attribute in mesh.attributes if _is_group(attribute)]


def _active(mesh):
    attribute = mesh.attributes.active
    if not _is_group(attribute):
        raise ValueError('Select a custom vertex group.')
    return attribute


def _layer(bm, attribute):
    layer = bm.verts.layers.int.get(attribute.name)
    if layer is None:
        raise ValueError('The custom group attribute is missing.')
    return layer


def _new_name(mesh, label, bm=None):
    taken = set(mesh.attributes.keys())
    if bm is not None:
        for domain in (bm.verts, bm.edges, bm.faces, bm.loops):
            for kind in ('int', 'float', 'float_vector', 'string', 'bool',
                         'color', 'float_color', 'byte_color', 'uv', 'shape'):
                layers = getattr(domain.layers, kind, None)
                if layers is not None:
                    taken.update(layers.keys())
    for number in range(len(taken) + 1):
        suffix = '' if number == 0 else f'.{number:03d}'
        stem = (PREFIX + label).encode('utf-8')[:63 - len(suffix)].decode('utf-8', errors='ignore')
        name = stem + suffix
        if name not in taken:
            return name
    raise ValueError('Could not find an unused custom group name.')


def new_group(context, name='Group'):
    mesh = _mesh(context)
    label = name.strip()
    if not label:
        raise ValueError('Enter a group name.')
    bm = bmesh.from_edit_mesh(mesh) if mesh.is_editmode else None
    attribute_name = _new_name(mesh, label, bm)
    if bm is not None:
        layer = bm.verts.layers.int.new(attribute_name)
        attribute_name = layer.name
        for vertex in bm.verts:
            vertex[layer] = 0
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    else:
        attribute_name = mesh.attributes.new(attribute_name, 'INT', 'POINT').name
    mesh.attributes.active_index = mesh.attributes.find(attribute_name)
    return attribute_name


def delete_group(context):
    mesh = _mesh(context)
    attribute = _active(mesh)
    names = [item.name for item in group_attributes(mesh)]
    index = names.index(attribute.name)
    if mesh.is_editmode:
        bm = bmesh.from_edit_mesh(mesh)
        bm.verts.layers.int.remove(_layer(bm, attribute))
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    else:
        mesh.attributes.remove(attribute)
    remaining = group_attributes(mesh)
    if remaining:
        mesh.attributes.active_index = mesh.attributes.find(remaining[min(index, len(remaining) - 1)].name)


def edit_membership(context, member):
    mesh = _mesh(context, edit=True)
    bm = bmesh.from_edit_mesh(mesh)
    layer = _layer(bm, _active(mesh))
    for vertex in bm.verts:
        if vertex.select and not vertex.hide:
            vertex[layer] = 1 if member else 0
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)


def select_group(context):
    mesh = _mesh(context, edit=True)
    bm = bmesh.from_edit_mesh(mesh)
    layer = _layer(bm, _active(mesh))
    context.tool_settings.mesh_select_mode = (True, False, False)
    bm.select_mode = {'VERT'}
    for domain in (bm.faces, bm.edges, bm.verts):
        for element in domain:
            element.select_set(False)
    for vertex in bm.verts:
        if not vertex.hide and vertex[layer] != 0:
            vertex.select_set(True)
    bm.select_history.clear()
    bm.select_flush(True)
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)


class CHARACTERDESIGNER_UL_custom_vertex_groups(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        layout.label(text=item.name[len(PREFIX):], icon='VERTEXSEL')

    def filter_items(self, context, data, property):
        return ([self.bitflag_filter_item if _is_group(item) else 0
                 for item in getattr(data, property)], [])


class _GroupOperator:
    @classmethod
    def poll(cls, context):
        try:
            _mesh(context, edit=cls.edit_only)
            return True
        except (ValueError, ReferenceError):
            return False

    def execute(self, context):
        try:
            self.apply(context)
            return {'FINISHED'}
        except (ValueError, RuntimeError, ReferenceError) as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}


class CHARACTERDESIGNER_OT_custom_vertex_group_new(_GroupOperator, Operator):
    bl_idname = 'character_designer.custom_vertex_group_new'
    bl_label = 'New Custom Vertex Group'
    bl_description = 'Create an empty modeling selection group'
    bl_options = {'REGISTER', 'UNDO'}
    edit_only = False
    name: StringProperty(name='Name', default='Group')

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=260)

    def apply(self, context):
        new_group(context, self.name)


class CHARACTERDESIGNER_OT_custom_vertex_group_delete(_GroupOperator, Operator):
    bl_idname = 'character_designer.custom_vertex_group_delete'
    bl_label = 'Delete Custom Vertex Group'
    bl_description = 'Delete this modeling selection group'
    bl_options = {'REGISTER', 'UNDO'}
    edit_only = False

    def apply(self, context):
        delete_group(context)


class CHARACTERDESIGNER_OT_custom_vertex_group_assign(_GroupOperator, Operator):
    bl_idname = 'character_designer.custom_vertex_group_assign'
    bl_label = 'Assign'
    bl_description = 'Add selected vertices to this custom group'
    bl_options = {'REGISTER', 'UNDO'}
    edit_only = True

    def apply(self, context):
        edit_membership(context, True)


class CHARACTERDESIGNER_OT_custom_vertex_group_remove(_GroupOperator, Operator):
    bl_idname = 'character_designer.custom_vertex_group_remove'
    bl_label = 'Remove'
    bl_description = 'Remove selected vertices from this custom group'
    bl_options = {'REGISTER', 'UNDO'}
    edit_only = True

    def apply(self, context):
        edit_membership(context, False)


class CHARACTERDESIGNER_OT_custom_vertex_group_select(_GroupOperator, Operator):
    bl_idname = 'character_designer.custom_vertex_group_select'
    bl_label = 'Select'
    bl_description = 'Select this custom group\'s visible vertices'
    bl_options = {'REGISTER', 'UNDO'}
    edit_only = True

    def apply(self, context):
        select_group(context)


def draw(layout, context):
    try:
        mesh = _mesh(context)
    except (ValueError, ReferenceError) as exc:
        layout.label(text=str(exc), icon='INFO')
        return
    row = layout.row()
    row.template_list('CHARACTERDESIGNER_UL_custom_vertex_groups', '', mesh, 'attributes',
                      mesh.attributes, 'active_index', rows=3)
    column = row.column(align=True)
    column.operator('character_designer.custom_vertex_group_new', text='', icon='ADD')
    remove = column.column(align=True)
    remove.enabled = _is_group(mesh.attributes.active)
    remove.operator('character_designer.custom_vertex_group_delete', text='', icon='REMOVE')
    row = layout.row(align=True)
    row.enabled = mesh.is_editmode and _is_group(mesh.attributes.active)
    row.operator('character_designer.custom_vertex_group_assign')
    row.operator('character_designer.custom_vertex_group_remove')
    row.operator('character_designer.custom_vertex_group_select')


CLASSES = (CHARACTERDESIGNER_UL_custom_vertex_groups,
           CHARACTERDESIGNER_OT_custom_vertex_group_new, CHARACTERDESIGNER_OT_custom_vertex_group_delete,
           CHARACTERDESIGNER_OT_custom_vertex_group_assign, CHARACTERDESIGNER_OT_custom_vertex_group_remove,
           CHARACTERDESIGNER_OT_custom_vertex_group_select)
