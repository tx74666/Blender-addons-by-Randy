"""Place an animator's knee pole from the evaluated hip, knee and ankle."""

import math

from mathutils import Quaternion, Vector


def condition_shin(hip, shin, ankle):
    """Cap the native pre-IK bend on the independent IK edit, keeping its bend plane and roll."""
    upper = shin.translation - hip.translation
    lower = ankle.translation - shin.translation
    if min(upper.length, lower.length) < 1.e-8:
        raise ValueError('The knee solver needs two leg segments with measurable length.')
    normal = upper.cross(lower)
    angle = math.atan2(normal.length, upper.dot(lower))
    limit = math.radians(65.)
    if angle <= limit:
        return shin.copy(), False
    if normal.length <= upper.length * lower.length * 1.e-6:
        # At a complete fold either plane contains the collinear segments.
        # Prefer the bone-local hinge, projected into the plane normal to the thigh.
        axis = upper.normalized()
        axes = (shin.to_3x3().col[i] for i in (0, 2))
        normal = max((a - axis*a.dot(axis) for a in axes), key=lambda a: a.length)
    result = Quaternion(normal.normalized(), limit-angle).to_matrix().to_4x4() @ shin
    result.translation = shin.translation
    return result, True


def position(armature, limb, desired, *, previous=None):
    """Return the armature-space handle position. Previous is the last matched handle."""
    thigh, shin, foot = limb['chain']
    hip, knee, ankle = (desired[name].translation for name in (thigh, shin, foot))
    upper = knee - hip
    span = upper.length + (ankle - knee).length
    if not math.isfinite(span) or span < 1.e-8:
        raise ValueError('The knee pole needs a leg with measurable length.')
    rest_pole = armature.data.bones[limb['pole'].name].head_local
    rest_shin = armature.data.bones[shin].head_local
    distance = (rest_pole - rest_shin).length
    if distance < span * .01:
        distance = .75 * span
    axis = ankle - hip
    if axis.length < span * 1.e-5:
        # At a full fold the knee still has a well-defined direction from the hip.
        return knee + upper.normalized() * distance
    axis.normalize()
    radial = upper - axis * upper.dot(axis)
    bend = radial.length / span
    if bend >= .01:
        return knee + radial.normalized() * distance

    rest_thigh = armature.data.bones[thigh].matrix_local
    rotation = desired[thigh].to_quaternion() @ rest_thigh.to_quaternion().inverted()
    reference = rotation @ (rest_pole - rest_shin)
    candidates = []
    if previous is not None:
        candidates.append(previous - knee)
    candidates.extend((reference, rotation @ Vector(limb.get('pole_direction') or (0., -1., 0.))))
    for vector in candidates:
        projected = vector - axis * vector.dot(axis)
        if projected.length > 1.e-7 * max(1., vector.length):
            hint = projected.normalized()
            break
    else:
        hint = axis.orthogonal().normalized()
    # A straight chain has no unique bending plane. Ease out of the last
    # reliable plane until the knee displacement supplies a stable normal.
    if bend > .002:
        direction = radial.normalized()
        angle = math.atan2(axis.dot(hint.cross(direction)), hint.dot(direction))
        weight = (bend - .002) / .008
        hint = Quaternion(axis, angle * weight * weight * (3. - 2. * weight)) @ hint
    return knee + hint * distance
