"""Owned Blender worker for controller mapping from current RAM.

The parent writes an ID library and appends one verified Action. All scene
evaluation happens in the separately owned background process.
"""
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
import traceback
import uuid

import bpy

SCHEMA = 'character-designer.controller-worker/1'
_ACTIVE = None
_JOBS = {}


class StaleInputs(ValueError):
    """The retained worker result no longer matches the current artist inputs."""


def _require(value, message):
    if not value:
        raise RuntimeError(message)


def _sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _digest(value):
    return hashlib.sha256(_json(value).encode('utf8')).hexdigest()


def _write(path, value):
    path = Path(path)
    pending = path.with_name(path.name + '.pending')
    with pending.open('x', encoding='utf8') as stream:
        stream.write(_json(value))
    pending.replace(path)


def _package_hashes(package):
    return {path.relative_to(package).as_posix(): _sha(path)
            for path in sorted(package.rglob('*.py'))}


def _resources(path):
    reading = dict(disk=shutil.disk_usage(path)._asdict(), available_bytes=None, used_percent=None)
    if os.name == 'nt':
        import ctypes
        class MemoryStatus(ctypes.Structure):
            _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong),
                        ('total', ctypes.c_ulonglong), ('available', ctypes.c_ulonglong),
                        ('page_total', ctypes.c_ulonglong), ('page_available', ctypes.c_ulonglong),
                        ('virtual_total', ctypes.c_ulonglong), ('virtual_available', ctypes.c_ulonglong),
                        ('extended', ctypes.c_ulonglong)]
        memory = MemoryStatus()
        memory.length = ctypes.sizeof(memory)
        _require(ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)),
                 'Cannot read actual available memory before controller conversion.')
        reading.update(available_bytes=int(memory.available), used_percent=int(memory.load))
    elif hasattr(os, 'sysconf'):
        try:
            reading['available_bytes'] = os.sysconf('SC_AVPHYS_PAGES') * os.sysconf('SC_PAGE_SIZE')
        except (OSError, ValueError):
            pass
    _require(reading['available_bytes'] is None or reading['available_bytes'] >= 209715200,
             'Actual available memory is below 200 MB; retry controller conversion after memory is available.')
    return reading


def _windows_process(pid):
    """Open one exact process object and retain its creation identity."""
    import ctypes
    from ctypes import wintypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    kernel.OpenProcess.restype = wintypes.HANDLE
    kernel.GetProcessTimes.argtypes = (wintypes.HANDLE, *([ctypes.POINTER(wintypes.FILETIME)] * 4))
    kernel.GetProcessTimes.restype = wintypes.BOOL
    kernel.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
    kernel.WaitForSingleObject.restype = wintypes.DWORD
    kernel.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel.CloseHandle.restype = wintypes.BOOL
    handle = kernel.OpenProcess(0x00100000 | 0x1000, False, pid)  # SYNCHRONIZE | QUERY_LIMITED_INFORMATION
    _require(handle, 'The controller worker cannot authenticate its parent process.')
    try:
        times = [wintypes.FILETIME() for _ in range(4)]
        _require(kernel.GetProcessTimes(handle, *(ctypes.byref(value) for value in times)),
                 'The controller worker cannot read its parent process creation time.')
        created = (int(times[0].dwHighDateTime) << 32) | int(times[0].dwLowDateTime)
        return kernel, handle, created
    except BaseException:
        kernel.CloseHandle(handle)
        raise


def _parent_identity():
    identity = dict(pid=os.getpid())
    if os.name == 'nt':
        kernel, handle, created = _windows_process(identity['pid'])
        try:
            identity['windows_creation'] = created
        finally:
            kernel.CloseHandle(handle)
    return identity


def _parent_watch_backend(identity):
    if os.name == 'nt':
        kernel, handle, created = _windows_process(identity['pid'])
        if created != identity.get('windows_creation'):
            kernel.CloseHandle(handle)
            raise RuntimeError('The controller worker parent PID was reused; the result was refused.')
        def exited():
            status = kernel.WaitForSingleObject(handle, 250)
            _require(status in (0, 258), 'The controller parent process handle became unreadable.')
            return status == 0
        return exited, lambda: kernel.CloseHandle(handle)
    _require(os.getppid() == identity['pid'], 'The controller worker no longer has its initiating parent.')
    def exited():
        time.sleep(.25)
        return os.getppid() != identity['pid']
    return exited, lambda: None


def _watch_parent(request, root):
    """Child only: no bpy calls, and termination applies only to this process."""
    identity = request['parent_identity']
    _require(identity['pid'] == request['parent_pid'] and identity['pid'] != os.getpid(),
             'The controller worker parent identity differs from its request.')
    exited, close = _parent_watch_backend(identity)
    stop = threading.Event()
    def run():
        try:
            while not stop.is_set():
                if exited():
                    try:
                        _write(root / 'parent_exit.json', dict(schema=SCHEMA, job=root.name,
                                                               state='PARENT_EXITED', parent=identity))
                    except BaseException:
                        pass
                    os._exit(1)
                    return
        except BaseException as exc:
            try:
                _write(root / 'parent_watch_error.json', dict(schema=SCHEMA, job=root.name, error=str(exc)))
            except BaseException:
                pass
            os._exit(1)
        finally:
            close()
    thread = threading.Thread(target=run, name='Controller worker parent', daemon=True)
    try:
        thread.start()
    except BaseException:
        close()
        raise
    def finish():
        stop.set()
        thread.join()
    return finish


def _value(value, depth=0):
    _require(depth <= 24, 'Controller ownership metadata exceeds the supported depth.')
    if isinstance(value, bpy.types.ID):
        library = value.library
        return dict(id_type=value.bl_rna.identifier, name=value.name_full,
                    library=str(Path(bpy.path.abspath(library.filepath)).resolve()) if library else None)
    if isinstance(value, (bpy.types.Bone, bpy.types.PoseBone)):
        return dict(rna_type=value.bl_rna.identifier, owner=_value(value.id_data, depth + 1), name=value.name)
    if value is None or type(value) in (str, int, bool, float):
        return value
    if isinstance(value, set):
        return sorted(value)
    if hasattr(value, 'items'):
        return {str(k): _value(v, depth + 1) for k, v in value.items()}
    if hasattr(value, 'to_list'):
        return _value(value.to_list(), depth + 1)
    if isinstance(value, (tuple, list)) or hasattr(value, '__len__'):
        return [_value(v, depth + 1) for v in value]
    raise RuntimeError('Controller ownership metadata contains an unsupported value: ' + type(value).__name__)


def _rna(block, *, exclude=(), collections=False, depth=0):
    _require(depth <= 16, 'Controller RNA dependencies exceed the supported depth.')
    out = {}
    for prop in block.bl_rna.properties:
        name = prop.identifier
        if name == 'rna_type' or name in exclude:
            continue
        if prop.type == 'COLLECTION':
            if collections:
                out[name] = [_rna(item, collections=True, depth=depth + 1) for item in getattr(block, name)]
        elif not prop.is_readonly and prop.type in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM', 'POINTER'}:
            out[name] = _value(getattr(block, name))
    return out


def _curve(curve):
    out = _rna(curve, exclude={'group', 'driver'})
    out['keys'] = [_rna(point) for point in curve.keyframe_points]
    out['samples'] = [_rna(point) for point in curve.sampled_points]
    out['modifiers'] = [_rna(modifier, collections=True) for modifier in curve.modifiers]
    if curve.driver is not None:
        out['driver'] = _rna(curve.driver, collections=True)
    return out


def _strip(strip):
    return dict(settings=_rna(strip, exclude={'action_slot'}), slot=getattr(strip, 'action_slot_handle', 0),
                curves=[_curve(curve) for curve in strip.fcurves],
                strips=[_strip(child) for child in strip.strips])


def _animation(ad):
    if ad is None:
        return None
    return dict(action=_value(ad.action), slot=ad.action_slot_handle, use_nla=ad.use_nla,
                blend=ad.action_blend_type, influence=ad.action_influence, extrapolation=ad.action_extrapolation,
                drivers=[_curve(curve) for curve in ad.drivers],
                nla=[dict(settings=_rna(track), strips=[_strip(strip) for strip in track.strips])
                     for track in ad.nla_tracks])


def _control_fingerprint(source, target):
    from . import animation_controller_isolation as isolation, animation_controller_mapping as mapping
    graph = isolation._graph(target)
    _, secondary = isolation._secondary_sources(target)
    objects = {source, target, *secondary}
    if graph:
        objects.update(graph['collection'].objects)
    rows = []
    for obj in sorted(objects, key=lambda value: value.name_full):
        row = dict(id=_value(obj), parent=_value(obj.parent), parent_type=obj.parent_type,
                   parent_bone=obj.parent_bone, parent_inverse=_value(obj.matrix_parent_inverse),
                   basis=_value(obj.matrix_basis),
                   delta={key: _value(getattr(obj, key)) for key in (
                       'delta_location', 'delta_rotation_euler', 'delta_rotation_quaternion', 'delta_scale')},
                   properties=_value(dict(obj.items())), animation=_animation(obj.animation_data),
                   constraints=[_rna(con, collections=True) for con in obj.constraints])
        if obj in (source, target):
            row['mapping_world'] = _value(mapping._current_world(obj))
        if obj.type == 'ARMATURE':
            row.update(data=_value(obj.data), data_properties=_value(dict(obj.data.items())),
                       pose_position=obj.data.pose_position, data_animation=_animation(obj.data.animation_data),
                       bones=[(bone.name, bone.use_local_location, bone.bbone_segments,
                               _value(dict(bone.items()))) for bone in obj.data.bones],
                       pose=[(bone.name, _value(dict(bone.items())), _value(bone.custom_shape),
                              _value(bone.custom_shape_transform),
                              [_rna(con, collections=True) for con in bone.constraints]) for bone in obj.pose.bones],
                       collections=[(col.name, _value(dict(col.items())), [b.name for b in col.bones])
                                    for col in obj.data.collections_all])
        rows.append(row)
    return _digest(rows)


def _action_hash(action, slot):
    from . import animation_worklist_fingerprint as fingerprint
    proof = fingerprint.fingerprint_action(action, slot)
    _require(proof.get('fingerprint_known') is True,
             'The worker input Action cannot be verified: ' + proof.get('proof_reason', 'unknown'))
    return proof['action_fingerprint']


def _raw_packet(rig):
    from . import controller_animation as controller
    raw = controller._raw(rig, tuple(rig.pose.bones.keys()))
    return dict(object=raw['object'], pose=raw['pose'],
                constraints=[[bone, name, settings] for (bone, name), settings in raw['constraints'].items()])


def _restore_packet(rig, packet):
    from . import controller_animation as controller
    raw = dict(object=packet['object'], pose=packet['pose'],
               constraints={(bone, name): settings for bone, name, settings in packet['constraints']})
    controller._restore_raw(rig, raw)


def _portable(source, action, slot, target):
    from . import animation_controller_mapping as mapping
    return dict(source_action=_action_hash(action, slot), source_slot=int(slot),
                source_metadata=_digest(_value(dict(action.items()))),
                source_rest=mapping._rest_fingerprint(source), target_rest=mapping._rest_fingerprint(target),
                controls=_control_fingerprint(source, target))


def _binding(rig):
    ad = rig.animation_data
    if ad is None:
        return None
    return (ad.action.as_pointer() if ad.action else None, ad.action_slot_handle,
            ad.use_nla, ad.action_blend_type, ad.action_influence, ad.action_extrapolation,
            tuple((track.as_pointer(), track.name, track.mute,
                   tuple((strip.as_pointer(), strip.action.as_pointer() if strip.action else None,
                          getattr(strip, 'action_slot_handle', 0)) for strip in track.strips))
                  for track in ad.nla_tracks))


def _witness(context, source, action, slot, target):
    """Read current inputs without seeking or evaluating a scene."""
    from . import animation_controller_mapping as mapping
    return dict(portable=_portable(source, action, slot, target),
                filepath=bpy.data.filepath, dirty=bpy.data.is_dirty,
                scene=context.scene.as_pointer(), view_layer=context.view_layer.as_pointer(),
                mode=context.mode, active=context.view_layer.objects.active.as_pointer()
                if context.view_layer.objects.active else None,
                selected=sorted(obj.as_pointer() for obj in context.selected_objects),
                scenes=[(s.as_pointer(), s.frame_current, s.frame_subframe, s.frame_start,
                         s.frame_end, s.frame_preview_start, s.frame_preview_end, s.use_preview_range,
                         s.tool_settings.use_keyframe_insert_auto) for s in bpy.data.scenes],
                rigs=[(rig.as_pointer(), rig.data.as_pointer(), rig.name, _binding(rig),
                       mapping._rest_fingerprint(rig), _digest(_raw_packet(rig)))
                      for rig in bpy.data.objects if rig.type == 'ARMATURE'])


def _same_witness(before, after, *, appended=False):
    if appended:
        after = dict(after, dirty=before['dirty'])
    return before == after


def _scene_inputs(scene):
    return dict(fps=scene.render.fps, fps_base=scene.render.fps_base,
                unit_system=scene.unit_settings.system, unit_scale=scene.unit_settings.scale_length,
                frame=scene.frame_current + scene.frame_subframe)


def _fresh_inputs(context, source, action, slot, target):
    from . import animation_controller_isolation as isolation
    graph = isolation._graph(target)
    _, secondary = isolation._secondary_sources(target)
    rigs = {source, target, *(obj for obj in secondary if obj.type == 'ARMATURE')}
    if graph:
        rigs.update(obj for obj in graph['collection'].objects if obj.type == 'ARMATURE')
    return dict(portable=_portable(source, action, slot, target), scene=_scene_inputs(context.scene),
                identities=(context.scene.as_pointer(), source.as_pointer(), source.data.as_pointer(),
                            action.as_pointer(), target.as_pointer(), target.data.as_pointer()),
                raw={rig.name_full: _digest(_raw_packet(rig)) for rig in rigs})


def conflicting(source, target):
    for job in _JOBS.values():
        try:
            if source in job['owners'] or target in job['owners']:
                return job
        except ReferenceError:
            # Load/undo invalidated the old RNA while its cancelled child exits.
            continue
    return None


def _close(job):
    global _ACTIVE
    process = job.get('process')
    _require(process is None or process.poll() is not None,
             'The controller worker is still running; its owned job was retained: ' + str(job['root']))
    if job.get('log') is not None:
        job['log'].close()
    if _ACTIVE is job:
        _ACTIVE = None
    _JOBS.pop(str(job['root']), None)


def _stop(job):
    """Never release the owner or its files until this process actually exits."""
    process = job.get('process')
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
    _close(job)


def _remove_output(action, original):
    if action is not None and action not in original:
        action.use_fake_user = False
        _require(action.users == 0, 'A rejected controller result gained a user and was retained for recovery.')
        bpy.data.actions.remove(action)


def _remove_append_libraries(path, original_ids):
    """Remove only an authenticated, unused Library stub left by native append."""
    path = Path(path).resolve()
    users = bpy.data.user_map()
    candidates = [item for item in set(users) - original_ids
                  if isinstance(item, bpy.types.Library)
                  and Path(bpy.path.abspath(item.filepath)).resolve() == path]
    _require(len(candidates) <= 1, 'The controller append produced ambiguous Library owners; dependencies were retained.')
    for library in candidates:
        _require(not library.use_fake_user and library.users == int(library.use_extra_user)
                 and library.parent is None and not users.get(library)
                 and not any(getattr(item, 'library', None) == library for item in users)
                 and not any(item.parent == library for item in bpy.data.libraries),
                 'The controller append Library still has references; its dependencies were retained.')
        # Blender retains this empty append stub with one intrinsic extra user.
        # The reference checks above exclude every real dependent ID first.
        bpy.data.libraries.remove(library, do_unlink=True)


def _load_output(job, receipt):
    path = job['root'] / 'controller.blend'
    _require(path.is_file() and _sha(path) == receipt.get('output_sha256'), 'The worker Action library is missing or changed.')
    original = set(bpy.data.actions)
    original_ids = set(bpy.data.user_map())
    selected, action = None, None
    try:
        with bpy.data.libraries.load(str(path), link=False) as (available, loaded):
            _require(available.actions == [receipt['action']], 'The worker library contains an unexpected Action inventory.')
            _require(not available.objects, 'The worker result unexpectedly contains Objects.')
            selected = loaded
            loaded.actions = [receipt['action']]
        action = selected.actions[0]
        _require(action is not None and action not in original and action.library is None,
                 'The worker did not append one fresh local Action.')
        action.use_fake_user = False
        _require(action.users == 0, 'The new worker Action is unexpectedly assigned.')
        _remove_append_libraries(path, original_ids)
        _require(set(bpy.data.user_map()) - original_ids == {action},
                 'The worker appended unexpected dependencies; its files were retained for recovery.')
        slot = next((slot for slot in action.slots if slot.handle == receipt['slot']), None)
        _require(slot is not None and slot.identifier == receipt['slot_identifier'], 'The returned controller slot changed.')
        _require(_action_hash(action, slot.handle) == receipt['action_sha256'], 'The returned controller curves changed.')
        _require(list(map(float, action.frame_range)) == receipt['frame_range'], 'The returned controller frame range changed.')
        return action, slot.handle
    except Exception as exc:
        if action is None and selected is not None:
            action = next((item for item in selected.actions if isinstance(item, bpy.types.Action)), None)
        recovery = []
        for label, cleanup in (
                ('Action', lambda: _remove_output(action, original)),
                ('Library stub', lambda: _remove_append_libraries(path, original_ids))):
            try:
                cleanup()
            except Exception as error:
                recovery.append(label + ': ' + str(error))
        if recovery:
            raise RuntimeError('Controller append cleanup needs recovery: ' + '; '.join(recovery)) from exc
        raise


def _conversion(context, source_rig, source_action, source_slot, target_rig, *, source_fps=None):
    """Yield the owned job, then publish only when resumed after native exit."""
    global _ACTIVE
    from . import animation_controller_mapping as mapping, animation_controller_isolation as isolation
    if conflicting(source_rig, target_rig) is not None:
        raise RuntimeError('This source or character already has a controller conversion; finish or cancel it first.')
    _require(context.window is not None and target_rig in context.scene.objects.values(),
             'Open controller conversion from the character scene.')
    before = _witness(context, source_rig, source_action, source_slot, target_rig)
    source_fps = mapping._source_fps(source_rig, source_fps)
    graph = isolation._graph(target_rig)
    _, secondary = isolation._secondary_sources(target_rig)
    roots = {context.scene, source_rig, source_action, target_rig, *secondary}
    if graph:
        roots.add(graph['collection'])
        roots.update(graph['collection'].objects)
    _require(None not in roots, 'A controller dependency is missing.')
    package = Path(__file__).resolve().parent
    parent = Path(bpy.utils.user_resource('DATAFILES', path='character_designer/controller_jobs', create=True)).resolve()
    root = parent / uuid.uuid4().hex
    root.mkdir(exist_ok=False)
    config = root / 'CONFIG'
    config.mkdir()
    job = dict(root=root, process=None, log=None, owners=(source_rig, target_rig),
               started=time.monotonic(), phase='Preparing snapshot', cancel_requested=False,
               fresh_inputs=_fresh_inputs(context, source_rig, source_action, source_slot, target_rig))
    output = None
    original_actions = set(bpy.data.actions)
    request = dict(schema=SCHEMA, job=root.name, parent_pid=os.getpid(), package=str(package),
                   parent_identity=_parent_identity(),
                   package_sha256=_package_hashes(package), blender_version=list(bpy.app.version),
                   home=context.scene.name, source=source_rig.name, target=target_rig.name,
                   action=source_action.name, slot=int(source_slot), source_fps=source_fps,
                   frame=float(context.scene.frame_current + context.scene.frame_subframe),
                   scene_inputs=_scene_inputs(context.scene),
                   input_proof=before['portable'],
                   raw_inputs={rig.name: _raw_packet(rig) for rig in roots
                               if isinstance(rig, bpy.types.Object) and rig.type == 'ARMATURE'})
    try:
        snapshot = root / 'inputs.blend'
        request['resources_before_snapshot'] = _resources(root)
        bpy.data.libraries.write(str(snapshot), roots, path_remap='ABSOLUTE', fake_user=False, compress=True)
        _require(_same_witness(before, _witness(context, source_rig, source_action, source_slot, target_rig)),
                 'Writing the controller snapshot changed original inputs; its job was retained.')
        request['snapshot_sha256'] = _sha(snapshot)
        request['resources_before_launch'] = _resources(root)
        _write(root / 'job.json', request)
        job['log'] = (root / 'worker.log').open('x', encoding='utf8')
        environment = os.environ.copy()
        environment['BLENDER_USER_CONFIG'] = str(config)
        environment['PYTHONUTF8'] = '1'
        environment['PYTHONDONTWRITEBYTECODE'] = '1'
        command = [bpy.app.binary_path, '--background', '--factory-startup', '--enable-autoexec',
                   '--threads', '2', '--python-exit-code', '1', '--python', str(Path(__file__).resolve()),
                   '--', str(root / 'job.json')]
        job['process'] = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=job['log'],
                                          stderr=subprocess.STDOUT, env=environment,
                                          creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        _ACTIVE = job
        _JOBS[str(root)] = job
        job['phase'] = 'Creating controls'
        yield job
        _require(not job['cancel_requested'], 'The controller conversion was cancelled before publication.')
        _require(job['process'].poll() is not None, 'The controller worker has not exited.')
        _close(job)
        _write(root / 'process.json', dict(schema=SCHEMA, job=root.name, parent_pid=os.getpid(),
                                          worker_pid=job['process'].pid, elapsed=time.monotonic() - job['started'],
                                          running=False, returncode=job['process'].returncode))
        if _fresh_inputs(context, source_rig, source_action, source_slot, target_rig) != job['fresh_inputs']:
            raise StaleInputs('The character or source changed while creating controls. Open again to convert the current inputs; the completed disk result was retained.')
        result_path = root / 'result.json'
        receipt = json.loads(result_path.read_text(encoding='utf8')) if result_path.is_file() else {}
        _require(receipt.get('schema') == SCHEMA and receipt.get('job') == root.name,
                 'The controller worker did not return a matching receipt. See ' + str(root / 'worker.log'))
        if receipt.get('state') == 'MAPPING_NEEDED':
            raise mapping.MappingNeeded(receipt.get('error', 'Controller mapping needs review.') + ' See ' + str(root / 'worker.log'))
        _require(job['process'].returncode == 0 and receipt.get('state') == 'READY',
                 receipt.get('error', 'Controller worker failed.') + ' See ' + str(root / 'worker.log'))
        _require(receipt.get('input_proof') == request['input_proof'] and
                 receipt.get('snapshot_sha256') == request['snapshot_sha256'], 'The worker converted a different input snapshot.')
        diagnostics = receipt['diagnostics']
        _require(diagnostics.get('native_output_verified') is True and
                 diagnostics.get('source_action_sha256') == request['input_proof']['source_action'],
                 'The controller output lost its native verification or source provenance.')
        publication_before = _witness(context, source_rig, source_action, source_slot, target_rig)
        output, slot = _load_output(job, receipt)
        _require(_same_witness(publication_before, _witness(context, source_rig, source_action, source_slot, target_rig), appended=True),
                 'Appending the controller Action changed the original character inputs.')
        diagnostics['worker'] = dict(job=str(root), snapshot_sha256=request['snapshot_sha256'],
                                     output_sha256=receipt['output_sha256'], parent_evaluation=False)
        output[mapping.RECORD] = _json(diagnostics)
        cleanup = ''
        try:
            _require(job['process'].poll() is not None and root.parent == parent and root.name == request['job'],
                     'The controller snapshot still has an unresolved owner.')
            _require(not any(Path(bpy.path.abspath(lib.filepath)).resolve() == snapshot
                             for lib in bpy.data.libraries), 'The controller snapshot acquired a library user.')
            snapshot.unlink()
        except (OSError, RuntimeError) as exc:
            cleanup = str(exc)
        _write(root / 'accepted.json', dict(schema=SCHEMA, job=root.name, action=output.name,
                                           slot=slot, action_sha256=receipt['action_sha256'],
                                           input_snapshot_removed=not snapshot.exists(), cleanup_warning=cleanup))
        return mapping.MappingResult(output, slot, request['input_proof']['source_action'], diagnostics)
    except GeneratorExit:
        _require(job.get('process') is None or job['process'].poll() is not None,
                 'The owned controller worker must exit before its continuation is released.')
        _close(job)
        _write(root / 'cancelled.json', dict(schema=SCHEMA, job=root.name, state='CANCELLED'))
        raise
    except BaseException as exc:
        recovery = []
        try:
            if job.get('process') is not None and job['process'].poll() is None:
                _stop(job)
            else:
                _close(job)
        except BaseException as error:
            recovery.append('worker stop: ' + str(error))
        try:
            _remove_output(output, original_actions)
        except BaseException as error:
            recovery.append('result cleanup: ' + str(error))
        _write(root / 'parent_error.json', dict(schema=SCHEMA, job=root.name, error=str(exc),
                                              type=type(exc).__name__, traceback=traceback.format_exc(),
                                              recovery_errors=recovery))
        if recovery:
            raise RuntimeError('Controller conversion needs recovery. ' + '; '.join(recovery) + '. See ' + str(root)) from exc
        raise


def begin(context, source_rig, source_action, source_slot, target_rig, *, source_fps=None):
    transaction = _conversion(context, source_rig, source_action, source_slot, target_rig, source_fps=source_fps)
    job = next(transaction)
    job['continuation'] = transaction
    return job


def request_cancel(job):
    """Artist UI: initiate cancellation without waiting on the child."""
    if job['cancel_requested']:
        return
    job['cancel_requested'] = True
    job['phase'] = 'Cancelling'
    job['cancel_started'] = time.monotonic()
    job['kill_requested'] = False
    _write(job['root'] / 'cancel.json', dict(schema=SCHEMA, job=job['root'].name, state='CANCELLING'))
    if job['process'].poll() is None:
        job['process'].terminate()


def poll(job):
    """Read one small progress receipt; never import Actions or mutate scenes."""
    process = job['process']
    code = process.poll()
    if job['cancel_requested']:
        if code is None:
            if time.monotonic() - job['cancel_started'] >= 5 and not job['kill_requested']:
                job['kill_requested'] = True
                process.kill()
            return None
        job['continuation'].close()
        return dict(state='CANCELLED')
    progress = job['root'] / 'progress.json'
    if progress.is_file():
        try:
            value = json.loads(progress.read_text(encoding='utf8'))
            if value.get('job') == job['root'].name:
                job['phase'] = str(value.get('phase') or 'Creating controls')
        except (OSError, ValueError):
            pass
    _write(job['root'] / 'process.json', dict(schema=SCHEMA, job=job['root'].name, parent_pid=os.getpid(),
                                             worker_pid=process.pid, elapsed=time.monotonic() - job['started'],
                                             running=code is None, returncode=code))
    return None if code is None else dict(state='EXITED')


def finish(job):
    _require(not job['cancel_requested'], 'Cancellation wins over the completed worker result.')
    _require(job['process'].poll() is not None, 'The controller worker has not exited.')
    try:
        next(job['continuation'])
    except StopIteration as result:
        return result.value
    raise RuntimeError('The controller worker continuation yielded unexpectedly.')


def build(context, source_rig, source_action, source_slot, target_rig, *, source_fps=None):
    """Synchronous entry for scripts; the artist UI uses begin/poll/finish."""
    job = begin(context, source_rig, source_action, source_slot, target_rig, source_fps=source_fps)
    try:
        while poll(job) is None:
            time.sleep(.1)
        return finish(job)
    except BaseException:
        _stop(job)
        job['continuation'].close()
        raise


def _child(job_path):
    """Standalone entry: never called by the artist-side service."""
    path = Path(job_path).resolve(strict=True)
    root = path.parent
    request = json.loads(path.read_text(encoding='utf8'))
    _require(bpy.app.background and request.get('schema') == SCHEMA and request.get('job') == root.name
             and request.get('parent_pid') != os.getpid(), 'Controller worker ownership was not established.')
    _require(Path(os.environ.get('BLENDER_USER_CONFIG', '')).resolve() == root / 'CONFIG',
             'Controller worker needs its private CONFIG.')
    receipt = dict(schema=SCHEMA, job=root.name, state='ERROR')
    stop_parent_watch = None
    try:
        stop_parent_watch = _watch_parent(request, root)
        _write(root / 'progress.json', dict(job=root.name, phase='Loading snapshot'))
        package = Path(request['package']).resolve(strict=True)
        sys.dont_write_bytecode = True
        _require(_package_hashes(package) == request['package_sha256'], 'The controller worker package changed.')
        _require(list(bpy.app.version) == request['blender_version'], 'The controller worker Blender version differs.')
        sys.path.insert(0, str(package.parent))
        addon = importlib.import_module(package.name)
        _require(Path(addon.__file__).resolve().parent == package, 'The worker imported another add-on package.')
        addon.register()
        mapping = importlib.import_module(package.name + '.animation_controller_mapping')
        helpers = importlib.import_module(package.name + '.animation_controller_worker')
        snapshot = root / 'inputs.blend'
        _require(_sha(snapshot) == request['snapshot_sha256'], 'The controller input snapshot changed.')
        _require(bpy.ops.wm.open_mainfile(filepath=str(snapshot), use_scripts=True) == {'FINISHED'},
                 'The controller snapshot did not open.')
        home = bpy.data.scenes.get(request['home'])
        source = bpy.data.objects.get(request['source'])
        target = bpy.data.objects.get(request['target'])
        action = bpy.data.actions.get(request['action'])
        _require(home is not None and source is not None and target is not None and action is not None,
                 'The controller snapshot lost its scene, character, source or Action.')
        bpy.context.window.scene = home
        _require(helpers._scene_inputs(home) == request['scene_inputs'], 'The snapshot scene timing or units changed.')
        natural = importlib.import_module(package.name + '.natural_bind_mode')
        pending = bpy.app.timers.is_registered(natural._after_read)
        lifecycle = dict(pending_before=pending, loaded_inputs_before=sorted(natural._loaded_inputs))
        receipt['load_lifecycle'] = lifecycle
        if pending:
            # Background Python does not drive the normal deferred load timer.
            # Consume exactly that scheduled callback before seeding RAM inputs.
            bpy.app.timers.unregister(natural._after_read)
            natural._after_read()
        lifecycle.update(pending_after=bpy.app.timers.is_registered(natural._after_read),
                         loaded_inputs_after=sorted(natural._loaded_inputs))
        # Seed immediate RAM inputs after native file loading, only in this worker.
        for name, raw in request['raw_inputs'].items():
            rig = bpy.data.objects.get(name)
            _require(rig is not None and rig.type == 'ARMATURE', 'The snapshot lost an authenticated Armature.')
            helpers._restore_packet(rig, raw)
        proof = helpers._portable(source, action, request['slot'], target)
        _require(proof == request['input_proof'], 'The snapshot source Action or Armature Rest differs from current RAM.')
        _write(root / 'progress.json', dict(job=root.name, phase='Mapping and refining controller motion'))
        result = mapping._build_isolated(bpy.context, source, action, request['slot'], target,
                                         source_fps=request['source_fps'])
        _require(result.action.users == 0, 'The worker output Action is still assigned.')
        slot = next((s for s in result.action.slots if s.handle == result.slot), None)
        _require(slot is not None, 'The controller output lost its slot.')
        output = root / 'controller.blend'
        _write(root / 'progress.json', dict(job=root.name, phase='Writing verified Action'))
        bpy.data.libraries.write(str(output), {result.action}, path_remap='ABSOLUTE', fake_user=True, compress=True)
        receipt.update(state='READY', input_proof=proof, snapshot_sha256=request['snapshot_sha256'],
                       action=result.action.name, slot=result.slot, slot_identifier=slot.identifier,
                       action_sha256=helpers._action_hash(result.action, result.slot),
                       frame_range=list(map(float, result.action.frame_range)),
                       output_sha256=_sha(output), diagnostics=result.diagnostics)
        _require(_package_hashes(package) == request['package_sha256'],
                 'The controller worker package changed during conversion; its result was not accepted.')
        _write(root / 'result.json', receipt)
    except BaseException as exc:
        mapping_module = sys.modules.get(Path(request.get('package', '')).name + '.animation_controller_mapping')
        needed = mapping_module is not None and isinstance(exc, mapping_module.MappingNeeded)
        receipt.update(state='MAPPING_NEEDED' if needed else 'ERROR', error=str(exc),
                       type=type(exc).__name__, traceback=traceback.format_exc())
        _write(root / 'result.json', receipt)
        raise
    finally:
        if stop_parent_watch is not None:
            stop_parent_watch()


if __name__ == '__main__':
    _child(sys.argv[sys.argv.index('--') + 1])
