"""Open one source motion as an independently retained character-controller edit."""

import math
import time

import bpy

_OPENING = False
_PENDING = {}


def _target(home, expected):
    target = home.character_designer_setup.rig
    if (home.library or home.override_library or target is None or target != expected
            or target.type != 'ARMATURE' or target.library or target.override_library
            or not target.is_editable or target.data.library or target.data.override_library
            or home.objects.get(target.name) != target or target.mode == 'EDIT'):
        raise ValueError('The controller edit needs its locally editable character in the original scene outside Edit Mode.')
    return target


def _record(home, row, *, create=True):
    records = home.character_designer_controller_motions
    identity = home.character_designer_animation_worklist.workspace_identity
    key = row.work_item_id or row.clip_key
    target = home.character_designer_setup.rig
    matches = [record for record in records if record.workspace_identity == identity
               and record.work_item_id == key and record.target == target]
    if len(matches) > 1:
        raise ValueError('This motion has multiple saved controller edits. Resolve their identity before opening it.')
    if matches:
        return matches[0]
    if not create:
        return None
    index = len(records)
    record = records.add()
    try:
        record.workspace_identity = identity
        record.work_item_id = key
        record.clip_key = row.clip_key
        record.target = target
    except Exception:
        records.remove(index)
        raise
    return record


def _publish(record, row, built):
    values = dict(source_rig=row.rig, source_action=row.custom_action, source_slot=row.custom_slot,
                  source_fingerprint=built.source_fingerprint, controller_action=built.action,
                  controller_slot=built.slot, state='READY', error='')
    previous = {key: getattr(record, key) for key in values}
    try:
        for key, value in values.items():
            setattr(record, key, value)
    except Exception as exc:
        failures = []
        for key, value in previous.items():
            try:
                setattr(record, key, value)
            except Exception as recovery:
                failures.append(str(recovery))
        if failures:
            raise RuntimeError('Controller edit publication needs recovery: ' + '; '.join(failures)) from exc
        raise


def _native(context, scene, row, message='', *, mapping_needed=False):
    from . import animation_worklist as worklist, animation_worklist_edit_scene as edit_scene
    previous_scene = context.scene
    try:
        context.window.scene = scene
        worklist.activate(context, row.item_id, 'CUSTOM')
    except Exception as exc:
        try:
            setup = getattr(previous_scene, 'character_designer_setup', None)
            if setup is not None and setup.rig is not None and edit_scene.editing_scene(previous_scene) == scene:
                return_to_character(context, previous_scene)
            elif context.window.scene != previous_scene:
                context.window.scene = previous_scene
        except Exception as recovery:
            raise RuntimeError('Native motion activation needs context recovery: ' + str(recovery)) from exc
        raise
    result = dict(state='MAPPING_NEEDED' if mapping_needed else 'NATIVE',
                  message=message or 'Original bone editing.')
    saved = worklist.state(context)
    saved.status, saved.has_error = result['message'], mapping_needed
    return result


def _return_identity(home, rig):
    from . import animation_controller_worker as worker, animation_controller_isolation as isolation
    return (home.character_designer_setup.rig, rig.data, worker._binding(rig),
            home.frame_current, home.frame_subframe,
            worker._digest(worker._value(isolation._graph(rig))))


def _restore_changed_inputs(rig, before, after):
    from . import controller_animation as controller
    if before['constraints'] != after['constraints'] or before['pose'].keys() != after['pose'].keys():
        raise ValueError('The character constraints or bone ownership changed during return.')
    def numeric(value):
        return ((type(value) in (bool, int, float) and math.isfinite(value))
                or isinstance(value, (tuple, list)) and all(numeric(item) for item in value))
    changes = []
    blocks = [(rig, before['object'], after['object'])] + [
        (rig.pose.bones[name], values, after['pose'][name]) for name, values in before['pose'].items()]
    for block, saved, current in blocks:
        if (saved['rotation_mode'] != current['rotation_mode']
                or saved['settings'].keys() != current['settings'].keys()
                or saved['properties'].keys() != current['properties'].keys()):
            raise ValueError('The character input structure changed during return.')
        for field in controller._TRANSFORMS:
            if saved[field] != current[field]:
                changes.append((block, field, saved[field], False))
        for group in ('settings', 'properties'):
            for field, value in saved[group].items():
                if value != current[group][field]:
                    if not numeric(value) or not numeric(current[group][field]):
                        raise ValueError('An unsupported character setting changed during return: ' + field)
                    changes.append((block, field, value, group == 'properties'))
    for block, field, value, custom in changes:
        if custom:
            block[field] = value
        else:
            setattr(block, field, value)


def return_to_character(context, home):
    """Preserve inputs held immediately before this switch, never a departure pose."""
    from . import animation_worklist as worklist, animation_link_source as source
    from . import animation_controller_worker as worker
    worklist._idle(context)
    rig = _target(home, home.character_designer_setup.rig)
    caller = source._context_state(context)
    identity = _return_identity(home, rig)
    before = worker._raw_packet(rig)
    try:
        context.window.scene = home
        if _return_identity(home, rig) != identity:
            raise ValueError('The character binding, frame or ownership changed during return.')
        _restore_changed_inputs(rig, before, worker._raw_packet(rig))
        context.view_layer.update()
        if _return_identity(home, rig) != identity or worker._raw_packet(rig) != before:
            raise RuntimeError('The current character inputs did not survive the native return update.')
    except Exception as exc:
        try:
            source._restore_context(context, caller, playing=False)
            if _return_identity(home, rig) == identity:
                _restore_changed_inputs(rig, before, worker._raw_packet(rig))
        except Exception as recovery:
            raise RuntimeError('Returning to the character needs recovery: ' + str(recovery)) from exc
        raise


def _activate(context, home, record):
    from . import natural_bind_mode, unity_animation as ua
    rig = _target(home, record.target)
    recovery = ''
    try:
        with natural_bind_mode.defer_expiry(rig) as transition:
            result = _activate_provisional(context, home, record)
            transition.commit()
    except natural_bind_mode.ExpiryCommitError as exc:
        recovery = str(exc)
    if not recovery:
        try:
            # The committed expiry can remove a neutral solver and restore its
            # held inputs. Evaluate the selected Action after that boundary.
            ua._set_frame(home, home.frame_current + home.frame_subframe)
            context.view_layer.update()
        except Exception as exc:
            recovery = str(exc)
    if recovery:
        message = 'The controller Action is open, but its pose refresh failed. Open this motion again. ' + recovery
        settings = home.character_designer_animation_worklist
        settings.status, settings.has_error = message, True
        return dict(state='CONTROLLER_RECOVERY', message=message)
    return result


def _activate_provisional(context, home, record):
    from .animation_local_motion_pins import assign_character_action
    from .animation_original_inputs_ui import original_inputs_live
    from . import animation_worklist as worklist, animation_composition as composition
    from . import animation_link_source as source, unity_animation as ua
    from . import controller_animation as controller
    if record.state != 'READY':
        raise ValueError('The saved controller edit is incomplete. Its Action was retained for recovery.')
    rig = _target(home, record.target)
    caller = source._context_state(context)
    saved = None
    try:
        worklist._idle(context)
        if context.scene != home:
            return_to_character(context, home)
        else:
            context.window.scene = home
        worklist._idle(context)
        if original_inputs_live(context):
            raise ValueError('Finish editing Original Rigging Inputs first.')
        if composition.active(rig):
            raise ValueError('Close Composition before switching controller Actions; both drafts are retained.')
        if ua.active_preview(rig):
            raise ValueError('Restore the unrelated Unity test preview before switching controller Actions.')
        if context.view_layer.objects.get(rig.name) != rig:
            raise ValueError('The character must be available in the current view layer.')
        start, end = map(float, record.controller_action.frame_range)
        if not math.isfinite(start) or not math.isfinite(end) or start > end:
            raise ValueError('The controller Action has an invalid frame range.')
        ad = rig.animation_data
        prior_action = ad.action if ad else None
        settings = home.character_designer_animation_worklist
        window_settings = context.window_manager.character_designer_animation
        range_fields = ('frame_start', 'frame_end', 'frame_preview_start', 'frame_preview_end', 'use_preview_range')
        saved = dict(context=source._context_state(context), ad=ad,
                     action=prior_action, slot=ad.action_slot if ad else None,
                     fake=prior_action.use_fake_user if prior_action else None,
                     animation={key: getattr(ad, key) for key in ('use_nla', 'action_blend_type', 'action_influence')} if ad else {},
                     range={key: getattr(home, key) for key in range_fields},
                     frame=home.frame_current + home.frame_subframe,
                     auto_key=home.tool_settings.use_keyframe_insert_auto,
                     hidden=rig.hide_get(), target=window_settings.target,
                     pose=controller._raw(rig, tuple(bone.name for bone in rig.pose.bones)),
                     catalog_index=settings.catalog_index,
                     status=settings.status, has_error=settings.has_error)
        ua._set_playing(context, False)
        assign_character_action(rig, record.controller_action, record.controller_slot)
        ad = rig.animation_data
        ad.use_nla, ad.action_blend_type, ad.action_influence = False, 'REPLACE', 1.0
        home.tool_settings.use_keyframe_insert_auto = False
        home.frame_start = home.frame_preview_start = math.floor(start)
        home.frame_end = home.frame_preview_end = max(math.ceil(end), home.frame_start)
        home.use_preview_range = True
        ua._set_frame(home, start)
        for selected in context.selected_objects:
            selected.select_set(False)
        rig.hide_set(False)
        rig.select_set(True)
        context.view_layer.objects.active = rig
        window_settings.target = rig
        context.view_layer.update()
        selected_index = next((i for i, row in enumerate(settings.catalog) if row.clip_key == record.clip_key), None)
        if selected_index is not None:
            settings.catalog_index = selected_index
        settings.status, settings.has_error = 'Controller editing.', False
    except Exception as exc:
        failures = []
        def restore(label, callback):
            try:
                callback()
            except Exception as recovery:
                failures.append(label + ': ' + str(recovery))
        if saved is not None:
            if saved['ad'] is None:
                restore('animation data', rig.animation_data_clear)
            else:
                restore('Action', lambda: setattr(saved['ad'], 'action', saved['action']))
                restore('Action slot', lambda: setattr(saved['ad'], 'action_slot', saved['slot']))
                for key, value in saved['animation'].items():
                    restore(key, lambda key=key, value=value: setattr(saved['ad'], key, value))
            if saved['action'] is not None:
                restore('Action retention', lambda: setattr(saved['action'], 'use_fake_user', saved['fake']))
            for key, value in saved['range'].items():
                restore(key, lambda key=key, value=value: setattr(home, key, value))
            restore('auto key', lambda: setattr(home.tool_settings, 'use_keyframe_insert_auto', saved['auto_key']))
            restore('frame', lambda: ua._set_frame(home, saved['frame']))
            restore('held character inputs', lambda: controller._restore_raw(rig, saved['pose']))
            restore('character context', lambda: source._restore_context(context, saved['context'], playing=False))
            restore('character pose evaluation', lambda: saved['context']['view_layer'].update())
            restore('character visibility', lambda: rig.hide_set(saved['hidden']))
            restore('animation target', lambda: setattr(window_settings, 'target', saved['target']))
            restore('catalog selection', lambda: setattr(settings, 'catalog_index', saved['catalog_index']))
            restore('status', lambda: setattr(settings, 'status', saved['status']))
            restore('error status', lambda: setattr(settings, 'has_error', saved['has_error']))
        restore('caller context', lambda: source._restore_context(context, caller, playing=True))
        if failures:
            raise RuntimeError('Controller motion opening needs recovery: ' + '; '.join(failures)) from exc
        raise
    return dict(state='CONTROLLER', message='Controller editing.')


def open_motion(context, home, clip_key, *, asynchronous=False):
    """An explicit open may build one motion. Drawing and file loading never build."""
    global _OPENING
    if _OPENING:
        raise RuntimeError('Finish opening the current motion before opening another controller edit.')
    _OPENING = True
    try:
        if asynchronous:
            return _open_async(context, home, clip_key)
        return _open_motion(context, home, clip_key)
    finally:
        _OPENING = False


def _open_motion(context, home, clip_key):
    from . import animation_worklist as worklist, animation_worklist_edit_scene as edit_scene
    from . import animation_controller_mapping as mapping
    from . import animation_action_browser as browser

    worklist._idle(context)
    source_scene = edit_scene.editing_scene(home)
    if source_scene is None or context.window is None:
        raise ValueError('The editing scene for this workspace is unavailable.')
    row = edit_scene._local_row(source_scene, clip_key)
    if row is None:
        if not any(entry.clip_key == clip_key and entry.ready
                   for entry in home.character_designer_animation_worklist.catalog):
            raise ValueError('This motion is no longer in the prepared list.')
        previous_scene = context.scene
        try:
            context.window.scene = source_scene
            row = worklist.add(context, clip_key, activate_new=False)
        finally:
            if previous_scene == home:
                return_to_character(context, home)
            else:
                context.window.scene = previous_scene
    if not home.character_designer_animation_worklist.convert_imported_to_controls:
        return _native(context, source_scene, row)

    record = _record(home, row)
    if record.controller_action is not None:
        # Published edits remain authoritative for this work identity. A source
        # refresh never silently rebuilds over the user's controller changes.
        return _activate(context, home, record)

    previous_scene = context.scene
    created = None
    try:
        target = home.character_designer_setup.rig
        source_fps = source_scene.render.fps / source_scene.render.fps_base
        layer = context.view_layer if context.scene == home else home.view_layers[0]
        with context.temp_override(scene=home, view_layer=layer):
            built = mapping.build(bpy.context, row.rig, row.custom_action, row.custom_slot,
                                  target, source_fps=source_fps)
        created = built.action
        browser.classify_action(created, target, role='WORK', label=row.name,
                                clip_id=row.work_item_id or row.clip_key)
        created.name = home.character_designer_animation_worklist.target_name + ' · ' + row.name + ' · Controllers'
        created.use_fake_user = True
        _target(home, target)
        _publish(record, row, built)
        result = _activate(context, home, record)
        return result
    except mapping.MappingNeeded as exc:
        try:
            record.state, record.error = 'MAPPING_NEEDED', str(exc)
            return _native(context, source_scene, row,
                           'Mapping needed. ' + str(exc), mapping_needed=True)
        except Exception:
            if context.window.scene != previous_scene:
                context.window.scene = previous_scene
            raise
    except Exception:
        # Keep a complete built result if activation failed. It can be opened
        # again after the native context issue is resolved.
        try:
            if created is not None and record.controller_action is None:
                created.use_fake_user = False
                if not created.users:
                    try:
                        bpy.data.actions.remove(created)
                    except Exception:
                        created.use_fake_user = True
                        raise
        finally:
            if context.window.scene != previous_scene:
                context.window.scene = previous_scene
        raise


def pending(home, clip_key=None):
    for key, item in _PENDING.items():
        try:
            matches = item['home'] == home and (clip_key is None or item['clip_key'] == clip_key)
        except ReferenceError:
            continue
        if matches:
            job = item['job']
            elapsed = max(0, int(time.monotonic() - job['started']))
            return dict(job_id=key, phase=job['phase'], elapsed=elapsed,
                        cancelling=job['cancel_requested'], error=item.get('error', ''))
    return None


def _initiator(context):
    return (context.window, context.scene, context.view_layer,
            context.view_layer.objects.active, tuple(context.selected_objects), context.mode)


def _same_initiator(item):
    window, scene, layer, active, selected, mode = item['initiator']
    try:
        if (bpy.context.window != window or window not in bpy.context.window_manager.windows
                or window.scene != scene or window.view_layer != layer):
            return False
        with bpy.context.temp_override(window=window, scene=scene, view_layer=layer):
            return (bpy.context.view_layer.objects.active == active
                    and set(bpy.context.selected_objects) == set(selected) and bpy.context.mode == mode)
    except (ReferenceError, RuntimeError):
        return False


def _row_for_pending(item):
    from . import animation_worklist_edit_scene as edit_scene
    home = item['home']
    if home.character_designer_animation_worklist.workspace_identity != item['workspace']:
        raise ValueError('The motion workspace changed while creating controls. Open again to use its current inputs.')
    scene = edit_scene.editing_scene(home)
    row = edit_scene._local_row(scene, item['clip_key']) if scene is not None else None
    if (row is None or (row.work_item_id or row.clip_key) != item['work_item_id']
            or row.rig != item['source_rig'] or row.custom_action != item['source_action']
            or row.custom_slot != item['source_slot']):
        raise ValueError('The source work item changed while creating controls. Its disk result was retained.')
    if (scene.render.fps, scene.render.fps_base) != item['source_timing']:
        raise ValueError('The source motion timing changed while creating controls. Open again to use its current timing.')
    _target(home, item['target'])
    return scene, row


def _open_async(context, home, clip_key):
    from . import animation_worklist as worklist, animation_worklist_edit_scene as edit_scene
    from . import animation_controller_worker as worker, animation_controller_mapping as mapping
    worklist._idle(context)
    scene = edit_scene.editing_scene(home)
    if scene is None or context.window is None:
        raise ValueError('The editing scene for this workspace is unavailable.')
    row = edit_scene._local_row(scene, clip_key)
    if row is None:
        if not any(entry.clip_key == clip_key and entry.ready for entry in home.character_designer_animation_worklist.catalog):
            raise ValueError('This motion is no longer in the prepared list.')
        original = context.window.scene
        try:
            context.window.scene = scene
            row = worklist.add(context, clip_key, activate_new=False)
        finally:
            if original == home:
                return_to_character(context, home)
            else:
                context.window.scene = original
    current = pending(home, clip_key)
    if not home.character_designer_animation_worklist.convert_imported_to_controls:
        if current is not None:
            cancel_pending(current['job_id'])
        return _native(context, scene, row)
    if current is not None:
        return dict(state='PENDING', message=current['phase'])
    record = _record(home, row, create=False)
    if record is not None and record.controller_action is not None:
        return _activate(context, home, record)
    target = _target(home, home.character_designer_setup.rig)
    initiator = _initiator(context)
    layer = context.view_layer if context.scene == home else home.view_layers[0]
    try:
        with context.temp_override(scene=home, view_layer=layer):
            job = worker.begin(bpy.context, row.rig, row.custom_action, row.custom_slot, target,
                               source_fps=scene.render.fps / scene.render.fps_base)
    except mapping.MappingNeeded as exc:
        record = _record(home, row)
        record.state, record.error = 'MAPPING_NEEDED', str(exc)
        return _native(context, scene, row, 'Mapping needed. ' + str(exc), mapping_needed=True)
    key = job['root'].name
    _PENDING[key] = dict(job=job, home=home, layer=layer, initiator=initiator, clip_key=clip_key,
                         workspace=home.character_designer_animation_worklist.workspace_identity,
                         work_item_id=row.work_item_id or row.clip_key, source_rig=row.rig,
                         source_action=row.custom_action, source_slot=row.custom_slot, target=target)
    _PENDING[key]['source_timing'] = (scene.render.fps, scene.render.fps_base)
    try:
        _start_runtime()
    except BaseException:
        worker._stop(job)
        job['continuation'].close()
        _PENDING.pop(key, None)
        raise
    return dict(state='PENDING', message='Creating controls. You can continue working or cancel.')


def cancel_pending(key):
    from . import animation_controller_worker as worker
    item = _PENDING.get(key)
    if item is None:
        return
    worker.request_cancel(item['job'])
    _start_runtime()


def _pending_error(item, error):
    message = str(error) + ' Worker files: ' + str(item['job']['root'])
    item['error'] = message
    item['job']['phase'] = 'Needs attention: ' + message
    try:
        settings = item['home'].character_designer_animation_worklist
        settings.status, settings.has_error = message, True
    except ReferenceError:
        # A load/undo may already have invalidated this owner. Its worker
        # receipts remain the durable error record; never touch the new scene.
        pass


def finalize_pending(context, key):
    from . import animation_controller_worker as worker, animation_controller_mapping as mapping
    from . import animation_action_browser as browser
    item = _PENDING.get(key)
    if item is None:
        raise ValueError('This controller conversion is no longer pending.')
    home, job = item['home'], item['job']
    created, record = None, None
    try:
        if job['cancel_requested'] or not home.character_designer_animation_worklist.convert_imported_to_controls:
            if not job['cancel_requested']:
                worker.request_cancel(job)
            worker.poll(job)
            return dict(state='CANCELLED', message='Controller conversion cancelled.')
        scene, row = _row_for_pending(item)
        record = _record(home, row, create=False)
        if record is not None and record.controller_action is not None:
            raise ValueError('This work item acquired a controller edit while conversion was pending. Both results were retained.')
        activate = _same_initiator(item)
        with context.temp_override(scene=home, view_layer=item['layer']):
            built = worker.finish(job)
        created = built.action
        browser.classify_action(created, item['target'], role='WORK', label=row.name,
                                clip_id=row.work_item_id or row.clip_key)
        created.name = home.character_designer_animation_worklist.target_name + ' · ' + row.name + ' · Controllers'
        created.use_fake_user = True
        record = _record(home, row)
        _publish(record, row, built)
        if activate:
            window, initiating_scene, layer, *_ = item['initiator']
            with context.temp_override(window=window):
                return _activate(bpy.context, home, record)
        return dict(state='READY', message='Controllers ready. Open this motion to edit them.')
    except mapping.MappingNeeded as exc:
        scene, row = _row_for_pending(item)
        record = _record(home, row)
        record.state, record.error = 'MAPPING_NEEDED', str(exc)
        if _same_initiator(item):
            window, initiating_scene, layer, *_ = item['initiator']
            with context.temp_override(window=window):
                return _native(bpy.context, scene, row, 'Mapping needed. ' + str(exc), mapping_needed=True)
        return dict(state='MAPPING_NEEDED', message=str(exc))
    except Exception as exc:
        _pending_error(item, exc)
        if created is not None and (record is None or record.controller_action is None):
            created.use_fake_user = False
            if not created.users:
                bpy.data.actions.remove(created)
        raise
    finally:
        if job['process'].poll() is not None:
            job['continuation'].close()
            worker._close(job)
            _PENDING.pop(key, None)


def _redraw_pending():
    for wm in bpy.data.window_managers:
        for window in wm.windows:
            if window.screen:
                for area in window.screen.areas:
                    if area.type in {'DOPESHEET_EDITOR', 'VIEW_3D'}:
                        area.tag_redraw()


def _poll_pending():
    from . import animation_controller_worker as worker
    for key, item in tuple(_PENDING.items()):
        job = item['job']
        try:
            if not job['cancel_requested']:
                try:
                    enabled = item['home'].character_designer_animation_worklist.convert_imported_to_controls
                except ReferenceError:
                    enabled = False
                if not enabled:
                    worker.request_cancel(job)
            result = worker.poll(job)
            if result is None:
                continue
            if result['state'] == 'CANCELLED':
                _PENDING.pop(key, None)
                continue
            bpy.ops.character_designer.finish_controller_motion(job_id=key)
        except Exception as exc:
            _pending_error(item, exc)
            # A failed stop retains the process and its poll owner. A completed
            # transaction retains its disk receipt and can be retried explicitly.
            if job['process'].poll() is not None:
                job['continuation'].close()
                worker._close(job)
                _PENDING.pop(key, None)
    _redraw_pending()
    if _PENDING:
        return .25
    _remove_handlers()
    return None


def _cancel_for_read(_unused):
    for key in tuple(_PENDING):
        try:
            cancel_pending(key)
        except Exception as exc:
            _PENDING[key]['error'] = str(exc)


def _remove_handlers():
    for name in ('load_pre', 'undo_pre', 'redo_pre'):
        handlers = getattr(bpy.app.handlers, name)
        if _cancel_for_read in handlers:
            handlers.remove(_cancel_for_read)


def _start_runtime():
    bpy.app.handlers.persistent(_cancel_for_read)
    added = []
    registered = bpy.app.timers.is_registered(_poll_pending)
    try:
        for name in ('load_pre', 'undo_pre', 'redo_pre'):
            handlers = getattr(bpy.app.handlers, name)
            if _cancel_for_read not in handlers:
                handlers.append(_cancel_for_read)
                added.append(handlers)
        if not registered:
            bpy.app.timers.register(_poll_pending, first_interval=.25, persistent=True)
    except Exception:
        for handlers in added:
            handlers.remove(_cancel_for_read)
        if not registered and bpy.app.timers.is_registered(_poll_pending):
            bpy.app.timers.unregister(_poll_pending)
        raise


def stop_runtime():
    _cancel_for_read(None)
    if not _PENDING:
        _remove_handlers()
        if bpy.app.timers.is_registered(_poll_pending):
            bpy.app.timers.unregister(_poll_pending)
