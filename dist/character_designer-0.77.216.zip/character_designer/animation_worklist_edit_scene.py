"""Open a prepared motion in the local scene that owns its editable Action."""

import bpy
from bpy.props import CollectionProperty, EnumProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, PropertyGroup, UIList

EDIT_SCENE = 'character_designer_prepared_edit_scene_v1'


class CharacterDesignerControllerMotion(PropertyGroup):
    workspace_identity: StringProperty(options={'HIDDEN'})
    work_item_id: StringProperty(options={'HIDDEN'})
    clip_key: StringProperty(options={'HIDDEN'})
    target: PointerProperty(type=bpy.types.Object)
    source_rig: PointerProperty(type=bpy.types.Object)
    source_action: PointerProperty(type=bpy.types.Action)
    source_slot: IntProperty(default=0, options={'HIDDEN'})
    source_fingerprint: StringProperty(options={'HIDDEN'})
    controller_action: PointerProperty(type=bpy.types.Action)
    controller_slot: IntProperty(default=0, options={'HIDDEN'})
    state: EnumProperty(items=(
        ('UNTRIED', 'Original bones', 'Controller mapping has not been attempted'),
        ('READY', 'Controllers', 'A controller Action is available for this character'),
        ('MAPPING_NEEDED', 'Mapping needed', 'Open the original motion and review the mapping issue'),
    ), default='UNTRIED', options={'HIDDEN'})
    error: StringProperty(options={'HIDDEN'})

    @classmethod
    def register(cls):
        bpy.types.Scene.character_designer_controller_motions = CollectionProperty(type=cls)

    @classmethod
    def unregister(cls):
        from . import animation_controller_edit
        animation_controller_edit.stop_runtime()
        del bpy.types.Scene.character_designer_controller_motions


def editing_scene(home):
    scene = home.get(EDIT_SCENE) if hasattr(home, 'get') else None
    if scene is None:
        return None
    if not isinstance(scene, bpy.types.Scene) or scene == home or scene.library or scene.override_library:
        return None
    owner = home.character_designer_animation_worklist
    actions = scene.character_designer_animation_worklist
    if (not owner.workspace_identity or owner.workspace_identity != actions.workspace_identity
            or not actions.rig or actions.rig == owner.rig or actions.rig.name not in scene.objects):
        return None
    return scene


def _local_row(scene, key):
    return next((row for row in scene.character_designer_animation_worklist.items if row.clip_key == key), None)


def mapping_home(scene):
    if editing_scene(scene) is not None:
        return scene
    homes = home_scenes(scene)
    return homes[0] if len(homes) == 1 else None


def mapping_record(home, row):
    if home is None or row is None:
        return None
    identity = home.character_designer_animation_worklist.workspace_identity
    target = home.character_designer_setup.rig
    key = getattr(row, 'work_item_id', '') or row.clip_key
    matches = [record for record in getattr(home, 'character_designer_controller_motions', ())
               if record.workspace_identity == identity and record.work_item_id == key
               and record.target == target]
    return matches[0] if len(matches) == 1 else None


def draw_mapping_state(layout, context, row):
    from . import animation_controller_edit
    home = mapping_home(context.scene)
    if home is None:
        return
    running = animation_controller_edit.pending(home, row.clip_key)
    if running is not None:
        layout.label(text='Cancelling' if running['cancelling'] else 'Creating controls', icon='TIME')
        return
    requested = home.character_designer_animation_worklist.convert_imported_to_controls
    record = mapping_record(home, row)
    if requested and record is not None and record.state == 'MAPPING_NEEDED':
        layout.label(text='Mapping needed', icon='INFO')
    elif requested and record is not None and record.state == 'READY' and record.controller_action:
        layout.label(text='Controllers')
    else:
        layout.label(text='Original bones')


def draw_mapping_options(layout, context):
    from . import animation_controller_edit
    home = mapping_home(context.scene)
    if home is None:
        return
    settings = home.character_designer_animation_worklist
    layout.prop(settings, 'convert_imported_to_controls', text='Convert to Character Controls')
    running = animation_controller_edit.pending(home)
    if running is not None:
        line = layout.row(align=True)
        minutes, seconds = divmod(running['elapsed'], 60)
        line.label(text=running['phase'] + ' · %d:%02d' % (minutes, seconds), icon='TIME')
        cancel = line.operator('character_designer.cancel_controller_motion', text='Cancel', icon='CANCEL')
        cancel.job_id = running['job_id']
    current = context.scene.character_designer_animation_worklist
    rows = current.items if current.items else current.catalog
    index = current.active_index if current.items else current.catalog_index
    row = rows[index] if 0 <= index < len(rows) else None
    record = mapping_record(home, row)
    if (settings.convert_imported_to_controls and record is not None
            and record.state == 'MAPPING_NEEDED' and record.error):
        from .animation_physics_ui import wrapped_label
        wrapped_label(layout, context, record.error, icon='INFO')


class CHARACTERDESIGNER_OT_edit_prepared_motion(Operator):
    bl_idname = 'character_designer.edit_prepared_motion'
    bl_label = 'Open Motion for Editing'
    bl_description = 'Open the character controller version or the original bone animation'
    bl_options = {'REGISTER', 'UNDO'}

    clip_key: StringProperty(options={'HIDDEN'})

    def execute(self, context):
        from . import animation_controller_edit
        home = context.scene
        scene = editing_scene(home)
        if scene is None or context.window is None:
            self.report({'ERROR'}, 'The editing scene for this workspace is unavailable.')
            return {'CANCELLED'}
        try:
            result = animation_controller_edit.open_motion(context, home, self.clip_key,
                asynchronous=not getattr(bpy.app, 'background', False))
        except (ValueError, OSError, RuntimeError, ReferenceError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        if result.get('state') in {'MAPPING_NEEDED', 'CONTROLLER_RECOVERY'} and result.get('message'):
            self.report({'WARNING'}, result['message'])
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_return_from_motion(Operator):
    bl_idname = 'character_designer.return_from_motion'
    bl_label = 'Return to Character'
    home_scene: StringProperty(options={'HIDDEN'})

    def execute(self, context):
        from . import animation_controller_edit
        home = bpy.data.scenes.get(self.home_scene)
        if home is None or editing_scene(home) != context.scene:
            self.report({'ERROR'}, 'The character scene no longer uses this editing scene.')
            return {'CANCELLED'}
        try:
            animation_controller_edit.return_to_character(context, home)
        except (ValueError, RuntimeError, ReferenceError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_finish_controller_motion(Operator):
    bl_idname = 'character_designer.finish_controller_motion'
    bl_label = 'Finish Controller Motion'
    bl_options = {'INTERNAL', 'UNDO'}

    job_id: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        from . import animation_controller_edit
        try:
            result = animation_controller_edit.finalize_pending(context, self.job_id)
        except (ValueError, RuntimeError, OSError, ReferenceError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'WARNING'} if result['state'] in {'MAPPING_NEEDED', 'CONTROLLER_RECOVERY'} else {'INFO'}, result['message'])
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_cancel_controller_motion(Operator):
    bl_idname = 'character_designer.cancel_controller_motion'
    bl_label = 'Cancel Controller Conversion'
    bl_description = 'Stop this conversion and keep the original motion and existing controller edits'

    job_id: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        from . import animation_controller_edit
        try:
            animation_controller_edit.cancel_pending(self.job_id)
        except (ValueError, RuntimeError, OSError, ReferenceError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class CHARACTERDESIGNER_UL_prepared_motions(UIList):
    def filter_items(self, context, data, propname):
        from . import animation_motion_pins as pins
        return pins.filter_rows(self, context, data, propname)

    def draw_filter(self, context, layout):
        layout.prop(self, 'filter_name', text='', icon='VIEWZOOM')

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        from . import animation_motion_pins as pins
        scene = editing_scene(context.scene)
        local = _local_row(scene, item.clip_key) if scene else None
        label = local.name if local else item.name
        layout = layout.row(align=True)
        if scene and (local or item.ready):
            button = layout.operator('character_designer.edit_prepared_motion', text=label,
                                     icon='ACTION' if local else 'IMPORT')
            button.clip_key = item.clip_key
            if not local:
                layout.label(text='Import')
            draw_mapping_state(layout, context, local or item)
        else:
            layout.label(text=label, icon='ACTION')
            if not item.ready:
                layout.label(text='Not prepared')
        pins.draw_pin(layout, context.scene, item)


def home_scenes(scene):
    return tuple(home for home in bpy.data.scenes if home != scene and home.get(EDIT_SCENE) == scene
                 and editing_scene(home) == scene)


def draw_return(layout, context):
    for home in home_scenes(context.scene):
        button = layout.operator('character_designer.return_from_motion', text='Return to ' + home.name,
                                 icon='LOOP_BACK')
        button.home_scene = home.name


CLASSES = (CharacterDesignerControllerMotion,
           CHARACTERDESIGNER_OT_finish_controller_motion, CHARACTERDESIGNER_OT_cancel_controller_motion,
           CHARACTERDESIGNER_OT_edit_prepared_motion, CHARACTERDESIGNER_OT_return_from_motion,
           CHARACTERDESIGNER_UL_prepared_motions)
