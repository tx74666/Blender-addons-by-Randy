"""Small shared workflow UI; preview plans/batches are built only on demand."""
import json
import textwrap
import time

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, CollectionProperty, FloatProperty, IntProperty, PointerProperty, StringProperty, EnumProperty
from bpy.types import Operator, PropertyGroup
from mathutils import Vector

from . import finger_workflow as workflow, finger_bank as bank, finger_definition as definition
from . import finger_targets as targets, finger_definition_ui as definition_ui

_preview = None
_handles = []


def hide():
    global _preview
    _preview = None
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D': area.tag_redraw()


def _changed(self, context):
    if _preview and context and not bpy.app.timers.is_registered(_refresh): bpy.app.timers.register(_refresh, first_interval=.03)


class CharacterDesignerFingerJointSettings(PropertyGroup):
    position: FloatProperty(name='Joint', default=.34, min=.01, max=.99, subtype='FACTOR', update=_changed)
    width: FloatProperty(name='Half Width', default=.025, min=.002, max=.15, subtype='FACTOR', update=_changed)
    inner_spacing: FloatProperty(name='Inner Spacing', default=1, min=.25, max=2, update=_changed)
    outer_spacing: FloatProperty(name='Outer Spacing', default=1, min=.25, max=2, update=_changed)
    root_weight: FloatProperty(name='Root Ring A', default=.8, min=0, max=1, update=_changed)
    center_weight: FloatProperty(name='Center Ring A', default=.5, min=0, max=1, update=_changed)
    tip_weight: FloatProperty(name='Tip Ring A', default=.2, min=0, max=1, update=_changed)


class CharacterDesignerFingerPairSettings(PropertyGroup):
    joints: CollectionProperty(type=CharacterDesignerFingerJointSettings)
    active_joint: IntProperty(name='Joint Number', default=1, min=1)
    between: IntProperty(name='Between Joints', default=1, min=0, max=8, update=_changed)
    auto_weight: BoolProperty(name='Weight After Rings', description='Assign only the previewed joint regions; invalid bone/weight prerequisites abort the complete operation', default=True)
    recipe: StringProperty(options={'HIDDEN'})
    labels: StringProperty(options={'HIDDEN'})
    applied: BoolProperty(options={'HIDDEN'})


class CharacterDesignerFingerWorkflow(PropertyGroup):
    pairs: CollectionProperty(type=CharacterDesignerFingerPairSettings)
    source: PointerProperty(type=bpy.types.Mesh)
    signature: StringProperty(options={'HIDDEN'})
    bodies: StringProperty(options={'HIDDEN'})
    results: StringProperty(options={'HIDDEN'})
    status: StringProperty(options={'SKIP_SAVE'})


def show(context):
    global _preview
    entries = workflow.plans(context)
    obj = entries[0][3]['obj']
    groups, labels = [], []
    rig = None
    try: _, rig = targets.owner(context)
    except ValueError: pass
    chain_cache, pair_labels = {}, {}
    candidates = targets.index(rig) if rig else {}
    for pair, key, recipe, plan in entries:
        bone_labels = {}
        if rig:
            try:
                if pair.name not in chain_cache: chain_cache[pair.name] = targets.pair(obj, rig, pair.name, candidates)
                chain = chain_cache[pair.name][key]
                for i, joint in enumerate(pair.joints):
                    a, b, offset = workflow.joint_bones(obj, rig, chain, recipe, joint)
                    bone_labels[key+':'+str(i)] = {'A': a, 'B': b, 'offset': offset}
            except ValueError: pass  # Markers can be moved into a valid region in preview.
        pair_labels.setdefault(pair.name, {}).update(bone_labels)
        for ring in plan['rings']:
            color = ((1, .28, .22, 1) if ring['joint'] % 2 == 0 else (.1, .8, 1, 1)) if ring['flank'] == 0 and ring['joint'] >= 0 else (.7, .75, .8, .8)
            points = ring['points']
            segments = [tuple(p) for i in range(len(points)) for p in (points[i], points[(i+1) % len(points)])]
            groups.append((segments, color))
            if ring['flank'] == 0 and ring['joint'] >= 0:
                label = str(ring['joint']+1)
                match = bone_labels.get(key+':'+str(ring['joint']))
                if rig and not match: label += '  bone junction unmatched'
                if rig and match:
                    from .finger_bones import _bone_collection, _head
                    bone = _bone_collection(rig).get(match['B'])
                    if bone:
                        head = obj.matrix_world.inverted() @ rig.matrix_world @ _head(bone)
                        center = sum(points, Vector())/len(points)
                        radius = sum((p-center).length for p in points)/len(points)
                        marker = [tuple(head), tuple(center)]
                        for axis in (Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1))):
                            marker.extend((tuple(head-axis*radius*.16), tuple(head+axis*radius*.16)))
                        groups.append((marker, (1, .5, .1, 1)))
                        if (center-head).length > radius*.02: label += f"  offset {(center-head).length:.3g}"
                labels.append((points[0].copy(), label, color))
    for pair, _, _, _ in entries: pair.labels = json.dumps(pair_labels[pair.name])
    _install(context, obj, groups, labels, rig=rig)


def _install(context, obj, groups, labels, *, rig=None, kind='RINGS', all_fingers=False):
    global _preview
    _preview = {'obj': obj, 'rig': rig, 'kind': kind, 'all': all_fingers, 'groups': groups, 'labels': labels,
                'batches': None, 'active': obj.character_designer_finger_bank.active,
                'selected': bank.selected_digits(obj.character_designer_finger_bank)}
    if not _handles and not bpy.app.background:
        _handles.append(bpy.types.SpaceView3D.draw_handler_add(_draw, (), 'WINDOW', 'POST_VIEW'))
        _handles.append(bpy.types.SpaceView3D.draw_handler_add(_labels, (), 'WINDOW', 'POST_PIXEL'))
    for area in context.screen.areas if context.screen else []:
        if area.type == 'VIEW_3D': area.tag_redraw()


def show_bend(context, *, all_fingers=False):
    """Resolve once on the button event; drawing only consumes cached lines."""
    from . import finger_flex as flex
    from .finger_bones import _head, _tail
    obj = bank.active_object(context)
    if not obj: raise ValueError('Capture Finger Basic Setup first.')
    b = obj.character_designer_finger_bank
    rig = None
    try: _, rig = targets.owner(context)
    except ValueError: pass
    candidates = targets.index(rig) if rig else {}
    digits = bank.DIGITS if hasattr(bank, 'DIGITS') else ('THUMB', 'INDEX', 'MIDDLE', 'RING', 'PINKY')
    digits = digits if all_fingers else bank.selected_digits(b)
    groups, labels = [], []
    inverse = obj.matrix_world.inverted()
    for digit in digits:
        slots = [s for s in b.slots if s.name.split('.')[0] == digit and s.guide.record and not s.error]
        if not slots: continue
        chains = targets.pair(obj, rig, digit, candidates) if rig else {}
        for slot in slots:
            data = definition.frame(bank.scoped(context, slot.guide), require_bend=True)
            forward, bend, arcs, axes, current = [], [], [], [], []
            rows = []
            for bone in chains.get(slot.name, ()):
                head, tail = rig.matrix_world @ _head(bone), rig.matrix_world @ _tail(bone)
                x = bone.x_axis if rig.mode == 'EDIT' else bone.matrix_local.to_3x3().col[0]
                rows.append((head, tail, (rig.matrix_world.to_3x3() @ x).normalized()))
            if not rows: rows = [(data['root'], data['tip'], None)]
            for head, tail, x in rows:
                t, inward, axis = flex.frame(tail-head, data['bend'])
                length = (tail-head).length
                flex.arrow(forward, head, t, length, inward)
                flex.arrow(bend, head, inward, length*.35, t)
                flex.arc(arcs, head, t, axis, length)
                axes += [head-axis*length*.2, head+axis*length*.2]
                if x is not None: current += [head-x*length*.15, head+x*length*.15]
            for points, color in zip((forward, bend, arcs, axes, current),
                    ((.1, .65, 1, 1), (1, .4, .05, 1), (.2, 1, .3, 1), (.8, .35, 1, 1), (1, .12, .12, 1))):
                if points: groups.append(([tuple(inverse @ Vector(p)) for p in points], color))
            labels.append((inverse @ data['root'], slot.name, (.1, .65, 1, 1)))
    if not groups: raise ValueError('No valid bend definitions to preview.')
    _install(context, obj, groups, labels, rig=rig, kind='BEND', all_fingers=all_fingers)


def _refresh():
    if not _preview: return
    try:
        if _preview['kind'] == 'BEND': show_bend(bpy.context, all_fingers=_preview['all'])
        else: show(bpy.context)
    except (ValueError, ReferenceError, RuntimeError) as exc:
        obj = _preview['obj']
        obj.character_designer_finger_workflow.status = str(exc)
        hide()


def _valid():
    if not _preview: return None
    obj = _preview['obj']
    if bpy.context.object not in (obj, _preview['rig']) or not obj.visible_get(): return None
    if not _preview['all'] and obj.character_designer_finger_bank.active != _preview['active']: return None
    if _preview['kind'] == 'BEND' and not _preview['all'] and bank.selected_digits(obj.character_designer_finger_bank) != _preview['selected']: return None
    return _preview


def _draw():
    p = _valid()
    if not p: return
    import gpu
    from gpu_extras.batch import batch_for_shader
    if p['batches'] is None:
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        p['batches'] = shader, [(batch_for_shader(shader, 'LINES', {'pos': points}), color) for points, color in p['groups']]
    shader, batches = p['batches']
    depth, width, blend = gpu.state.depth_test_get(), gpu.state.line_width_get(), gpu.state.blend_get()
    try:
        gpu.state.depth_test_set('NONE'); gpu.state.line_width_set(2); gpu.state.blend_set('ALPHA')
        with gpu.matrix.push_pop():
            gpu.matrix.multiply_matrix(p['obj'].matrix_world)
            shader.bind()
            for batch, color in batches:
                shader.uniform_float('color', color)
                batch.draw(shader)
    finally:
        gpu.state.depth_test_set(depth); gpu.state.line_width_set(width); gpu.state.blend_set(blend)


def _labels():
    p = _valid()
    if not p or not bpy.context.region_data: return
    import blf
    from bpy_extras.view3d_utils import location_3d_to_region_2d
    blf.size(0, 14)
    for point, text, color in p['labels']:
        xy = location_3d_to_region_2d(bpy.context.region, bpy.context.region_data, p['obj'].matrix_world @ point)
        if xy:
            blf.position(0, xy.x+6, xy.y+6, 0); blf.color(0, *color); blf.draw(0, text)


class CHARACTERDESIGNER_OT_finger_workflow(Operator):
    bl_idname = 'character_designer.finger_workflow'
    bl_label = 'Finger Setup Workflow'
    bl_options = {'REGISTER', 'UNDO'}
    all_fingers: BoolProperty(default=False, options={'SKIP_SAVE'})
    action: EnumProperty(items=[(k, label, '') for k, label in (
        ('ALL', 'Calibrate All'), ('SELECTED', 'Calibrate Selected'), ('FLIP', 'Reverse Bend'),
        ('PREPARE', 'Prepare Joints'), ('LOOP', 'Use Selected Center Loop'), ('APPLY', 'Generate / Update Rings'),
        ('WEIGHTS', 'Update Local Weights'), ('PREVIEW', 'Show / Hide Joint Preview'), ('BEND', 'Preview Bend'), ('RELEASE', 'Release Prepared Results'))])

    @classmethod
    def description(cls, context, props):
        if props.action == 'BEND': return 'Toggle bend axes for the highlighted finger pairs. Shift-click previews all prepared fingers. Does not change pose'
        if props.action == 'PREPARE': return 'Prepare the captured finger pair. Shift-click edits joint spacing and weight ratios'
        if props.action == 'RELEASE': return 'Keep mesh, weights and joint parameters; release all prepared recipes for this character so current edits can become a new source'
        return 'Use the current character Finger Setup; validate both sides before writing'

    def invoke(self, context, event):
        if self.action == 'PREPARE' and event.shift:
            return bpy.ops.character_designer.finger_joint_options('INVOKE_DEFAULT')
        self.all_fingers = bool(event.shift)
        return self.execute(context)

    def execute(self, context):
        obj = None
        try:
            obj = bank.active_object(context)
            if self.action in {'ALL', 'SELECTED'}:
                started = time.perf_counter()
                result = targets.calibrate(context, self.action == 'SELECTED')
                obj, _ = targets.owner(context)
                lines = [f"Calibrated: {', '.join(result['success']) or 'none'} ({time.perf_counter()-started:.3f}s)"]
                lines += [f'{kind.title()} {key}: {message}' for kind in ('skipped', 'failed') for key, message in result[kind].items()]
                obj.character_designer_finger_workflow.status = '\n'.join(lines)
                self.report({'INFO'} if not result['skipped'] and not result['failed'] else {'WARNING'}, ' | '.join(lines))
                return {'FINISHED'} if result['success'] else {'CANCELLED'}
            if obj is None: raise ValueError('Capture Finger Basic Setup first.')
            s = obj.character_designer_finger_workflow
            if self.action == 'FLIP':
                b = obj.character_designer_finger_bank
                source = b.slots[b.active].guide
                source.flip_bend = not source.flip_bend
                source.confirmed = True
                for slot in b.slots:
                    if slot.name.split('.')[0] == b.active.split('.')[0] and slot.guide.record:
                        slot.guide.flip_bend, slot.guide.confirmed = source.flip_bend, True
                definition_ui.show()
                hide()
            elif self.action == 'PREPARE':
                pair = workflow.prepare(context)
                # An explicitly unbound character can prepare topology; do not
                # pretend automatic weights succeeded or implicitly bind it.
                from . import character_setup
                if character_setup.preferred_rig(context) is None: pair.auto_weight = False
                show(context)
            elif self.action == 'LOOP': workflow.capture_joint(context); show(context)
            elif self.action == 'PREVIEW':
                if _preview: hide()
                else: show(context)
            elif self.action == 'BEND':
                if _preview and _preview['kind'] == 'BEND' and _preview['all'] == self.all_fingers: hide()
                else: show_bend(context, all_fingers=self.all_fingers)
            elif self.action == 'RELEASE': hide(); workflow.release(context)
            else:
                result = workflow.apply(context, weights_only=self.action == 'WEIGHTS')
                definition_ui.redraw()
                s.status = f"{result['added']} vertices added; {result['weighted']} local vertices weighted ({result['seconds']:.3f}s)."
                try: show(context)
                except (ValueError, RuntimeError, KeyError, ReferenceError) as exc:
                    hide()
                    s.status += ' Preview unavailable: '+str(exc)
                    # The data commit succeeded. Never discard its undo step
                    # just because the non-mutating overlay could not rebuild.
                self.report({'INFO'}, s.status)
                return {'FINISHED'}
            s.status = ''
            return {'FINISHED'}
        except (ValueError, RuntimeError, KeyError, IndexError, ReferenceError) as exc:
            hide()
            if obj: obj.character_designer_finger_workflow.status = str(exc)
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}


class CHARACTERDESIGNER_OT_finger_joint_options(Operator):
    bl_idname = 'character_designer.finger_joint_options'
    bl_label = 'Joint Spacing and Local Weights'
    def invoke(self, context, event):
        try: _, _, pair = workflow.settings(context)
        except ValueError as exc:
            self.report({'WARNING'}, str(exc)); return {'CANCELLED'}
        if not pair.joints: return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self, width=400)
    def execute(self, context): return {'FINISHED'}
    def draw(self, context):
        _, _, pair = workflow.settings(context)
        self.layout.prop(pair, 'active_joint')
        joint = pair.joints[min(pair.active_joint-1, len(pair.joints)-1)]
        for field in ('width', 'inner_spacing', 'outer_spacing', 'root_weight', 'center_weight', 'tip_weight'):
            self.layout.prop(joint, field)
        self.layout.prop(pair, 'between')
        self.layout.label(text='A / B share the remaining deform-weight budget.')
        for key, label in json.loads(pair.labels or '{}').items():
            if key.endswith(':'+str(min(pair.active_joint-1, len(pair.joints)-1))):
                self.layout.label(text=key+': '+label['A']+' / '+label['B'])


def draw_controls(layout, context):
    obj = bank.active_object(context)
    if not obj: return
    s = obj.character_designer_finger_workflow
    box = layout.box()
    box.label(text='Bone Roll', icon='BONE_DATA')
    row = box.row(align=True)
    row.operator('character_designer.finger_workflow', text='Calibrate All').action = 'ALL'
    row.operator('character_designer.finger_workflow', text='Calibrate Selected').action = 'SELECTED'
    row = box.row(align=True)
    row.operator('character_designer.finger_workflow', text='Preview Bend').action = 'BEND'
    row.operator('character_designer.finger_workflow', text='', icon='ARROW_LEFTRIGHT').action = 'FLIP'
    if context.mode == 'EDIT_MESH':
        box = layout.box()
        box.label(text='Joint Topology & Weights', icon='MESH_GRID')
        row = box.row(align=True)
        row.operator('character_designer.finger_workflow', text='Prepare Joints').action = 'PREPARE'
        pair = s.pairs.get(obj.character_designer_finger_bank.active.split('.')[0])
        if pair and pair.recipe:
            row.operator('character_designer.finger_workflow', text='', icon='X').action = 'RELEASE'
            for i, j in enumerate(pair.joints): box.prop(j, 'position', text=f'Joint {i+1}', slider=True)
            row = box.row(align=True)
            row.prop(pair, 'active_joint', text='Joint')
            row.operator('character_designer.finger_workflow', text='Use Selected Loop').action = 'LOOP'
            row = box.row(align=True)
            row.prop(pair, 'auto_weight')
            row.operator('character_designer.finger_workflow', text='', icon='HIDE_OFF').action = 'PREVIEW'
            box.operator('character_designer.finger_workflow', text='Generate / Update Rings').action = 'APPLY'
            if pair.applied: box.operator('character_designer.finger_workflow', text='Update Local Weights').action = 'WEIGHTS'
            if not pair.auto_weight: box.label(text='Topology only; weights will not be changed.')
    if s.status:
        for line in s.status.splitlines():
            for part in textwrap.wrap(line, 45): layout.label(text=part)


@persistent
def _invalidate(*args): hide()


@persistent
def _dirty(scene, depsgraph):
    if _preview:
        owners = {_preview['obj'], _preview['obj'].data}
        if _preview['rig']: owners.update((_preview['rig'], _preview['rig'].data))
        if any((u.is_updated_geometry or u.is_updated_transform) and u.id.original in owners for u in depsgraph.updates): hide()


CLASSES = (CharacterDesignerFingerJointSettings, CharacterDesignerFingerPairSettings, CharacterDesignerFingerWorkflow,
           CHARACTERDESIGNER_OT_finger_workflow, CHARACTERDESIGNER_OT_finger_joint_options)


def register_runtime():
    bpy.types.Object.character_designer_finger_workflow = PointerProperty(type=CharacterDesignerFingerWorkflow)
    for group in (bpy.app.handlers.load_pre, bpy.app.handlers.undo_pre, bpy.app.handlers.redo_pre):
        if _invalidate not in group: group.append(_invalidate)
    if _dirty not in bpy.app.handlers.depsgraph_update_post: bpy.app.handlers.depsgraph_update_post.append(_dirty)


def unregister_runtime():
    hide()
    if bpy.app.timers.is_registered(_refresh): bpy.app.timers.unregister(_refresh)
    for h in _handles: bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
    _handles.clear()
    for group in (bpy.app.handlers.load_pre, bpy.app.handlers.undo_pre, bpy.app.handlers.redo_pre):
        if _invalidate in group: group.remove(_invalidate)
    if _dirty in bpy.app.handlers.depsgraph_update_post: bpy.app.handlers.depsgraph_update_post.remove(_dirty)
    if hasattr(bpy.types.Object, 'character_designer_finger_workflow'): del bpy.types.Object.character_designer_finger_workflow
