"""Animation-page physics controls; drawing reads saved metadata only."""

import unicodedata

from bpy.props import BoolProperty, EnumProperty, StringProperty
from bpy.types import Operator


def _service():
    from . import animation_physics
    return animation_physics


def _panel(layout, identifier, *, default_closed=False):
    """Native region-local folds; older Blender layouts remain usable."""
    panel = getattr(layout, "panel", None)
    if callable(panel):
        return panel(identifier, default_closed=default_closed)
    box = layout.box()
    return box.row(align=True), box


def section(layout, identifier, label, *, icon="NONE", default_closed=False):
    header, body = _panel(layout, identifier, default_closed=default_closed)
    header.label(text=label, icon=icon)
    return body


def _line_width(context):
    region = getattr(context, "region", None)
    width = getattr(region, "width", 320)
    system = getattr(getattr(context, "preferences", None), "system", None)
    scale = max(.5, float(getattr(system, "ui_scale", 1.) or 1.))
    return max(14, min(100, int((width / scale - 56) / 7.5)))


def _cells(text):
    return sum(0 if unicodedata.combining(char) else
               2 if unicodedata.east_asian_width(char) in {"F", "W"} else 1
               for char in text)


def _wrapped(text, width):
    """Wrap every character, including long paths and full-width text."""
    result = []
    for paragraph in str(text).expandtabs(4).splitlines() or [""]:
        line = ""
        for char in paragraph:
            if line and _cells(line + char) > width:
                split = line.rfind(" ")
                if split > 0:
                    result.append(line[:split].rstrip())
                    line = line[split + 1:] + char
                else:
                    result.append(line.rstrip())
                    line = char
            else:
                line += char
        result.append(line.rstrip())
    return result


def wrapped_label(layout, context, text, *, icon="INFO"):
    for index, line in enumerate(_wrapped(text, _line_width(context))):
        layout.label(text=line, icon=icon if index == 0 else "NONE")


def _message(layout, context, text, identifier, *, icon="INFO", details=()):
    """Keep the useful reason visible and retain all longer detail in a fold."""
    if not text and not details:
        return
    lines = _wrapped(text, _line_width(context)) if text else []
    if len(lines) <= 2 and not details:
        wrapped_label(layout, context, text, icon=icon)
        return
    for index, line in enumerate(lines[:2]):
        layout.label(text=line, icon=icon if index == 0 else "NONE")
    body = section(layout, identifier, "Details", default_closed=True)
    if body is not None:
        if len(lines) > 2:
            wrapped_label(body, context, text, icon=icon)
        for detail in details:
            wrapped_label(body, context, detail, icon="NONE")


def _target_token(rig):
    return str(rig.as_pointer()) if rig is not None else ""


def _capture_target(operator, state):
    rig = state.get("rig")
    operator.target_name = rig.name if rig is not None else ""
    operator.target_pointer = _target_token(rig)
    return operator


def _checked_target(operator, context):
    state = _service().status(context)
    if not state.get("valid", False):
        raise ValueError(state.get("message") or "Physics settings need review before changing them.")
    rig = state.get("rig")
    if (rig is None or rig.name != operator.target_name
            or _target_token(rig) != operator.target_pointer):
        raise ValueError("The current character changed. Use its Physics controls again.")
    return state


def _run(operator, context, action):
    try:
        _checked_target(operator, context)
        action()
    except (ValueError, RuntimeError, ReferenceError, TypeError, KeyError) as error:
        operator.report({"ERROR"}, str(error))
        area = getattr(context, "area", None)
        if area is not None:
            area.tag_redraw()
        return {"CANCELLED"}
    area = getattr(context, "area", None)
    if area is not None:
        area.tag_redraw()
    return {"FINISHED"}


class CHARACTERDESIGNER_OT_animation_physics_set(Operator):
    bl_idname = "character_designer.animation_physics_set"
    bl_label = "Set Animation Physics"
    bl_description = "Enable or pause this character's physics while retaining its setup and modes"
    bl_options = {"REGISTER", "UNDO"}

    component: EnumProperty(items=(
        ("ALL", "All Physics", "This character's master physics switch"),
        ("SKIRT", "Skirt", "This character's skirt physics"),
        ("HAIR", "Hair", "This character's hair physics"),
    ), default="ALL")
    enabled: BoolProperty(default=True)
    target_name: StringProperty(options={"HIDDEN"})
    target_pointer: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        def apply():
            if self.component == "ALL":
                _service().set_enabled(context, self.enabled)
            else:
                _service().set_component(context, self.component, self.enabled)
        return _run(self, context, apply)


class CHARACTERDESIGNER_OT_animation_physics_skirt_mode(Operator):
    bl_idname = "character_designer.animation_physics_skirt_mode"
    bl_label = "Set Skirt Motion Mode"
    bl_description = "Change the existing skirt motion mode without creating another setup"
    bl_options = {"REGISTER", "UNDO"}

    source_name: StringProperty(options={"HIDDEN"})
    source_owner: StringProperty(options={"HIDDEN"})
    mode: EnumProperty(items=(
        ("AUTOMATIC", "Automatic", "Use this skirt's automatic motion"),
        ("MANUAL", "Manual", "Use this skirt's manual motion mode"),
    ), default="MANUAL")
    target_name: StringProperty(options={"HIDDEN"})
    target_pointer: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        return _run(self, context, lambda: _service().set_skirt_mode(
            context, self.source_name, self.mode, expected_owner=self.source_owner))


class CHARACTERDESIGNER_OT_animation_physics_start_hair(Operator):
    bl_idname = "character_designer.animation_physics_start_hair"
    bl_label = "Start Hair Preview"
    bl_description = "Start this character's Hair physics preview using its existing strand settings"
    bl_options = {"REGISTER", "UNDO"}

    target_name: StringProperty(options={"HIDDEN"})
    target_pointer: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        return _run(self, context, lambda: _service().start_hair_preview(context))


class CHARACTERDESIGNER_OT_animation_physics_dependency(Operator):
    bl_idname = "character_designer.animation_physics_dependency"
    bl_label = "Check Physics Extension"
    bl_description = "Check or enable the installed supported Wiggle extension without saving preferences"
    bl_options = {"REGISTER"}

    component: EnumProperty(items=(("SKIRT", "Skirt", "Skirt motion extension"),
                                  ("HAIR", "Hair", "Hair preview extension")))
    action: EnumProperty(items=(("CHECK", "Check", "Read the actual extension compatibility"),
                               ("ENABLE", "Enable", "Enable the installed supported extension")),
                         default="CHECK")
    target_name: StringProperty(options={"HIDDEN"})
    target_pointer: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        def apply():
            if self.action == "ENABLE":
                _service().enable_dependency(context, self.component)
            else:
                _service().dependency_status(self.component, refresh=True)
        return _run(self, context, apply)


class CHARACTERDESIGNER_OT_animation_physics_controls(Operator):
    bl_idname = "character_designer.animation_physics_controls"
    bl_label = "Return to Controls"
    bl_description = "Leave this character's Original bone display using its existing guarded Controls action"
    bl_options = {"REGISTER", "UNDO"}

    target_name: StringProperty(options={"HIDDEN"})
    target_pointer: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        return _run(self, context, lambda: _service().return_to_controls(context))


def _checkbox(layout, state, *, component, label, checked, enabled):
    row = layout.row(align=True)
    row.enabled = enabled
    operator = row.operator(
        CHARACTERDESIGNER_OT_animation_physics_set.bl_idname, text=label,
        icon="CHECKBOX_HLT" if checked else "CHECKBOX_DEHLT", emboss=False)
    operator.component = component
    operator.enabled = not checked
    _capture_target(operator, state)


def _draw_dependency(layout, context, state, component, dependency, identifier):
    if not dependency:
        return
    kind = dependency.get("state", "UNCHECKED")
    label = dependency.get("label") or "Wiggle"
    if kind == "READY":
        row = layout.row(align=True)
        row.label(text=label + " ready", icon="CHECKMARK")
        operator = row.operator(CHARACTERDESIGNER_OT_animation_physics_dependency.bl_idname,
                                text="", icon="FILE_REFRESH")
        operator.component, operator.action = component, "CHECK"
        _capture_target(operator, state)
    elif kind == "MISSING":
        wrapped_label(layout, context, "Install " + label + " to use this preview.")
        row = layout.row(align=True)
        operator = row.operator(CHARACTERDESIGNER_OT_animation_physics_dependency.bl_idname,
                                text="Check Again", icon="FILE_REFRESH")
        operator.component, operator.action = component, "CHECK"
        _capture_target(operator, state)
    else:
        unchecked = kind == "UNCHECKED"
        action = "ENABLE" if unchecked or dependency.get("enable_available") else "CHECK"
        row = layout.row(align=True)
        row.enabled = context.mode in {"OBJECT", "POSE"}
        operator = row.operator(CHARACTERDESIGNER_OT_animation_physics_dependency.bl_idname,
                                text="Enable / Check Wiggle" if unchecked else
                                     "Enable Wiggle" if action == "ENABLE" else "Check Wiggle",
                                icon="CHECKMARK" if action == "ENABLE" else "FILE_REFRESH")
        operator.component, operator.action = component, action
        _capture_target(operator, state)
    _message(layout, context, dependency.get("message", ""), identifier + "_dependency_details",
             details=dependency.get("details", ()))


def _can_start(entry):
    dependency = entry.get("dependency") or {}
    return bool(entry.get("available", False)) and dependency.get("state") in {None, "READY", "UNCHECKED"}


def _draw_skirts(layout, context, state, editable):
    dresses = state.get("dresses", ())
    enabled = bool(state.get("enabled", True))
    skirt_enabled = enabled and bool(state.get("skirt_enabled", True))
    header, body = _panel(layout, "character_designer_animation_physics_skirt")
    _checkbox(header, state, component="SKIRT", label="Skirt",
              checked=bool(state.get("skirt_enabled", True)),
              enabled=editable and enabled and bool(dresses))
    if body is None:
        return
    if not dresses:
        wrapped_label(body, context, "No skirt setup on this character.")
        return
    for dress in dresses:
        identifier = "character_designer_animation_physics_skirt_" + dress.get("owner", dress["source"])
        # UILayout.panel requires full region width, including its Details
        # folds below. Keep this path on the native panel body, not a column.
        column = body
        wrapped_label(column, context, dress.get("name", dress["source"]), icon="NONE")
        row = column.row(align=True)
        requires_controls = bool(dress.get("requires_controls", False))
        context_blocked = bool(dress.get("context_blocked", False)) or requires_controls
        can_change = (editable and not context_blocked and dress.get("can_change_mode", True)
                      and (skirt_enabled or dress.get("can_change_mode_paused", False)))
        for mode, label in (("AUTOMATIC", "Automatic"), ("MANUAL", "Manual")):
            choice = row.row(align=True)
            choice.enabled = can_change and (mode == "MANUAL" or _can_start(dress))
            operator = choice.operator(
                CHARACTERDESIGNER_OT_animation_physics_skirt_mode.bl_idname,
                text=label, depress=dress.get("mode") == mode)
            operator.source_name = dress["source"]
            operator.source_owner = dress.get("owner", "")
            operator.mode = mode
            _capture_target(operator, state)
        if not skirt_enabled and not dress.get("can_change_mode_paused", False):
            wrapped_label(column, context, "Enable skirt physics before changing its mode.")
        block_reason = dress.get("block_reason") or dress.get("context_message")
        if context_blocked:
            _message(column, context, block_reason or "Finish Original mode in Bone Display before changing Dress motion.",
                     identifier + "_context_blocked")
        if requires_controls:
            row = column.row(align=True)
            row.enabled = editable
            operator = row.operator(CHARACTERDESIGNER_OT_animation_physics_controls.bl_idname,
                                    text="Return to Controls", icon="POSE_HLT")
            _capture_target(operator, state)
        if dress.get("backend") == "WIGGLE":
            _draw_dependency(column, context, state, "SKIRT", dress.get("dependency"), identifier)
        dependency_message = (dress.get("dependency") or {}).get("message")
        if dress.get("message") and dress["message"] not in {dependency_message, block_reason}:
            _message(column, context, dress["message"], identifier + "_motion_details")
        if dress.get("last_error") and dress["last_error"] not in {dress.get("message"), dependency_message}:
            _message(column, context, dress["last_error"], identifier + "_last_error", icon="ERROR")


def _draw_hair(layout, context, state, editable):
    hair = state.get("hair", {})
    enabled = bool(state.get("enabled", True))
    header, body = _panel(layout, "character_designer_animation_physics_hair")
    _checkbox(header, state, component="HAIR", label="Hair",
              checked=bool(state.get("hair_enabled", True)),
              enabled=editable and enabled and bool(hair.get("sources")))
    if body is None:
        return
    identifier = "character_designer_animation_physics_hair"
    if hair.get("sources"):
        paused = bool(hair.get("paused", False))
        running = bool(hair.get("running", hair.get("active", False) and not paused))
        body.label(text="Hair physics paused." if paused else
                   "Hair preview active." if running else "Hair preview inactive.")
        if not running:
            row = body.row(align=True)
            row.enabled = (editable and enabled and bool(state.get("hair_enabled", True))
                           and _can_start(hair))
            operator = row.operator(CHARACTERDESIGNER_OT_animation_physics_start_hair.bl_idname,
                                    text="Resume Hair Preview" if paused else "Start Hair Preview",
                                    icon="PLAY")
            _capture_target(operator, state)
    else:
        wrapped_label(body, context, "No initialized Hair motion on this character.")
    _draw_dependency(body, context, state, "HAIR", hair.get("dependency"), identifier)
    dependency_message = (hair.get("dependency") or {}).get("message")
    if hair.get("message") and hair["message"] != dependency_message:
        _message(body, context, hair["message"], identifier + "_motion_details")
    if hair.get("last_error") and hair["last_error"] not in {hair.get("message"), dependency_message}:
        _message(body, context, hair["last_error"], identifier + "_last_error", icon="ERROR")
    seen_errors = {hair.get("last_error"), hair.get("message"), dependency_message}
    for source, error in (hair.get("source_errors") or {}).items():
        if error and error not in seen_errors:
            _message(body, context, source + ": " + error, identifier + "_source_error_" + source, icon="ERROR")
            seen_errors.add(error)


def draw(layout, context):
    """Draw permission, mode and dependency controls in independent folds."""
    box = section(layout, "character_designer_animation_physics", "Physics", icon="PHYSICS")
    if box is None:
        return
    try:
        state = _service().status(context)
    except (ValueError, RuntimeError, ReferenceError, TypeError, KeyError) as error:
        _message(box, context, str(error), "character_designer_animation_physics_error", icon="ERROR")
        return
    rig = state.get("rig")
    if not state.get("valid", False):
        _message(box, context, state.get("message") or "Physics settings need review.",
                 "character_designer_animation_physics_invalid", icon="ERROR")
        return
    enabled = bool(state.get("enabled", True))
    editable = rig is not None and context.mode in {"OBJECT", "POSE"}
    _checkbox(box, state, component="ALL", label="Enable Physics", checked=enabled,
              enabled=editable)
    if rig is None:
        wrapped_label(box, context, state.get("message") or "Choose the character's Main Rig first.")
        return
    wrapped_label(box, context, "Character: " + rig.name, icon="NONE")
    if not enabled:
        wrapped_label(box, context, "Enable Physics is off. Saved modes are retained.")
    if state.get("message"):
        _message(box, context, state["message"], "character_designer_animation_physics_status")
    _draw_skirts(box, context, state, editable)
    _draw_hair(box, context, state, editable)


PHYSICS_CLASSES = (
    CHARACTERDESIGNER_OT_animation_physics_set,
    CHARACTERDESIGNER_OT_animation_physics_skirt_mode,
    CHARACTERDESIGNER_OT_animation_physics_start_hair,
    CHARACTERDESIGNER_OT_animation_physics_dependency,
    CHARACTERDESIGNER_OT_animation_physics_controls,
)
