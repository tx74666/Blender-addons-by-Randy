"""Character-owned physics permission and reversible native suspension.

The saved JSON is a permission, not proof that a solver is running. Dress
motion modes remain owned by their existing services. Suspending Cloth records
its exact native flags; suspending Wiggle releases only this Dress's lease.
No frame handler, Action, keyframe, Rest, or geometry is created here.
"""
import hashlib
import importlib
import json
import time


STATE_KEY = 'character_designer_animation_physics_v1'
SKIRT_RECORD = 'character_designer_skirt_v1'
SKIRT_RIG = 'character_designer_skirt_armature'
HAIR_RECORD = 'character_designer_hair_bones_v1'
HAIR_RIG = 'character_designer_hair_bones_armature'
HAIR_REGISTRY = 'character_designer_hair_strands_v1'
COMPONENTS = ('SKIRT', 'HAIR')
_LAST_ERRORS = {}


class AnimationPhysicsError(ValueError):
    """A physics permission or suspension cannot be changed safely."""


def _module(name):
    return importlib.import_module(__package__ + '.' + name)


def dependency_status(component, *, refresh=False):
    return _module('physics_dependencies').status(component, refresh=refresh)


def _error_key(rig, component, source=None):
    identity = lambda value: (getattr(value, 'session_uid', value.as_pointer()), value.name)
    return identity(rig), component, identity(source) if source is not None else None


def record_error(context, component, error, *, source_name=None):
    if component not in COMPONENTS:
        return
    rig = _selected_rig(context)
    if rig is not None:
        source = context.scene.objects.get(source_name) if source_name else None
        _LAST_ERRORS[_error_key(rig, component, source)] = str(error)


def clear_error(context, component, *, source_name=None):
    rig = _selected_rig(context)
    if rig is not None:
        source = context.scene.objects.get(source_name) if source_name else None
        _LAST_ERRORS.pop(_error_key(rig, component, source), None)


def _last_error(rig, component, source=None):
    return (_LAST_ERRORS.get(_error_key(rig, component, source), '')
            or _LAST_ERRORS.get(_error_key(rig, component), ''))


def enable_dependency(context, component):
    _local(_selected_rig(context), context)
    try:
        return _module('physics_dependencies').enable(component)
    except (ValueError, RuntimeError) as error:
        record_error(context, component, error)
        raise


def _require(value, message):
    if not value:
        raise AnimationPhysicsError(message)


def _fresh():
    return {'version': 1, 'enabled': True, 'skirt_enabled': True,
            'hair_enabled': True, 'suspended': []}


def _read(rig):
    raw = rig.get(STATE_KEY)
    if raw is None:
        return _fresh()
    try:
        state = json.loads(raw)
        _require(set(state) == set(_fresh()) and type(state['version']) is int
                 and state['version'] == 1, 'Invalid physics permission version.')
        _require(all(type(state[key]) is bool for key in
                     ('enabled', 'skirt_enabled', 'hair_enabled'))
                 and type(state['suspended']) is list, 'Invalid physics permission values.')
        seen = set()
        for item in state['suspended']:
            _require(type(item) is dict and item.get('kind') in {'CLOTH', 'DIRECT', 'WIGGLE'}
                     and all(type(item.get(key)) is str and item[key] for key in
                             ('source', 'owner', 'record_sha256')),
                     'Invalid saved physics suspension.')
            _require(item['source'] not in seen, 'Duplicate saved physics suspension.')
            seen.add(item['source'])
            if item['kind'] in {'CLOTH', 'DIRECT'}:
                _require(type(item.get('flags')) is list and len(item['flags']) == 2
                         and all(type(flag) is bool for flag in item['flags'])
                         and all(type(item.get(key)) is str and item[key]
                                 for key in ('proxy', 'modifier')),
                         'Invalid saved Cloth suspension.')
        return state
    except (ValueError, TypeError, KeyError, AttributeError) as error:
        raise AnimationPhysicsError('Saved Physics permissions need review; preserve this file.') from error


def _write(rig, state):
    rig[STATE_KEY] = json.dumps(state, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _selected_rig(context):
    worklist = getattr(context.scene, 'character_designer_animation_worklist', None)
    if worklist is not None and getattr(worklist, 'workspace_path', ''):
        return worklist.rig
    setup = getattr(context.scene, 'character_designer_setup', None)
    return setup.rig if setup is not None else None


def _local(rig, context):
    _require(rig is not None and rig.type == 'ARMATURE', 'Choose Main Rig in Character Setup first.')
    _require(not rig.library and not rig.override_library and rig.is_editable
             and context.scene.objects.get(rig.name) == rig,
             'Physics controls require the local Main Rig in this scene.')


def _owner(source, component):
    key = HAIR_RIG if component == 'HAIR' else SKIRT_RIG
    rig = source.get(key) if source is not None else None
    if component == 'SKIRT' and rig is not None:
        try:
            record = json.loads(source[SKIRT_RECORD])
            owner = record['owner']
            if record.get('shared'):
                # The source's native ID reference and the Main Rig's own
                # source registry must agree; a parent alone is no authority.
                if rig.get('character_designer_shared_skirts_v1', {}).get(owner) != source:
                    return None
                return rig
            if (rig.get('character_designer_skirt_owner') != owner
                    or rig.get('character_designer_skirt_source') is not source
                    or rig.data.get('character_designer_skirt_owner') != owner):
                return None
        except (ValueError, TypeError, KeyError, AttributeError):
            return None
        parent = getattr(rig, 'parent', None)
        if (parent is not None and getattr(parent, 'type', None) == 'ARMATURE'
                and getattr(rig, 'parent_type', None) == 'BONE'
                and getattr(rig, 'parent_bone', '') in parent.data.bones):
            return parent
    return rig


def _component(source, component=None):
    if component is not None:
        _require(component in COMPONENTS, 'Choose Hair or Skirt physics.')
        return component
    if source is not None and HAIR_RECORD in source:
        return 'HAIR'
    return 'SKIRT'


def is_enabled(source, *, component=None):
    """Read a source's own character permission without selection fallback."""
    selected = _component(source, component)
    rig = _owner(source, selected)
    if rig is None:
        return True  # Existing source validation owns the missing-rig refusal.
    state = _read(rig)
    return state['enabled'] and state[selected.lower() + '_enabled']


def require_enabled(source, context=None, *, component=None):
    selected = _component(source, component)
    _require(is_enabled(source, component=selected),
             'Enable ' + selected.title() + ' Physics in Animation before starting simulation.')


def _raw_record(source):
    raw = source.get(SKIRT_RECORD)
    _require(type(raw) is str, 'The Dress ownership record is missing.')
    try:
        record = json.loads(raw)
    except (ValueError, TypeError) as error:
        raise AnimationPhysicsError('The Dress ownership record needs review.') from error
    _require(type(record) is dict and type(record.get('owner')) is str and record['owner'],
             'The Dress ownership record needs review.')
    return raw, record


def _digest(raw):
    return hashlib.sha256(raw.encode('utf8')).hexdigest()


def _sources(context, rig, component):
    key = HAIR_RECORD if component == 'HAIR' else SKIRT_RECORD
    result = []
    for source in context.scene.objects:
        if getattr(source, 'type', None) != 'MESH' or key not in source:
            continue
        owner = _owner(source, component)
        target = source.get(HAIR_RIG if component == 'HAIR' else SKIRT_RIG)
        if target is rig or (target is not None and getattr(target, 'parent', None) is rig):
            _require(owner is not None, 'A character physics source has invalid attachment ownership.')
        if owner == rig:
            result.append(source)
    return tuple(result)


def _cached_availability(module, cache_name, time_name):
    cached = getattr(module, cache_name, None)
    stamp = getattr(module, time_name, 0.0)
    if cached is not None and time.monotonic() - stamp < 1.0:
        return cached
    # Drawing must not scan/hash third-party files. A stale/absent cache is
    # unknown, and the explicit activation action runs its full native proof.
    return {'available': True, 'reason': 'Backend compatibility is checked when starting physics.'}


def _mode(source, record):
    if record.get('physics'):
        profiles = _module('skirt_motion_profiles')
        profile = profiles.read(source, record)
        if profile is not None:
            return profile['mode']
        rig_service = _module('skirt_rig')
        holder, _rig, _path = rig_service.physics_control(source)
        return 'AUTOMATIC' if holder.get('physics_influence', 0.0) > 0 else 'MANUAL'
    return _module('skirt_wiggle').mode(source)


def _dress_context_block(context, source):
    if context.mode not in {'OBJECT', 'POSE'}:
        return 'Choose Object or Pose Mode before starting Dress physics.', False
    try:
        # This exact gate reads only saved Original ownership markers. Keep
        # its permission boundary; never finish/restore a session while drawing.
        _module('skirt_rig')._require_controls_for_setup(source)
    except (ValueError, RuntimeError, ReferenceError) as error:
        return 'Dress physics needs Controls mode; finish Original mode in Bone Display first. ' + str(error), True
    return '', False


def status(context):
    """Lightweight saved-state drawing; never validate/evaluate a mesh."""
    rig = _selected_rig(context)
    result = dict(_fresh(), rig=rig, valid=False, dresses=[], hair={'sources': [], 'active': False,
                                                   'paused': False, 'running': False,
                                                   'available': False, 'message': ''}, message='')
    if rig is None:
        result['message'] = 'Choose Main Rig in Character Setup first.'
        return result
    try:
        _local(rig, context)
        result.update(_read(rig))
        result['dependencies'] = {part: dependency_status(part) for part in COMPONENTS}
        for source in _sources(context, rig, 'SKIRT'):
            raw, record = _raw_record(source)
            cloth = bool(record.get('physics'))
            availability = ({'available': True, 'reason': ''} if cloth else
                _cached_availability(_module('skirt_wiggle'), '_BACKEND_CACHE', '_BACKEND_CACHE_TIME'))
            dependency = None if cloth else result['dependencies']['SKIRT']
            if dependency is not None and dependency['state'] != 'UNCHECKED':
                availability = {'available': dependency['available'], 'reason': dependency['message']}
            mode = _mode(source, record)
            context_message, requires_controls = _dress_context_block(context, source)
            running, message = False, availability.get('reason', '')
            if not cloth:
                wiggle = _module('skirt_wiggle')
                running = source.as_pointer() in wiggle._SESSIONS
                saved = wiggle._state(source) or {}
                reason = saved.get('reason', '')
                if not running and mode == 'AUTOMATIC' and not reason:
                    reason = 'Automatic is paused. Choose Automatic to resume.'
                message = ' '.join(part for part in (reason, message) if part)
            if context_message:
                message = ' '.join(part for part in (context_message, message) if part)
            result['dresses'].append({'source': source.name, 'name': source.name,
                'owner': record['owner'], 'mode': mode, 'running': running,
                'backend': record['physics'].get('backend', 'LEGACY_CAGE') if cloth else 'WIGGLE',
                'available': availability['available'] and not context_message, 'message': message,
                'context_blocked': bool(context_message), 'context_message': context_message,
                'mode_blocked': bool(context_message), 'block_reason': context_message,
                'requires_controls': requires_controls,
                'can_change_mode': not context_message,
                'dependency': dependency, 'last_error': _last_error(rig, 'SKIRT', source),
                'can_change_mode_paused': False})
        hairs = _sources(context, rig, 'HAIR')
        hair = _module('hair_wiggle_adapter')
        current = hair.status(context)
        availability = _cached_availability(hair, '_AVAILABLE_CACHE', '_AVAILABLE_CACHE_TIME')
        dependency = result['dependencies']['HAIR']
        if dependency['state'] != 'UNCHECKED':
            availability = {'available': dependency['available'], 'reason': dependency['message']}
        active = bool(current.get('active') and current.get('source') in {source.name for source in hairs})
        paused = bool(active and current.get('paused'))
        result['hair'] = {'sources': [source.name for source in hairs],
            'active': active, 'paused': paused, 'running': active and not paused,
            'available': availability['available'], 'message': availability.get('reason', ''),
            'dependency': dependency, 'last_error': _last_error(rig, 'HAIR', hairs[0] if len(hairs) == 1 else None),
            'source_errors': {source.name: _last_error(rig, 'HAIR', source) for source in hairs}}
        if not result['enabled']:
            result['message'] = 'Physics permission is off. Saved Dress modes are retained.'
        result['valid'] = True
    except (ValueError, RuntimeError, ReferenceError, AttributeError) as error:
        result['message'] = str(error)
    return result


def _entry(source, record, kind, **extra):
    return dict(kind=kind, source=source.name, owner=record['owner'],
                record_sha256=_digest(source[SKIRT_RECORD]), **extra)


def return_to_controls(context):
    """User-invoked equivalent of Bone Display's existing Controls action."""
    try:
        rig = _selected_rig(context)
        _local(rig, context)
        _require(context.mode in {'OBJECT', 'POSE'}, 'Choose Object or Pose Mode before returning to Controls.')
        original, display = _module('body_original_mode'), _module('bone_display')
        if original.active(rig):
            # Keep run_return's complete ownership/Rest/rollback policy. This
            # action does not forge a session, restore history, or grant an
            # old Action new permissions.
            original.leave(context, rig)
        elif display.view_mode(rig):
            display.restore_view(rig)
    except (ValueError, RuntimeError, ReferenceError, AttributeError, TypeError) as error:
        record_error(context, 'SKIRT', error)
        raise
    clear_error(context, 'SKIRT')
    return status(context)


def _source_for_entry(context, rig, item):
    source = context.scene.objects.get(item['source'])
    _require(source is not None, 'A suspended Dress was removed.')
    raw, record = _raw_record(source)
    _require(record['owner'] == item['owner'] and _digest(raw) == item['record_sha256'],
             'A suspended Dress setup changed. Preserve it before resuming Physics.')
    _require(_owner(source, 'SKIRT') == rig,
             'A suspended Dress moved to another character.')
    return source, record


def _flags(modifier):
    return [bool(modifier.show_viewport), bool(modifier.show_render)]


def _set_flags(modifier, flags):
    modifier.show_viewport, modifier.show_render = flags
    _require(_flags(modifier) == list(flags), 'Blender did not apply the owned Cloth flags.')


def _prepare_dress_pause(context, rig, state):
    actions, entries = [], []
    wiggle, physics = _module('skirt_wiggle'), _module('skirt_physics')
    for source in _sources(context, rig, 'SKIRT'):
        _raw, record = _raw_record(source)
        _module('skirt_rig')._require_controls_for_setup(source)
        if record.get('physics'):
            record, _target, proxy, cloth = physics.validate_physics(source)
            _require(not cloth.point_cache.is_baking, 'Finish the Dress bake before pausing Physics.')
            kind = 'DIRECT' if record['physics'].get('backend') == 'DIRECT_MAIN_CLOTH_V1' else 'CLOTH'
            item = _entry(source, record, kind, proxy=proxy.name,
                          modifier=cloth.name, flags=_flags(cloth))
            entries.append(item)
            if kind == 'DIRECT':
                actions.append(('DIRECT', source, record, None, None))
            else:
                actions.append(('CLOTH', cloth, [False, False], item['flags'], source))
        else:
            saved = wiggle._SESSIONS.get(source.as_pointer())
            if saved is not None:
                _require(not wiggle._changed(saved), 'The Dress simulation changed; choose its mode again first.')
                item = _entry(source, record, 'WIGGLE')
                entries.append(item)
                actions.append(('WIGGLE_STOP', source, None, None, None))
            else:
                target = source.get(SKIRT_RIG)
                for chain in record.get('chains', ()):
                    for name in chain.get('phys', ()):
                        bone = target.pose.bones.get(name) if target is not None else None
                        _require(bone is not None, 'A Dress physics bone is missing.')
                        _require(not (getattr(bone, 'wiggle_head', False)
                                      or getattr(bone, 'wiggle_tail', False)),
                                 'A Dress has an unowned live Wiggle configuration; choose its mode first.')
    return actions, entries


def _prepare_dress_resume(context, rig, entries):
    actions = []
    for item in entries:
        source, record = _source_for_entry(context, rig, item)
        if item['kind'] == 'WIGGLE':
            if _module('skirt_wiggle').mode(source) == 'AUTOMATIC':
                actions.append(('WIGGLE_START', source, None, None, None))
            continue
        proxy = context.scene.objects.get(item['proxy'])
        cloth = proxy.modifiers.get(item['modifier']) if proxy is not None else None
        _require(cloth is not None and cloth.type == 'CLOTH' and _flags(cloth) == [False, False],
                 'A paused Cloth modifier changed; its external edit was preserved.')
        _require(not cloth.point_cache.is_baking, 'Finish the Dress bake before resuming Physics.')
        if item['kind'] == 'DIRECT':
            # Direct's runtime also owns its typed output socket. Validate the
            # old, gated endpoint, then synchronize all native endpoints after
            # publishing the new permission; never force stale Cloth flags.
            _module('skirt_physics').validate_physics(source)
            actions.append(('DIRECT', source, record, None, None))
        else:
            _paused_cloth_ownership(source, record, proxy, cloth)
            actions.append(('CLOTH', cloth, item['flags'], [False, False], source))
    return actions


def _paused_cloth_ownership(source, record, proxy, cloth):
    """Prove the exact owned native writer before any resume setter.

    The ordinary full graph validator still runs after restoring its expected
    visibility. This preflight excludes only those two deliberately paused
    Cloth flags; it does not borrow authority from the saved helper name.
    """
    physics = _module('skirt_physics')
    physics._owned_mesh(proxy, source, record)
    details = record['physics']
    _require(details.get('proxy') == proxy.name,
             'The suspended Cloth is not this Dress physics endpoint.')
    target = source.get(SKIRT_RIG)
    modifiers = list(proxy.modifiers)
    backend = details.get('backend', 'LEGACY_CAGE')
    if backend == 'ACTUAL_SURFACE_DELTA_V1':
        surface = details.get('surface', {})
        _require(surface.get('roles', {}).get('CLOTH_PROXY') == [proxy.name],
                 'The suspended Cloth no longer has its exact surface role.')
        service = _module('skirt_surface')
        _require(service._helper_contract(proxy, dynamic_pin=True)
                 == surface.get('contracts', {}).get(proxy.name),
                 'The suspended Cloth native binding was edited.')
        expected_types = ['ARMATURE', 'SURFACE_DEFORM', 'CLOTH']
    else:
        _require(backend == 'LEGACY_CAGE', 'Unknown suspended Cloth backend.')
        expected_types = ['ARMATURE', 'CLOTH']
    _require([modifier.type for modifier in modifiers] == expected_types
             and modifiers[-1] == cloth and sum(modifier.type == 'CLOTH' for modifier in modifiers) == 1
             and all(modifier.show_viewport and modifier.show_render for modifier in modifiers[:-1])
             and proxy.parent == target and proxy.parent_type == 'OBJECT' and not proxy.parent_bone,
             'The suspended Cloth modifier order or attachment changed.')
    armature = modifiers[0]
    _require(armature.object == target and armature.use_vertex_groups
             and not armature.use_bone_envelopes and not armature.vertex_group
             and not armature.use_multi_modifier and armature.show_viewport and armature.show_render
             and record['controls']['waist'] in target.data.bones,
             'The suspended Cloth native bone binding changed.')


def _hair_action(context, rig, pause):
    hair = _module('hair_wiggle_adapter')
    current = hair.status(context)
    sources = _sources(context, rig, 'HAIR')
    source = next((source for source in sources if source.name == current.get('source')), None)
    if source is None or not current.get('active'):
        if pause:
            for candidate in sources:
                raw = candidate.get(HAIR_REGISTRY)
                if raw is None:
                    continue
                try:
                    registry = json.loads(raw)
                    names = [name for item in registry['strands'] for name in item['bones']]
                except (ValueError, TypeError, KeyError) as error:
                    raise AnimationPhysicsError('Hair ownership needs review before pausing Physics.') from error
                target = candidate.get(HAIR_RIG)
                for name in names:
                    bone = target.pose.bones.get(name)
                    _require(bone is not None, 'An owned Hair bone is missing.')
                    group = getattr(bone, 'wiggle', None)
                    _require(not (getattr(group, 'head', False) or getattr(group, 'tail', False)),
                             'Hair has an unowned Wiggle configuration; stop that preview first.')
        return []
    return [('HAIR', source, pause, bool(current.get('paused', False)), None)]


def _perform(context, action, *, reverse=False):
    kind, target, after, before, source = action
    if kind == 'CLOTH':
        _set_flags(target, before if reverse else after)
        if not reverse and after != [False, False]:
            _module('skirt_physics').validate_physics(source)
    elif kind == 'DIRECT':
        service = _module('skirt_surface_direct')
        service._sync(target, after, service._state(target, after))
        _module('skirt_physics').validate_physics(target)
    elif kind in {'WIGGLE_STOP', 'WIGGLE_START'}:
        start = (kind == 'WIGGLE_START') != reverse
        wiggle = _module('skirt_wiggle')
        if start:
            wiggle.set_mode(context, target, 'AUTOMATIC')
        else:
            wiggle._stop(target.as_pointer(), reason='Animation Physics is paused.', preserve_preference=True)
    elif kind == 'HAIR':
        _module('hair_wiggle_adapter').set_preview_paused(context, target, before if reverse else after)


def _transition(context, rig, after):
    _local(rig, context)
    before = _read(rig)
    old_allowed = {part: before['enabled'] and before[part.lower() + '_enabled'] for part in COMPONENTS}
    new_allowed = {part: after['enabled'] and after[part.lower() + '_enabled'] for part in COMPONENTS}
    actions = []
    if old_allowed['SKIRT'] and not new_allowed['SKIRT']:
        _require(not before['suspended'], 'An earlier Dress suspension needs review.')
        dress_actions, entries = _prepare_dress_pause(context, rig, before)
        actions.extend(dress_actions)
        after['suspended'] = entries
    elif not old_allowed['SKIRT'] and new_allowed['SKIRT']:
        actions.extend(_prepare_dress_resume(context, rig, before['suspended']))
        after['suspended'] = []
    if old_allowed['HAIR'] != new_allowed['HAIR']:
        actions.extend(_hair_action(context, rig, not new_allowed['HAIR']))
    old_raw = rig.get(STATE_KEY)
    touched = []
    try:
        _write(rig, after)
        for action in actions:
            touched.append(action)
            _perform(context, action)
        context.view_layer.update()
    except Exception as error:
        if old_raw is None:
            if STATE_KEY in rig:
                del rig[STATE_KEY]
        else:
            rig[STATE_KEY] = old_raw
        failures = []
        for action in reversed(touched):
            try:
                _perform(context, action, reverse=True)
            except Exception as rollback_error:
                failures.append(str(rollback_error))
        if failures:
            raise AnimationPhysicsError('Physics change failed; rollback needs review: ' + '; '.join(failures)) from error
        raise
    return status(context)


def set_enabled(context, enabled):
    _require(type(enabled) is bool, 'Enable Physics must be checked or unchecked.')
    rig = _selected_rig(context)
    _local(rig, context)
    after = _read(rig)
    after['enabled'] = enabled
    return _transition(context, rig, after)


def set_component(context, component, enabled):
    _require(component in COMPONENTS and type(enabled) is bool, 'Choose Hair or Skirt physics.')
    rig = _selected_rig(context)
    _local(rig, context)
    old_raw = rig.get(STATE_KEY)
    before = _read(rig)
    after = dict(before)
    after[component.lower() + '_enabled'] = enabled
    result = _transition(context, rig, after)
    if component == 'HAIR' and enabled and after['enabled'] and not before['hair_enabled']:
        hair = _module('hair_wiggle_adapter')
        if not hair.status(context).get('active'):
            try:
                start_hair_preview(context)
            except Exception as error:
                # The existing adapter owns its start rollback. Restore only
                # this permission after a refused start, never stop a foreign
                # session or make the checkbox claim it started successfully.
                try:
                    _transition(context, rig, before)
                except Exception as rollback_error:
                    raise AnimationPhysicsError('Hair preview was refused; permission rollback needs review: '
                                                + str(rollback_error)) from error
                if old_raw is None:
                    if STATE_KEY in rig:
                        del rig[STATE_KEY]
                else:
                    rig[STATE_KEY] = old_raw
                raise
            result = status(context)
    return result


def start_hair_preview(context):
    source_name = None
    try:
        rig = _selected_rig(context)
        if rig is not None:
            sources = _sources(context, rig, 'HAIR')
            source_name = sources[0].name if len(sources) == 1 else None
        result = _start_hair_preview(context)
    except (ValueError, RuntimeError, ReferenceError, AttributeError, TypeError) as error:
        record_error(context, 'HAIR', error, source_name=source_name)
        raise
    clear_error(context, 'HAIR', source_name=source_name)
    result['hair']['last_error'] = _last_error(_selected_rig(context), 'HAIR', sources[0] if len(sources) == 1 else None)
    return result


def _start_hair_preview(context):
    """Explicitly start the selected character's sole initialized Hair source."""
    rig = _selected_rig(context)
    _local(rig, context)
    state = _read(rig)
    _require(state['enabled'] and state['hair_enabled'],
             'Enable Hair Physics in Animation before starting its preview.')
    sources = _sources(context, rig, 'HAIR')
    _require(len(sources) == 1, 'Choose one Hair source in Rig to start its physics preview.')
    source = sources[0]
    hair = _module('hair_wiggle_adapter')
    current = hair.status(context)
    if current.get('active'):
        _require(current.get('source') == source.name,
                 'Another Hair preview is active; finish that preview first.')
        hair.set_preview_paused(context, source, False)
        return status(context)
    registry = _module('hair_strand_registry').read(source, validate=True)
    _require(registry and registry.get('strands'), 'Initialize Hair strand motion before enabling its preview.')
    profiles = _module('hair_motion_profiles').effective_all(source, registry=registry)
    hair.start_preview(context, source, registry, profiles,
                       [item['strand_id'] for item in registry['strands']])
    return status(context)


def set_skirt_mode(context, source_name, mode, *, expected_owner=''):
    try:
        result = _set_skirt_mode(context, source_name, mode, expected_owner=expected_owner)
    except (ValueError, RuntimeError, ReferenceError, AttributeError, TypeError) as error:
        record_error(context, 'SKIRT', error, source_name=source_name)
        raise
    clear_error(context, 'SKIRT', source_name=source_name)
    for row in result['dresses']:
        if row['source'] == source_name:
            row['last_error'] = _last_error(_selected_rig(context), 'SKIRT', context.scene.objects.get(source_name))
    return result


def _set_skirt_mode(context, source_name, mode, *, expected_owner=''):
    _require(mode in {'AUTOMATIC', 'MANUAL'}, 'Choose Automatic or Manual Dress motion.')
    rig = _selected_rig(context)
    _local(rig, context)
    source = context.scene.objects.get(source_name)
    _require(source is not None and _owner(source, 'SKIRT') == rig,
             'The selected Dress changed character.')
    _raw, record = _raw_record(source)
    _require(not expected_owner or record['owner'] == expected_owner, 'The selected Dress setup changed.')
    require_enabled(source, context, component='SKIRT')
    if record.get('physics'):
        _module('skirt_motion_tuning').apply(context, (source,), mode=mode)
    else:
        _module('skirt_wiggle').set_mode(context, source, mode)
    return status(context)
