"""Finish a whole-character transform clear against the rig's original limbs.

An individual shortcut retains Blender's per-channel meaning. A complete
clear is recognized only on the same rig, frame, selection and pose inputs.
The sequence exists only in memory and never adds properties to a .blend.
"""

import bpy


_CHANNELS = frozenset(('LOCATION', 'ROTATION', 'SCALE'))
_pending = None
_completed = None


def _pending_hooks():
    handlers = bpy.app.handlers
    return (handlers.frame_change_pre, handlers.undo_pre, handlers.redo_pre, handlers.load_pre)


def forget(*_event):
    global _pending, _completed
    if _pending is not None or _completed is not None:
        for hooks in _pending_hooks():
            if forget in hooks:
                hooks.remove(forget)
    _pending = None
    _completed = None


def _visible_selected(context, names):
    visible = getattr(context, 'visible_pose_bones', None)
    return bool(visible) and all(p.name in names for p in visible
                                 if p.id_data == context.object and not p.bone.hide_select)


def _selected_limb(rig, target, pole, chain, names):
    if {target.name, pole.name} <= names:
        return True
    return (rig.pose.bones[target.name].get('ik_fk') == 0.0 and target.hide and pole.hide
            and len(chain) == 3 and set(chain) <= names)


def _fk_body_selected(context, owner, names, limb):
    if not _visible_selected(context, names):
        return False
    from . import limb_control_selection
    rig = context.object
    tagged = {}
    for bone in rig.data.bones:
        if limb._owned(bone, owner):
            key = (bone.get(limb.KIND_KEY), bone.get(limb.SIDE_KEY), bone.get(limb.ROLE_KEY))
            if key[2] not in {'HAND_IK', 'FOOT_IK', 'POLE'}:
                continue
            if key in tagged:
                return False
            tagged[key] = bone
    for kind, target_role in (('ARM', 'HAND_IK'), ('LEG', 'FOOT_IK')):
        for side in ('L', 'R'):
            target = tagged.get((kind, side, target_role))
            pole = tagged.get((kind, side, 'POLE'))
            if target is None or pole is None:
                return False
            chain = limb_control_selection._chain(target.get(limb.CHAIN_KEY))
            if not chain or not _selected_limb(rig, target, pole, chain, names):
                return False
    return True


def body_selected(context):
    if context.mode != 'POSE':
        return False
    selected = context.selected_pose_bones or ()
    if len(selected) < 9:
        return False
    from . import foot_controls, limb_ik as limb, root_control
    rig = context.object
    if rig is None or rig.type != 'ARMATURE' or context.scene.tool_settings.use_keyframe_insert_auto:
        return False
    owner = rig.data.get(limb.ARMATURE_ID_KEY)
    if (not owner or rig.data.get(limb.SCHEMA_KEY) != limb.DIRECT_PREROLL_SCHEMA
            or not rig.data.get(foot_controls.RECORD_KEY) or any(obj != rig for obj in context.objects_in_mode)):
        return False
    root = False
    controls = set()
    for pb in selected:
        if pb.id_data != rig:
            return False
        bone = pb.bone
        if (bone.get(root_control.OWNER_KEY) == root_control.OWNER_VALUE
                and bone.get(root_control.ROLE_KEY) == 'MASTER'):
            root = True
        if limb._owned(bone, owner):
            controls.add((bone.get(limb.KIND_KEY), bone.get(limb.SIDE_KEY), bone.get(limb.ROLE_KEY)))
    complete = root and all((kind, side, role) in controls for side in ('L', 'R')
                            for kind, target in (('ARM', 'HAND_IK'), ('LEG', 'FOOT_IK'))
                            for role in (target, 'POLE'))
    if not complete and (not root or not _fk_body_selected(context, owner, {p.name for p in selected}, limb)):
        return False
    try:
        return set(foot_controls.records(rig)) == {'L', 'R'}
    except ValueError:
        # A damaged owned record belongs to the service preflight. It can
        # report the error to the artist before attempting a bind reset.
        return True


def _pose_inputs(rig):
    from . import control_pose_assets as poses
    return {pb.name: {key: tuple(getattr(pb, key)) if count > 1 else getattr(pb, key)
                      for key, count in poses._FIELDS.items()} for pb in rig.pose.bones}


def _signature(context):
    rig = context.object
    ad = rig.animation_data
    bones = tuple((pb.name, pb.rotation_mode, pb.get('ik_fk'), pb.get('uniform_scale'), tuple(pb.lock_location),
                   tuple(pb.lock_rotation), pb.lock_rotation_w, pb.lock_rotations_4d, tuple(pb.lock_scale))
                  for pb in rig.pose.bones)
    active = rig.data.bones.active
    # View-layer names are unique in their scene. The RNA pointer may change
    # when Blender restores the same layer through undo or redo.
    return (context.scene.session_uid, rig.session_uid, rig.data.session_uid, context.view_layer.name,
            context.scene.frame_current, context.scene.frame_subframe, rig.pose.use_mirror_x,
            ad.action.session_uid if ad and ad.action else None, ad.action_slot_handle if ad else None,
            active.name if active else None, frozenset(pb.name for pb in context.selected_pose_bones),
            tuple(tuple(row) for row in rig.matrix_world), bones, _pose_inputs(rig))


def _native(context, channel):
    if channel == 'ROTATION':
        from . import controller_transform_clear, limb_ik_fk, limb_ik_wrist_rotation_ui as ui, natural_bind_graph
        rig = context.object
        selected = tuple(context.selected_pose_bones)
        wrists = tuple(pb for pb in selected if ui._owned_wrist(pb))
        if (not wrists or natural_bind_graph.KEY in rig and natural_bind_graph.validate(rig)['enabled']
                or any(pb.get(limb_ik_fk.PROPERTY) != 1.0 for pb in wrists)):
            # A partially weighted or inactive IK target cannot independently
            # set the hand's orientation. Clear the selected rotation inputs
            # together and let the complete gesture restore the native FK chain.
            if bpy.ops.pose.rot_clear('EXEC_DEFAULT', False) != {'FINISHED'}:
                raise ValueError('Blender could not clear the selected rotations.')
            return
        companions = tuple(pb for pb in selected if pb not in wrists)
        controller_transform_clear.reset_mixed_rotation(context, wrists, companions)
        return
    operator = bpy.ops.pose.loc_clear if channel == 'LOCATION' else bpy.ops.pose.scale_clear
    if operator('EXEC_DEFAULT', False) != {'FINISHED'}:
        raise ValueError('Blender could not clear the selected transform channel.')


def _finish(context, previous):
    """Restore every transform channel for a complete body gesture or the reset button."""
    from . import natural_bind_graph, natural_bind_mode, natural_limb_inventory, natural_limb_solve
    from . import natural_body_reference, limb_ik_fk, root_control
    rig = context.object
    inventory = natural_limb_inventory.prepare(context, rig)
    selected = {pb.name for pb in context.selected_pose_bones}
    root = root_control.get_record(rig)
    if not root or root['master'] not in selected:
        raise ValueError('Select this rig’s root control to restore the whole body.')
    if not all({entry['target'].name, entry['pole'].name} <= selected for entry in inventory['rigs'].values()):
        if not _visible_selected(context, selected) or not all(
                _selected_limb(rig, entry['target'], entry['pole'], entry['chain'], selected)
                for entry in inventory['rigs'].values()):
            raise ValueError('Select the visible controls for all four limbs.')
    before = _pose_inputs(rig)
    graph = rig.get(natural_bind_graph.KEY)
    created = False
    restore_calibration = None
    try:
        _native(context, 'LOCATION')
        _native(context, 'SCALE')
        if bpy.ops.pose.rot_clear('EXEC_DEFAULT', False) != {'FINISHED'}:
            raise ValueError('Blender could not clear the selected rotations.')
        natural_body_reference.prepare_body(context, rig, inventory)
        natural_limb_solve.reset_limbs(context, rig, inventory)
        if graph is None:
            natural_bind_graph.install(context, rig, inventory, solver='STABLE_MCH_ORI')
            created = True
        else:
            restore_calibration = natural_bind_graph.recalibrate(
                context, rig, inventory, solver='STABLE_MCH_ORI')
        if natural_bind_graph.solver_kind(rig) != 'STABLE_MCH_ORI':
            raise ValueError('The hidden Stable limb solver could not be activated.')
        natural_limb_solve.verify_bind(rig, inventory)
        natural_bind_mode.begin_preview(context, rig, previous)
    except Exception:
        if created:
            natural_bind_graph.remove(context, rig)
        elif restore_calibration:
            restore_calibration()
        after = _pose_inputs(rig)
        for name, values in before.items():
            pb = rig.pose.bones[name]
            for field, saved in values.items():
                if saved != after[name][field]:
                    setattr(pb, field, saved)
        limb_ik_fk._update(context, rig)
        raise


def _completion_state(context):
    from . import natural_bind_graph, natural_bind_mode
    rig = context.object
    graph = rig.get(natural_bind_graph.KEY)
    preview = rig.get(natural_bind_mode.KEY)
    if (not graph or not preview or not graph['enabled'] or graph['token'] != preview['token']
            or natural_bind_graph.solver_kind(rig) != 'STABLE_MCH_ORI'):
        return None
    # A constraint, IK target, or parent can also move the body without a
    # local transform edit. Never swallow a subsequent clear on a changed pose.
    return (graph['token'], natural_bind_graph.active_branch(graph)['offset_signature'],
            tuple(tuple(x for row in pb.matrix for x in row) for pb in rig.pose.bones))


def _remember_completion(context):
    global _completed
    _completed = (_signature(context), _completion_state(context))
    # The witness holds Python values only. Undo before completion removes the
    # matching graph/pose. Redo can restore that exact verified pose, including
    # its compensated hips. In-progress sequences still expire on every undo.
    # Blender also emits frame_change_pre while restoring an undo step at
    # the same frame. The signature already checks the exact frame and pose.
    bpy.app.handlers.load_pre.append(forget)


def clear_channel(context, channel):
    global _pending
    if channel not in _CHANNELS:
        raise ValueError('Unknown transform channel.')
    before = _signature(context)
    if _completed and _completed[0] == before:
        if _completed[1] is not None and _completed[1] == _completion_state(context):
            return True
    if _pending and _pending[0] == before:
        _, seen, previous = _pending
    else:
        from . import natural_bind_mode
        previous = natural_bind_mode.capture(context, context.object)
        seen = frozenset()
    forget()
    seen = seen | {channel}
    if {'LOCATION', 'ROTATION'} <= seen:
        _finish(context, previous)
        _remember_completion(context)
        return True
    _native(context, channel)
    _pending = (_signature(context), seen, previous)
    for hooks in _pending_hooks():
        hooks.append(forget)
    return False


def clear_body(context):
    forget()
    if not body_selected(context):
        raise ValueError('Select the root and all four limb targets and poles in Pose Mode.')
    from . import natural_bind_mode
    _finish(context, natural_bind_mode.capture(context, context.object))
    _remember_completion(context)
