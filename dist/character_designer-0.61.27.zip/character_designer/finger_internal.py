"""Conservative straight internal axes; no scene data or surface offsets.

Search is deliberately bounded to the detected longitudinal direction. A closed
temporary finger volume (real body/tip plus a virtual root cap) certifies the
whole segment, using distance-field Lipschitz bounds rather than endpoint tests.
"""
import math
import statistics

from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.geometry import tessellate_polygon


class Volume:
    def __init__(self, bm, candidate):
        ids = set(candidate['faces'])
        directed = {}
        for i in ids:
            face = bm.faces[i]
            if face.hide: raise ValueError('Internal guide: a supporting finger face is hidden.')
            for loop in face.loops:
                a, b = loop.vert.index, loop.link_loop_next.vert.index
                directed.setdefault(tuple(sorted((a, b))), []).append((a, b))
        boundary = {e for e, directions in directed.items() if len(directions) == 1}
        root = candidate['rings'][0][:]
        expected = {tuple(sorted((v, root[(i+1) % len(root)]))) for i, v in enumerate(root)}
        if boundary != expected:
            raise ValueError('Internal guide: the finger body has a hole or an extra boundary.')
        for directions in directed.values():
            if len(directions) != 1 and (len(directions) != 2 or directions[0] != directions[1][::-1]):
                raise ValueError('Internal guide: inconsistent or non-manifold finger faces.')
        if directed[tuple(sorted(root[:2]))][0] == tuple(root[:2]): root.reverse()
        triangles = [tuple(loop.vert.co.copy() for loop in tri)
                     for tri in bm.calc_loop_triangles() if tri[0].face.index in ids]
        root_points = [bm.verts[i].co.copy() for i in root]
        triangles += [tuple(root_points[p].copy() if isinstance(p, int) else p.copy() for p in tri)
                      for tri in tessellate_polygon([root_points])]
        scale = candidate['length']
        if not triangles or any((b-a).cross(c-a).length < scale*scale*1e-12 for a, b, c in triangles):
            raise ValueError('Internal guide: a supporting triangle is collapsed.')
        self.triangles = triangles
        vertices = [p for tri in triangles for p in tri]
        self.tree = BVHTree.FromPolygons(vertices, [tuple(range(i, i+3)) for i in range(0, len(vertices), 3)], all_triangles=True)

    def distance(self, point):
        return self.tree.find_nearest(point)[3]

    def inside(self, point):
        total = 0.
        for triangle in self.triangles:
            a, b, c = (p-point for p in triangle)
            denominator = a.length*b.length*c.length+a.dot(b)*c.length+b.dot(c)*a.length+c.dot(a)*b.length
            total += 2*math.atan2(a.dot(b.cross(c)), denominator)
        # A single closed, consistently oriented volume has winding +/-1.
        return abs(abs(total)-4*math.pi) < .02

    def certify(self, path, margin):
        a, b = map(Vector, path)
        if not self.inside((a+b)*.5): return None
        pending, lower = [(a, b, 0)], float('inf')
        while pending:
            a, b, depth = pending.pop()
            mid, half = (a+b)*.5, (b-a).length*.5
            distance = self.distance(mid)
            if distance is None or distance < margin: return None
            # Every point in this interval lies in an interior ball with at
            # least this clearance. The connected certified balls cover [A,B].
            bound = distance-half
            if bound >= margin:
                lower = min(lower, bound)
                continue
            if depth >= 16: return None
            pending.extend(((a, mid, depth+1), (mid, b, depth+1)))
        return lower


def geometry(bm, candidate):
    centers = [sum((bm.verts[i].co for i in row), Vector())/len(row) for row in candidate['rings']]
    main = centers[-1]-centers[0]
    if main.length < candidate['length']*.65:
        raise ValueError('Internal guide: this finger bends too far for a full-range straight axis.')
    main.normalize()
    radial = bm.verts[candidate['rings'][0][0]].co-centers[0]
    u = radial-main*radial.dot(main)
    if u.length < candidate['radius']*.01: raise ValueError('Internal guide: the root cross-section is collapsed.')
    u.normalize()
    v = main.cross(u).normalized()
    widths = []
    for row in candidate['rings']:
        spans = []
        for i in range(12):
            direction = u*math.cos(i*math.pi/12)+v*math.sin(i*math.pi/12)
            values = [bm.verts[j].co.dot(direction) for j in row]
            spans.append(max(values)-min(values))
        widths.append(min(spans))
    # Exclude the last, possibly collapsed tip ring. Use stable body sections.
    root_width = statistics.median(widths[:min(3, len(widths)-1)])
    tip_width = statistics.median(widths[max(0, len(widths)-4):-1])
    thickness = min(root_width, tip_width)
    if thickness < candidate['length']*1e-5: raise ValueError('Internal guide: no stable finger thickness could be measured.')
    return centers, main, u, v, root_width, tip_width, thickness


def solve(bm, candidate, range_path):
    centers, main, u, v, root_width, tip_width, thickness = geometry(bm, candidate)
    points = list(map(Vector, range_path))
    lo, hi = points[0].dot(main), points[-1].dot(main)
    span = hi-lo
    if span <= thickness*.5: raise ValueError('Internal guide: the selected longitudinal range is too short.')
    volume = Volume(bm, candidate)
    center = sum(centers, Vector())/len(centers)
    ts = [(p-center).dot(main) for p in centers]
    variance = sum(t*t for t in ts)
    fitted = sum(((p-center)*t for p, t in zip(centers, ts)), Vector())/variance
    fitted.normalize()
    if fitted.dot(main) < .97: fitted = main
    directions = [main, fitted]
    directions += [(fitted+u*a+v*b).normalized() for a, b in ((-.05, 0), (.05, 0), (0, -.05), (0, .05))]
    margin = thickness*.04
    # Preserve longitudinal coverage first. Never shrink past these small
    # automatic endpoint margins, and never accept less than 85% of the span.
    for retreat in (.10, .125, .15):
        start, end = lo+root_width*retreat, hi-tip_width*retreat
        if end-start < span*.85: continue
        options = []
        for direction in directions:
            dot = direction.dot(main)
            if dot < .97: continue
            for x in (-.30, -.15, 0., .15, .30):
                for y in (-.30, -.15, 0., .15, .30):
                    anchor = center+(u*x+v*y)*thickness
                    a = anchor+direction*((start-anchor.dot(main))/dot)
                    b = anchor+direction*((end-anchor.dot(main))/dot)
                    clear = min(volume.distance(a.lerp(b, i/16)) for i in range(17))
                    if clear <= margin: continue
                    stable = sum((p-(a+direction*(p-a).dot(direction))).length_squared for p in centers)
                    options.append((clear, -stable, a, b))
        # Equal coverage: prefer clearance, then distance from section centers.
        options.sort(key=lambda item: item[:2], reverse=True)
        for _, _, a, b in options:
            certified = volume.certify((a, b), margin)
            if certified is not None:
                return {'path': [list(a), list(b)], 'margin': margin,
                        'clearance_lower_bound': certified, 'thickness': thickness,
                        'start_retreat': root_width*retreat, 'tip_retreat': tip_width*retreat,
                        'coverage': (end-start)/span, 'method': 'certified_straight_v1'}
    raise ValueError('Internal guide: no safe straight axis covers this finger range with surface clearance. The finger may be too bent, pinched, or the selection may extend into the palm. Previous definition retained.')


def verify(bm, candidate, internal):
    thickness = geometry(bm, candidate)[-1]
    certified = Volume(bm, candidate).certify(internal['path'], thickness*.04) if len(internal['path']) == 2 else None
    if certified is None:
        raise ValueError('The opposite internal straight axis does not have safe clearance in its actual finger body.')
    return {'margin': thickness*.04, 'thickness': thickness, 'clearance_lower_bound': certified}
