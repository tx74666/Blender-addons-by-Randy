"""Shared Setup -> paired staged rings -> bounded two-bone weights.

One immutable transaction source per character, multiple per-finger recipes.
Updates regenerate only the managed fingers on that source. Proven local ring
edits adopt the current mesh as a new source; no old snapshot wins over new data.
"""
import json
import math
import time
from types import SimpleNamespace

import bmesh
import bpy
from mathutils import Vector

from . import finger_bank as bank, finger_definition as definition, finger_layout as layout
from . import finger_ring_slide as slide, finger_targets as targets
from . import finger_joint_plan, finger_chain

SOURCE_TAG = 'character_designer_finger_workflow_source'
RESULT_TAG = 'character_designer_finger_workflow_result'
LAYOUT_SCHEMA = 2


def state(context):
    obj = bank.active_object(context)
    if not obj: raise ValueError('Capture Finger Basic Setup on this mesh first.')
    return obj, obj.character_designer_finger_workflow


def settings(context):
    obj, s = state(context)
    digit = obj.character_designer_finger_bank.active.split('.')[0]
    pair = s.pairs.get(digit)
    if pair is None: raise ValueError('Prepare this finger first.')
    return obj, s, pair


def check_source(obj, s):
    if not s.source: return
    signature = layout.fingerprint(obj)
    if signature != s.signature:
        if bank.active_object(bpy.context) == obj and refresh_topology(bpy.context, signature=signature):
            return
        raise ValueError('Mesh, Shape Keys, attributes or weights changed since preparation. Release prepared results and prepare again; new edits were not overwritten.')


def refresh_topology(context, *, signature=None):
    from . import finger_workflow_rebase
    return finger_workflow_rebase.refresh(context, signature=signature)


def ensure_pair(s, digit):
    pair = s.pairs.get(digit)
    if pair is None:
        pair = s.pairs.add()
        pair.name = digit
    return pair


def _initial_positions(context, obj, digit, frame, count=None):
    """Keep the existing bone-derived preparation defaults, per finger pair."""
    try:
        _, rig = targets.owner(context)
        chain = targets.pair(obj, rig, digit, targets.index(rig))[obj.character_designer_finger_bank.active]
        from .finger_bones import _head
        positions = [definition.project_distance(rig.matrix_world @ _head(bone), frame['path'])/frame['length'] for bone in chain[1:]]
        if positions and (count is None or len(positions) == count):
            return [max(.01, min(.99, t)) for t in positions], 'BONES', ''
        reason = 'Bone junction count differs from the existing markers; marker count is kept.'
    except ValueError as exc:
        reason = str(exc)  # Topology preparation never requires bones.
    count = 2 if count is None else count
    return ([.34, .68] if count == 2 else [(i+1)/(count+1) for i in range(count)]), 'TOPOLOGY', reason


def _position_profile(positions, source, reason=''):
    return json.dumps(dict(schema=1, positions=list(positions), source=source, reason=reason))


def default_positions(pair, *, automatic=False):
    raw = pair.automatic_defaults if automatic or not pair.custom_defaults else pair.custom_defaults
    if not raw:
        raise ValueError('Prepare this finger again to establish its automatic defaults; current positions are kept.')
    try:
        data = json.loads(raw)
        values = data['positions']
        if data['schema'] != 1 or not isinstance(values, list) or not values:
            raise ValueError()
        if any(type(v) not in (int, float) or not math.isfinite(v) or not .01 <= v <= .99 for v in values):
            raise ValueError()
    except (ValueError, KeyError, TypeError):
        raise ValueError('Stored joint defaults are invalid; current positions are kept.') from None
    return values


def _check_positions(obj, s, pair, values):
    """Validate a complete positional update before changing any RNA settings."""
    check_source(obj, s)
    if not s.source or not pair.recipe:
        raise ValueError('Prepare this finger first.')
    if len(values) != len(pair.joints):
        raise ValueError('Default joint count differs from this finger; current markers are kept.')
    if any(not math.isfinite(v) or not .01 <= v <= .99 for v in values) or any(a >= z for a, z in zip(values, values[1:])):
        raise ValueError('Joint defaults must be ordered from root to tip, without overlapping centers.')
    data = parameters(pair)
    for joint, value in zip(data['joints'], values): joint['position'] = value
    config = SimpleNamespace(**{k: v for k, v in data.items() if k != 'joints'},
                             joints=[SimpleNamespace(**j) for j in data['joints']])
    for key, recipe in json.loads(pair.recipe).items():
        slot = obj.character_designer_finger_bank.slots.get(key)
        if not slot or slot.error or slot.guide.revision != recipe['definition_id']:
            raise ValueError(f'{key}: Setup changed; prepare this finger again.')
        recipe['flip_bend'] = slot.guide.flip_bend
        build_plan(obj, s.source, recipe, config, centers_only=True)


def save_defaults(context):
    """Only marker positions, not widths, weights, geometry or other fingers."""
    obj, s, pair = settings(context)
    values = [j.position for j in pair.joints]
    _check_positions(obj, s, pair, values)
    pair.custom_defaults = _position_profile(values, 'CUSTOM')
    return values


def restore_defaults(context, *, automatic=False):
    obj, s, pair = settings(context)
    values = default_positions(pair, automatic=automatic)
    if committed_phase(pair, s) == 'FINAL' and values != [j.position for j in pair.joints]:
        raise ValueError('Undo Step 2 before restoring different center positions.')
    _check_positions(obj, s, pair, values)
    previous = [j.position for j in pair.joints]
    try:
        for joint, value in zip(pair.joints, values): joint.position = value
    except Exception:
        for joint, value in zip(pair.joints, previous): joint.position = value
        raise
    return values


def prepare(context):
    obj = layout._edit(context)
    obj2, s = state(context)
    if obj != obj2: raise ValueError('Edit the captured character mesh.')
    check_source(obj, s)
    b = obj.character_designer_finger_bank
    guide = definition.state(context)
    frame = definition.frame(context, require_basis=True, require_confirmed=True, purpose='TOPOLOGY')
    current = bank.current_candidate(context)
    digit = b.active.split('.')[0]
    report = json.loads(b.survey)
    keys = [digit+'.'+side for side in ('L', 'R') if digit+'.'+side in report['candidates']]
    if len(keys) == 2 and report['warnings'].get(digit): raise ValueError(report['warnings'][digit])
    if len(keys) == 1:
        other = 'R' if keys[0].endswith('.L') else 'L'
        if any(k.endswith('.'+other) for k in report['candidates']) or not targets.opposite_absent(obj, current):
            raise ValueError('The opposite hand exists but this finger is unmatched; no single-sided topology fallback.')
    source = s.source or obj.data.copy()
    fresh = not s.source
    try:
        bodies = json.loads(s.bodies) if s.bodies else report['candidates']
        records = {}
        for key in keys:
            slot = b.slots[key]
            if not slot.guide.record or slot.error: raise ValueError(slot.error or 'Opposite Setup is incomplete.')
            r = json.loads(slot.guide.record)
            if key not in bodies: raise ValueError('Release prepared results to include this newly detected finger.')
            rows = bodies[key]['rings']
            path = [obj.matrix_world @ Vector(p) for p in r['basis']['path']]
            length = sum((q-p).length for p, q in zip(path, path[1:]))
            positions = [definition.project_distance(sum((obj.matrix_world @ source.vertices[i].co for i in row), Vector())/len(row), path)/length for row in rows]
            if any(z-a < 1e-5 for a, z in zip(positions, positions[1:])): raise ValueError('The topology range folds back.')
            records[key] = {'schema': 2, 'rings': rows, 'positions': positions, 'root': r['basis']['path'][0],
                            'tip': r['basis']['path'][-1], 'path': r['basis']['path'], 'length': length, 'definition_id': slot.guide.revision,
                            'normal': r['basis'].get('normal'), 'flip_bend': slot.guide.flip_bend,
                            'protected_rows': sorted(slide.protected_rows(source, rows))}
        pair = ensure_pair(s, digit)
        positions, origin, reason = _initial_positions(context, obj, digit, frame, len(pair.joints) or None)
        if not pair.joints:
            for t in positions:
                joint = pair.joints.add()
                joint.position = t
        labels = {}
        try:
            _, rig = targets.owner(context)
            chains = targets.pair(obj, rig, digit, targets.index(rig))
            for key, recipe in records.items():
                finger_chain.bind(obj, rig, key, chains[key], recipe)
            for key, recipe in records.items():
                for i, joint in enumerate(pair.joints):
                    a, z, offset = joint_bones(obj, rig, chains[key], recipe, joint, index=i, config=pair)
                    labels[key+':'+str(i)] = {'A': a, 'B': z, 'offset': offset}
        except ValueError as exc:
            for recipe in records.values(): recipe['chain_binding_error'] = str(exc)
            from . import character_setup
            if character_setup.preferred_rig(context) is None: pair.sync_bones = False
        pair.recipe = json.dumps(records)
        pair.labels = json.dumps(labels)
        if fresh:
            source.name = '.CD Finger Workflow Source'
            source[SOURCE_TAG] = True
            s.source, s.bodies = source, json.dumps(bodies)
            s.signature = layout.fingerprint(obj)
            from . import finger_workflow_rebase
            s['topology'] = finger_workflow_rebase.topology(obj)
        # Reprepare updates the automatic baseline, never current/custom values.
        pair.automatic_defaults = _position_profile(positions, origin, reason)
        return pair
    except Exception:
        if fresh and source.users == 0: bpy.data.meshes.remove(source)
        raise


def capture_joint(context):
    obj, s, pair = settings(context)
    check_source(obj, s)
    bm = bmesh.from_edit_mesh(obj.data)
    definition._index(bm)
    chosen = {e for e in bm.edges if e.select and not e.hide}
    from .finger_joint import _ordered_loop
    ring = _ordered_loop(chosen)
    candidate = bank.current_candidate(context)
    if not any({v.index for v in ring} == set(row) for row in candidate['rings'][1:-1]):
        raise ValueError('Select one complete internal ring of the active Setup finger; face-band centers must be specified as an edge loop.')
    frame = definition.frame(context, require_basis=True, purpose='TOPOLOGY')
    center = sum((obj.matrix_world @ v.co for v in ring), Vector())/len(ring)
    t = definition.project_distance(center, frame['path'])/frame['length']
    if not pair.joints: pair.joints.add()
    pair.joints[min(pair.active_joint-1, len(pair.joints)-1)].position = t
    return t


def build_plan(obj, source, recipe, pair, *, centers_only=False, center_rows=None):
    """Move existing centers; insert new supports only in the second phase."""
    return finger_joint_plan.build_plan(obj, source, recipe, pair,
                                       centers_only=centers_only, center_rows=center_rows)


def preview_plan(obj, source, recipe, pair, *, centers_only=False, center_rows=None):
    """Invalid editing parameters still have a drawable, never writable draft."""
    try:
        return build_plan(obj, source, recipe, pair, centers_only=centers_only, center_rows=center_rows)
    except ValueError as exc:
        rows, ts = recipe['rings'], recipe['positions']
        rings = []
        for i, joint in enumerate(pair.joints):
            for flank in (0,) if centers_only else (-1, 0, 1):
                t = joint.position + flank*joint.width
                # No extrapolation into the protected palm/tip. Out-of-range
                # targets are explicitly labelled at the nearest safe boundary.
                sampled_t = max(ts[0], min(ts[-1], t))
                points, band, fraction = layout._sample(source, rows, ts, sampled_t)
                rings.append(dict(t=t, kind='JOINT_'+str(i+1) if not flank else 'SUPPORT',
                                  joint=i, flank=flank, points=points, band=band,
                                  fraction=fraction, blocked=True, boundary=sampled_t != t))
        return dict(obj=obj, rings=rings, warning=str(exc), preview_only=True, centers_only=centers_only)


def _center_identity(recipe):
    """Saved preparation evidence only; no live mesh or bone reads in panels."""
    return {key: value for key, value in recipe.items() if key not in {'flip_bend', 'chain_binding_error'}}


def _center_parameters(pair):
    return {'positions': [j.position for j in pair.joints],
            'sync_bones': bool(getattr(pair, 'sync_bones', False))}


def committed_phase(pair, s):
    """Metadata-only phase for the currently prepared pair."""
    if not pair or not pair.applied or not pair.recipe: return ''
    try:
        saved, recipes = json.loads(s.results or '{}'), json.loads(pair.recipe)
        phases = {saved.get(key, {}).get('phase', '') for key in recipes}
        if recipes and len(phases) == 1 and phases <= {'CENTERS', 'FINAL'}:
            return phases.pop()
    except (ValueError, TypeError, AttributeError): pass
    return ''


def support_ready(pair, s):
    """Cheap UI gate; Apply also proves source equality and live bone bindings."""
    if not pair or not s.source or not pair.recipe or not pair.applied:
        return False, 'Complete Step 1: Position Centers first.'
    try:
        saved, recipes = json.loads(s.results or '{}'), json.loads(pair.recipe)
        if not recipes: return False, 'Prepare this finger and complete Step 1 first.'
        current = _center_parameters(pair)
        expected_ordinals = {str(i) for i in range(len(pair.joints))}
        for key, recipe in recipes.items():
            result = saved.get(key, {})
            confirmation = result.get('center_confirmation', {})
            rows = result.get('center_rows', {})
            if result.get('layout_schema') != LAYOUT_SCHEMA or result.get('phase') not in {'CENTERS', 'FINAL'}:
                return False, 'Complete Step 1 with this version before adding support loops.'
            if confirmation.get('parameters') != current:
                return False, 'Joint positions or bone synchronization changed; complete Step 1 again.'
            if confirmation.get('identity') != _center_identity(recipe):
                return False, 'Prepared finger identities changed; complete Step 1 again.'
            if set(map(str, rows)) != expected_ordinals or any(type(row) is not int for row in rows.values()):
                return False, 'Confirmed center-loop mapping is missing; complete Step 1 again.'
        return True, ''
    except (ValueError, TypeError, AttributeError):
        return False, 'Confirmed center metadata is invalid; Prepare and complete Step 1 again.'


def plans(context, *, all_applied=False, preview=False, centers_only=False, supports_only=False):
    obj, s, active = settings(context)
    if not s.source: raise ValueError('Prepare this finger first.')
    result = []
    committed = json.loads(s.results or '{}')
    if all_applied:
        legacy = [key for pair in s.pairs if pair != active and pair.applied
                  for key in json.loads(pair.recipe or '{}')
                  if committed.get(key, {}).get('layout_schema') != LAYOUT_SCHEMA or
                  'flip_bend' not in committed.get(key, {}) or
                  not {'fill_between', 'sync_bones'} <= set(committed.get(key, {}).get('geometry', {}))]
        if legacy:
            raise ValueError('Previously generated fingers use an older ring layout: '+', '.join(legacy)+
                             '. Release Prepared Results to keep the current mesh and bones as the new source, '
                             'then Prepare the finger you want to update. No existing finger was regenerated.')
    ready, reason = support_ready(active, s)
    if supports_only and not ready: raise ValueError(reason)
    if preview:
        centers_only = not ready
        supports_only = ready
    for pair in s.pairs:
        if pair != active and (not all_applied or not pair.applied): continue
        if not pair.recipe: continue
        for key, recipe in json.loads(pair.recipe).items():
            slot = obj.character_designer_finger_bank.slots.get(key)
            if not slot or slot.error or slot.guide.revision != recipe['definition_id']:
                raise ValueError(f'{key}: Setup changed; prepare this finger again.')
            config = pair
            saved = committed.get(key, {})
            if pair != active and saved.get('center_confirmation', {}).get('identity') != _center_identity(recipe):
                raise ValueError(f'{key}: the prepared finger identity changed after confirmation. '
                                 'Release Prepared Results to keep the current mesh and bones, then Prepare the finger you want to update.')
            recipe['flip_bend'] = slot.guide.flip_bend if pair == active else saved['flip_bend']
            if pair != active and key in committed:
                data = saved['parameters']
                config = SimpleNamespace(**{k: v for k, v in data.items() if k != 'joints'},
                                         joints=[SimpleNamespace(**j) for j in data['joints']])
            phase = ('CENTERS' if centers_only else 'FINAL') if pair == active else saved.get('phase', 'FINAL')
            pinned = saved.get('center_rows') if pair != active or supports_only else None
            from . import finger_subdivision
            adopted_geometry = (saved.get('adopted') and not saved.get('subdivision_dirty')
                                and geometry_parameters(config) == saved.get('geometry')
                                and recipe['flip_bend'] == saved.get('flip_bend') and
                                saved.get('plan', {}).get('subdivision', {}).get('config') == finger_subdivision.configuration(obj))
            if saved.get('adopted') and (pair != active or (supports_only and adopted_geometry)):
                from . import finger_workflow_rebase
                plan = finger_workflow_rebase.frozen_plan(obj, recipe, saved)
                if pair == active:
                    plan.pop('frozen')
                    plan['preserve_geometry'] = True
            else:
                plan = (preview_plan if preview else build_plan)(obj, s.source, recipe, config,
                            centers_only=phase == 'CENTERS', center_rows=pinned)
            plan['settings'] = config
            plan['phase'] = phase
            result.append((pair, key, recipe, plan))
    if not result: raise ValueError('Prepare the current finger first.')
    return result


def joint_bones(obj, rig, chain, recipe, joint, *, index=None, config=None):
    if config is not None and getattr(config, 'sync_bones', False):
        if index is None: raise ValueError('A fixed joint index is required for bone synchronization.')
        match = finger_chain.joint_targets(obj, rig, recipe, config)[index]
        return match['A'], match['B'], match['offset']
    from .finger_bones import _head
    path = [obj.matrix_world @ Vector(p) for p in recipe.get('path', (recipe['root'], recipe['tip']))]
    # Both the marker and bone are projected into the same topology path below.
    length = sum((z-a).length for a, z in zip(path, path[1:]))
    options = sorted((abs(definition.project_distance(rig.matrix_world @ _head(b), path)/length-joint.position), i)
                     for i, b in enumerate(chain) if i)
    if not options or options[0][0] > .12 or len(options) > 1 and options[1][0] < options[0][0]+.025:
        raise ValueError('Joint marker has no unique nearby bone junction; move it to the intended joint.')
    i = options[0][1]
    return chain[i-1].name, chain[i].name, options[0][0]*length


def weight_rows(plan):
    slots = {vi: (plan.get('moves', {}).get(i, t), column) for i, (row, t) in enumerate(zip(plan['rows'], plan['positions'])) for column, vi in enumerate(row)}
    for ring in plan['rings']:
        for column, vi in enumerate(ring['vertex_ids']): slots[vi] = ring.get('times', [ring['t']]*len(ring['vertex_ids']))[column], column
    return slots


def weight_plan(obj, mesh, entries, context, force=False):
    """Only existing deform groups contribute to the reserved budget."""
    _, rig = targets.owner(context)
    candidates = targets.index(rig)
    by_digit, names, output, labels = {}, {g.name: g.index for g in obj.vertex_groups}, {}, {}
    missing = []
    deform = {b.name for b in rig.data.bones if b.use_deform}
    for pair, key, recipe, plan in entries:
        config = plan.get('settings', pair)
        if plan.get('phase') == 'CENTERS': continue
        if not config.auto_weight and not force: continue
        if pair.name not in by_digit: by_digit[pair.name] = targets.pair(obj, rig, pair.name, candidates)
        chain = by_digit[pair.name][key]
        for i, joint in enumerate(config.joints):
            a, b, offset = joint_bones(obj, rig, chain, recipe, joint, index=i, config=config)
            for n in (a, b):
                if n not in names: names[n] = len(names); missing.append(n)
            if any(obj.vertex_groups.get(n) and obj.vertex_groups[n].lock_weight for n in (a, b)): raise ValueError(f'{key}: target group is locked.')
            if not 0 <= joint.tip_weight <= joint.center_weight <= joint.root_weight <= 1:
                raise ValueError('Use decreasing root-to-tip ratios between 0 and 1.')
            triplet = sorted((r for r in plan['rings'] if r['joint'] == i), key=lambda r: r['flank'])
            if len(triplet) != 3: raise ValueError('A joint requires exactly three reference rings for weights.')
            values = (joint.root_weight, joint.center_weight, joint.tip_weight)
            labels[key+':'+str(i)] = {'A': a, 'B': b, 'offset': offset}
            for vi, (t, column) in weight_rows(plan).items():
                positions = [r.get('times', [r['t']]*len(r['vertex_ids']))[column] for r in triplet]
                if t < positions[0]-1e-6 or t > positions[2]+1e-6: continue
                if vi in output: raise ValueError('Two weight regions overlap; no order-dependent overwriting is allowed.')
                k = 0 if t <= positions[1] else 1
                f = max(0., min(1., (t-positions[k])/(positions[k+1]-positions[k])))
                ratio = values[k]+(values[k+1]-values[k])*f
                reserved = sum(g.weight for g in mesh.vertices[vi].groups if obj.vertex_groups[g.group].name in deform-{a, b})
                if not math.isfinite(reserved) or reserved > 1+1e-6 or reserved < 0:
                    raise ValueError(f'Vertex {vi}: preserved deform weights leave no valid budget.')
                remaining = max(0., 1-reserved)
                output[vi] = {names[a]: remaining*ratio, names[b]: remaining*(1-ratio)}
    return output, labels, missing


def write_weights(obj, mesh, weights, missing=()):
    names = list(obj.vertex_groups.keys())+list(missing)
    staging = obj.copy()
    try:
        staging.data = mesh
        # Blender 5.2 keeps the group-name table with the mesh. A staged source
        # may predate groups created by a previous joint operation. Append in
        # current order before indexing; never reinterpret existing indices.
        existing = list(staging.vertex_groups.keys())
        if names[:len(existing)] != existing:
            raise ValueError('The source vertex-group table changed; release and prepare again.')
        for name in names[len(existing):]: staging.vertex_groups.new(name=name)
        for vi, values in weights.items():
            for group, value in values.items(): staging.vertex_groups[group].add([vi], value, 'REPLACE')
        mesh.update()
    finally: bpy.data.objects.remove(staging)


def _bank_backup(obj):
    b = obj.character_designer_finger_bank
    return ({p: getattr(b, p) for p in ('survey', 'active', 'status', 'needs_recheck')},
            {slot.name: ({p: getattr(slot.guide, p) for p in bank.FIELDS}, slot.error, slot.bones) for slot in b.slots})


def _restore_bank(obj, backup):
    b = obj.character_designer_finger_bank
    for p, v in backup[0].items(): setattr(b, p, v)
    for key, (guide, error, bones) in backup[1].items():
        slot = b.slots[key]
        for p, v in guide.items(): setattr(slot.guide, p, v)
        slot.error, slot.bones = error, bones


def _check_confirmed_bones(context, entries):
    """Step 2 verifies the live Step 1 result without moving any rest bones."""
    from .finger_bones import _bone_collection, _head, _tail
    plan = finger_chain.plans(context, entries)
    bones = _bone_collection(plan['rig'])
    for chain in plan['chains']:
        for name, head, tail in zip(chain['names'], chain['nodes'], chain['nodes'][1:]):
            bone = bones[name]
            if (_head(bone)-Vector(head)).length > finger_chain.EPS or (_tail(bone)-Vector(tail)).length > finger_chain.EPS:
                raise ValueError('Confirmed bone joints no longer match the center loops; complete Step 1 again.')


def _saved_ring(ring, plan, source):
    item = {k: v for k, v in ring.items() if k not in {'points', 'display_points', 'original_ring'}}
    points = ring.get('points', ring.get('cage_points'))
    if points is None:
        points = [layout._sample(source, plan['rows'], plan['positions'], t)[0][j]
                  for j, t in enumerate(ring.get('times', [ring['t']]*len(plan['rows'][0])))]
    item['cage_points'] = [list(p) for p in points]
    return item


def apply(context, *, weights_only=False, centers_only=False, supports_only=False, after_commit=None):
    started = time.perf_counter()
    if sum(map(bool, (weights_only, centers_only, supports_only))) > 1:
        raise ValueError('Choose one operation: centers, support loops, or weights.')
    obj = layout._edit(context)
    owner, s, active = settings(context)
    if obj != owner: raise ValueError('Return to this Setup mesh.')
    check_source(obj, s)
    committed = json.loads(s.results or '{}')
    phase = committed_phase(active, s)
    if weights_only and any(committed.get(key, {}).get('subdivision_dirty') for key in json.loads(active.recipe or '{}')):
        raise ValueError('Added or removed loops changed the subdivided surface; Update Support Rings before updating only weights.')
    if centers_only and phase == 'FINAL':
        raise ValueError('Step 2 is finalized; Undo Step 2 to reposition centers, or Release and Prepare to start from the current mesh.')
    if centers_only and active.applied and any(committed.get(key, {}).get('layout_schema') != LAYOUT_SCHEMA
                                               for key in json.loads(active.recipe or '{}')):
        raise ValueError('This finger has an older generated layout. Release Prepared Results to keep its current mesh, bones and weights, then Prepare and complete Step 1.')
    if weights_only and phase != 'FINAL':
        raise ValueError('Complete Step 2: Add Support Loops before updating only weights.')
    entries = plans(context, all_applied=True, centers_only=centers_only,
                    supports_only=supports_only or weights_only)
    active_entries = [e for e in entries if e[0] == active]
    if supports_only and active.sync_bones: _check_confirmed_bones(context, active_entries)
    # Only the confirmed active pair moves. Other pairs use their committed
    # geometry/weights and must not apply drafts from their current sliders.
    rig_plan = (finger_chain.plans(context, active_entries)
                if not weights_only and not supports_only and active.sync_bones else None)
    rig_backup = finger_chain.snapshot(context, rig_plan) if rig_plan else None
    if not weights_only and not active.auto_weight and any(
            e[0] == active and committed.get(e[1], {}).get('phase') != 'CENTERS' and
            committed.get(e[1], {}).get('parameters', {}).get('auto_weight') for e in entries):
        raise ValueError('This pair already has generated local weights. Keep Weight After Rings enabled, or release and prepare again to preserve them as the new source; topology-only must not reset them.')
    old, backup = obj.data, _bank_backup(obj)
    old_state = (s.signature, s.results, active.applied, active.labels, active.recipe, s.get('topology', ''))
    created_groups = []
    active_group = obj.vertex_groups.active_index
    if weights_only and not active.applied: raise ValueError('Generate the joint rings before updating only weights.')
    if weights_only:
        saved = json.loads(s.results)
        for pair, key, recipe, plan in entries:
            if key not in saved: raise ValueError('Generated ring mapping is missing.')
            if pair == active:
                # Position/spacing changes are topology edits, never a weight-only operation.
                if saved[key]['geometry'] != geometry_parameters(pair): raise ValueError('Ring positions changed; Generate / Update Rings first.')
            plan.update(saved[key]['plan'])
        new = old.copy()
    else: new = layout.stage(s.source, [e[3] for e in entries])
    try:
        if not weights_only:
            from . import finger_subdivision
            finger_subdivision.verify_staged(obj, new, [e[3] for e in entries])
        weight_entries = [e for e in entries if e[3]['phase'] == 'FINAL' and not e[3].get('frozen')
                          and (not weights_only or e[0] == active)]
        if weights_only or any(e[3]['settings'].auto_weight for e in weight_entries):
            weights, labels, missing = weight_plan(obj, new, weight_entries, context, force=weights_only)
            before = {v.index: {g.group: g.weight for g in v.groups} for v in new.vertices}
            write_weights(obj, new, weights, missing)
            for v in new.vertices:
                expected = dict(before[v.index]); expected.update(weights.get(v.index, {}))
                actual = {g.group: g.weight for g in v.groups}
                if any(abs(actual.get(k, 0)-expected.get(k, 0)) > 1e-6 for k in expected.keys() | actual.keys()):
                    raise ValueError('Local weight verification failed; no data was committed.')
        else: weights, labels, missing = {}, {}, []
        results = {}
        for pair, key, recipe, plan in entries:
            if plan.get('frozen'):
                results[key] = committed[key]
                continue
            stored_parameters = parameters(plan['settings'])
            if weights_only and pair == active: stored_parameters['auto_weight'] = True
            results[key] = {'layout_schema': LAYOUT_SCHEMA, 'phase': plan['phase'],
                'flip_bend': committed.get(key, {}).get('flip_bend', recipe['flip_bend']) if weights_only else recipe['flip_bend'],
                'center_rows': plan.get('center_rows', committed.get(key, {}).get('center_rows', {})),
                'center_confirmation': committed.get(key, {}).get('center_confirmation', {}),
                'geometry': geometry_parameters(plan['settings']), 'parameters': stored_parameters, 'plan': {
                'rows': plan['rows'], 'positions': plan['positions'], 'moves': plan.get('moves', {}),
                'rings': [_saved_ring(r, plan, s.source) for r in plan['rings']]}}
            if plan.get('subdivision'): results[key]['plan']['subdivision'] = plan['subdivision']
            if (weights_only or plan.get('preserve_geometry')) and committed.get(key, {}).get('adopted'):
                results[key]['adopted'] = True
        bpy.ops.object.mode_set(mode='OBJECT')
        for name in missing:
            created_groups.append(obj.vertex_groups.new(name=name).name)
        obj.data = new
        bpy.ops.object.mode_set(mode='EDIT')
        if rig_plan: finger_chain.apply(context, rig_plan)
        if after_commit: after_commit()
        if not weights_only:
            bank.recheck(context, own_layout=True, updated_keys={e[1] for e in entries if not e[3].get('frozen')})
            for _, key, _, _ in entries:
                if obj.character_designer_finger_bank.slots[key].error: raise ValueError(key+': '+obj.character_designer_finger_bank.slots[key].error)
        if rig_plan: finger_chain.commit(obj, rig_plan['rig'], rig_plan['keys'])
        if not weights_only and not supports_only:
            # Bone commit refreshes the expected rest signature. Record that
            # accepted binding, never the pre-write recipe, for Step 2's gate.
            recipes = json.loads(active.recipe)
            for _, key, _, plan in active_entries:
                results[key]['center_confirmation'] = {
                    'parameters': _center_parameters(plan['settings']),
                    'identity': _center_identity(recipes[key])}
        s.signature, s.results, active.applied = layout.fingerprint(obj), json.dumps(results), True
        from . import finger_workflow_rebase
        s['topology'] = finger_workflow_rebase.topology(obj)
        if not centers_only: active.labels = json.dumps(labels)
        new.name = old.name
        if SOURCE_TAG in new: del new[SOURCE_TAG]
        new[RESULT_TAG] = True
        added = len(new.vertices)-len(old.vertices)
        if old.users == 0 and old.get(RESULT_TAG): bpy.data.meshes.remove(old)
        return {'added': added, 'weighted': len(weights),
                'synced': sum(len(c['nodes'])-2 for c in rig_plan['chains']) if rig_plan else 0,
                'phase': 'CENTERS' if centers_only else 'FINAL',
                'seconds': time.perf_counter()-started}
    except Exception:
        if obj.mode == 'EDIT': bpy.ops.object.mode_set(mode='OBJECT')
        obj.data = old
        for name in reversed(created_groups): obj.vertex_groups.remove(obj.vertex_groups[name])
        bpy.ops.object.mode_set(mode='EDIT')
        if rig_backup: finger_chain.restore(context, rig_plan, rig_backup)
        _restore_bank(obj, backup)
        s.signature, s.results, active.applied, active.labels, active.recipe, s['topology'] = old_state
        raise
    finally:
        obj.vertex_groups.active_index = active_group
        if new.users == 0: bpy.data.meshes.remove(new)


def geometry_parameters(pair):
    return {'fill_between': finger_joint_plan.fill_between(pair),
            'sync_bones': bool(getattr(pair, 'sync_bones', False)),
            'joints': [[j.position, j.width, j.inner_spacing, j.outer_spacing] for j in pair.joints]}


def parameters(pair):
    return {'between': pair.between, 'fill_between': finger_joint_plan.fill_between(pair),
            'sync_bones': bool(getattr(pair, 'sync_bones', False)), 'auto_weight': pair.auto_weight,
            'joints': [{p: getattr(j, p) for p in ('position', 'width', 'inner_spacing', 'outer_spacing', 'root_weight', 'center_weight', 'tip_weight')} for j in pair.joints]}


def release(context):
    obj, s = state(context)
    source = s.source
    s.source = None
    s.signature = s.bodies = s.results = ''
    if 'topology' in s: del s['topology']
    for pair in s.pairs: pair.recipe, pair.applied = '', False
    if source and source.users == 0 and source.get(SOURCE_TAG): bpy.data.meshes.remove(source)
