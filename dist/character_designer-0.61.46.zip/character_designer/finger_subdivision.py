"""Place joint loops on the evaluated Catmull-Clark surface.

The solver changes only the scalar positions already supported by ring-slide.
Blender supplies the subdivision response; a bounded cache reuses that linear
response while the immutable rails and insertion topology remain unchanged.
Point attributes identify descendants of a loop without relying on evaluated
vertex indices. Every write must also verify the complete staged candidate.
"""
from bisect import bisect_right
from collections import OrderedDict
from contextlib import contextmanager

import bpy
import numpy as np
from mathutils import Vector

from . import finger_layout as layout, finger_ring_slide as slide

_CACHE = OrderedDict()
_CACHE_LIMIT = 12
_TAG = 'cd_joint_subdivision_probe'
_SETTINGS = ('subdivision_type', 'levels', 'quality', 'uv_smooth',
             'boundary_smooth', 'use_limit_surface', 'use_creases')
TOLERANCE = 2e-5
# Blender pose/rest matrices are float32. Hierarchy evaluation on a neutral rig
# can differ by several millionths; inspect local skinning, not exact equality.
POSE_MATRIX_TOLERANCE = 1e-5


class PlacementError(ValueError):
    """This row allocation is infeasible; another unconfirmed row may work."""


def _armature_flags(obj, modifier):
    rig = modifier.object
    if rig is None or rig.type != 'ARMATURE':
        raise ValueError(f'Armature modifier "{modifier.name}" needs a valid rig for final-surface joint placement.')
    if not modifier.use_vertex_groups or modifier.use_bone_envelopes or modifier.use_multi_modifier:
        raise ValueError(f'Armature modifier "{modifier.name}" requires vertex-group deformation with envelopes and Multi Modifier disabled for final-surface joint placement.')
    if modifier.vertex_group and obj.vertex_groups.get(modifier.vertex_group) is None:
        raise ValueError(f'Armature modifier "{modifier.name}" has an unresolved vertex-group mask.')
    return rig


def configuration(obj):
    """Return an explicit supported viewport stack, or refuse an ambiguous one."""
    enabled = [m for m in obj.modifiers if m.show_viewport]
    subdivisions = [m for m in enabled if m.type == 'SUBSURF' and m.levels > 0]
    if not subdivisions:
        return None
    if len(subdivisions) != 1:
        raise ValueError('Final-surface joint placement requires one enabled Subdivision Surface modifier.')
    modifier = subdivisions[0]
    if modifier.subdivision_type != 'CATMULL_CLARK' or modifier.levels not in (1, 2):
        raise ValueError('Final-surface joint placement supports Catmull-Clark viewport levels 1 and 2.')
    if not modifier.show_in_editmode:
        raise ValueError('Enable Subdivision Surface in Edit Mode to place joints on its visible final surface.')
    for other in enabled:
        if other == modifier or other.type == 'SUBSURF' and other.levels == 0:
            continue
        if other.type == 'ARMATURE':
            _armature_flags(obj, other)
            continue
        raise ValueError(f'Final-surface joint placement cannot ignore enabled modifier "{other.name}". Use a neutral armature and a single Catmull-Clark modifier.')
    keys = obj.data.shape_keys
    if keys and not keys.use_relative:
        raise ValueError('Final-surface joint placement requires relative Shape Keys; absolute Shape Keys are not supported.')
    return {name: getattr(modifier, name) for name in _SETTINGS if hasattr(modifier, name)}


def _influence_region(mesh, vertices, config):
    region = set(vertices)
    if not region or min(region) < 0 or max(region) >= len(mesh.vertices):
        raise ValueError('The subdivision influence check has invalid finger vertices.')
    faces = [set(face.vertices) for face in mesh.polygons]
    frontier = set(region)
    for _ in range(config['levels']+1):
        reached = set()
        for face in faces:
            if face & frontier:
                reached.update(face)
        frontier = reached-region
        region.update(frontier)
        if not frontier:
            break
    return region


def _neutral_armature_region(obj, mesh, region):
    """Prove neutrality only for deform bones with actual local skin weights."""
    modifiers = [modifier for modifier in obj.modifiers if modifier.show_viewport and modifier.type == 'ARMATURE']
    graph = None
    for modifier in modifiers:
        rig = _armature_flags(obj, modifier)
        if rig.data.pose_position == 'REST':
            continue
        deform = {group.index: rig.data.bones[group.name] for group in obj.vertex_groups
                  if group.name in rig.data.bones and rig.data.bones[group.name].use_deform}
        mask = obj.vertex_groups.get(modifier.vertex_group) if modifier.vertex_group else None
        influencing = {}
        for vi in region:
            weights = {g.group: g.weight for g in mesh.vertices[vi].groups}
            if mask is not None:
                amount = weights.get(mask.index, 0.)
                if modifier.invert_vertex_group:
                    amount = 1.-amount
                if amount <= 0.:
                    continue
            for group, weight in weights.items():
                if weight > 0. and group in deform:
                    influencing.setdefault(deform[group].name, []).append(vi)
        if not influencing:
            continue
        if graph is None:
            graph = bpy.context.evaluated_depsgraph_get()
        evaluated = rig.evaluated_get(graph)
        try:
            mesh_to_rig = evaluated.matrix_world.inverted() @ obj.matrix_world
            rig_to_mesh = mesh_to_rig.inverted()
        except ValueError:
            raise ValueError('Armature or mesh has a singular transform; final-surface joint placement cannot certify local skinning.') from None
        points = [mesh.vertices[i].co for i in region]
        span = Vector(tuple(max(p[axis] for p in points)-min(p[axis] for p in points) for axis in range(3))).length
        magnitude = max(1., max(abs(component) for point in points for component in point))
        roundoff = 64.*np.finfo(np.float32).eps*magnitude
        tolerance = max(roundoff, span*POSE_MATRIX_TOLERANCE)
        for name, vertices in influencing.items():
            bone, pose = rig.data.bones[name], evaluated.pose.bones.get(name)
            if bone.bbone_segments > 1:
                raise ValueError(f'Influencing B-Bone "{name}" has multiple segments; its local subdivision deformation cannot be certified.')
            if pose is None:
                raise ValueError(f'Influencing deform bone "{name}" has no evaluated pose.')
            transform = rig_to_mesh @ pose.matrix @ bone.matrix_local.inverted() @ mesh_to_rig
            error = max(abs(transform[i][j]-(1. if i == j else 0.)) for i in range(4) for j in range(4))
            if error > POSE_MATRIX_TOLERANCE or any((transform @ mesh.vertices[vi].co-mesh.vertices[vi].co).length > tolerance for vi in vertices):
                raise ValueError(f'Armature bone "{name}" deforms this finger or its subdivision neighbours. Use a locally neutral pose before positioning final-surface joints; unrelated bones may stay posed.')


def _neutral_shape_region(obj, mesh, region):
    """Allow remote correctives, but prove this subdivision stencil is neutral.

    The probe evaluates Basis geometry. A live relative key may be nonzero when
    its effective displacement is zero throughout the finger and a conservative
    face-neighbour halo. Relative-key chains and vertex-group masks are honoured;
    unrelated corrective values and data are never changed by this check.
    """
    live = obj.data.shape_keys
    if not live:
        return
    active = [key for key in live.key_blocks
              if key != live.reference_key and not key.mute and key.value != 0.]
    if not active:
        return
    keys = mesh.shape_keys
    if not keys or not keys.use_relative:
        raise ValueError('The relative Shape Keys needed to verify this finger are missing from its source.')
    for current in active:
        key = keys.key_blocks.get(current.name)
        relative = keys.key_blocks.get(current.relative_key.name) if current.relative_key else None
        if key is None or relative is None or len(key.data) != len(mesh.vertices) or len(relative.data) != len(mesh.vertices):
            raise ValueError(f'Shape Keys correspondence for "{current.name}" changed; refresh this finger source.')
        group = obj.vertex_groups.get(current.vertex_group) if current.vertex_group else None
        for vi in region:
            influence = float(current.value)
            if group is not None:
                influence *= next((g.weight for g in mesh.vertices[vi].groups if g.group == group.index), 0.)
            if influence == 0.:
                continue
            if ((key.data[vi].co-relative.data[vi].co)*influence).length > 1e-7:
                raise ValueError(f'Shape Keys: "{current.name}" deforms this finger or its subdivision neighbours. Use a locally neutral shape before positioning final-surface joints; remote corrective values can stay enabled.')


def _neutral_region(obj, mesh, vertices, config):
    region = _influence_region(mesh, vertices, config)
    _neutral_armature_region(obj, mesh, region)
    _neutral_shape_region(obj, mesh, region)


def _creases(mesh):
    # A crease changes the position stencil. Refuse it explicitly until the
    # geometry-only probe also transports split-edge/vertex crease attributes.
    for name in ('crease_edge', 'crease_vert'):
        attr = mesh.attributes.get(name)
        if attr and any(abs(item.value) > 1e-8 for item in attr.data):
            raise ValueError('Final-surface joint placement does not yet support nonzero subdivision creases. No cage-only fallback was applied.')


def _geometry(source, plan):
    """Reproduce ring-slide topology without copying keys, UVs or weights."""
    coordinates = [tuple(v.co) for v in source.vertices]
    rows = plan['rows']
    for row, t in plan['moves'].items():
        points = layout._sample(source, rows, plan['positions'], t)[0]
        for vi, co in zip(rows[row], points):
            coordinates[vi] = tuple(co)
    groups = []
    for ring in plan['rings']:
        if 'reuse' in ring:
            indices = list(rows[ring['reuse']])
            for vi, co in zip(indices, ring['points']):
                coordinates[vi] = tuple(co)
        else:
            indices = list(range(len(coordinates), len(coordinates)+len(ring['points'])))
            coordinates.extend(tuple(p) for p in ring['points'])
        groups.append(indices)
    by_ring = {id(ring): indices for ring, indices in zip(plan['rings'], groups)}
    inserted = {}
    for ring in slide.split_plan(plan, source)['rings']:
        inserted.setdefault(ring['band'], []).append(ring['original_ring'])
    faces = [tuple(p.vertices) for p in source.polygons]
    faces_by_vertices = {frozenset(face): i for i, face in enumerate(faces)}
    removed, added = set(), []
    width = len(rows[0])
    for band, rings in inserted.items():
        rings.sort(key=lambda r: r['t'])
        strip = [rows[band]]+[by_ring[id(r)] for r in rings]+[rows[band+1]]
        for j in range(width):
            k = (j+1) % width
            quad = (rows[band][j], rows[band][k], rows[band+1][k], rows[band+1][j])
            index = faces_by_vertices.get(frozenset(quad))
            if index is None:
                raise ValueError('The subdivision probe cannot identify a complete source quad strip.')
            removed.add(index)
            original = faces[index]
            forward = any(original[i] == quad[0] and original[(i+1) % 4] == quad[1]
                          for i in range(4))
            for a, b in zip(strip, strip[1:]):
                face = (a[j], a[k], b[k], b[j])
                added.append(face if forward else tuple(reversed(face)))
    return coordinates, [f for i, f in enumerate(faces) if i not in removed]+added, groups


def _loop_order(mesh, indices):
    indices = set(indices)
    neighbours = {i: [] for i in indices}
    for edge in mesh.edges:
        a, b = edge.vertices
        if a in indices and b in indices:
            neighbours[a].append(b)
            neighbours[b].append(a)
    if not indices or any(len(items) != 2 for items in neighbours.values()):
        raise ValueError('Subdivision did not retain an unambiguous closed joint loop.')
    start = min(indices)
    order, previous, current = [start], None, start
    while True:
        options = sorted(neighbours[current])
        following = next(i for i in options if i != previous)
        if following == start:
            break
        if following in order:
            raise ValueError('Subdivision loop correspondence is not a single closed loop.')
        order.append(following)
        previous, current = current, following
    if len(order) != len(indices):
        raise ValueError('Subdivision loop correspondence contains disconnected pieces.')
    return order


class _Probe:
    def __init__(self, coordinates, faces, groups, config):
        self.scene = self.obj = self.mesh = None
        self.groups, self.config, self.orders = groups, config, None
        try:
            self.scene = bpy.data.scenes.new('.CD subdivision probe')
            self.mesh = bpy.data.meshes.new('.CD subdivision probe')
            self.mesh.from_pydata(coordinates, [], faces)
            self.mesh.update()
            tag = self.mesh.attributes.new(_TAG, 'FLOAT_VECTOR', 'POINT')
            for code, indices in enumerate(groups, 1):
                for vi in indices:
                    tag.data[vi].vector = (code, code*code, code*code*code)
            self.obj = bpy.data.objects.new('.CD subdivision probe', self.mesh)
            self.scene.collection.objects.link(self.obj)
            modifier = self.obj.modifiers.new('Target Subdivision', 'SUBSURF')
            for name, value in config.items():
                setattr(modifier, name, value)
        except Exception:
            self.close()
            raise

    def close(self):
        if self.obj is not None:
            bpy.data.objects.remove(self.obj, do_unlink=True)
            self.obj = None
        if self.mesh is not None:
            bpy.data.meshes.remove(self.mesh)
            self.mesh = None
        if self.scene is not None:
            bpy.data.scenes.remove(self.scene)
            self.scene = None

    def evaluate(self, coordinates=None):
        if coordinates is not None:
            self.mesh.vertices.foreach_set('co', np.asarray(coordinates, dtype=float).reshape(-1))
            self.mesh.update()
        with bpy.context.temp_override(scene=self.scene, view_layer=self.scene.view_layers[0]):
            graph = bpy.context.evaluated_depsgraph_get()
            graph.update()
            evaluated = self.obj.evaluated_get(graph)
            mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=graph)
            try:
                if self.orders is None:
                    tag = mesh.attributes.get(_TAG)
                    if not tag:
                        raise ValueError('Subdivision discarded the joint-loop correspondence attribute.')
                    buckets = [[] for _ in self.groups]
                    for vi, item in enumerate(tag.data):
                        value = tuple(item.vector)
                        code = round(value[0])
                        if 1 <= code <= len(buckets) and value == (code, code*code, code*code*code):
                            buckets[code-1].append(vi)
                    self.orders = []
                    for original, indices in zip(self.groups, buckets):
                        if len(indices) != len(original)*(2**self.config['levels']):
                            raise ValueError('Subdivision joint-loop correspondence has an unexpected number of vertices.')
                        self.orders.append(_loop_order(mesh, indices))
                loops = [np.asarray([tuple(mesh.vertices[i].co) for i in order], dtype=float) for order in self.orders]
                return np.asarray(loops) if len({len(loop) for loop in loops}) == 1 else loops
            finally:
                evaluated.to_mesh_clear()


@contextmanager
def _probe(coordinates, faces, groups, config):
    probe = _Probe(coordinates, faces, groups, config)
    try:
        yield probe
    finally:
        probe.close()


def _plane(obj, recipe, fraction):
    path = [obj.matrix_world @ Vector(p) for p in recipe.get('path', (recipe['root'], recipe['tip']))]
    lengths = [(b-a).length for a, b in zip(path, path[1:])]
    total = sum(lengths)
    if total <= layout.EPS:
        raise ValueError('The subdivision target path has no length.')
    distance = fraction*total
    for i, length in enumerate(lengths):
        if length <= layout.EPS:
            continue
        if distance <= length or i == len(lengths)-1:
            return path[i].lerp(path[i+1], distance/length), (path[i+1]-path[i])/length, total
        distance -= length
    raise ValueError('The subdivision target has no usable path segment.')


def _bands(plan):
    ts = plan['positions']
    source_bands = tuple(tuple(max(0, min(bisect_right(ts, t)-1, len(ts)-2))
                               for t in r.get('times', [r['t']]*len(plan['rows'][0])))
                         for r in plan['rings'])
    positions = [plan['moves'].get(i, t) for i, t in enumerate(ts)]
    insertion = tuple(None if 'reuse' in r else max(0, min(bisect_right(positions, r['t'])-1, len(ts)-2))
                      for r in plan['rings'])
    return source_bands, insertion


def _set_values(source, plan, values):
    ts, rows = plan['positions'], plan['rows']
    plan['moves'] = {}
    for ring, value in zip(plan['rings'], values):
        offsets = ring['_subdivision_offsets']
        times = [float(value)+offset for offset in offsets]
        if min(times) <= ts[0]+layout.EPS or max(times) >= ts[-1]-layout.EPS:
            raise PlacementError('Subdivision compensation would cross the protected root/tip. Move the marker inward or reduce support spacing.')
        ring['t'] = float(value)
        if 'times' in ring:
            ring['times'] = times
        ring['points'], ring['band'], ring['fraction'] = layout._sample(source, rows, ts, value)
        if 'times' in ring:
            ring['points'] = [layout._sample(source, rows, ts, t)[0][j] for j, t in enumerate(times)]
        if 'reuse' in ring:
            row = ring['reuse']
            changed = any((point-source.vertices[vi].co).length > layout.EPS
                          for point, vi in zip(ring['points'], rows[row]))
            if row in plan['protected_rows'] and changed:
                raise PlacementError('Subdivision compensation would move a protected source row.')
            if changed:
                plan['moves'][row] = float(value)
            ring['allocation'] = 'MOVED' if row in plan['moves'] else 'REUSED'
    positions = [plan['moves'].get(i, t) for i, t in enumerate(ts)]
    if any(b-a <= layout.EPS for a, b in zip(positions, positions[1:])):
        raise PlacementError('Subdivision compensation would cross an authored ring. Move the marker or reduce support spacing.')
    if any(b['t']-a['t'] <= layout.EPS for a, b in zip(plan['rings'], plan['rings'][1:])):
        raise PlacementError('Subdivision compensation would cross another target ring. Increase their separation.')
    slide.split_plan(plan, source)
    plan['allocation_counts'] = {kind: sum(r['allocation'] == kind for r in plan['rings'])
                                 for kind in ('REUSED', 'MOVED', 'NEW')}


def _key(source, plan, config):
    # The immutable source may be replaced/rebased without reloading the add-on.
    # Actual geometry and topology participate; pointers alone are insufficient.
    geometry = (tuple(tuple(v.co) for v in source.vertices),
                tuple(tuple(p.vertices) for p in source.polygons))
    return (hash(geometry), tuple(sorted(config.items())), tuple(map(tuple, plan['rows'])),
            tuple(plan['positions']), tuple((r.get('reuse'), r['kind'], r['joint'], r['flank'],
                                            tuple(r['_subdivision_offsets'])) for r in plan['rings']), _bands(plan))


def _response(source, plan, config):
    key = _key(source, plan, config)
    if key in _CACHE:
        _CACHE.move_to_end(key)
        return _CACHE[key]
    values = np.asarray([r['t'] for r in plan['rings']], dtype=float)
    coordinates, faces, groups = _geometry(source, plan)
    source_bands, _ = _bands(plan)
    derivatives = []
    with _probe(coordinates, faces, groups, config) as probe:
        base = probe.evaluate()
        for i, ring in enumerate(plan['rings']):
            times = ring.get('times', [ring['t']]*len(plan['rows'][0]))
            plus = min(plan['positions'][band+1]-t for band, t in zip(source_bands[i], times))
            minus = min(t-plan['positions'][band] for band, t in zip(source_bands[i], times))
            step = min(.025, plus*.4) if plus >= minus else -min(.025, minus*.4)
            if abs(step) < 1e-5:
                raise PlacementError('The subdivision target lies too close to a source-rail corner to solve reliably.')
            changed = list(coordinates)
            for column, vi in enumerate(groups[i]):
                t = times[column]+step
                changed[vi] = tuple(layout._sample(source, plan['rows'], plan['positions'], t)[0][column])
            derivatives.append((probe.evaluate(changed)-base)/step)
    result = (values, base, np.asarray(derivatives))
    _CACHE[key] = result
    while len(_CACHE) > _CACHE_LIMIT:
        _CACHE.popitem(last=False)
    return result


def compensate(obj, source, recipe, plan):
    """Keep desired target_t separate from the compensated cage t/times."""
    config = configuration(obj)
    if config is None:
        return plan
    _neutral_region(obj, source, (vi for row in plan['rows'] for vi in row), config)
    _creases(source)
    for ring in plan['rings']:
        ring['target_t'] = ring.get('target_t', ring['t'])
        ring['_subdivision_offsets'] = [t-ring['t'] for t in ring.get('times', [ring['t']]*len(plan['rows'][0]))]
    planes = [_plane(obj, recipe, ring['target_t']) for ring in plan['rings']]
    linear = np.asarray(obj.matrix_world.to_3x3(), dtype=float)
    translation = np.asarray(obj.matrix_world.translation, dtype=float)
    for _ in range(5):
        bands = _bands(plan)
        values, base, derivatives = _response(source, plan, config)
        means = base.mean(axis=1) @ linear.T+translation
        changes = derivatives.mean(axis=2) @ linear.T
        jacobian = np.asarray([[np.dot(changes[j, i], normal) for j in range(len(values))]
                               for i, (_, normal, _) in enumerate(planes)])
        residual = np.asarray([np.dot(np.asarray(point)-mean, normal)
                               for mean, (point, normal, _) in zip(means, planes)])
        try:
            if np.linalg.cond(jacobian) > 1e8:
                raise np.linalg.LinAlgError()
            solved = values+np.linalg.solve(jacobian, residual)
        except np.linalg.LinAlgError:
            raise PlacementError('Subdivision joint positions cannot be solved uniquely on these surface rails.') from None
        _set_values(source, plan, solved)
        if _bands(plan) != bands:
            continue
        displayed = base+np.tensordot(solved-values, derivatives, axes=(0, 0))
        break
    else:
        raise PlacementError('Subdivision compensation crossed too many source-rail corners; move the marker to a stable span.')
    plan['subdivision'] = dict(config=config, tolerance=TOLERANCE, planes=[])
    for ring, points, (point, normal, length) in zip(plan['rings'], displayed, planes):
        ring['display_points'] = [Vector(p) for p in points]
        plan['subdivision']['planes'].append(dict(point=list(point), normal=list(normal), length=length))
        del ring['_subdivision_offsets']
    return plan


def verify_staged(obj, mesh, plans):
    """Evaluate all simultaneous changes once, before the mesh transaction commits."""
    # Frozen fingers belong to the newly adopted artist source. They are not
    # being edited by this transaction; only an explicit update of that finger
    # should correct its evaluated targets after the artist changes its stencil.
    selected = [plan for plan in plans if plan.get('subdivision') and not plan.get('frozen')]
    if not selected:
        return
    config = configuration(obj)
    if any(plan['subdivision']['config'] != config for plan in selected):
        raise ValueError('Subdivision settings changed after planning; refresh the joint preview.')
    _creases(mesh)
    rings = [ring for plan in selected for ring in plan['rings']]
    planes = [plane for plan in selected for plane in plan['subdivision']['planes']]
    groups = [ring['vertex_ids'] for ring in rings]
    _neutral_region(obj, mesh, (vi for group in groups for vi in group), config)
    with _probe([tuple(v.co) for v in mesh.vertices], [tuple(p.vertices) for p in mesh.polygons], groups, config) as probe:
        loops = probe.evaluate()
    for ring, points, plane in zip(rings, loops, planes):
        center = obj.matrix_world @ Vector(points.mean(axis=0))
        residual = abs((center-Vector(plane['point'])).dot(Vector(plane['normal'])))/plane['length']
        if residual > TOLERANCE:
            raise ValueError('The complete subdivided candidate differs from its joint targets; no mesh or bones were committed.')
        ring['display_points'] = [Vector(p) for p in points]
