"""Ordered existing-ring allocation for the shared finger joint workflow.

Only central joint rows may move. Center identity is independent of support
width/spacing; both flank supports are always newly inserted. Original rows are
never removed, and data transfer stays on the immutable captured surface rails.
"""
from functools import lru_cache
from bisect import bisect_right
from collections import OrderedDict
from itertools import product
import math

from mathutils import Vector

from . import finger_layout as layout, finger_ring_slide as slide

_CENTER_ASSIGNMENTS = OrderedDict()
_CENTER_ASSIGNMENT_LIMIT = 32
_CENTER_CANDIDATE_LIMIT = 25


def fill_between(pair):
    """Read the new toggle while preserving an older saved zero-between choice."""
    legacy = bool(getattr(pair, 'between', 1))
    if (hasattr(pair, 'fill_between') and hasattr(pair, 'is_property_set') and
            not pair.is_property_set('fill_between')):
        return legacy
    return bool(getattr(pair, 'fill_between', legacy))


def _allocate(ts, rings, protected):
    """Match every center to an old row, minimizing total ordered movement.

    A transition either keeps an old row or matches it to the next center.
    There is deliberately no new-center transition and no support input.
    """
    size, count = len(ts), len(rings)

    @lru_cache(maxsize=None)
    def visit(i, j, last):
        previous = ts[i-1] if last == 0 else rings[j-1]['t'] if last == 1 else -math.inf
        if i == size and j == count:
            return 0., ()
        choices = []
        if i < size and ts[i] > previous+layout.EPS:
            tail = visit(i+1, j, 0)
            if tail is not None: choices.append(tail)
        if (j < count and 0 < i < size-1 and rings[j]['t'] > previous+layout.EPS and
                (i not in protected or abs(ts[i]-rings[j]['t']) < layout.EPS)):
            tail = visit(i+1, j+1, 1)
            if tail is not None:
                choices.append((tail[0]+abs(ts[i]-rings[j]['t']), (i,)+tail[1]))
        if not choices: return None
        return min(choices)

    result = visit(0, 0, -1)
    if result is None:
        raise ValueError('Each joint center needs a safely movable existing internal ring. Move the joint markers or prepare a suitable source; no new center ring was added.')
    return result[1]


def _pinned_rows(ts, rings, protected, center_rows, *, surface_targets=False):
    """Validate saved center identities; spacing changes cannot choose new rows."""
    try:
        if not isinstance(center_rows, dict): raise ValueError()
        if any(not (type(key) is int or isinstance(key, str) and key.isdecimal() and str(int(key)) == key)
               for key in center_rows): raise ValueError()
        pinned = {int(key): value for key, value in center_rows.items()}
        if len(pinned) != len(center_rows) or set(pinned) != {r['joint'] for r in rings}:
            raise ValueError()
        assigned = [pinned[ring['joint']] for ring in rings]
        if any(not isinstance(row, int) or isinstance(row, bool) or not 0 < row < len(ts)-1 for row in assigned):
            raise ValueError()
        if len(set(assigned)) != len(assigned): raise ValueError()
        positions = list(ts)
        for ring, row in zip(rings, assigned):
            if surface_targets: continue
            if row in protected and abs(ts[row]-ring['t']) >= layout.EPS: raise ValueError()
            positions[row] = ts[row] if abs(ts[row]-ring['t']) < layout.EPS else ring['t']
        if any(b-a <= layout.EPS for a, b in zip(positions, positions[1:])): raise ValueError()
        if any(a >= b for a, b in zip(assigned, assigned[1:])): raise ValueError()
    except (ValueError, TypeError, OverflowError):
        raise ValueError('Confirmed center-ring identities no longer fit these markers. Confirm the joint centers again before adding supports.') from None
    return assigned


def _ring(source, rows, ts, t, kind, joint, flank, *, times=None):
    points, band, fraction = layout._sample(source, rows, ts, t)
    ring = dict(t=t, kind=kind, joint=joint, flank=flank, points=points,
                band=band, fraction=fraction, blocked=False)
    if times is not None:
        ring['times'] = times
        ring['points'] = [layout._sample(source, rows, ts, value)[0][i] for i, value in enumerate(times)]
    return ring


def _center_candidates(source, recipe, pair, config):
    """Bounded, ordered alternatives; a successful mapping is tried first on drag."""
    ts, rows = recipe['positions'], recipe['rings']
    targets = [float(joint.position) for joint in pair.joints]
    if not targets or any(not math.isfinite(t) for t in targets):
        raise ValueError('Prepare finite, ordered joint markers before positioning centers.')
    protected = set(recipe['protected_rows']) if recipe.get('protected_rows') is not None else slide.protected_rows(source, rows)
    key = (source.as_pointer(), tuple(map(tuple, rows)), tuple(ts), tuple(sorted(protected)),
           tuple(sorted(config.items())), tuple(bisect_right(ts, t) for t in targets))
    preferred = _CENTER_ASSIGNMENTS.get(key)
    if preferred is not None:
        _CENTER_ASSIGNMENTS.move_to_end(key)
    pools = []
    for target in targets:
        nearest = min(range(1, len(ts)-1), key=lambda i: (abs(ts[i]-target), i))
        pools.append([i for i in range(max(1, nearest-2), min(len(ts)-1, nearest+3)) if i not in protected])
    candidates = [indices for indices in product(*pools)
                  if all(a < b for a, b in zip(indices, indices[1:]))]
    candidates.sort(key=lambda indices: (sum(abs(ts[i]-target) for i, target in zip(indices, targets)), indices))
    # Keep the previous cage allocator as the first cold candidate when valid.
    # Its final-surface feasibility is still checked by the actual solver.
    try:
        original = tuple(_allocate(ts, [{'t': t} for t in targets], protected))
    except ValueError:
        original = None
    ordered = []
    for indices in (preferred, original, *candidates):
        if indices is not None and indices not in ordered:
            ordered.append(indices)
    return key, ordered[:_CENTER_CANDIDATE_LIMIT]


def build_plan(obj, source, recipe, pair, *, centers_only=False, center_rows=None):
    from . import finger_subdivision
    config = finger_subdivision.configuration(obj)
    if centers_only and config is not None:
        if center_rows is not None:
            plan = _build_plan(obj, source, recipe, pair, centers_only=True,
                               center_rows=center_rows, surface_targets=True)
            return finger_subdivision.compensate(obj, source, recipe, plan)
        key, candidates = _center_candidates(source, recipe, pair, config)
        failure = None
        for indices in candidates:
            plan = _build_plan(obj, source, recipe, pair, centers_only=True,
                               center_rows=dict(enumerate(indices)), surface_targets=True)
            try:
                plan = finger_subdivision.compensate(obj, source, recipe, plan)
            except finger_subdivision.PlacementError as exc:
                failure = exc
                continue
            _CENTER_ASSIGNMENTS[key] = indices
            _CENTER_ASSIGNMENTS.move_to_end(key)
            while len(_CENTER_ASSIGNMENTS) > _CENTER_ASSIGNMENT_LIMIT:
                _CENTER_ASSIGNMENTS.popitem(last=False)
            return plan
        if failure is not None:
            raise ValueError('No nearby ordered center-ring allocation can reach these subdivided targets without crossing or moving protected authored rows. Move the joint marker to a feasible surface span.') from failure
        raise ValueError('Each joint center needs a safely movable existing internal ring near its subdivided target; no new center ring was added.')
    plan = _build_plan(obj, source, recipe, pair, centers_only=centers_only, center_rows=center_rows)
    return finger_subdivision.compensate(obj, source, recipe, plan)


def _build_plan(obj, source, recipe, pair, *, centers_only=False, center_rows=None, surface_targets=False):
    rows, ts = recipe['rings'], recipe['positions']
    if (len(rows) < 3 or len(rows) != len(ts) or not rows[0] or
            any(len(row) != len(rows[0]) for row in rows) or
            any(not math.isfinite(t) for t in ts) or
            any(b-a <= layout.EPS for a, b in zip(ts, ts[1:]))):
        raise ValueError('Prepared surface rows are invalid; prepare this finger again.')
    ordered = list(enumerate(pair.joints))
    if not ordered: raise ValueError('Prepare at least one joint marker.')
    rings = []
    for joint_id, joint in ordered:
        t = joint.position
        if not math.isfinite(t) or not ts[0]+layout.EPS < t < ts[-1]-layout.EPS:
            raise ValueError(f'Joint {joint_id+1} center must stay inside the protected root/tip.')
        if rings and t-rings[-1]['t'] <= layout.EPS:
            raise ValueError('Keep joint markers in root-to-tip order and separate their central rings.')
        rings.append(_ring(source, rows, ts, t, 'JOINT_'+str(joint_id+1), joint_id, 0))
    protected = set(recipe['protected_rows']) if recipe.get('protected_rows') is not None else slide.protected_rows(source, rows)
    assignments = (_allocate(ts, rings, protected) if center_rows is None else
                   _pinned_rows(ts, rings, protected, center_rows, surface_targets=surface_targets))
    moves, used = {}, set()
    for ring, row in zip(rings, assignments):
        ring.update(reuse=row, source_row=row, source_t=ts[row])
        used.add(row)
        if surface_targets:
            # A final-surface target is not a legal initial cage coordinate.
            # Begin at the existing row and validate movement after inversion.
            ring['target_t'], ring['t'] = ring['t'], ts[row]
        if abs(ts[row]-ring['t']) < layout.EPS:
            ring['t'] = ts[row]
            ring['points'], ring['band'], ring['fraction'] = layout._sample(source, rows, ts, ts[row])
            ring['allocation'] = 'REUSED'
        else:
            moves[row] = ring['t']
            ring['allocation'] = 'MOVED'
    mapping = {ring['joint']: row for ring, row in zip(rings, assignments)}
    positions = [moves.get(i, t) for i, t in enumerate(ts)]
    if any(b-a <= layout.EPS for a, b in zip(positions, positions[1:])):
        raise ValueError('Central rings would cross or collapse after matching existing rows. Separate the joint markers.')
    if centers_only:
        return _finish(obj, source, rows, ts, rings, moves, protected, mapping, True, [])
    centers = {ring['joint']: ring for ring in rings}
    varying = any(abs(j.inner_spacing-j.outer_spacing) > 1e-6 for _, j in ordered)
    axis = bend = None
    if varying:
        if not recipe.get('normal'):
            raise ValueError('Asymmetric spacing needs this finger\'s bend side.')
        normal = Vector(recipe['normal'])*(1 if recipe.get('flip_bend') else -1)
        axis = Vector(recipe['tip'])-Vector(recipe['root'])
        if axis.length <= layout.EPS: raise ValueError('The prepared finger axis is degenerate.')
        axis.normalize()
        bend = normal-axis*normal.dot(axis)
        if bend.length <= layout.EPS: raise ValueError('The prepared bend side is parallel to the finger.')
        bend.normalize()
    intervals = []
    retained = recipe.get('retained_support_rows', {})
    if retained:
        expected = {f'{i}:{flank}' for i, _ in ordered for flank in (-1, 1)}
        if (set(retained) != expected or any(type(row) is not int or not 0 < row < len(rows)-1
                                            for row in retained.values()) or
                len(set(retained.values())) != len(retained) or set(retained.values()) & used):
            raise ValueError('Previously generated support identities are invalid; rebind this finger.')
    for joint_id, joint in ordered:
        values = (joint.position, joint.width, joint.inner_spacing, joint.outer_spacing)
        if any(not math.isfinite(value) for value in values) or min(values[1:]) <= 0:
            raise ValueError('Joint widths and spacing must be finite positive values.')
        outer = joint.width*max(joint.inner_spacing, joint.outer_spacing)
        if joint.position-outer <= ts[0]+layout.EPS or joint.position+outer >= ts[-1]-layout.EPS:
            raise ValueError(f'Joint {joint_id+1} support region crosses the protected root/tip. Reduce width or move the marker.')
        if intervals and joint.position-outer <= intervals[-1][1]+.002:
            raise ValueError('Joint support/weight regions overlap; separate the markers or reduce widths.')
        intervals.append((joint.position-outer, joint.position+outer))
        center_points = centers[joint_id]['points']
        center = sum(center_points, Vector())/len(center_points)
        asymmetric = abs(joint.inner_spacing-joint.outer_spacing) > 1e-6
        for flank in (-1, 1):
            times = None
            t = joint.position+flank*joint.width*joint.inner_spacing
            if flank and asymmetric:
                times = []
                for point in center_points:
                    radial = point-center-axis*(point-center).dot(axis)
                    mix = .5+.5*radial.normalized().dot(bend)
                    factor = joint.outer_spacing+(joint.inner_spacing-joint.outer_spacing)*mix
                    times.append(joint.position+flank*joint.width*factor)
                t = sum(times)/len(times)
            ring = _ring(source, rows, ts, t, 'SUPPORT', joint_id, flank, times=times)
            owned_row = retained.get(f'{joint_id}:{flank}')
            if owned_row is not None:
                # These are exact identities of this tool's already-created
                # supports after an artist edit rebased the source, never
                # nearest authored neighbors chosen as replacement supports.
                changed = any((point-source.vertices[vi].co).length > layout.EPS
                              for point, vi in zip(ring['points'], rows[owned_row]))
                if changed and owned_row in protected:
                    raise ValueError('A previously generated support now carries protected artist data; keep its position or rebind this finger.')
                ring.update(reuse=owned_row, source_row=owned_row, source_t=ts[owned_row],
                            allocation='MOVED' if changed else 'REUSED')
                used.add(owned_row)
                if changed: moves[owned_row] = t
            else:
                ring['allocation'] = 'NEW'
                if any(abs(value-original) <= layout.EPS for value in ring.get('times', [t]) for original in positions):
                    raise ValueError(f'Joint {joint_id+1} support coincides with an existing ring. Adjust support width/spacing; existing rings are not moved or reused as supports.')
            rings.append(ring)
    positions = [moves.get(i, t) for i, t in enumerate(ts)]
    if any(b-a <= layout.EPS for a, b in zip(positions, positions[1:])):
        raise ValueError('An updated support would cross an authored ring; reduce support spacing.')
    between_gaps = []
    for (left_id, _), (right_id, _) in zip(ordered, ordered[1:]):
        left = next(r for r in rings if r['joint'] == left_id and r['flank'] == 1)
        right = next(r for r in rings if r['joint'] == right_id and r['flank'] == -1)
        a, b = max(left.get('times', [left['t']])), min(right.get('times', [right['t']]))
        ordinary = [i for i, t in enumerate(positions) if i not in used and a+layout.EPS < t < b-layout.EPS]
        added = not ordinary and fill_between(pair)
        if added:
            ring = _ring(source, rows, ts, (a+b)*.5, 'BETWEEN', -1, 0)
            ring['allocation'] = 'NEW'
            rings.append(ring)
        between_gaps.append(dict(left_joint=left_id, right_joint=right_id,
                                 ordinary_count=len(ordinary), ordinary_rows=ordinary, added=bool(added)))
    return _finish(obj, source, rows, ts, rings, moves, protected, mapping, False, between_gaps)


def _finish(obj, source, rows, ts, rings, moves, protected, mapping, centers_only, between_gaps):
    rings.sort(key=lambda ring: ring['t'])
    plan = dict(obj=obj, rows=rows, positions=ts, rings=rings, moves=moves,
                protected_rows=protected, sliding=True, joint_reuse=True, defined=True,
                center_rows=mapping, centers_only=centers_only,
                root=[source.vertices[i].co.copy() for i in rows[0]],
                tip=[source.vertices[i].co.copy() for i in rows[-1]], between_gaps=between_gaps,
                allocation_counts={kind: sum(r['allocation'] == kind for r in rings) for kind in ('REUSED', 'MOVED', 'NEW')})
    # Validate all insertion bands now, while planning is still read-only.
    slide.split_plan(plan, source)
    return plan
