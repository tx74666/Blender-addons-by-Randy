"""Adopt explicit artist topology edits without replaying an old mesh snapshot.

Reference adaptation proves each local finger independently. The current mesh,
including all artist data, becomes the new immutable source. Existing committed
rings keep exact identities when present; missing rings reset only that pair's
generation phase, never the other fingers or their geometry.
"""
import copy
import json

import bpy
from mathutils import Vector
from mathutils.kdtree import KDTree

from . import finger_bank as bank, finger_definition as definition
from . import finger_layout as layout, finger_ring_slide as slide


def topology(obj):
    bm = definition._snapshot(obj, definition._basis_name(obj))
    try: return definition._topology(bm)
    finally: bm.free()


def remembered_topology(obj, state):
    saved = state.get('topology', '')
    if saved: return saved
    # Upgrade existing preparations without guessing from the pre-generation
    # source, whose topology deliberately differs after inserting supports.
    for slot in obj.character_designer_finger_bank.slots:
        if slot.guide.record:
            try: return json.loads(slot.guide.record)['topology']
            except (ValueError, KeyError, TypeError): continue
    return ''


def recipe(obj, source, candidate, guide, previous):
    result = copy.deepcopy(previous)
    record = json.loads(guide.record)
    rows = candidate['rings']
    path = [obj.matrix_world @ Vector(p) for p in record['basis']['path']]
    length = sum((b-a).length for a, b in zip(path, path[1:]))
    if length <= layout.EPS: raise ValueError('The saved finger span collapsed.')
    positions = [definition.project_distance(
        sum((obj.matrix_world @ source.vertices[i].co for i in row), Vector())/len(row), path)/length for row in rows]
    if any(b-a <= 1e-5 for a, b in zip(positions, positions[1:])):
        raise ValueError('The edited finger rows fold back along the saved span.')
    result.update(rings=rows, positions=positions, root=record['basis']['path'][0],
                  tip=record['basis']['path'][-1], path=record['basis']['path'], length=length,
                  definition_id=guide.revision, normal=record['basis'].get('normal'),
                  flip_bend=guide.flip_bend, protected_rows=sorted(slide.protected_rows(source, rows)))
    result.pop('retained_support_rows', None)
    return result


def _retained_result(source, updated, previous, tree, result):
    rows = updated['rings']
    lookup = {frozenset(row): i for i, row in enumerate(rows)}
    saved = copy.deepcopy(result)
    mapping, supports, rings, planes = {}, {}, [], []
    old_plan = result['plan']
    for index, item in enumerate(old_plan['rings']):
        if item['joint'] < 0: continue  # Ordinary middle loops are now authored source.
        ring = copy.deepcopy(item)
        points = ring.get('cage_points')
        if points is None:
            times = ring.get('times', [ring['t']]*len(previous['rings'][0]))
            points = [layout._sample(source, previous['rings'], previous['positions'], t)[0][j]
                      for j, t in enumerate(times)]
        vertices = []
        for point in points:
            hits = tree.find_range(Vector(point), 2e-6)
            if len(hits) != 1: raise ValueError('A previously generated joint ring was edited or removed.')
            vertices.append(hits[0][1])
        row = lookup.get(frozenset(vertices))
        if row is None or not 0 < row < len(rows)-1:
            raise ValueError('A previously generated joint ring is no longer a complete internal row.')
        if ring['flank'] == 0: mapping[str(ring['joint'])] = row
        else: supports[f"{ring['joint']}:{ring['flank']}"] = row
        ring.update(vertex_ids=vertices, reuse=row, source_row=row, source_t=updated['positions'][row],
                    band=row, fraction=0., allocation='REUSED', cage_points=[list(p) for p in points])
        rings.append(ring)
        if old_plan.get('subdivision'): planes.append(old_plan['subdivision']['planes'][index])
    if len(mapping) != len(result['center_rows']):
        raise ValueError('A confirmed center ring is missing.')
    if result['phase'] == 'FINAL' and len(supports) != len(mapping)*2:
        raise ValueError('A completed support ring is missing.')
    if supports: updated['retained_support_rows'] = supports
    saved.update(adopted=True, center_rows=mapping,
                 plan=dict(rows=rows, positions=updated['positions'], rings=rings, moves={}))
    if old_plan.get('subdivision'):
        saved['plan']['subdivision'] = dict(copy.deepcopy(old_plan['subdivision']), planes=planes)
    from . import finger_workflow as workflow
    saved['center_confirmation']['identity'] = workflow._center_identity(updated)
    return saved


def refresh(context, *, signature=None):
    """Outside drawing only. Return True when topology metadata was refreshed."""
    from . import finger_workflow as workflow
    obj = bank.active_object(context)
    if obj is None: return False
    state = obj.character_designer_finger_workflow
    before = remembered_topology(obj, state)
    current = topology(obj)
    if not before or before == current: return False
    if obj.data.shape_keys and obj.active_shape_key_index != 0:
        return False
    old_bank = workflow._bank_backup(obj)
    old_source = state.source
    old = (state.signature, state.bodies, state.results, state.get('topology', ''))
    pairs = {p.name: (p.recipe, p.applied, p.labels) for p in state.pairs}
    new_source = None
    try:
        report = bank.adapt_topology(context)
        if not old_source:
            state['topology'] = current
            return True
        obj.update_from_editmode() if obj.mode == 'EDIT' else None
        new_source = obj.data.copy()
        new_source.name = '.CD Finger Workflow Source'
        new_source[workflow.SOURCE_TAG] = True
        if workflow.RESULT_TAG in new_source: del new_source[workflow.RESULT_TAG]
        survey = report['survey']
        old_results = json.loads(state.results or '{}')
        tree = KDTree(len(new_source.vertices))
        for vertex in new_source.vertices: tree.insert(vertex.co, vertex.index)
        tree.balance()
        results, updates, rebound = {}, {}, []
        for pair in state.pairs:
            if not pair.recipe: continue
            previous = json.loads(pair.recipe)
            records, accepted = {}, {}
            for key, prior in previous.items():
                slot = obj.character_designer_finger_bank.slots.get(key)
                candidate = survey['candidates'].get(key)
                if not slot or slot.error or not candidate:
                    break
                try:
                    records[key] = recipe(obj, new_source, candidate, slot.guide, prior)
                    if pair.applied:
                        accepted[key] = _retained_result(old_source, records[key], prior, tree, old_results[key])
                        if key in report['adapted'] and accepted[key]['plan'].get('subdivision'):
                            # New authored rows change this finger's subdivision
                            # stencil, while its accepted surface targets stay put.
                            accepted[key]['subdivision_dirty'] = True
                except (ValueError, KeyError, TypeError):
                    # Retain usable definitions and sliders; the user can run
                    # Step 1 again when one of its former rings was removed.
                    accepted.clear()
                    continue
            valid = len(records) == len(previous)
            kept = valid and len(accepted) == len(previous) and pair.applied
            if not kept:
                for item in records.values(): item.pop('retained_support_rows', None)
                rebound.append(pair.name)
            else: results.update(accepted)
            updates[pair.name] = (json.dumps(records) if valid else '', bool(kept), pair.labels if valid else '')
        state.source = new_source
        state.signature = signature or layout.fingerprint(obj)
        state.bodies, state.results = json.dumps(survey['candidates']), json.dumps(results)
        state['topology'] = current
        for pair in state.pairs:
            if pair.name in updates: pair.recipe, pair.applied, pair.labels = updates[pair.name]
        state.status = ('Topology adapted; existing mesh, weights and joint markers kept.' +
                        (' Run Step 1 again: '+', '.join(rebound)+'.' if rebound else ''))
    except Exception:
        state.source = old_source
        state.signature, state.bodies, state.results, state['topology'] = old
        for pair in state.pairs:
            if pair.name in pairs: pair.recipe, pair.applied, pair.labels = pairs[pair.name]
        workflow._restore_bank(obj, old_bank)
        if new_source and new_source.users == 0: bpy.data.meshes.remove(new_source)
        raise
    if old_source and old_source.users == 0 and old_source.get(workflow.SOURCE_TAG):
        bpy.data.meshes.remove(old_source)
    return True


def frozen_plan(obj, recipe, saved):
    plan = copy.deepcopy(saved['plan'])
    plan.update(obj=obj, frozen=True, centers_only=saved['phase'] == 'CENTERS',
                center_rows=saved['center_rows'], allocation_counts={'REUSED': len(plan['rings']), 'MOVED': 0, 'NEW': 0})
    for ring in plan['rings']:
        ring['blocked'] = False
        ring['points'] = [obj.data.vertices[i].co.copy() for i in ring['vertex_ids']]
    return plan
