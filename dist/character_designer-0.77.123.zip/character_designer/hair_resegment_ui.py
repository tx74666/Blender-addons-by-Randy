"""Explicit Hair versions; no update callbacks or playback services."""
import bpy
from bpy.props import IntProperty, StringProperty


def service():
    from . import hair_resegment
    return hair_resegment


def current_source(context):
    obj = context.active_object
    if obj is not None:
        candidate = obj if obj.type == 'MESH' else obj.get('character_designer_hair_resegment_mesh')
        if candidate is not None and service().is_version(candidate):
            return candidate
        # An explicit active original Hair outranks a previously remembered
        # visible version from another family. Let hair_bones resolve it.
        from . import hair_bones_rig as hair
        if obj.type=='MESH' and hair.RECORD_KEY in obj:
            return None
        if obj.type=='ARMATURE':
            active=getattr(context,'active_pose_bone',None)
            if active is not None and active.bone.get(hair.SOURCE_KEY) is not None:
                return None
    state = getattr(context.window_manager, 'character_designer_hair_bones', None)
    candidate = state.source if state is not None else None
    if candidate is not None and service().is_version(candidate) and candidate.visible_get():
        return candidate
    return None


def is_version(source):
    return source is not None and service().is_version(source)


def source_before_switch(context, source):
    from . import hair_bones_variants as variants
    original = service().root_source(source)
    if is_version(source) or any(item.get(variants.MODE_KEY) == 'RESEGMENTED'
                                 for item in variants.variants_for(original)):
        service().guard_switch(context, source)
    return original


class CHARACTERDESIGNER_OT_hair_resegment(bpy.types.Operator):
    bl_idname = 'character_designer.hair_resegment'
    bl_label = 'Change Hair Segments'
    bl_description = 'Create a new hair version with transferred current weights and sampled motion; retain the original'
    bl_options = {'REGISTER', 'UNDO'}

    bone_count: IntProperty(name='Bones per Chain', default=6, min=1, max=12)

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.mode in {'OBJECT', 'POSE', 'EDIT_MESH'}

    def invoke(self, context, event):
        settings = context.window_manager.character_designer_hair_bones
        self.bone_count = settings.bone_count
        return context.window_manager.invoke_props_dialog(self, width=390)

    def draw(self, context):
        self.layout.prop(self, 'bone_count')
        self.layout.label(text='Creates a new version; retains the original.')
        self.layout.label(text='Transfers current paint and samples visible motion.')
        self.layout.label(text='Check the new bending result before continuing.')

    def execute(self, context):
        from . import hair_bones
        try:
            source = hair_bones._source(context)
            result = service().create(context, source, bone_count=self.bone_count)
            settings = context.window_manager.character_designer_hair_bones
            settings.source = result['mesh']
            settings.bone_count = self.bone_count
            settings.last_message = f'Created {self.bone_count}-bone Hair version; original retained.'
            self.report({'INFO'}, settings.last_message)
            return {'FINISHED'}
        except (ValueError, RuntimeError, KeyError, TypeError) as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}


class CHARACTERDESIGNER_OT_hair_show_version(bpy.types.Operator):
    bl_idname = 'character_designer.hair_show_version'
    bl_label = 'Show Hair Version'
    bl_description = 'Switch to a retained hair version without changing the original'
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: StringProperty(options={'HIDDEN'})

    def execute(self, context):
        from . import hair_bones, hair_bones_variants as variants
        try:
            source = hair_bones._source(context)
            original = source_before_switch(context, source)
            collection = bpy.data.collections.get(self.collection_name)
            if collection is None or collection not in variants.variants_for(original):
                raise ValueError('This Hair version is no longer available.')
            mesh = service().show_version(context, source, collection)
            context.window_manager.character_designer_hair_bones.source = mesh
            return {'FINISHED'}
        except (ValueError, RuntimeError, KeyError, TypeError) as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}


class CHARACTERDESIGNER_OT_hair_show_original_version(bpy.types.Operator):
    bl_idname = 'character_designer.hair_show_original_version'
    bl_label = 'Show Original Hair'
    bl_description = 'Return to the retained original binding in Object Mode'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from . import hair_bones
        try:
            original = service().show_original(context, hair_bones._source(context))
            context.window_manager.character_designer_hair_bones.source = original
            return {'FINISHED'}
        except (ValueError, RuntimeError, KeyError, TypeError) as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}


def draw_versions(layout, context, source, bound):
    from . import hair_bones_variants as variants
    if bound:
        layout.operator('character_designer.hair_resegment', icon='BONE_DATA')
    if source is None:
        return
    original = service().root_source(source)
    if any(c.get(variants.MODE_KEY) == 'RESEGMENTED' for c in variants.variants_for(original)):
        layout.operator('character_designer.hair_show_original_version', text='Original Hair',
                        icon='OUTLINER_OB_MESH', depress=original.visible_get())
    for collection in variants.variants_for(original):
        if collection.get(variants.MODE_KEY) != 'RESEGMENTED':
            continue
        row = layout.row(align=True)
        item = row.operator('character_designer.hair_show_version',
            text=collection.name, depress=not collection.hide_viewport, icon='ARMATURE_DATA')
        item.collection_name = collection.name


CLASSES = (CHARACTERDESIGNER_OT_hair_resegment, CHARACTERDESIGNER_OT_hair_show_version,
           CHARACTERDESIGNER_OT_hair_show_original_version)
