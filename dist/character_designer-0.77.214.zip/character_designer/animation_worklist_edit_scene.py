"""Open a prepared motion in the local scene that owns its editable Action."""

import bpy
from bpy.props import StringProperty
from bpy.types import Operator, UIList

EDIT_SCENE = 'character_designer_prepared_edit_scene_v1'


def editing_scene(home):
    scene = home.get(EDIT_SCENE)
    if not isinstance(scene, bpy.types.Scene) or scene == home or scene.library or scene.override_library:
        return None
    owner = home.character_designer_animation_worklist
    actions = scene.character_designer_animation_worklist
    if (not owner.workspace_identity or owner.workspace_identity != actions.workspace_identity
            or not actions.rig or actions.rig == owner.rig or actions.rig.name not in scene.objects):
        return None
    return scene


def _local_row(scene, key):
    return next((row for row in scene.character_designer_animation_worklist.items if row.clip_key == key), None)


class CHARACTERDESIGNER_OT_edit_prepared_motion(Operator):
    bl_idname = 'character_designer.edit_prepared_motion'
    bl_label = 'Open Motion in Editing Scene'
    bl_description = 'Switch to the source rig in this file and edit its local Custom Action'
    bl_options = {'REGISTER', 'UNDO'}

    clip_key: StringProperty(options={'HIDDEN'})

    def execute(self, context):
        from . import animation_worklist as worklist
        home = context.scene
        scene = editing_scene(home)
        if scene is None or context.window is None:
            self.report({'ERROR'}, 'The editing scene for this workspace is unavailable.')
            return {'CANCELLED'}
        try:
            worklist._idle(context)
            item = _local_row(scene, self.clip_key)
            if item is None and not any(entry.clip_key == self.clip_key and entry.ready
                                        for entry in home.character_designer_animation_worklist.catalog):
                raise ValueError('This motion is no longer in the prepared list.')
            context.window.scene = scene
            with context.temp_override(scene=scene, view_layer=context.window.view_layer):
                if item is None:
                    worklist.add(context, self.clip_key)
                else:
                    worklist.activate(context, item.item_id, 'CUSTOM')
        except (ValueError, OSError, RuntimeError, ReferenceError) as exc:
            if context.window.scene != home:
                context.window.scene = home
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_return_from_motion(Operator):
    bl_idname = 'character_designer.return_from_motion'
    bl_label = 'Return to Character'
    home_scene: StringProperty(options={'HIDDEN'})

    def execute(self, context):
        from . import animation_worklist as worklist
        home = bpy.data.scenes.get(self.home_scene)
        if home is None or editing_scene(home) != context.scene:
            self.report({'ERROR'}, 'The character scene no longer uses this editing scene.')
            return {'CANCELLED'}
        try:
            worklist._idle(context)
        except (ValueError, RuntimeError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        context.window.scene = home
        return {'FINISHED'}


class CHARACTERDESIGNER_UL_prepared_motions(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index=0, flt_flag=0):
        scene = editing_scene(context.scene)
        local = _local_row(scene, item.clip_key) if scene else None
        label = local.name if local else item.name
        if scene and (local or item.ready):
            button = layout.operator('character_designer.edit_prepared_motion', text=label,
                                     icon='ACTION' if local else 'IMPORT')
            button.clip_key = item.clip_key
            if not local:
                layout.label(text='Import')
        else:
            layout.label(text=label, icon='ACTION')
            if not item.ready:
                layout.label(text='Not prepared')


def draw_return(layout, context):
    for home in bpy.data.scenes:
        if home != context.scene and home.get(EDIT_SCENE) == context.scene and editing_scene(home) == context.scene:
            button = layout.operator('character_designer.return_from_motion', text='Return to ' + home.name,
                                     icon='LOOP_BACK')
            button.home_scene = home.name


CLASSES = (CHARACTERDESIGNER_OT_edit_prepared_motion, CHARACTERDESIGNER_OT_return_from_motion,
           CHARACTERDESIGNER_UL_prepared_motions)
