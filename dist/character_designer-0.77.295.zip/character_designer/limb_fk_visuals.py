"""Reversible display shapes for native FK joints."""
from __future__ import annotations

import json
import math
import uuid

import bpy
from . import validation_native

from . import generated_names, validation_json

OWNER_KEY = 'character_designer_owner'
OWNER_VALUE = 'limb_fk_visuals'
ID_KEY = 'character_designer_fk_visual_id'
ROLE_KEY = 'character_designer_fk_visual_role'
RIG_KEY = 'character_designer_fk_visual_armature_id'
RECORD_KEY = 'character_designer_limb_fk_visuals_v1'
NATIVE_DISPLAY_KEY = 'character_designer_limb_fk_native_display_v1'
IK_SIZE_RECORD_KEY = 'character_designer_limb_ik_size_fit_v1'
VERSION = 1
RING_SEGMENTS = 32
RING_FLATTENING = .819
RADIUS_FACTORS = {'ARM': .15, 'LEG': .22}
_DISPLAY_PATHS = ('custom_shape', 'custom_shape_transform', 'custom_shape_scale_xyz',
                  'custom_shape_translation', 'custom_shape_rotation_euler',
                  'use_custom_shape_bone_size', 'custom_shape_wire_width')


def _limb():
    from . import limb_ik
    return limb_ik


def _error(message):
    return _limb().LimbIKError(message)


def _active(context, armature):
    from . import torso_controls
    torso_controls._active(context, armature)


def _update(context, armature):
    from . import torso_controls
    torso_controls._update(context, armature)


def _tag(item, record, role):
    item[OWNER_KEY], item[ID_KEY] = OWNER_VALUE, record['id']
    item[ROLE_KEY], item[RIG_KEY] = role, record['armature_id']


def _owned(item, record, role):
    return (item is not None and item.get(OWNER_KEY) == OWNER_VALUE
            and item.get(ID_KEY) == record['id'] and item.get(ROLE_KEY) == role
            and item.get(RIG_KEY) == record['armature_id'])


def binding_names(kind, chain):
    """Native joints eligible for an FK display shape."""
    return chain[:3]


def ring_radius(armature, kind, chain, name):
    """Size a new wrist ring like its forearm; never resize existing rings."""
    radius_name = chain[1] if kind == 'ARM' and name == chain[2] else name
    radius = float(armature.pose.bones[radius_name].bone.length) * RADIUS_FACTORS[kind]
    if not math.isfinite(radius) or radius <= 1e-6:
        raise _error(f"Bone '{name}' is too short for an FK ring.")
    return radius


def get_record(armature):
    raw = armature.data.get(RECORD_KEY)
    if raw is None:
        return None
    try:
        record = validation_json.decode(raw)
        if (record['version'] != VERSION or not isinstance(record['bindings'], dict)
                or not record['bindings'] or not isinstance(record['id'], str)
                or record['armature_id'] != armature.data.get(_limb().ARMATURE_ID_KEY)):
            raise ValueError('unsupported record')
        for name, entry in record['bindings'].items():
            if (entry['kind'] not in RADIUS_FACTORS or entry['side'] not in {'L', 'R'}
                    or len(entry['chain']) != 3
                    or name not in binding_names(entry['kind'], entry['chain'])
                    or (entry['kind'] == 'LEG' and name == entry['chain'][2]
                        and entry.get('shape_kind') != 'FOOT')
                    or not isinstance(entry['object'], str) or not isinstance(entry['mesh'], str)):
                raise ValueError('invalid binding')
            _limb()._validate_shape_state(entry['original'], 'Saved FK ring display', original=True)
            _limb()._validate_shape_state(entry['generated'], 'Generated FK ring display')
        return record
    except (KeyError, TypeError, ValueError) as exc:
        raise _error('FK ring recovery data is invalid; restore a saved copy.') from exc


def _same_display(pb, expected):
    actual = _limb()._pose_shape_json_state(pb)
    return (actual['custom_shape_transform'] == expected['custom_shape_transform']
            and actual['use_bone_size'] == expected['use_bone_size']
            and all(_limb()._shape_values_match(actual[key], expected[key])
                    for key in ('scale', 'translation', 'rotation'))
            and (expected['wire_width'] is None or abs(actual['wire_width'] - expected['wire_width']) < 1e-6))


def _native_display(armature, record):
    """Exact, saved authorization for temporarily detached owned ring shapes.

    The marker describes a display override, not an IK/FK evaluation value.
    A no-pop matcher changes that value before the display handoff, so strict
    inventory must also accept this exact state during that transaction.
    """
    raw = armature.data.get(NATIVE_DISPLAY_KEY)
    if raw is None:
        return {}
    try:
        saved = json.loads(raw)
        if (not isinstance(saved, dict) or not saved or record is None
                or any(name not in record['bindings']
                       or widget != record['bindings'][name]['object']
                       for name, widget in saved.items())):
            raise ValueError('invalid native ring display')
        return saved
    except (KeyError, TypeError, ValueError) as exc:
        raise _error('The native FK display authorization no longer matches its owned rings.') from exc


def native_display_snapshot(armature):
    """Primitive display checkpoint; no additional widget ID users are added."""
    record = get_record(armature)
    _native_display(armature, record)
    return {'marker': armature.data.get(NATIVE_DISPLAY_KEY),
            'shapes': {name: (armature.pose.bones[name].custom_shape.name
                             if armature.pose.bones[name].custom_shape else '')
                       for name in (record or {}).get('bindings', {})}}


def restore_native_display(armature, saved):
    shapes = {}
    for name, widget in saved.get('shapes', {}).items():
        pb = armature.pose.bones.get(name)
        shape = bpy.data.objects.get(widget) if widget else None
        if pb is None or (widget and shape is None):
            raise _error('The saved native FK display cannot restore a missing bone or widget.')
        shapes[name] = shape
    for name, shape in shapes.items():
        if armature.pose.bones[name].custom_shape != shape:
            armature.pose.bones[name].custom_shape = shape
    raw = saved.get('marker')
    if raw is None:
        armature.data.pop(NATIVE_DISPLAY_KEY, None)
    else:
        armature.data[NATIVE_DISPLAY_KEY] = raw


def sync_native_display(armature, inventory, *, keys=None):
    """Show the long FK bones with selectable wrist and sole shapes.

    ``inventory`` must already have passed the operator's strict preflight.
    The handoff audits only these bindings, never rescans scene objects.
    Artist shapes and animated display channels are not overridden.
    """
    from . import limb_ik_fk, limb_ik_fk_pose_key
    record = get_record(armature)
    before = _native_display(armature, record)
    if record is None:
        return 0
    editing_clip = limb_ik_fk_pose_key.active_record(bpy.context, armature) is not None
    selected = set(inventory['rigs']) if keys is None else set(keys)
    desired = dict(before)
    pending = {}
    for name, entry in record['bindings'].items():
        key = (entry['kind'], entry['side'])
        if key not in selected:
            continue
        rig = inventory['rigs'].get(key)
        pb = armature.pose.bones.get(name)
        widget = bpy.data.objects.get(entry['object'])
        # A saved clip may have shed an unused, already detached FK widget.
        # Editing in native display needs neither its object nor a new binding.
        detached = editing_clip and name in before and widget is None
        if (rig is None or list(rig['chain']) != entry['chain'] or pb is None
                or (not detached and not _owned(widget, record, name))
                or pb.custom_shape != (None if name in before else widget)
                or not _same_display(pb, entry['generated'])):
            raise _error(f"The owned FK display on '{name}' changed; preserve that setup first.")
        # Long FK segments remain easy to distinguish. The end shapes are
        # drawn on the native joints and share their selection and pivot.
        endpoint = name == entry['chain'][2]
        native = detached or (not endpoint and (
            editing_clip or limb_ik_fk.mode_for_rig(armature, rig) == 'FK'))
        shape = None if native else widget
        if pb.custom_shape != shape:
            if _animated_display(armature, pb):
                raise _error(f"The FK display on '{name}' is animated; preserve those channels before changing its display.")
            pending[name] = shape
        if native:
            desired[name] = entry['object']
        else:
            desired.pop(name, None)
    snapshot = native_display_snapshot(armature)
    try:
        for name, shape in pending.items():
            armature.pose.bones[name].custom_shape = shape
        if desired != before:
            if desired:
                armature.data[NATIVE_DISPLAY_KEY] = json.dumps(desired, sort_keys=True, separators=(',', ':'))
            else:
                armature.data.pop(NATIVE_DISPLAY_KEY, None)
    except Exception:
        restore_native_display(armature, snapshot)
        raise
    return len(pending)


def validate(armature, inventory=None, *, allow_detached_missing=False):
    """Validate this visual registry without recursively entering limb inventory."""
    record = get_record(armature)
    native_display = _native_display(armature, record)
    rig_id = armature.data.get(_limb().ARMATURE_ID_KEY)
    owned_objects = {obj.name for obj in bpy.data.objects
                     if obj.get(OWNER_KEY) == OWNER_VALUE and obj.get(RIG_KEY) == rig_id}
    if record is None:
        if owned_objects:
            raise _error('FK ring widgets have lost their recovery data.')
        return None
    try:
        detached = set()
        for name in native_display:
            obj = bpy.data.objects.get(record['bindings'][name]['object'])
            if validation_native.missing_pose_asset(armature, obj) or (allow_detached_missing and obj is None):
                detached.add(native_display[name])
        if owned_objects != {entry['object'] for entry in record['bindings'].values()} - detached:
            raise _error('FK ring widgets were added, removed or renamed.')
        collection = bpy.data.collections.get(record['collection'])
        missing_collection = (validation_native.missing_pose_asset(armature, collection)
                              or (allow_detached_missing and collection is None and not owned_objects))
        if not missing_collection and not _owned(collection, record, 'COLLECTION'):
            raise _error('The FK ring widget collection is missing or was replaced.')
        for name, entry in record['bindings'].items():
            pb = armature.pose.bones.get(name)
            obj = bpy.data.objects.get(entry['object'])
            if (pb is None or pb.bone.get(OWNER_KEY) in _limb().GENERATED_CONTROL_OWNERS
                    or (entry['object'] not in detached and (not _owned(obj, record, name) or obj.type != 'MESH'
                        or obj.data.name != entry['mesh'] or not _owned(obj.data, record, name)))
                    or pb.custom_shape != (None if name in native_display else obj)
                    or not _same_display(pb, entry['generated'])):
                raise _error(f"FK ring assignment or display on '{name}' was edited; preserve that setup first.")
            if inventory is not None:
                rig = inventory['rigs'].get((entry['kind'], entry['side']))
                if rig is None or list(rig['chain']) != entry['chain']:
                    raise _error(f"The limb using FK ring '{name}' changed; remove its ring visuals before rebuilding.")
    except (KeyError, TypeError, AttributeError) as exc:
        raise _error('FK ring recovery data no longer matches this armature.') from exc
    return record


def _animated_display(armature, pb):
    paths = {pb.path_from_id(field) for field in _DISPLAY_PATHS if hasattr(pb, field)}
    curves = [curve for action in _limb()._actions_for_id(armature)
              for curve in _limb()._fcurves_for_action(action)]
    if armature.animation_data:
        curves.extend(armature.animation_data.drivers)
    return any(curve.data_path in paths for curve in curves)


def _geometry():
    vertices = [(math.cos(i * math.tau / RING_SEGMENTS), 0.0,
                 math.sin(i * math.tau / RING_SEGMENTS) * RING_FLATTENING)
                for i in range(RING_SEGMENTS)]
    return vertices, [(i, (i + 1) % RING_SEGMENTS) for i in range(RING_SEGMENTS)]


def _create_widget(context, armature, record, name, entry, *, geometry=None, organize=True):
    collection = bpy.data.collections.get(record['collection'])
    if collection is None or not _owned(collection, record, 'COLLECTION'):
        collection = bpy.data.collections.new(record['collection'])
        record['collection'] = collection.name
        context.scene.collection.children.link(collection)
        _tag(collection, record, 'COLLECTION')
        if organize:
            from . import widget_collections
            widget_collections.ensure_container(context, collection, armature, 'FK Rings', allow_numbered=True)
            record['collection'] = collection.name
    mesh = bpy.data.meshes.new(entry['mesh'])
    entry['mesh'] = mesh.name
    _tag(mesh, record, name)
    if geometry is not None:
        vertices, edges = geometry
    elif entry.get('shape_kind') == 'HAND':
        from . import limb_fk_wrist_visuals
        vertices, edges = limb_fk_wrist_visuals.geometry()
    else:
        vertices, edges = _geometry()
    mesh.from_pydata(vertices, edges, [])
    mesh.update()
    obj = bpy.data.objects.new(entry['object'], mesh)
    entry['object'] = obj.name
    _tag(obj, record, name)
    collection.objects.link(obj)
    obj.hide_render, obj.hide_select = True, True
    obj.hide_set(True)
    pb = armature.pose.bones[name]
    pb.custom_shape = obj
    # No custom-shape transform or midpoint offset: the ring follows the
    # native FK joint itself, including an existing intermediate IK/FK value.
    _limb()._apply_source_widget_generated_state(pb, entry['generated'])


def _plan_sole(armature, rig):
    """Copy the fitted IK outline into the native ankle's rest frame."""
    from . import foot_sole_display, limb_fk_wrist_visuals
    limb = _limb()
    end = armature.pose.bones[rig['chain'][2]]
    target = armature.pose.bones[rig['target'].name]
    shape = target.custom_shape
    rig_id = armature.data.get(limb.ARMATURE_ID_KEY)
    donor = target.custom_shape_transform
    if (not limb_fk_wrist_visuals._plain_mesh_object(shape)
            or not limb._owned(shape, rig_id, role='WIDGET')
            or not limb._owned(shape.data, rig_id, role='WIDGET_DATA')
            or shape.get(limb.KIND_KEY) not in {'FOOT', 'FOOT_L', 'FOOT_R'}
            or shape.data.get(limb.KIND_KEY) != shape.get(limb.KIND_KEY)
            or (donor != end and not foot_sole_display.valid_frame(target))
            or shape.data.polygons or not shape.data.edges
            or _animated_display(armature, target)):
        raise limb_fk_wrist_visuals.UnsupportedSource('The IK foot has no supported fitted sole outline.')
    state = limb._control_visual_state(target)
    if target.use_custom_shape_bone_size:
        length = (donor or target).bone.length
        state['scale'] = [value * length for value in state['scale']]
    local = (end.bone.matrix_local.inverted() @ (donor or target).bone.matrix_local
             @ limb._custom_shape_state_matrix(state))
    vertices = [tuple(local @ vertex.co) for vertex in shape.data.vertices]
    if not all(math.isfinite(value) for point in vertices for value in point):
        raise limb_fk_wrist_visuals.UnsupportedSource('The IK sole outline has invalid coordinates.')
    edges = [tuple(edge.vertices) for edge in shape.data.edges]
    display = {'custom_shape': '', 'custom_shape_transform': '', 'use_bone_size': False,
               'scale': [1.0] * 3, 'translation': [0.0] * 3, 'rotation': [0.0] * 3,
               'wire_width': 1.5 if hasattr(end, 'custom_shape_wire_width') else None}
    return display, (vertices, edges)


def _delete_resources(record, names):
    for name in names:
        entry = record['bindings'][name]
        obj = bpy.data.objects.get(entry['object'])
        if _owned(obj, record, name):
            bpy.data.objects.remove(obj, do_unlink=True)
        mesh = bpy.data.meshes.get(entry['mesh'])
        if _owned(mesh, record, name) and mesh.users == 0:
            bpy.data.meshes.remove(mesh)
    collection = bpy.data.collections.get(record['collection'])
    if (_owned(collection, record, 'COLLECTION')
            and not collection.objects and not collection.children):
        bpy.data.collections.remove(collection)
        from . import widget_collections
        widget_collections.prune_empty(bpy.context)


def _verify_pose(armature, expected):
    for name, matrix in expected.items():
        for i in range(4):
            for j in range(4):
                error = abs(armature.pose.bones[name].matrix[i][j] - matrix[i][j])
                if not math.isfinite(error) or error > 2e-6:
                    raise _error('FK ring visuals could not preserve the current pose; no changes kept.')


def build(context, armature, *, keys=None, clip_endpoints=False):
    """Add missing FK rings, wrist controls and sole outlines on explicit setup.

    Existing two-joint arm records stay valid and gain only eligible wrists.
    Artist shapes, animated display and previously generated widgets stay intact.
    Existing wrist circles require the separate explicit Hand-shape migration.
    """
    if clip_endpoints:
        from . import bone_collections, bone_display, limb_ik_fk_pose_key
        if context.mode != 'POSE' or context.object != armature or not limb_ik_fk_pose_key.active_record(context, armature):
            raise _error('Open a controller Action in Pose Mode to set up its FK controls.')
        bone_collections._structural_edit_guard(armature)
        bone_display._controls_editable(context, armature)
        inventory = _limb()._validate_inventory(armature, limb_pose_only=True)
        previous = validate(armature, inventory, allow_detached_missing=True)
    else:
        _active(context, armature)
        inventory = _limb()._validate_inventory(armature)
        previous = validate(armature, inventory)
    before_raw = armature.data.get(RECORD_KEY)
    before_marker = armature.data.get(NATIVE_DISPLAY_KEY)
    marker = _native_display(armature, previous)
    before_detached = set(marker)
    record = json.loads(before_raw) if previous else {
        'version': VERSION, 'id': uuid.uuid4().hex, 'armature_id': inventory['armature_id'],
        'bindings': {}, 'skipped': {},
    }
    record.setdefault('collection', generated_names.collection_name(armature, 'FK Rings'))
    pending = {}
    originals = {}
    for (kind, side), rig in inventory['rigs'].items():
        if keys is not None and (kind, side) not in keys:
            continue
        candidates = rig['chain'][2:] if clip_endpoints else binding_names(kind, rig['chain'])
        for name in candidates:
            old = record['bindings'].get(name)
            restore_widget = (clip_endpoints and old is not None and name in marker
                              and bpy.data.objects.get(old['object']) is None)
            if old is not None and not restore_widget:
                continue
            pb = armature.pose.bones[name]
            if pb.custom_shape is not None or pb.custom_shape_transform is not None:
                record['skipped'][name] = 'Existing artist shape or custom-shape transform'
                continue
            if _animated_display(armature, pb):
                record['skipped'][name] = 'Animated custom-shape display'
                continue
            geometry = None
            shape_kind = None
            if restore_widget and old.get('shape_kind') != 'FOOT':
                shape_kind = old.get('shape_kind')
                generated = old['generated']
            elif name == rig['chain'][2]:
                from . import limb_fk_wrist_visuals
                try:
                    if kind == 'ARM':
                        shape_kind = 'HAND'
                        generated = limb_fk_wrist_visuals.plan(armature, rig)
                    else:
                        shape_kind = 'FOOT'
                        generated, geometry = _plan_sole(armature, rig)
                except limb_fk_wrist_visuals.UnsupportedSource as exc:
                    record['skipped'][name] = str(exc)
                    continue
            else:
                radius = ring_radius(armature, kind, rig['chain'], name)
                generated = {'custom_shape': '', 'custom_shape_transform': '', 'use_bone_size': False,
                             'scale': [radius] * 3, 'translation': [0.0] * 3, 'rotation': [0.0] * 3,
                             'wire_width': 2.0 if hasattr(pb, 'custom_shape_wire_width') else None}
            original = old['original'] if restore_widget else _limb()._pose_shape_json_state(pb)
            widget_name = generated_names.widget_name(armature, 'FK_' + name)
            record['bindings'][name] = {'kind': kind, 'side': side, 'chain': list(rig['chain']),
                                         'object': widget_name, 'mesh': widget_name,
                                         'original': original, 'generated': generated}
            if shape_kind:
                record['bindings'][name]['shape_kind'] = shape_kind
            originals[name] = _limb()._pose_shape_runtime_state(pb)
            record['skipped'].pop(name, None)
            if restore_widget:
                del marker[name]
            pending[name] = geometry
    if not pending:
        return previous or {'version': VERSION, 'bindings': {}, 'skipped': record['skipped']}
    _update(context, armature)
    expected = {pb.name: pb.matrix.copy() for pb in armature.pose.bones}
    try:
        for name, geometry in pending.items():
            if geometry is None and not clip_endpoints:
                _create_widget(context, armature, record, name, record['bindings'][name])
            else:
                _create_widget(context, armature, record, name, record['bindings'][name],
                               geometry=geometry, organize=not clip_endpoints)
        armature.data[RECORD_KEY] = json.dumps(record)
        if set(marker) != before_detached:
            if marker:
                armature.data[NATIVE_DISPLAY_KEY] = json.dumps(marker, sort_keys=True, separators=(',', ':'))
            else:
                armature.data.pop(NATIVE_DISPLAY_KEY, None)
        _update(context, armature)
        _verify_pose(armature, expected)
        if clip_endpoints:
            validate(armature, inventory, allow_detached_missing=True)
        else:
            validate(armature, inventory)
    except Exception:
        for name, state in originals.items():
            _limb()._restore_pose_shape_state(armature, armature.pose.bones[name], state, runtime=True)
        _delete_resources(record, pending)
        if before_raw is None:
            armature.data.pop(RECORD_KEY, None)
        else:
            armature.data[RECORD_KEY] = before_raw
        if before_marker is None:
            armature.data.pop(NATIVE_DISPLAY_KEY, None)
        else:
            armature.data[NATIVE_DISPLAY_KEY] = before_marker
        _update(context, armature)
        raise
    return record


apply = build


def _refuse_dependencies(armature, record):
    collection = bpy.data.collections[record['collection']]
    objects = {entry['object']: name for name, entry in record['bindings'].items()}
    if (collection.children or collection.users > 1
            or set(collection.objects.keys()) != set(objects)):
        raise _error('The FK ring widget collection contains artist data or is shared; separate it before removal.')
    for entry in record['bindings'].values():
        obj = bpy.data.objects[entry['object']]
        if (obj.data.users != 1 or obj.users > 2 or tuple(obj.users_collection) != (collection,)
                or obj.animation_data is not None or obj.data.animation_data is not None):
            raise _error('An FK ring widget is shared or animated; preserve that use before removal.')
    for obj in bpy.data.objects:
        if obj.type != 'ARMATURE':
            continue
        for pb in obj.pose.bones:
            if (pb.custom_shape and pb.custom_shape.name in objects
                    and (obj != armature or pb.name != objects[pb.custom_shape.name])):
                raise _error('An FK ring widget is used by another bone; preserve that use before removal.')
    for name in record['bindings']:
        if _animated_display(armature, armature.pose.bones[name]):
            raise _error('An FK ring display has animation or drivers; preserve those channels before removal.')


def remove(context, armature):
    """Restore the exact preceding display state and delete only owned widgets."""
    from . import control_colors
    _active(context, armature)
    record = validate(armature)
    if record is None:
        return {'removed': 0}
    _refuse_dependencies(armature, record)
    _update(context, armature)
    expected = {pb.name: pb.matrix.copy() for pb in armature.pose.bones}
    before = {name: _limb()._pose_shape_runtime_state(armature.pose.bones[name]) for name in record['bindings']}
    try:
        for name, entry in record['bindings'].items():
            _limb()._restore_pose_shape_state(armature, armature.pose.bones[name], entry['original'])
        _update(context, armature)
        _verify_pose(armature, expected)
    except Exception:
        for name, state in before.items():
            _limb()._restore_pose_shape_state(armature, armature.pose.bones[name], state, runtime=True)
        _update(context, armature)
        raise
    _delete_resources(record, record['bindings'])
    del armature.data[RECORD_KEY]
    armature.data.pop(NATIVE_DISPLAY_KEY, None)
    control_colors.cleanup(armature)
    return {'removed': len(record['bindings'])}


def has_ik_size_backup(armature):
    return bool(armature and armature.type == 'ARMATURE' and IK_SIZE_RECORD_KEY in armature.data)


def _size_record(armature):
    raw = armature.data.get(IK_SIZE_RECORD_KEY)
    if raw is None:
        return None
    try:
        record = json.loads(raw)
        if (record['version'] != VERSION or not isinstance(record['bindings'], dict)
                or not record['bindings']
                or record['armature_id'] != armature.data.get(_limb().ARMATURE_ID_KEY)):
            raise ValueError('unsupported structure')
        for name, entry in record['bindings'].items():
            if (not isinstance(name, str) or not isinstance(entry['object'], str)
                    or not isinstance(entry['transform'], str)
                    or entry['factor'] not in {.8, .55}):
                raise ValueError('invalid size binding')
            for key in ('original', 'fitted'):
                _limb()._shape_vector({'scale': entry[key]}, 'scale', 'Saved IK control size')
        return record
    except (KeyError, TypeError, ValueError) as exc:
        raise _error('IK control-size recovery data is invalid; restore a saved copy.') from exc


def _validate_size_binding(armature, record, name, entry):
    pb = armature.pose.bones.get(name)
    if (pb is None or pb.bone.get(_limb().OWNER_KEY) != _limb().OWNER_VALUE
            or pb.bone.get(_limb().ARMATURE_ID_KEY) != record['armature_id']
            or pb.custom_shape is None or pb.custom_shape.name != entry['object']
            or (pb.custom_shape_transform.name if pb.custom_shape_transform else '') != entry['transform']
            or _limb()._control_shape_style(pb.bone) != 'DEFAULT'
            or not _limb()._shape_values_match(pb.custom_shape_scale_xyz, entry['fitted'])):
        raise _error(f"Fitted IK control '{name}' was edited; restore its fitted size and default shape before restoring its previous size.")
    if _animated_display(armature, pb):
        raise _error(f"Fitted IK control '{name}' has animated display settings; preserve those channels first.")
    return pb


def fit_ik_sizes(context, armature):
    """Explicitly shrink only default hand shapes and knee poles, with backups.

    The core's saved visual defaults remain unchanged. Translation, rotation,
    Custom Shape Transform and every pose channel remain untouched.
    """
    _active(context, armature)
    inventory = _limb()._validate_inventory(armature)
    previous = _size_record(armature)
    record = json.loads(json.dumps(previous)) if previous else {
        'version': VERSION, 'armature_id': inventory['armature_id'], 'bindings': {},
    }
    for name, entry in record['bindings'].items():
        _validate_size_binding(armature, record, name, entry)
    pending, skipped = {}, {}
    for (kind, side), rig in inventory['rigs'].items():
        name, factor = (rig['target'].name, .8) if kind == 'ARM' else (rig['pole'].name, .55)
        if name in record['bindings']:
            continue
        pb = armature.pose.bones[name]
        if _limb()._control_shape_style(pb.bone) != 'DEFAULT':
            skipped[name] = 'A custom shape style is selected'
            continue
        raw = pb.bone.get(_limb().CONTROL_VISUAL_DEFAULT_KEY)
        if raw is None:
            skipped[name] = 'No saved default-size evidence'
            continue
        default = _limb()._parse_control_visual_state(raw, f"Control '{name}'")
        if not _limb()._shape_values_match(pb.custom_shape_scale_xyz, default['scale']):
            skipped[name] = 'Artist-edited custom-shape size'
            continue
        if _animated_display(armature, pb):
            skipped[name] = 'Animated custom-shape display'
            continue
        original = list(pb.custom_shape_scale_xyz)
        pending[name] = {'original': original, 'fitted': [value * factor for value in original],
                         'object': pb.custom_shape.name, 'factor': factor,
                         'transform': pb.custom_shape_transform.name if pb.custom_shape_transform else ''}
    if not pending:
        return {'fitted': 0, 'skipped': skipped, 'retained': len(record['bindings'])}
    _update(context, armature)
    expected = {pb.name: pb.matrix.copy() for pb in armature.pose.bones}
    before_raw = armature.data.get(IK_SIZE_RECORD_KEY)
    try:
        for name, entry in pending.items():
            armature.pose.bones[name].custom_shape_scale_xyz = entry['fitted']
        record['bindings'].update(pending)
        armature.data[IK_SIZE_RECORD_KEY] = json.dumps(record)
        _update(context, armature)
        _verify_pose(armature, expected)
        for name, entry in record['bindings'].items():
            _validate_size_binding(armature, record, name, entry)
    except Exception:
        for name, entry in pending.items():
            armature.pose.bones[name].custom_shape_scale_xyz = entry['original']
        if before_raw is None:
            armature.data.pop(IK_SIZE_RECORD_KEY, None)
        else:
            armature.data[IK_SIZE_RECORD_KEY] = before_raw
        _update(context, armature)
        raise
    return {'fitted': len(pending), 'skipped': skipped, 'retained': len(record['bindings']) - len(pending)}


def restore_ik_sizes(context, armature):
    """Restore only unchanged, recorded size fits; never overwrite artist edits."""
    _active(context, armature)
    record = _size_record(armature)
    if record is None:
        return {'restored': 0}
    for name, entry in record['bindings'].items():
        _validate_size_binding(armature, record, name, entry)
    _update(context, armature)
    expected = {pb.name: pb.matrix.copy() for pb in armature.pose.bones}
    try:
        for name, entry in record['bindings'].items():
            armature.pose.bones[name].custom_shape_scale_xyz = entry['original']
        _update(context, armature)
        _verify_pose(armature, expected)
    except Exception:
        for name, entry in record['bindings'].items():
            armature.pose.bones[name].custom_shape_scale_xyz = entry['fitted']
        _update(context, armature)
        raise
    del armature.data[IK_SIZE_RECORD_KEY]
    return {'restored': len(record['bindings'])}
