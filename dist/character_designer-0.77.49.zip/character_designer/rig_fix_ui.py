"""Small placement and display adjustments, separate from rig construction."""
from bpy.types import Operator, Panel

from .ui_constants import SIDEBAR_CATEGORY, rig_page_active


class CHARACTERDESIGNER_OT_fix_show_body_controls(Operator):
    bl_idname = 'character_designer.fix_show_body_controls'
    bl_label = 'Show Body Controls'
    bl_description = 'Show existing body controls and their custom shapes without moving or rebuilding the rig'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        from . import body_original_mode

        rig = getattr(context, 'object', None)
        return bool(rig and rig.type == 'ARMATURE'
                    and context.mode in {'OBJECT', 'POSE'}
                    and rig.is_editable and not rig.library
                    and not rig.override_library and not rig.data.library
                    and not body_original_mode.active(rig))

    def execute(self, context):
        from . import bone_display

        try:
            bone_display.show_controls(context, bone_display.character_rig(context),
                                       role='BODY', toggle=False)
            self.report({'INFO'}, 'Body controls shown; custom shapes kept.')
            return {'FINISHED'}
        except (ValueError, RuntimeError, TypeError, KeyError, ReferenceError) as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}


def _draw_body_controls(layout, context):
    from . import bone_display, body_original_mode

    box = layout.box()
    box.label(text='Control Visibility', icon='HIDE_OFF')
    try:
        rig = bone_display.character_rig(context)
        if rig is None:
            box.label(text='Select the character or set Main Rig.', icon='INFO')
            return
        original = body_original_mode.active(rig)
        collection = bone_display.groups.body_collection(rig)
        row = box.row()
        row.enabled = bool(collection and not original
                           and CHARACTERDESIGNER_OT_fix_show_body_controls.poll(context))
        row.operator('character_designer.fix_show_body_controls',
                     text='Show Body Controls', icon='ARMATURE_DATA')
        if original:
            box.label(text='Choose Controls in Bone Display first.', icon='INFO')
        elif collection is None:
            box.label(text='Set up body controls first.', icon='INFO')
        box.label(text='Display only; keeps custom shapes.')
    except (ValueError, RuntimeError, TypeError, KeyError, ReferenceError) as exc:
        box.label(text=str(exc), icon='ERROR')


class CHARACTERDESIGNER_PT_rig_fix(Panel):
    bl_idname = 'CHARACTERDESIGNER_PT_rig_fix'
    bl_label = 'Fix'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = SIDEBAR_CATEGORY
    bl_parent_id = 'CHARACTERDESIGNER_PT_main'
    bl_order = 2

    @classmethod
    def poll(cls, context):
        return rig_page_active(context, 'FIX')

    def draw(self, context):
        from . import character_ground

        layout = self.layout
        layout.label(text='Moves meshes, rig and controls together.')
        character_ground.draw(layout, context)
        _draw_body_controls(layout, context)


RIG_FIX_UI_CLASSES = (
    CHARACTERDESIGNER_OT_fix_show_body_controls,
    CHARACTERDESIGNER_PT_rig_fix,
)
