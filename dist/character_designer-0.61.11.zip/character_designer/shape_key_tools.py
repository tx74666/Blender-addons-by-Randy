"""Safe local cleanup tools for accidental Shape Key deformation."""

from dataclasses import dataclass
import traceback

import bmesh
import bpy
from bpy.types import Operator, Panel

from .ui_constants import SIDEBAR_CATEGORY, UI_PAGE_MISC, active_ui_page


class ShapeKeyCleanupError(ValueError):
    """An artist-facing Shape Key cleanup preflight or write failure."""


@dataclass(frozen=True)
class ShapeKeyClearPlan:
    obj: object
    key_names: tuple
    vertex_indices: tuple
    before: tuple
    targets: tuple
    changed_count: int


def _active_edit_mesh(context):
    if context.mode != "EDIT_MESH":
        raise ShapeKeyCleanupError("Use Shape Key cleanup in Mesh Edit Mode.")
    obj = context.view_layer.objects.active if context.view_layer else None
    if obj is None or obj.type != "MESH" or context.object is not obj:
        raise ShapeKeyCleanupError("Make one Mesh active in Edit Mode.")
    if obj.data.users != 1:
        raise ShapeKeyCleanupError(
            "The Mesh data is shared by multiple objects; make it Single User first."
        )
    return obj


def _selected_vertex_indices(obj):
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.verts.index_update()
    indices = tuple(sorted(vertex.index for vertex in bm.verts if vertex.select))
    if not indices:
        raise ShapeKeyCleanupError("Select the vertices whose Shape Key deformation should be cleared.")
    return indices


def _key_data_coordinates(key, indices):
    try:
        return tuple(key.data[index].co.copy() for index in indices)
    except (IndexError, TypeError) as exc:
        raise ShapeKeyCleanupError(
            f'Shape Key "{key.name}" does not match the Mesh vertex count.'
        ) from exc


def build_shape_key_clear_plan(context, *, all_keys=False):
    obj = _active_edit_mesh(context)
    shape_keys = obj.data.shape_keys
    if shape_keys is None or not shape_keys.key_blocks:
        raise ShapeKeyCleanupError("The active Mesh has no Shape Keys.")
    if not shape_keys.use_relative:
        raise ShapeKeyCleanupError(
            "This cleanup currently supports relative Shape Keys only; absolute keys were not changed."
        )

    reference = shape_keys.reference_key
    if all_keys:
        keys = tuple(key for key in shape_keys.key_blocks if key != reference)
        if not keys:
            raise ShapeKeyCleanupError("The Mesh has no editable Shape Keys besides its Basis.")
    else:
        key = obj.active_shape_key
        if key is None or key == reference:
            raise ShapeKeyCleanupError("Select an editable Shape Key, not Basis, as the active key.")
        keys = (key,)

    indices = _selected_vertex_indices(obj)
    before = []
    targets = []
    changed_count = 0
    for key in keys:
        if getattr(key, "lock_shape", False):
            raise ShapeKeyCleanupError(f'Shape Key "{key.name}" is locked; unlock it before clearing.')
        relative = key.relative_key
        if relative is None:
            raise ShapeKeyCleanupError(f'Shape Key "{key.name}" has no relative key.')
        # Capture all baselines before writing. This matters when one Shape Key
        # references another key that is also included in the All Keys action.
        original = _key_data_coordinates(key, indices)
        baseline = _key_data_coordinates(relative, indices)
        before.append((key.name, original))
        targets.append((key.name, baseline))
        changed_count += sum(
            1 for old, new in zip(original, baseline)
            if (old - new).length_squared > 1.0e-20
        )

    return ShapeKeyClearPlan(
        obj=obj,
        key_names=tuple(key.name for key in keys),
        vertex_indices=indices,
        before=tuple(before),
        targets=tuple(targets),
        changed_count=changed_count,
    )


def _write_records(obj, vertex_indices, records):
    for key_name, coordinates in records:
        key = obj.data.shape_keys.key_blocks.get(key_name)
        if key is None:
            raise ShapeKeyCleanupError(f'Shape Key "{key_name}" disappeared during cleanup.')
        for index, coordinate in zip(vertex_indices, coordinates):
            key.data[index].co = coordinate


def apply_shape_key_clear_plan(plan):
    obj = plan.obj
    if bpy.context.view_layer.objects.active is not obj or bpy.context.object is not obj:
        raise ShapeKeyCleanupError("The active Mesh changed; select the same Mesh and try again.")
    if obj.mode != "EDIT":
        raise ShapeKeyCleanupError("The Mesh left Edit Mode; run Shape Key cleanup again.")
    current_indices = _selected_vertex_indices(obj)
    if current_indices != plan.vertex_indices:
        raise ShapeKeyCleanupError("The vertex selection changed; run Shape Key cleanup again.")

    try:
        _write_records(obj, plan.vertex_indices, plan.targets)
        obj.data.update()
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        for key_name, expected in plan.targets:
            key = obj.data.shape_keys.key_blocks.get(key_name)
            actual = _key_data_coordinates(key, plan.vertex_indices)
            if any((got - want).length_squared > 1.0e-20 for got, want in zip(actual, expected)):
                raise ShapeKeyCleanupError(f'Shape Key "{key_name}" verification failed.')
    except Exception as exc:
        try:
            _write_records(obj, plan.vertex_indices, plan.before)
            obj.data.update()
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception as rollback:
            raise ShapeKeyCleanupError(
                f"Shape Key cleanup failed ({exc}); rollback also failed ({rollback})."
            ) from rollback
        raise ShapeKeyCleanupError(f"Shape Key cleanup was rolled back: {exc}") from exc
    return plan


class _ShapeKeyClearOperator(Operator):
    bl_options = {"REGISTER", "UNDO"}
    clear_all = False

    @classmethod
    def poll(cls, context):
        return (
            active_ui_page(context) == UI_PAGE_MISC
            and context.mode == "EDIT_MESH"
            and context.view_layer is not None
            and context.view_layer.objects.active is not None
            and context.view_layer.objects.active.type == "MESH"
        )

    def execute(self, context):
        try:
            plan = build_shape_key_clear_plan(context, all_keys=self.clear_all)
            apply_shape_key_clear_plan(plan)
        except ShapeKeyCleanupError as exc:
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}
        except Exception as exc:
            traceback.print_exc()
            self.report({"ERROR"}, f"Shape Key cleanup failed safely: {exc}")
            return {"CANCELLED"}

        scope = "all editable Shape Keys" if self.clear_all else plan.key_names[0]
        if plan.changed_count:
            self.report(
                {"INFO"},
                f"Cleared {plan.changed_count} selected Shape Key point(s) from {scope}; Undo available.",
            )
        else:
            self.report({"INFO"}, f"Selected vertices already match their relative key in {scope}.")
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_clear_shape_key_selected(_ShapeKeyClearOperator):
    bl_idname = "character_designer.clear_shape_key_selected"
    bl_label = "Clear Selected from Active Key"
    bl_description = "Restore selected vertices in the active Shape Key to its relative key"


class CHARACTERDESIGNER_OT_clear_shape_keys_selected(_ShapeKeyClearOperator):
    bl_idname = "character_designer.clear_shape_keys_selected"
    bl_label = "Clear Selected from All Keys"
    bl_description = "Restore selected vertices in every editable relative Shape Key to its relative key"
    clear_all = True


class CHARACTERDESIGNER_PT_shape_key_tools(Panel):
    bl_label = "Shape Key"
    bl_idname = "CHARACTERDESIGNER_PT_shape_key_tools"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = SIDEBAR_CATEGORY
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return active_ui_page(context) == UI_PAGE_MISC

    def draw(self, context):
        layout = self.layout
        layout.label(text="Clear accidental selected-vertex deformation", icon="SHAPEKEY_DATA")
        layout.operator(
            "character_designer.clear_shape_key_selected",
            text="Clear Selected from Active Key",
            icon="KEY_HLT",
        )
        layout.operator(
            "character_designer.clear_shape_keys_selected",
            text="Clear Selected from All Keys",
            icon="KEYINGSET",
        )


SHAPE_KEY_CLASSES = (
    CHARACTERDESIGNER_OT_clear_shape_key_selected,
    CHARACTERDESIGNER_OT_clear_shape_keys_selected,
    CHARACTERDESIGNER_PT_shape_key_tools,
)
