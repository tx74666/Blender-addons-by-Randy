"""Bounded, in-place rotation keys for one admitted Custom wrist reset.

No Action copy/rebinding or worklist publication. Rollback retains existing
FCurve identities and restores all key/handle settings, including UI selection.
"""
import math


def _require(value, message):
    if not value:
        raise ValueError(message)


def _settings(value):
    result = {}
    for prop in value.bl_rna.properties:
        if prop.is_readonly or prop.type not in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM'}:
            continue
        name = prop.identifier
        item = getattr(value, name)
        result[name] = tuple(item) if getattr(prop, 'is_array', False) else item
    return result


def _assign(value, settings):
    for name, item in settings.items():
        setattr(value, name, item)


def _point(point):
    return _settings(point)


def _curve(curve):
    _require(not curve.modifiers and not curve.sampled_points and not curve.lock
             and not (curve.group and curve.group.lock),
             'Unlock this wrist rotation curve and remove its modifiers/samples before resetting with Auto Key.')
    _require(len(curve.keyframe_points) <= 20001,
             'This wrist rotation curve is too large for one reset transaction.')
    points = [_point(p) for p in curve.keyframe_points]
    _require(all(math.isfinite(float(v)) for p in points for name in ('co', 'handle_left', 'handle_right')
                 for v in p[name]), 'The wrist rotation curve contains non-finite keys.')
    return dict(curve=curve, settings=_settings(curve), points=points, group=curve.group)


def _restore_curve(saved):
    curve, points = saved['curve'], saved['points']
    # Rebuilding key points leaves the existing FCurve and group identity intact.
    curve.keyframe_points.clear()
    curve.keyframe_points.add(len(points))
    for point, values in zip(curve.keyframe_points, points):
        point.co = values['co']
        for name, item in values.items():
            if name not in {'co', 'handle_left', 'handle_right'}:
                setattr(point, name, item)
    curve.update()
    # Updating AUTO handles may recalculate them. Restore saved handles last.
    for point, values in zip(curve.keyframe_points, points):
        point.handle_left = values['handle_left']
        point.handle_right = values['handle_right']
    _assign(curve, saved['settings'])
    if curve.group != saved['group']:
        curve.group = saved['group']


def _binding(plan):
    rig = plan['rig']
    ad = rig.animation_data
    _require(ad and ad.action is plan['action'] and ad.action_slot
             and ad.action_slot.handle == plan['slot'],
             'The active Custom Action or slot changed; the wrist reset was cancelled.')


def _policy(context):
    edit, settings = context.preferences.edit, context.scene.tool_settings
    flags = tuple(bool(getattr(owner, name, False)) for owner, name in (
        (edit, 'use_keyframe_insert_available'), (edit, 'use_auto_keyframe_insert_needed'),
        (edit, 'use_visual_keying'), (settings, 'use_keyframe_cycle_aware'),
        (settings, 'use_keyframe_insert_keyingset')))
    _require(not any(flags[2:]),
             'Disable Visual, Cycle Aware and Only Active Keying Set options before resetting a wrist with Auto Key.')
    return (settings.auto_keying_mode, getattr(settings, 'keyframe_type', 'KEYFRAME'),
            getattr(edit, 'keyframe_new_interpolation_type', None),
            getattr(edit, 'keyframe_new_handle_type', None), flags)


def validate_keying(context, plan):
    domain = plan.get('key_domain')
    if domain is not None:
        _binding(plan)
        _require(_policy(context) == domain['policy'],
                 'The Auto Key options changed after wrist preparation.')


def prepare_keying(context, plan):
    """Read-only admission/snapshot before the target's first rotation write."""
    plan['key_domain'] = None
    if not plan['autokey']:
        return
    action, rig, api, offset = (plan[k] for k in ('action', 'rig', 'api', 'offset'))
    _require(action is not None and plan.get('variant') is not None,
             'Auto Key needs the editable Custom version of this animation.')
    _binding(plan)
    _require(context.scene.keying_sets.active is None,
             'Disable the active Keying Set before resetting an IK wrist with Auto Key.')
    policy = _policy(context)
    mode = context.scene.tool_settings.auto_keying_mode
    _require(mode in {'ADD_REPLACE_KEYS', 'REPLACE_KEYS'}, 'Unsupported Auto Key mode; no wrist was changed.')
    # Worklist pointers may also own the Action; another animated Object or
    # an NLA strip may not receive an in-place edit through this rig.
    for obj in api.bpy.data.objects:
        ad = obj.animation_data
        _require(not (obj is not rig and ad and ad.action is action),
                 'This Custom Action is shared with another animated object; make its own Custom version first.')
        _require(not (ad and any(strip.action is action for track in ad.nla_tracks for strip in track.strips)),
                 'This Custom Action is also used by NLA; use an independent Custom version first.')
    owners = api.bpy.data.user_map(subset={action}).get(action, set())
    allowed_owners = {rig, context.scene}
    if plan['variant']['revision_value'] is not None:
        # validate() has authenticated this exact immutable checkpoint and its
        # current row. Its retained Custom reference is a legitimate ID user.
        api.revision.validate(context, plan['variant']['item_id'])
        allowed_owners.add(action[api.revision.CHECKPOINT])
    _require(all(owner in allowed_owners for owner in owners),
             'This Custom Action has another data owner; use an independent Custom version first.')
    scene_animation = context.scene.animation_data
    _require(not (scene_animation and (scene_animation.action is action or any(strip.action is action
                 for track in scene_animation.nla_tracks for strip in track.strips))),
             'This Custom Action also animates the Scene; use an independent Custom version first.')
    _require(not any(con.type == 'ACTION' and con.action is action for con in rig.constraints)
             and not any(con.type == 'ACTION' and con.action is action
                         for pb in rig.pose.bones for con in pb.constraints),
             'This Custom Action is also used by an Action constraint; use an independent Custom version first.')
    bag = offset._bag(action, plan['slot'])
    path = plan['target'].path_from_id(plan['rotation_path'])
    curves = [c for c in bag.fcurves if c.data_path == path]
    _require(len({c.array_index for c in curves}) == len(curves)
             and all(0 <= c.array_index < plan['rotation_size'] for c in curves),
             'The wrist has ambiguous rotation curves; no keys were changed.')
    saved = [_curve(c) for c in curves]
    if policy[4][0]:
        _require(len(curves) == plan['rotation_size'],
                 'Only Insert Available needs existing wrist rotation channels; insert a rotation key first or disable that option.')
    if mode == 'REPLACE_KEYS':
        _require(len(curves) == plan['rotation_size'] and all(any(abs(float(p.co[0])-plan['frame']) < 1e-5
                 for p in c.keyframe_points) for c in curves),
                 'Replace Keys needs an existing wrist rotation key on this frame.')
    plan['key_domain'] = dict(bag=bag, path=path, saved=saved,
        curves=tuple(c.as_pointer() for c in bag.fcurves),
        groups=tuple(g.as_pointer() for g in bag.groups), mode=mode, policy=policy, closed=False)


def _restore_domain(plan):
    domain = plan['key_domain']
    if domain['closed']:
        return
    _binding(plan)
    bag = domain['bag']
    batch_paths = plan.get('key_batch_paths', ())
    for curve in list(bag.fcurves):
        if curve.as_pointer() not in domain['curves']:
            if curve.data_path != domain['path'] and curve.data_path in batch_paths:
                continue  # Its authenticated sibling domain restores it next.
            _require(curve.data_path == domain['path'], 'An unrelated curve appeared during wrist keying; recovery was retained.')
            bag.fcurves.remove(curve)
    for saved in domain['saved']:
        _restore_curve(saved)
    for group in list(bag.groups):
        if group.as_pointer() not in domain['groups']:
            if group.channels and batch_paths and all(c.data_path in batch_paths for c in group.channels):
                continue
            _require(not group.channels, 'A new animation group gained unrelated keys; recovery was retained.')
            bag.groups.remove(group)
    for saved in domain['saved']:
        curve = saved['curve']
        _require(_settings(curve) == saved['settings'] and curve.group == saved['group']
                 and [_point(point) for point in curve.keyframe_points] == saved['points'],
                 'The original wrist curve settings, keys or handles did not restore exactly.')


def _verify_domain(plan):
    domain = plan['key_domain']
    if domain['closed']:
        return
    _binding(plan)
    api, offset = plan['api'], plan['offset']
    expected = plan['variant']['hashes']
    _require(all(offset._action_hash(api, plan['action'], handle) == digest
                 for handle, digest in expected.items()), 'The original Custom key recovery did not verify.')
    domain['closed'] = True


def _rollback(plan):
    _restore_domain(plan)
    _verify_domain(plan)


def key_rotation(context, plan):
    """Insert only the active representation's rotation into the current slot."""
    domain = plan.get('key_domain')
    if domain is None:
        return False
    validate_keying(context, plan)
    # Install recovery before native insertion: keyframe_insert can partially
    # write several components before reporting a later component failure.
    plan['key_rollback'] = lambda: _rollback(plan)
    plan['key_restore'] = lambda: _restore_domain(plan)
    plan['key_verify'] = lambda: _verify_domain(plan)
    plan['key_commit'] = lambda: domain.update(closed=True)
    options = {'INSERTKEY_REPLACE'} if domain['mode'] == 'REPLACE_KEYS' else set()
    if domain['policy'][4][0]:
        options.add('INSERTKEY_AVAILABLE')
    if domain['policy'][4][1]:
        options.add('INSERTKEY_NEEDED')
    inserted = plan['target'].keyframe_insert(data_path=plan['rotation_path'], frame=plan['frame'],
                                         group=plan['target'].name, options=options,
                                         keytype=domain['policy'][1])
    curves = [c for c in domain['bag'].fcurves if c.data_path == domain['path']]
    values = getattr(plan['target'], plan['rotation_path'])
    needed = domain['policy'][4][1]
    _require((inserted or needed) and len(curves) == plan['rotation_size'] and all(
             abs(float(c.evaluate(plan['frame']))-float(values[c.array_index])) < 2e-6
             and (needed or any(abs(float(p.co[0])-plan['frame']) < 1e-5
                    and abs(float(p.co[1])-float(values[c.array_index])) < 2e-6 for p in c.keyframe_points))
             for c in curves),
             'The wrist rotation key did not verify; its previous keys were restored.')
    variant, api, offset = plan['variant'], plan['api'], plan['offset']
    _require(offset._action_hash(api, variant['source'], variant['source_slot']) == variant['source_hash'],
             'The Source changed during wrist keying; recovery was retained.')
    if variant['revision_value'] is not None:
        api.revision.validate(context, variant['item_id'])
    return True
