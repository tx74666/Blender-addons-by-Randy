"""Explicit IK wrist neutral, preserving native FK inputs and the existing rig.

Only the visible target's active rotation representation is written. Raw target
zero is not redefined: this operation solves the compensation that makes the
native hand look like its own FK Alt-R at the current solved forearm pose.
"""
import math

PLAN_API = 1
MAX_ITERATIONS = 8
ROTATION_TOLERANCE = 3e-5
POSITION_TOLERANCE = 2e-5
SCALE_TOLERANCE = 2e-5
MATRIX_TOLERANCE = 4e-4
_TRANSFORMS = ('location', 'rotation_euler', 'rotation_quaternion', 'rotation_axis_angle', 'scale')
_EULER = {'XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'}


def _require(value, message):
    if not value:
        raise ValueError(message)


def _backend():
    from . import control_pose_offset, animation_physics
    return control_pose_offset, control_pose_offset._modules(), animation_physics


def _keying():
    from . import limb_ik_wrist_keying
    return limb_ik_wrist_keying


def _key_rotation(context, plan):
    """The key service owns its exact in-place curve transaction, never a row."""
    return _keying().key_rotation(context, plan)


def _fault(phase):
    """Inert seam for actual-write and post-key rollback validation."""
    return None


def _same(first, last):
    if first is last:
        return True
    return (first is not None and last is not None and hasattr(first, 'as_pointer')
            and hasattr(last, 'as_pointer') and first.as_pointer() == last.as_pointer())


def _rotation_path(mode):
    _require(mode in _EULER | {'QUATERNION', 'AXIS_ANGLE'}, 'Unsupported wrist rotation representation.')
    return 'rotation_quaternion' if mode == 'QUATERNION' else 'rotation_axis_angle' if mode == 'AXIS_ANGLE' else 'rotation_euler'


def _raw(rig):
    return {pb.name: dict(mode=pb.rotation_mode, ik_fk=pb.get('ik_fk'),
                         **{key: tuple(getattr(pb, key)) for key in _TRANSFORMS}) for pb in rig.pose.bones}


def _object_raw(rig):
    return (rig.rotation_mode, *(tuple(getattr(rig, key)) for key in _TRANSFORMS))


def _frame(context):
    return float(context.scene.frame_current + context.scene.frame_subframe)


def _physics_idle(context, rig, physics):
    state = physics.status(context)
    if state.get('rig') is rig:
        _require(state.get('valid'), 'Resolve the Physics error before resetting the wrist.')
    hair = state.get('hair', {})
    _require(not hair.get('running') and not hair.get('pending_recovery') and
             not any(row.get('running') or row.get('pending_recovery') for row in state.get('dresses', ())),
             'Pause Hair and Dress physics and finish their recovery before resetting the wrist.')


def _mirror_flags(rig):
    return bool(getattr(rig.pose, 'use_mirror_x', False)), bool(getattr(rig.data, 'use_mirror_x', False))


def _input_policy(context, rig, *, mirror_allowed=False):
    _require(mirror_allowed or not _mirror_flags(rig)[0],
             'Pose mirroring needs the complete authenticated wrist pair.')
    _require(all(getattr(getattr(context.scene, name, None), 'active', None) is None
                 for name in ('keying_sets', 'keying_sets_all')),
             'Use the default keying policy before resetting wrist rotation.')


def _resolve(context, rig, limb, match, target):
    if target is None:
        target = getattr(context, 'active_pose_bone', None)
    if isinstance(target, str):
        target = rig.pose.bones.get(target)
    _require(target is not None and _same(rig.pose.bones.get(target.name), target),
             'Choose one owned hand IK target on the current rig.')
    inventory = limb._validate_inventory(rig)
    found = [(key, value) for key, value in inventory['rigs'].items()
             if key[0] == 'ARM' and _same(value['target'], target.bone)]
    _require(len(found) == 1, 'Choose one authenticated hand IK target, not a foot or helper.')
    key, entry = found[0]
    _require(match.mode_for_rig(rig, entry) == 'IK'
             and abs(float(target.get(match.PROPERTY, 1.)) - 1.) <= 1e-6,
             'This wrist must already be fully IK; its FK/IK mode was kept.')
    _require(not target.constraints, 'The hand target has an unsupported constraint.')
    _rotation_path(target.rotation_mode)
    _require(not any(target.lock_rotation) and not target.lock_rotation_w,
             'Unlock the hand target rotation before resetting the wrist.')
    end = rig.pose.bones[entry['chain'][2]]
    forearm = rig.pose.bones[entry['chain'][1]]
    _require(_same(end.parent, forearm) and _same(entry['solver_target'], target.bone),
             'This wrist uses an unsupported solver or native parent.')
    rotations = [(pb, con, record) for pb, con, record in entry['entries']
                 if record['role'] == 'END_ROTATION']
    _require(len(rotations) == 1 and _same(rotations[0][0], end), 'The wrist end-rotation owner changed.')
    end_rotation = rotations[0][1]
    offset = entry.get('auto_offset_rotation')
    _require(offset is not None, 'This wrist needs its existing authenticated rotation offset.')
    owned = [con for pb, con, _record in entry['entries'] if _same(pb, end)]
    _require(all(any(_same(con, expected) for expected in owned) for con in end.constraints),
             'The native hand has an unsupported constraint.')
    if entry['auto_align']:
        _require(entry.get('auto_rotation_space') == 'PARENT_DELTA' and end_rotation.mute
                 and not offset.mute and abs(float(offset.influence) - 1.) <= 1e-6,
                 'Use the authenticated parent-delta Auto wrist contract.')
    else:
        _require(not end_rotation.mute and offset.mute and end_rotation.target_space == 'WORLD'
                 and end_rotation.owner_space == 'WORLD' and abs(float(end_rotation.influence) - 1.) <= 1e-6,
                 'Use the authenticated WORLD Manual wrist contract.')
    paths = {target.path_from_id(prop) for prop in _TRANSFORMS}
    paths.add(match.property_path(target))
    animation = rig.animation_data
    _require(not any(curve.data_path in paths for curve in getattr(animation, 'drivers', ())),
             'A driver controls the hand target input; its values were kept.')
    return target, end, forearm, inventory, key, entry


def _admission(context, target=None, *, mirror_allowed=False):
    offset, api, physics = _backend()
    rig = getattr(context, 'object', None)
    _require(rig is not None and rig.type == 'ARMATURE', 'Choose the current local armature.')
    api.pose._admission(context, rig, _purpose='ANIMATION')
    _require(not api.pose.active(rig) and not api.pose.natural_active(rig),
             'Finish the Base Pose or static Rest test before resetting the wrist.')
    _require(not getattr(getattr(context, 'screen', None), 'is_animation_playing', False),
             'Pause playback before resetting the wrist.')
    _input_policy(context, rig, mirror_allowed=mirror_allowed)
    _physics_idle(context, rig, physics)
    target, end, forearm, inventory, key, entry = _resolve(context, rig, api.limb, api.match, target)
    animation = rig.animation_data
    action = animation.action if animation else None
    _require(not (animation and animation.use_nla and any(not track.mute and track.strips for track in animation.nla_tracks)),
             'Active NLA needs a separate wrist-editing workflow.')
    variant = None
    if action is not None:
        # Source and unrelated Action admission applies even with Auto Key off.
        variant = offset.prepare_variant(context, rig, label='Wrist Neutral')
    else:
        _require(not context.scene.tool_settings.use_keyframe_insert_auto,
                 'Choose an editable Custom Action before resetting the wrist with Auto Key.')
    return offset, api, physics, rig, target, end, forearm, inventory, key, entry, variant


def _matrix_finite(matrix):
    determinant = matrix.determinant()
    return all(math.isfinite(value) for row in matrix for value in row) and math.isfinite(determinant) and determinant > 1e-12


def _reference(api, rig, end):
    from mathutils import Matrix, Quaternion, Vector
    native = api.poses.native_rest(rig)
    desired = {name: rig.pose.bones[name].matrix.copy() for name in native}
    location = Vector((0., 0., 0.)) if end.bone.use_connect else end.location.copy()
    basis = Matrix.LocRotScale(location, Quaternion(), end.scale.copy())
    desired[end.name] = api.poses._convert(end.bone, basis, end.parent.matrix)
    descendants = {pb.name for pb in end.children_recursive if pb.name in native}
    for name in sorted(descendants, key=lambda n: len(rig.pose.bones[n].parent_recursive)):
        pb = rig.pose.bones[name]
        _require(not any(not con.mute for con in pb.constraints),
                 'A wrist descendant has a constraint outside the neutral reset scope.')
        desired[name] = api.poses._convert(pb.bone, pb.matrix_basis.copy(), desired[pb.parent.name])
    _require(all(_matrix_finite(matrix) for matrix in desired.values()),
             'The wrist neutral reference is singular, reflected or non-finite.')
    return desired


def _prepare_single(context, *, target=None, _batch_side=False):
    """Read-only preparation; the keying service must also admit before writes."""
    offset, api, physics, rig, target, end, forearm, inventory, key, entry, variant = _admission(
        context, target, mirror_allowed=_batch_side)
    _require(len(rig.pose.bones) <= 4096, 'This rig exceeds the bounded wrist-reset scope.')
    _require(_matrix_finite(rig.matrix_world), 'The armature world transform is singular, reflected or non-finite.')
    desired = _reference(api, rig, end)
    capture = api.target._capture(context, rig)
    api.target._validate_capture(context, capture)
    path = _rotation_path(target.rotation_mode)
    plan = dict(plan_api=PLAN_API, phase='prepared', context=context, api=api, offset=offset,
        batch_side=bool(_batch_side), mirror_flags=_mirror_flags(rig),
        rig=rig, data=rig.data, target=target, end=end, forearm=forearm, key=key, inventory=inventory, limb=entry,
        frame=_frame(context), autokey=bool(context.scene.tool_settings.use_keyframe_insert_auto),
        action=rig.animation_data.action if rig.animation_data else None,
        slot=variant['slot'] if variant is not None else None, variant=variant, capture=capture,
        rotation_mode=target.rotation_mode, rotation_path=path, rotation_size=3 if path == 'rotation_euler' else 4,
        before_raw=_raw(rig), object_raw=_object_raw(rig), wanted_native=desired,
        structure=api.pose._structure(rig), target_position=target.matrix.translation.copy(),
        pole_matrix=rig.pose.bones[entry['pole'].name].matrix.copy(), world_matrix=rig.matrix_world.copy(),
        context_mode=context.mode, active=context.view_layer.objects.active,
        selected=tuple(context.selected_objects), key_rollback=None, key_commit=None)
    plan['unaffected'] = (offset._unaffected(api, plan['action'], plan['slot'],
        {(target.name, path, i) for i in range(plan['rotation_size'])}) if plan['action'] is not None else None)
    _keying().prepare_keying(context, plan)
    _unchanged_inputs(plan, allow_target_rotation=False)
    return plan


def prepare_wrist_neutral(context, *, target=None, targets=None):
    """Prepare one wrist, or the atomic pair required by selection/mirroring."""
    rig = getattr(context, 'object', None)
    if targets is not None or (rig is not None and getattr(getattr(rig, 'pose', None), 'use_mirror_x', False)):
        from . import limb_ik_wrist_batch
        return limb_ik_wrist_batch.prepare(context, target=target, targets=targets)
    return _prepare_single(context, target=target)


def _unchanged_inputs(plan, *, allow_target_rotation):
    rig, target = plan['rig'], plan['target']
    current = _raw(rig)
    expected = plan['before_raw']
    _require(set(current) == set(expected), 'The wrist rig structure changed.')
    for name in current:
        fields = set(current[name])
        if allow_target_rotation:
            allowed = plan.get('batch_rotations', {target.name: plan['rotation_path']})
            if name in allowed:
                fields.remove(allowed[name])
        _require(all(current[name][field] == expected[name][field] for field in fields),
                 'Another native or control input changed; the wrist reset was cancelled.')
    _require(_object_raw(rig) == plan['object_raw'], 'The armature transform changed.')


def _validate_plan(context, plan, *, _batch=False):
    _require(type(plan) is dict and plan.get('plan_api') == PLAN_API and plan.get('phase') == 'prepared'
             and plan.get('context') is context, 'Prepare this exact current wrist before resetting it.')
    _require(not plan.get('batch_side') or _batch, 'Apply this wrist through its complete prepared pair.')
    values = _admission(context, plan['target'], mirror_allowed=bool(_batch))
    _offset, api, _physics, rig, target, end, _parent, _inventory, key, _entry, _variant = values
    _require(rig is plan['rig'] and rig.data is plan['data'] and _same(target, plan['target'])
             and _same(end, plan['end']) and key == plan['key'] and _frame(context) == plan['frame']
             and bool(context.scene.tool_settings.use_keyframe_insert_auto) == plan['autokey'],
             'The prepared wrist, frame or Auto Key setting changed.')
    _require(_mirror_flags(rig) == plan['mirror_flags'], 'The wrist mirror options changed after preparation.')
    _require(api.pose._structure(rig) == plan['structure'], 'The wrist graph or native Rest changed.')
    if plan['variant'] is not None:
        plan['offset']._variant_owner(plan['variant'], final=True)
    else:
        _require(not rig.animation_data or rig.animation_data.action is None, 'An Action became active after preparation.')
    api.target._validate_capture(context, plan['capture'])
    _unchanged_inputs(plan, allow_target_rotation=False)
    _keying().validate_keying(context, plan)


def _rotation_error(actual, expected):
    delta = actual.to_quaternion().normalized().conjugated() @ expected.to_quaternion().normalized()
    return 2*math.atan2(math.hypot(delta.x, delta.y, delta.z), abs(delta.w))


def _assign_rotation(target, rotation):
    mode = target.rotation_mode
    if mode == 'QUATERNION':
        if rotation.dot(target.rotation_quaternion) < 0:
            rotation.negate()
        target.rotation_quaternion = rotation
    elif mode == 'AXIS_ANGLE':
        axis, angle = rotation.to_axis_angle()
        target.rotation_axis_angle = (angle, *axis)
    else:
        target.rotation_euler = rotation.to_euler(mode, target.rotation_euler)


def _solve(context, plan):
    from mathutils import Matrix
    rig, target, end = plan['rig'], plan['target'], plan['end']
    desired = plan['wanted_native'][end.name]
    for iteration in range(MAX_ITERATIONS):
        current = end.matrix.copy()
        _require(_matrix_finite(current) and _matrix_finite(target.matrix), 'The current wrist transform is invalid.')
        if _rotation_error(current, desired) <= 1e-6:
            return iteration
        delta = desired.to_quaternion().normalized() @ current.to_quaternion().normalized().inverted()
        posed = target.matrix.copy()
        wanted = Matrix.LocRotScale(posed.translation,
            (delta @ posed.to_quaternion().normalized()).normalized(), posed.to_scale())
        local = rig.convert_space(pose_bone=target, matrix=wanted, from_space='POSE', to_space='LOCAL')
        _require(_matrix_finite(local), 'The compensated target rotation cannot be represented safely.')
        _assign_rotation(target, local.to_quaternion())
        _fault('after_rotation_write')
        plan['api'].match._update(context, rig)
    return MAX_ITERATIONS


def _verify(context, plan):
    rig, api = plan['rig'], plan['api']
    api.target._validate_capture(context, plan['capture'])
    _unchanged_inputs(plan, allow_target_rotation=True)
    _require(api.pose._structure(rig) == plan['structure'] and _frame(context) == plan['frame'],
             'The wrist reset changed its graph, native Rest or frame.')
    _require(_mirror_flags(rig) == plan['mirror_flags'], 'The wrist reset changed a mirror option.')
    _require(context.mode == plan['context_mode'] and _same(context.view_layer.objects.active, plan['active'])
             and len(context.selected_objects) == len(plan['selected'])
             and all(any(_same(obj, before) for before in plan['selected']) for obj in context.selected_objects)
             and bool(context.scene.tool_settings.use_keyframe_insert_auto) == plan['autokey']
             and api.poses._difference(rig.matrix_world, plan['world_matrix']) <= 1e-7,
             'The wrist reset changed its context, Auto Key setting or armature world transform.')
    measurements = dict(position=0., rotation=0., scale=0., matrix=0.)
    for name, wanted in plan['wanted_native'].items():
        current = rig.pose.bones[name].matrix
        _require(_matrix_finite(current), 'The evaluated wrist pose is invalid.')
        measurements['matrix'] = max(measurements['matrix'], api.poses._difference(current, wanted))
        if name == plan['end'].name:
            actual_world, wanted_world = rig.matrix_world @ current, rig.matrix_world @ wanted
            _require(_matrix_finite(actual_world) and _matrix_finite(wanted_world), 'The world wrist pose is invalid.')
            measurements['position'] = math.hypot(*(a-b for a, b in zip(actual_world.translation, wanted_world.translation)))
            measurements['rotation'] = _rotation_error(actual_world, wanted_world)
            measurements['scale'] = math.hypot(*(a-b for a, b in zip(actual_world.to_scale(), wanted_world.to_scale())))
    _require(all(math.isfinite(value) for value in measurements.values())
             and measurements['matrix'] <= MATRIX_TOLERANCE and measurements['position'] <= POSITION_TOLERANCE
             and measurements['rotation'] <= ROTATION_TOLERANCE and measurements['scale'] <= SCALE_TOLERANCE,
             'The wrist cannot reach native FK neutral without another change; its original inputs were kept.')
    _require((plan['target'].matrix.translation - plan['target_position']).length <= POSITION_TOLERANCE
             and api.poses._difference(rig.pose.bones[plan['limb']['pole'].name].matrix, plan['pole_matrix']) <= MATRIX_TOLERANCE,
             'The wrist reset moved the hand target or Pole.')
    return measurements


def _rollback(context, plan):
    errors = []
    try:
        if plan.get('key_rollback') is not None:
            plan['key_rollback']()
    except Exception as error:
        errors.append('keys: ' + str(error))
    try:
        plan['api'].revision._restore_current(context, plan['rig'], plan['capture'], plan['api'].revision._modules())
    except Exception as error:
        errors.append('pose: ' + str(error))
    plan['phase'] = 'recovery_needed' if errors else 'rolled_back'
    _require(not errors, 'Owned wrist recovery needs review: ' + '; '.join(errors))


def apply_wrist_neutral(context, plan):
    if type(plan) is dict and plan.get('batch_api') is not None:
        from . import limb_ik_wrist_batch
        return limb_ik_wrist_batch.apply(context, plan)
    _validate_plan(context, plan)
    plan['phase'] = 'applying'
    try:
        iterations = _solve(context, plan)
        errors = _verify(context, plan)
        _fault('after_target_verification')
        keyed = _key_rotation(context, plan)
        _require(type(keyed) is bool and keyed == plan['autokey'], 'Wrist keying did not confirm the requested Auto Key policy.')
        _fault('after_key_rotation')
        errors = _verify(context, plan)
        if plan['action'] is not None:
            affected = {(plan['target'].name, plan['rotation_path'], i) for i in range(plan['rotation_size'])}
            _require(plan['offset']._unaffected(plan['api'], plan['action'], plan['slot'], affected) == plan['unaffected'],
                     'An unrelated native FK or other Action curve changed during wrist keying.')
        if plan['variant'] is not None:
            plan['offset']._variant_owner(plan['variant'], final=not plan['autokey'])
            if plan['variant']['revision_value'] is not None:
                plan['api'].revision.validate(context, plan['variant']['item_id'])
        if plan.get('key_commit') is not None:
            plan['key_commit']()
        plan['phase'] = 'applied'
        return dict(target=plan['target'].name, hand=plan['end'].name, key=plan['key'],
                    auto_align=bool(plan['limb']['auto_align']), keyed=keyed,
                    iterations=iterations, errors=errors, phase='applied')
    except Exception as error:
        try:
            _rollback(context, plan)
        except Exception as restore_error:
            raise RuntimeError(str(restore_error)) from error
        raise


def reset_wrist_neutral(context, *, target=None, targets=None):
    return apply_wrist_neutral(context, prepare_wrist_neutral(context, target=target, targets=targets))
