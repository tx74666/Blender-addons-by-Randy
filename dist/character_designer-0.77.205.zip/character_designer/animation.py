"""Local animation generation and explicit body Action application."""

from pathlib import Path

import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, Panel, PropertyGroup
from bpy.app.handlers import persistent

from .animation_runtime import DEFAULT_RUNTIME_ROOT, LocalMotionJob, read_runtime
from .ui_constants import SIDEBAR_CATEGORY, UI_PAGE_ANIMATION, active_ui_page


_job = None
_job_window_manager = None
_export_window_manager = None


def _armature_poll(_self, obj):
    return obj.type == "ARMATURE"


def _settings(context):
    return context.window_manager.character_designer_animation


def _main_rig(context):
    # Character Setup owns this saved choice. Reading it must not resolve to a
    # selection fallback or copy it into the transient animation settings.
    setup = getattr(context.scene, "character_designer_setup", None)
    return setup.rig if setup is not None else None


def _main_rig_error(context, rig):
    if rig.type != "ARMATURE" or rig.library is not None:
        return "Main Rig must be a local armature."
    if context.scene.objects.get(rig.name) != rig:
        return "Main Rig is not in this scene."
    return ""


def _target(context):
    worklist = getattr(context.scene, "character_designer_animation_worklist", None)
    if worklist is not None and worklist.workspace_path:
        rig = worklist.rig
        if (rig is not None and rig.type == "ARMATURE" and rig.library is None
                and context.scene.objects.get(rig.name) == rig):
            return rig
        return None
    rig = _main_rig(context)
    if rig is not None:
        return None if _main_rig_error(context, rig) else rig
    settings = _settings(context)
    if settings.target:
        return settings.target
    obj = context.object
    if obj and obj.type == "ARMATURE" and not obj.get("character_designer_motion_preview"):
        return obj
    return bpy.data.objects.get("CoshaRig")


def _redraw():
    for wm in bpy.data.window_managers:
        for window in wm.windows:
            if window.screen is None:
                continue
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    area.tag_redraw()


def _poll_job():
    global _job, _job_window_manager
    if _job is None:
        return None
    try:
        settings = _job_window_manager.character_designer_animation
        finished = _job.poll()
        settings.status = _job.status
        if finished:
            settings.result_path = _job.result_path
            settings.has_error = bool(_job.error)
            _job = None
            _job_window_manager = None
        _redraw()
        return None if finished else 0.5
    except Exception as exc:
        try:
            _job_window_manager.character_designer_animation.status = str(exc)
            _job_window_manager.character_designer_animation.has_error = True
        finally:
            stop_animation_runtime()
        return None


def _cancel_local_motion():
    """Release the owned worker only after its process has actually exited."""
    global _job, _job_window_manager
    if _job is not None:
        _job.cancel()
        _job.process.wait(timeout=5)
    _job, _job_window_manager = None, None


def stop_animation_runtime():
    global _job, _job_window_manager, _export_window_manager
    from . import animation_export
    from .animation_worklist_collection import stop as stop_collection
    stop_collection()
    if bpy.app.timers.is_registered(_poll_action_export):
        bpy.app.timers.unregister(_poll_action_export)
    animation_export.cancel_export()
    _export_window_manager = None
    if bpy.app.timers.is_registered(_poll_job):
        bpy.app.timers.unregister(_poll_job)
    _cancel_local_motion()


@persistent
def _animation_load_pre(_unused):
    stop_animation_runtime()


def register_animation_runtime():
    added_handler = _animation_load_pre not in bpy.app.handlers.load_pre
    if added_handler:
        bpy.app.handlers.load_pre.append(_animation_load_pre)
    try:
        from . import animation_action_browser
        animation_action_browser.register()
    except Exception:
        if added_handler and _animation_load_pre in bpy.app.handlers.load_pre:
            bpy.app.handlers.load_pre.remove(_animation_load_pre)
        raise


def unregister_animation_runtime():
    stop_animation_runtime()
    if _animation_load_pre in bpy.app.handlers.load_pre:
        bpy.app.handlers.load_pre.remove(_animation_load_pre)
    import sys
    browser = sys.modules.get(__package__ + '.animation_action_browser')
    if browser is not None:
        browser.unregister()


def _can_restore(context):
    from .animation_retarget import VERSION_KEY, TARGET_KEY
    from .unity_animation import active_preview
    target = _target(context)
    if target and active_preview(target):
        return True
    action = target.animation_data.action if target and target.animation_data else None
    return bool(action and action.get(VERSION_KEY) == 1 and action.get(TARGET_KEY) is target)


class CharacterDesignerAnimationState(PropertyGroup):
    target: PointerProperty(name="Character Rig", type=bpy.types.Object,
                            poll=_armature_poll, options={"SKIP_SAVE"})
    prompt: StringProperty(name="Motion", default="A person walks forward at a relaxed pace.",
                           description="Describe a short body action in English", options={"SKIP_SAVE"})
    duration: FloatProperty(name="Seconds", default=2.0, min=1.0, max=10.0, options={"SKIP_SAVE"})
    seed: IntProperty(name="Seed", default=42, min=0, options={"SKIP_SAVE"})
    start_frame: IntProperty(name="Start Frame", default=1, min=1, options={"SKIP_SAVE"})
    runtime_root: StringProperty(name="Kimodo Folder", default=DEFAULT_RUNTIME_ROOT,
                                 subtype="DIR_PATH", options={"SKIP_SAVE"})
    show_setup: BoolProperty(name="Local Setup", options={"SKIP_SAVE"})
    status: StringProperty(default="", options={"SKIP_SAVE"})
    has_error: BoolProperty(options={"SKIP_SAVE"})
    result_path: StringProperty(subtype="FILE_PATH", options={"SKIP_SAVE"})
    export_result_path: StringProperty(subtype="FILE_PATH", options={"SKIP_SAVE"})
    log_path: StringProperty(subtype="FILE_PATH", options={"SKIP_SAVE"})
    source: PointerProperty(type=bpy.types.Object, poll=_armature_poll, options={"SKIP_SAVE"})
    unity_directory: StringProperty(name="Unity Exchange Folder", subtype="DIR_PATH")
    show_unity_files: BoolProperty(name="Files", options={"SKIP_SAVE"})
    show_local_motion: BoolProperty(name="Local Motion Generation", options={"SKIP_SAVE"})


def unity_exchange_folder(context):
    settings = _settings(context)
    if settings.unity_directory:
        return Path(bpy.path.abspath(settings.unity_directory))
    target = _target(context)
    saved = target.get("character_designer_unity_animation_folder") if target else None
    if saved:
        return Path(saved)
    if bpy.data.filepath:
        return Path(bpy.data.filepath).parent.parent / "Animation" / "UnityExports"
    return Path.home() / "Documents" / "CharacterDesigner" / "UnityAnimations"


def latest_unity_animation(folder):
    files = list(Path(folder).glob("*.cdanim.json"))
    if not files:
        raise ValueError("Send an animation from Unity first, or select its .cdanim.json file.")
    return max(files, key=lambda path: (path.stat().st_mtime_ns, path.name))


def _track_action_export(context, job):
    """Give a launched job a poll owner, or dispose only that job on failure."""
    global _export_window_manager
    from . import animation_export
    timers = bpy.app.timers
    previous_owner = _export_window_manager
    registered_before = None
    try:
        registered_before = timers.is_registered(_poll_action_export)
        if registered_before:
            raise RuntimeError('Another Action export poll is still registered; retry after it finishes.')
        _export_window_manager = context.window_manager
        timers.register(_poll_action_export, first_interval=0.25)
    except Exception:
        try:
            if registered_before is False and timers.is_registered(_poll_action_export):
                timers.unregister(_poll_action_export)
        finally:
            try:
                animation_export.cancel_export(job)
            finally:
                _export_window_manager = previous_owner
        raise
    return job


def _poll_action_export():
    global _export_window_manager
    from . import animation_export
    job = animation_export.active_job()
    if job is None or job.get('composition_job'):
        return None
    settings, result, error = None, None, ''
    try:
        settings = _export_window_manager.character_designer_animation
    except (AttributeError, ReferenceError):
        pass
    try:
        result = animation_export.poll_export(job)
        if result is None:
            return 0.25
    except Exception as exc:
        if animation_export.active_job() is job:
            animation_export.cancel_export(job)
        error = str(exc)
    # Native completion has already published/disposed. A lost UI owner must
    # not cancel a real publication or prevent the serial queue from advancing.
    try:
        if settings is not None and result is not None:
            settings.export_result_path = result['filepath']
            if result.get('link_manifest'):
                settings.status = 'Synced ' + result['filepath'] + '. Preview and Apply the candidate in Unity.'
            else:
                settings.status = 'Exported skeletal Action: ' + result['filepath'] + '. Shape Keys and events are not included.'
            if result.get('unsupported_channels'):
                settings.status += ' Omitted: ' + '; '.join(result['unsupported_channels'])
            settings.has_error = False
        elif settings is not None:
            settings.status, settings.has_error = error, True
    except ReferenceError:
        settings = None
    from .animation_worklist_collection import export_finished
    receipt_error = export_finished(job, result, error)
    if receipt_error and settings is not None:
        settings.status, settings.has_error = receipt_error, True
    scene = job.get('_worklist_scene') if isinstance(job, dict) else None
    if scene is not None:
        try:
            worklist = scene.character_designer_animation_worklist
            if settings is None:
                if result is not None:
                    worklist.status = receipt_error or ('Synced ' + result['filepath'] + '. Preview and Apply the candidate in Unity.')
                    worklist.has_error = bool(receipt_error)
                else:
                    worklist.status = error or 'Action export stopped; its owner is no longer available.'
                    worklist.has_error = True
            else:
                worklist.status, worklist.has_error = settings.status, settings.has_error
        except ReferenceError:
            pass
    _export_window_manager = None
    _redraw()
    return None


def _link_import(context, manifest_path, model_file):
    from .animation_link_source import import_source
    settings = _settings(context)
    settings.status, settings.has_error = 'Importing linked character and Walk…', False
    _redraw()
    try:
        result = import_source(context, manifest_path, model_file, start_frame=settings.start_frame)
    except Exception as exc:
        settings.status, settings.has_error = str(exc), True
        _redraw()
        return None
    settings.target = result.rig
    settings.unity_directory = str(Path(manifest_path).resolve().parent)
    settings.status = 'Linked ' + result.action.name + '. Edit this Action, then click Send to Unity.'
    settings.has_error = False
    _redraw()
    return result


def _link_idle(*, include_collection=True):
    from . import animation_export, unity_export
    from .animation_worklist_collection import running as collection_running
    from .animation_worklist_ui import scan_pending
    return (_job is None and animation_export.active_job() is None
            and not unity_export.export_running() and not scan_pending()
            and (not include_collection or not collection_running()))


class CHARACTERDESIGNER_OT_animation_link_import(Operator):
    bl_idname = 'character_designer.animation_link_import'
    bl_label = 'Link / Import'
    bl_description = 'Open a Unity animation Link as an independent character and editable Action'
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default='character_animation_link.json;*.json', options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return _link_idle() and not (context.object and context.object.mode == 'EDIT')

    def invoke(self, context, _event):
        self.filepath = str(unity_exchange_folder(context) / 'character_animation_link.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        from .animation_link import load_link
        try:
            link = load_link(self.filepath)
        except Exception as exc:
            _settings(context).status, _settings(context).has_error = str(exc), True
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        model_file = link.get('modelFile') or ''
        if not model_file:
            bpy.ops.character_designer.animation_link_model('INVOKE_DEFAULT', manifest_path=self.filepath)
            return {'FINISHED'}
        return {'FINISHED'} if _link_import(context, self.filepath, model_file) else {'CANCELLED'}


class CHARACTERDESIGNER_OT_animation_link_model(Operator):
    bl_idname = 'character_designer.animation_link_model'
    bl_label = 'Choose Linked Character FBX'
    bl_description = 'Choose the exact character model used by the Unity animation Link'
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default='*.fbx', options={'HIDDEN'})
    manifest_path: StringProperty(options={'HIDDEN'})

    @classmethod
    def poll(cls, _context):
        return _link_idle()

    def invoke(self, context, _event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        return {'FINISHED'} if _link_import(context, self.manifest_path, self.filepath) else {'CANCELLED'}


def _linked_send_key(target, linked, bound):
    return f"{target.session_uid}:{bound.session_uid}:{linked['link_id']}:{linked['action_slot']}"


def _linked_send_ready(context, target, linked, bound):
    """Check the visible Action/slot or managed inputs; full file checks stay in the exporter."""
    if not isinstance(bound, bpy.types.Action) or not linked or target.data.pose_position == 'REST':
        return False
    identity = linked['identity']
    if (identity.get('sourceOnly') or identity.get('compositionReferenceSource')
            or identity.get('composition') is not None or type(linked.get('action_slot')) is not int):
        return False
    from .unity_animation import active_preview
    preview = active_preview(target)
    if preview is not None and preview is not bound:
        return False
    from .unity_animation_rigging import SESSION_KEY, display_state
    if SESSION_KEY in target:
        session = display_state(target)
        return bool(session and session['scene'] is context.scene and session['base_action'] is bound
                    and session['base_slot'] == linked['action_slot'] and not session['source_read_only'])
    ad = target.animation_data
    return bool(ad and ad.action is bound and ad.action_slot and ad.action_slot.target_id_type == 'OBJECT'
                and ad.action_slot.handle == linked['action_slot'] and not ad.use_tweak_mode
                and target.mode in {'OBJECT', 'POSE'})


class CHARACTERDESIGNER_OT_animation_link_sync(Operator):
    bl_idname = 'character_designer.animation_link_sync'
    bl_label = 'Sync to Unity'
    bl_description = 'Export the linked current Action as a new candidate for Unity preview'

    @classmethod
    def poll(cls, context):
        from .animation_link import ACTION_KEY, get_link
        worklist = getattr(context.scene, 'character_designer_animation_worklist', None)
        if worklist is not None and worklist.workspace_path:
            return False
        target = _target(context)
        if not _link_idle() or target is None:
            return False
        try:
            linked, bound = get_link(target), target.get(ACTION_KEY)
            if not _linked_send_ready(context, target, linked, bound):
                return False
            expected = getattr(context, 'cd_single_send_key', '')
            return not expected or expected == _linked_send_key(target, linked, bound)
        except (ValueError, ReferenceError):
            return False

    def execute(self, context):
        from .animation_link import begin_linked_export
        try:
            if not self.poll(context):
                raise ValueError('Select the linked Action and its Object slot again before sending.')
            job = begin_linked_export(context, _target(context))
            _track_action_export(context, job)
        except Exception as exc:
            _settings(context).status, _settings(context).has_error = str(exc), True
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        settings = _settings(context)
        settings.status, settings.has_error = 'Syncing linked Action to a new Unity candidate…', False
        _redraw()
        return {'FINISHED'}


def _export_base_owner(context, rig, action):
    from . import animation_worklist as worklist, animation_pose_test as pose
    from . import animation_rest_pose as rest, body_original_mode as original
    from . import animation_composition as composition, unity_animation as ua
    if not _link_idle():
        raise ValueError('Finish the current animation operation before capturing the export base pose.')
    if (rig is None or rig.type != 'ARMATURE' or rig.library or rig.data.library
            or rig.override_library or not rig.is_editable or not rig.data.is_editable
            or context.scene.objects.get(rig.name) is not rig
            or context.view_layer.objects.get(rig.name) is not rig or rig.mode not in {'OBJECT', 'POSE'}):
        raise ValueError('Return to this local animation rig and scene before capturing its export base pose.')
    ad = rig.animation_data
    if (action is None or action.library or action.override_library or not action.is_editable
            or action.asset_data or ad is None or ad.action is not action
            or ad.use_tweak_mode):
        raise ValueError('Activate the intended editable Custom Action outside NLA Tweak Mode before capture.')
    # Reuse the established same-rig owner, visibility and Forearm trial
    # admission. It performs no author writes or context changes.
    pose._admission(context, rig, _purpose='ANIMATION')
    from . import control_pose_blend_ui as blend
    modal = getattr(getattr(context, 'window', None), 'modal_operators', None)
    if (getattr(context, 'object', None) is rig and modal is not None
            and modal.get('POSELIB_OT_blend_pose_asset') is not None):
        raise ValueError('Finish or cancel Blend Pose before capturing the export base pose.')
    for operator in tuple(blend._ACTIVE_OPERATORS):
        session = getattr(operator, '_session', None)
        live = isinstance(session, dict) and session.get('rig') is rig and session.get('closed') is not True
        uncertain = not isinstance(session, dict) and getattr(operator, 'target_name', None) == rig.name
        if live or uncertain:
            raise ValueError('Finish or cancel Blend Pose before capturing the export base pose.')
    if getattr(getattr(context, 'screen', None), 'is_animation_playing', False):
        raise ValueError('Stop playback before capturing the export base pose.')
    if (pose.active(rig) or original.active(rig) or rest.is_rest(rig) or composition.active(rig)
            or ua.active_preview(rig) or pose.SESSION_KEY in action or pose.REFS_KEY in action
            or worklist._rigging_module(rig, action) is not None):
        raise ValueError('Return to ordinary Controls animation editing before capturing the export base pose.')
    saved = getattr(context.scene, 'character_designer_animation_worklist', None)
    if saved is not None and (saved.workspace_path or saved.items):
        item = worklist.current(context)
        if (item is None or item.rig is not rig or item.side != 'CUSTOM' or item.custom_action is not action
                or getattr(item, 'composition_json', '')
                or action.is_action_layered and (ad.action_slot is None or ad.action_slot.handle != item.custom_slot)):
            raise ValueError('Select the active ordinary Custom entry; Source and separate input drafts are protected.')
        if any(row.source_action is action for row in saved.items):
            raise ValueError('Source is read-only; capture an export base pose on its Custom copy.')
    from . import animation_physics as physics
    state = physics.status(context)
    if (state.get('hair', {}).get('running') or state.get('hair', {}).get('pending_recovery')
            or any(row.get('running') or row.get('pending_recovery') for row in state.get('dresses', ()))):
        raise ValueError('Pause Hair and Dress physics and finish recovery before capturing the export base pose.')
    return ad.action_slot.handle if action.is_action_layered and ad.action_slot else 0


class CHARACTERDESIGNER_OT_animation_export_base_pose(Operator):
    bl_idname = 'character_designer.animation_export_base_pose'
    bl_label = 'Capture Export Base Pose'
    bl_description = ('Retain this Custom Action\'s current unkeyed control inputs for future exports; '
                      'keep animation keys and the current pose')
    bl_options = {'REGISTER', 'UNDO'}
    rig_name: StringProperty(options={'HIDDEN'})
    action_name: StringProperty(options={'HIDDEN'})
    clear: BoolProperty(default=False, options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return _link_idle()

    def execute(self, context):
        from . import animation_export_inputs as inputs
        rig = bpy.data.objects.get(self.rig_name) if self.rig_name else _target(context)
        action = (bpy.data.actions.get(self.action_name) if self.action_name else
                  rig.animation_data.action if rig and rig.animation_data else None)
        try:
            if self.clear:
                inputs.clear(context, rig, action)
            else:
                handle = _export_base_owner(context, rig, action)
                inputs.capture(rig, action, handle)
        except Exception as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        self.report({'INFO'}, ('Export base pose cleared; animation keys and the current pose were kept.' if self.clear else
                              'Export base pose captured; animation keys and the current pose were kept.'))
        _redraw()
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_animation_export(Operator):
    bl_idname = 'character_designer.animation_export'
    bl_label = 'Export Action to Unity'
    bl_description = 'Export one selected skeletal Action to a new FBX; keep the current rig and existing files'
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default='*.fbx', options={'HIDDEN'})
    rig_name: StringProperty(options={'HIDDEN'})
    action_name: StringProperty(name='Action', options={'HIDDEN'})
    frame_start: FloatProperty(name='Start Frame', default=1)
    frame_end: FloatProperty(name='End Frame', default=25)
    loop: BoolProperty(name='Loop', default=False)

    @classmethod
    def poll(cls, context):
        from .animation_export import active_job
        return _target(context) is not None and active_job() is None and _job is None

    def invoke(self, context, _event):
        rig = _target(context)
        action = rig.animation_data.action if rig.animation_data else None
        if action is None:
            self.report({'ERROR'}, 'Select an Action in the Action Editor first.')
            return {'CANCELLED'}
        self.rig_name, self.action_name = rig.name, action.name
        self.frame_start, self.frame_end = action.frame_range
        self.loop = bool(action.get('unity_loop_time', False))
        from .unity_export import _filename
        name = ''.join('_' if c in '<>:"/\\|?*' else c for c in action.name)
        self.filepath = str(unity_exchange_folder(context).parent / 'BlenderActions' / _filename(name, rig))
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def draw(self, _context):
        self.layout.label(text='Action: ' + self.action_name)
        self.layout.prop(self, 'frame_start')
        self.layout.prop(self, 'frame_end')
        self.layout.prop(self, 'loop')
        self.layout.label(text='One Action; NLA is excluded.')
        self.layout.label(text='Skeletal only: no Shape Keys or events.')
        from . import animation_export_inputs as inputs
        rig = bpy.data.objects.get(self.rig_name)
        action = bpy.data.actions.get(self.action_name)
        self.layout.label(text=inputs.status(rig, action)['message'])
        capture = self.layout.operator('character_designer.animation_export_base_pose', icon='POSE_HLT')
        capture.rig_name, capture.action_name = self.rig_name, self.action_name
        capture.clear = False
        if action is not None and (inputs.RECORD in action or inputs.COUNT in action):
            clear = self.layout.operator('character_designer.animation_export_base_pose',
                                         text='Clear Export Base Pose', icon='X')
            clear.rig_name, clear.action_name, clear.clear = self.rig_name, self.action_name, True

    def execute(self, context):
        from . import animation_export
        rig = bpy.data.objects.get(self.rig_name) if self.rig_name else _target(context)
        action = bpy.data.actions.get(self.action_name)
        try:
            job = animation_export.begin_export(context, rig, action, self.filepath,
                frame_start=self.frame_start, frame_end=self.frame_end, loop=self.loop)
            _track_action_export(context, job)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        settings = _settings(context)
        settings.status, settings.has_error = 'Exporting selected Action in an isolated snapshot…', False
        _redraw()
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_animation_export_cancel(Operator):
    bl_idname = 'character_designer.animation_export_cancel'
    bl_label = 'Cancel Action Export'

    def execute(self, context):
        global _export_window_manager
        from . import animation_export
        from . import animation_worklist_collection as collection
        if collection.running():
            collection.cancel(context)
            _redraw()
            return {'FINISHED'}
        job = animation_export.active_job()
        animation_export.cancel_export()
        if isinstance(job, dict):
            collection.export_finished(job, error='Action export cancelled.')
        if bpy.app.timers.is_registered(_poll_action_export):
            bpy.app.timers.unregister(_poll_action_export)
        _export_window_manager = None
        _settings(context).status = 'Action export cancelled. Existing files were preserved.'
        _settings(context).has_error = False
        scene = job.get('_worklist_scene') if isinstance(job, dict) else None
        if scene is not None:
            try:
                scene.character_designer_animation_worklist.status = _settings(context).status
                scene.character_designer_animation_worklist.has_error = False
            except ReferenceError:
                pass
        _redraw()
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_animation_unity_import(Operator):
    bl_idname = "character_designer.animation_unity_import"
    bl_label = "Import Unity Test Action"
    bl_description = "Apply the evaluated character motion sent by Unity as a reversible test Action"
    bl_options = {"REGISTER", "UNDO"}
    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.cdanim.json", options={"HIDDEN"})
    use_latest: BoolProperty(default=True, options={"SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        from .unity_animation import active_preview
        target = _target(context)
        return bool(target and _job is None and not active_preview(target))

    def invoke(self, context, _event):
        if self.use_latest:
            return self.execute(context)
        self.filepath = str(unity_exchange_folder(context)) + "/"
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        from .unity_animation import import_test_action
        target = _target(context)
        settings = _settings(context)
        try:
            path = latest_unity_animation(unity_exchange_folder(context)) if self.use_latest else Path(bpy.path.abspath(self.filepath))
            result = import_test_action(context, target, path, start_frame=settings.start_frame)
        except Exception as exc:
            settings.has_error = True
            settings.status = str(exc)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        settings.target = target
        settings.unity_directory = str(path.parent)
        target["character_designer_unity_animation_folder"] = str(path.parent)
        settings.has_error = False
        settings.status = f"{result.action.name}: {result.sample_count} samples. Play or scrub the timeline; Restore returns to the previous Action."
        _redraw()
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_animation_play_pause(Operator):
    bl_idname = "character_designer.animation_play_pause"
    bl_label = "Play / Pause"
    bl_description = "Play or pause the current Action using Blender's timeline"

    @classmethod
    def poll(cls, context):
        return context.screen is not None and _target(context) is not None

    def execute(self, context):
        if context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)
        else:
            bpy.ops.screen.animation_play()
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_animation_unity_cancel(Operator):
    bl_idname = "character_designer.animation_unity_cancel"
    bl_label = "Cancel Preview"
    bl_description = "Leave this test and restore the complete previous animation state; retain the test Action"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        from .unity_animation import active_preview
        target = _target(context)
        return bool(target and active_preview(target))

    def execute(self, context):
        from .unity_animation import restore_preview
        try:
            restore_preview(context, _target(context))
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _settings(context).status = "Preview cancelled. Previous animation state restored; test Action retained."
        _settings(context).has_error = False
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_animation_generate(Operator):
    bl_idname = "character_designer.animation_generate"
    bl_label = "Generate Local Motion"
    bl_description = "Generate a short motion on this computer; does not change the character"

    @classmethod
    def poll(cls, context):
        from .animation_export import active_job
        return _job is None and active_job() is None

    def execute(self, context):
        global _job, _job_window_manager
        settings = _settings(context)
        previous_result_path = settings.result_path
        if not settings.prompt.strip():
            self.report({"ERROR"}, "Enter a motion description.")
            return {"CANCELLED"}
        try:
            if _job is not None or bpy.app.timers.is_registered(_poll_job):
                raise RuntimeError('Local generation is still active. Cancel it before starting another job.')
            job = LocalMotionJob(bpy.path.abspath(settings.runtime_root), prompt=settings.prompt,
                                 duration=settings.duration, seed=settings.seed)
        except Exception as exc:
            settings.status, settings.has_error = str(exc), True
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _job, _job_window_manager = job, context.window_manager
        try:
            bpy.app.timers.register(_poll_job, first_interval=0.5)
            settings.log_path = str(job.log_path)
            settings.status, settings.has_error = job.status, False
            # A previous imported preview remains usable while a new job runs.
            settings.result_path = ""
        except Exception as exc:
            cleanup_errors = []
            try:
                if bpy.app.timers.is_registered(_poll_job):
                    bpy.app.timers.unregister(_poll_job)
            except Exception as cleanup:
                cleanup_errors.append('poll timer: ' + str(cleanup))
            try:
                _cancel_local_motion()
            except Exception as cleanup:
                cleanup_errors.append('worker: ' + str(cleanup))
            try:
                settings.result_path = previous_result_path
            except Exception as cleanup:
                cleanup_errors.append('previous result: ' + str(cleanup))
            message = 'Local generation polling could not start: ' + str(exc)
            if _job is job:
                message += '. The worker is still owned; retry Cancel Generation before starting another job.'
            else:
                message += '. The generation worker was stopped.'
            if cleanup_errors:
                message += ' Cleanup: ' + '; '.join(cleanup_errors)
            try:
                settings.status, settings.has_error = message, True
            except Exception as cleanup:
                message += '. Status could not be updated: ' + str(cleanup)
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_animation_cancel(Operator):
    bl_idname = "character_designer.animation_cancel"
    bl_label = "Cancel Generation"

    def execute(self, context):
        global _job, _job_window_manager
        try:
            _cancel_local_motion()
        except Exception as exc:
            message = 'Local generation could not stop: ' + str(exc) + '. Retry Cancel Generation.'
            _settings(context).status, _settings(context).has_error = message, True
            self.report({'ERROR'}, message)
            return {'CANCELLED'}
        if bpy.app.timers.is_registered(_poll_job):
            bpy.app.timers.unregister(_poll_job)
        _settings(context).status = "Cancelled"
        _settings(context).has_error = False
        return {"FINISHED"}


def import_motion_preview(context, filepath, start_frame):
    """Import into a separate armature without changing frame rate or playback range."""
    from io_anim_bvh import import_bvh
    from bpy_extras.io_utils import axis_conversion

    before = set(bpy.data.objects)
    before_armatures = set(bpy.data.armatures)
    before_actions = set(bpy.data.actions)
    selected = tuple(context.selected_objects)
    active = context.view_layer.objects.active
    frame = context.scene.frame_current
    subframe = context.scene.frame_subframe
    # Blender exposes negative fractional times with a negative subframe, but
    # frame_set accepts only 0..1. Convert to its equivalent accepted arguments.
    if subframe < 0.0:
        frame -= 1
        subframe += 1.0
    old_mode = active.mode if active else "OBJECT"
    try:
        if context.object and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        import_bvh.load(context, filepath=str(filepath), target="ARMATURE", global_scale=1.0,
                        frame_start=start_frame, use_fps_scale=True, update_scene_fps=False,
                        update_scene_duration=False, rotate_mode="QUATERNION",
                        global_matrix=axis_conversion(from_forward="-Z", from_up="Y").to_4x4())
        created = [obj for obj in bpy.data.objects if obj not in before and obj.type == "ARMATURE"]
        if len(created) != 1:
            raise RuntimeError("BVH did not produce one motion armature.")
        source = created[0]
        source.name = "Kimodo Preview"
        source["character_designer_motion_preview"] = True
        source.show_in_front = True
        return source
    except Exception:
        if context.object and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        for obj in set(bpy.data.objects) - before:
            bpy.data.objects.remove(obj, do_unlink=True)
        for data in set(bpy.data.armatures) - before_armatures:
            if data.users == 0:
                bpy.data.armatures.remove(data)
        for action in set(bpy.data.actions) - before_actions:
            if action.users == 0:
                bpy.data.actions.remove(action)
        raise
    finally:
        context.scene.frame_set(frame, subframe=subframe)
        for obj in context.selected_objects:
            obj.select_set(False)
        for obj in selected:
            if obj.name in context.view_layer.objects:
                obj.select_set(True)
        context.view_layer.objects.active = active
        if active and old_mode != "OBJECT":
            bpy.ops.object.mode_set(mode=old_mode)


class CHARACTERDESIGNER_OT_animation_import(Operator):
    bl_idname = "character_designer.animation_import"
    bl_label = "Import Preview"
    bl_description = "Import the generated skeleton as a separate preview"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = _settings(context)
        filepath = bpy.path.abspath(settings.result_path)
        if not Path(filepath).is_file():
            self.report({"ERROR"}, "Generate a motion first.")
            return {"CANCELLED"}
        try:
            source = import_motion_preview(context, filepath, settings.start_frame)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        settings.source = source
        settings.status = "Preview imported. Apply to the character when ready."
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_animation_apply(Operator):
    bl_idname = "character_designer.animation_apply"
    bl_label = "Apply as New Action"
    bl_description = "Transfer the preview to body bones in a new Action"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        from .animation_retarget import retarget_action
        settings = _settings(context)
        target = _target(context)
        if not settings.source or not target or target == settings.source:
            self.report({"ERROR"}, "Import a preview and choose the character rig.")
            return {"CANCELLED"}
        try:
            retarget_action(context, settings.source, target,
                            start_frame=settings.start_frame,
                            action_name="Kimodo Body", assign=True)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        settings.target = target
        settings.status = "New body Action applied. Previous Action can be restored."
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_animation_restore(Operator):
    bl_idname = "character_designer.animation_restore"
    bl_label = "Restore Previous Action"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _can_restore(context)

    def execute(self, context):
        from .animation_retarget import restore_previous_action
        from .unity_animation import active_preview, restore_preview
        try:
            target = _target(context)
            if active_preview(target):
                restore_preview(context, target)
            else:
                restore_previous_action(context, target)
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        _settings(context).status = "Previous Action restored; generated Action is retained."
        _settings(context).has_error = False
        return {"FINISHED"}


class CHARACTERDESIGNER_OT_animation_open_log(Operator):
    bl_idname = "character_designer.animation_open_log"
    bl_label = "Open Job Folder"

    def execute(self, context):
        path = Path(_settings(context).log_path)
        if path.is_file():
            bpy.ops.wm.path_open(filepath=str(path.parent))
            return {"FINISHED"}
        return {"CANCELLED"}


def _draw_single_action(layout, context):
    settings = _settings(context)
    main_rig = _main_rig(context)
    if main_rig is None:
        layout.prop(settings, "target")
        if not settings.target and _target(context):
            layout.label(text=f"Using: {_target(context).name}")
    else:
        error = _main_rig_error(context, main_rig)
        if error:
            layout.label(text=error, icon='ERROR')
            layout.label(text='Choose Main Rig in Rig > Character Setup.')
    from .unity_animation import active_preview
    from .animation_link import ACTION_KEY, get_link
    from .animation_physics_ui import wrapped_label
    import sys
    target = _target(context)
    preview = active_preview(target) if target else None
    try:
        linked = get_link(target) if target else None
    except ValueError as exc:
        wrapped_label(layout, context, str(exc), icon='ERROR')
        linked = None
    browser = sys.modules.get(__package__ + '.animation_action_browser')
    bound = target.get(ACTION_KEY) if linked else None
    # The daily list hides archived work and may label the active Action with
    # its source clip name. On this detached rig, expose the existing All picker.
    archived_link = (linked and browser and isinstance(bound, bpy.types.Action)
                     and any(key in target for key in ('character_designer_worklist_main_session_v1',
                                                        'character_designer_worklist_main_restored_v1'))
                     and browser._eligible(context, target) and browser.display_role(bound, target) == 'ARCHIVED')
    if target is not None:
        actions = layout.column(align=True)
        actions.enabled = (not preview and _job is None
                           and not (target.animation_data
                                    and target.animation_data.use_tweak_mode))
        if archived_link:
            actions.enabled = actions.enabled and browser._idle(context, target)
            browser._draw_native(actions, target)
        elif browser is None or not browser.draw_selector(actions, context, target):
            actions.template_action(target, new="action.new", unlink="action.unlink",
                                    text="Action")
            animation_data = target.animation_data
            if animation_data and animation_data.action:
                actions.context_pointer_set("animated_id", target)
                actions.template_search(animation_data, "action_slot",
                                        animation_data, "action_suitable_slots",
                                        new="anim.slot_new_for_id",
                                        unlink="anim.slot_unassign_from_id")
    local_fbx = target is not None and not linked
    if linked:
        ad = target.animation_data
        current = ad.action if ad else None
        handle = linked.get('action_slot')
        identity = linked['identity']
        label = bound.name if isinstance(bound, bpy.types.Action) else linked.get('action_name') or 'Missing Action'
        wrapped_label(layout, context, ('Archived link: ' if archived_link else 'Unity link: ') + label, icon='LINKED')
        if identity.get('sourceOnly') or identity.get('compositionReferenceSource') or identity.get('composition'):
            wrapped_label(layout, context, 'Use the Unity action list for this composition.', icon='INFO')
        elif not isinstance(bound, bpy.types.Action) or type(handle) is not int or not any(
                slot.handle == handle and slot.target_id_type == 'OBJECT' for slot in bound.slots):
            wrapped_label(layout, context, 'Linked Action or slot missing. Open the link again in Advanced.', icon='ERROR')
        else:
            if _linked_send_ready(context, target, linked, bound):
                row = layout.row()
                row.enabled = _link_idle()
                row.context_string_set('cd_single_send_key', _linked_send_key(target, linked, bound))
                row.operator('character_designer.animation_link_sync', text='Send to Unity', icon='EXPORT')
            else:
                local_fbx = current is not None and current is not bound
                if not archived_link:
                    wrapped_label(layout, context, 'Editing: ' + (current.name if current else 'No Action'), icon='ACTION')
                if target.data.pose_position == 'REST':
                    wrapped_label(layout, context, 'Return to Pose before sending the linked Action.')
                elif preview:
                    wrapped_label(layout, context, 'End the preview to return to the linked Action.')
                elif (not archived_link and browser is not None and browser.can_select(context, target)
                      and browser.linked_choice(target, linked['link_id'], browser._uid(bound), handle) is bound):
                    op = layout.operator('character_designer.choose_working_action', text='Open Linked Action', icon='ACTION')
                    op.target_uid = browser._uid(target)
                    op.action_uid = 'link:' + linked['link_id'] + ':' + browser._uid(bound)
                    op.slot_handle = handle
                elif not archived_link:
                    slot = next(slot for slot in bound.slots if slot.handle == handle)
                    wrapped_label(layout, context, 'In the Action Editor, choose the linked Action and slot: ' + slot.name_display)
    if preview:
        _draw_unity_preview(layout, context, target, preview)
    elif local_fbx:
        idle = browser._idle(context, target) if browser is not None else _link_idle()
        _draw_local_fbx(layout, target, enabled=actions.enabled and idle)
        return True
    return False


def _draw_unity_preview(unity, context, target, preview):
    from .unity_animation import preview_time_seconds
    unity.label(text=preview.name, icon="ACTION")
    playing = context.screen and context.screen.is_animation_playing
    unity.operator("character_designer.animation_play_pause", text="Pause" if playing else "Play", icon="PAUSE" if playing else "PLAY")
    row = unity.row(align=True)
    row.prop(context.scene, "frame_current", text="Frame")
    row.prop(context.scene, "frame_subframe", text="Subframe")
    unity.label(text=f"Time: {preview_time_seconds(context, target):.3f} s")
    unity.operator("character_designer.animation_unity_cancel", text="End Preview", icon="LOOP_BACK")
    from .forearm_twist import _ERRORS as forearm_errors
    import textwrap
    for name, error in forearm_errors.items():
        mesh = context.scene.objects.get(name)
        if mesh and any(mod.type == "ARMATURE" and mod.object == target for mod in mesh.modifiers):
            warning = unity.box()
            warning.alert = True
            warning.label(text=f"{name}: Forearm Correction", icon="ERROR")
            for line in textwrap.wrap(error, width=38):
                warning.label(text=line)


def _draw_local_fbx(layout, target, *, enabled=True):
    export = layout.row()
    export.enabled = bool(enabled and target and target.animation_data and target.animation_data.action)
    export.operator('character_designer.animation_export', text='Export Current Action as FBX…', icon='EXPORT')


def _draw_single_files(layout, context, *, show_export=True):
    settings = _settings(context)
    from .unity_animation import active_preview
    target = _target(context)
    preview = active_preview(target) if target else None
    layout.operator('character_designer.animation_link_import', text='Open Single Unity Link', icon='LINKED')
    row = layout.row(align=True)
    row.enabled = not preview and _job is None
    row.operator('character_designer.animation_unity_import', text='Preview Latest from Unity', icon='IMPORT').use_latest = True
    row.operator('character_designer.animation_unity_import', text='', icon='FILE_FOLDER').use_latest = False
    if not preview:
        layout.prop(settings, 'start_frame')
    layout.prop(settings, 'show_unity_files', text='Exchange Folder',
                icon='TRIA_DOWN' if settings.show_unity_files else 'TRIA_RIGHT', emboss=False)
    if settings.show_unity_files:
        layout.prop(settings, 'unity_directory', text='Folder')
        if not settings.unity_directory:
            from .animation_physics_ui import wrapped_label
            wrapped_label(layout, context, str(unity_exchange_folder(context)), icon='FILE_FOLDER')
    if show_export:
        _draw_local_fbx(layout, target)


def _draw_local_motion(layout, context):
    settings = _settings(context)
    from .unity_animation import active_preview
    target = _target(context)
    preview = active_preview(target) if target else None
    layout.prop(settings, "show_local_motion", icon="TRIA_DOWN" if settings.show_local_motion else "TRIA_RIGHT", emboss=False)
    if not settings.show_local_motion and _job is None:
        return
    layout = layout.column()
    layout.enabled = not preview
    layout.label(text="Kimodo · Free local generation", icon="ARMATURE_DATA")
    controls = layout.column()
    controls.enabled = _job is None
    controls.prop(settings, "prompt")
    row = controls.row(align=True)
    row.prop(settings, "duration")
    row.prop(settings, "seed")
    controls.prop(settings, "start_frame")
    controls.operator("character_designer.animation_generate", icon="PLAY")
    if _job:
        layout.operator("character_designer.animation_cancel", icon="CANCEL")
    row = layout.row()
    row.enabled = bool(settings.result_path) and _job is None
    row.operator("character_designer.animation_import", icon="IMPORT")
    if settings.source:
        layout.label(text=f"Preview: {settings.source.name}")
        layout.operator("character_designer.animation_apply", icon="ACTION")
    if not preview and _can_restore(context):
        layout.operator("character_designer.animation_restore", icon="LOOP_BACK")
    if settings.log_path:
        layout.operator("character_designer.animation_open_log", icon="FILE_FOLDER")
    layout.prop(settings, "show_setup", icon="TRIA_DOWN" if settings.show_setup else "TRIA_RIGHT",
                emboss=False)
    if settings.show_setup:
        layout.prop(settings, "runtime_root")
        layout.prop(settings, "result_path", text="Motion File")
        try:
            read_runtime(bpy.path.abspath(settings.runtime_root))
            layout.label(text="Local runtime configured", icon="CHECKMARK")
        except Exception:
            layout.label(text="Local runtime needs setup", icon="INFO")
        layout.label(text="First use of a prompt takes longer.")


class CHARACTERDESIGNER_PT_animation(Panel):
    bl_label = "Animation"
    bl_idname = "CHARACTERDESIGNER_PT_animation"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = SIDEBAR_CATEGORY

    @classmethod
    def poll(cls, context):
        return active_ui_page(context) == UI_PAGE_ANIMATION

    def draw(self, context):
        layout = self.layout
        from .animation_physics_ui import draw as draw_physics, section, wrapped_label
        draw_physics(layout, context)
        page = section(layout, "character_designer_animation_animations", "Animations", icon="ACTION")
        if page is not None:
            from .animation_worklist_ui import draw_worklist, draw_worklist_tools, scan_pending
            from .animation_worklist_collection import running as collection_running
            from .animation_export import active_job
            worklist = context.scene.character_designer_animation_worklist
            draw_worklist(page, context, include_original_inputs=False, include_tools=False)
            local_fbx_shown = not worklist.workspace_path and _draw_single_action(page, context)
            job = active_job()
            if job and not (job.get('composition_job') or collection_running() or scan_pending()):
                page.operator('character_designer.animation_export_cancel', icon='CANCEL')
            settings = _settings(context)
            if not worklist.workspace_path and settings.status:
                if settings.has_error or worklist.show_advanced:
                    wrapped_label(page, context, settings.status, icon='ERROR' if settings.has_error else 'INFO')
                elif settings.status.startswith('Synced '):
                    wrapped_label(page, context, 'Last send: preview the candidate in Unity.', icon='CHECKMARK')
                    if '. Omitted: ' in settings.status:
                        wrapped_label(page, context, 'Omitted: ' + settings.status.split('. Omitted: ', 1)[1])
            draw_worklist_tools(page, context)
            if not worklist.workspace_path:
                if worklist.show_advanced:
                    _draw_single_files(page, context, show_export=not local_fbx_shown)
                if worklist.show_advanced or _job is not None:
                    _draw_local_motion(page, context)
        original = section(layout, "character_designer_animation_original_inputs",
                           "Original Rigging Inputs", icon="ARMATURE_DATA", default_closed=True)
        if original is not None:
            from .animation_original_inputs_ui import draw_original_inputs
            draw_original_inputs(original, context)


ANIMATION_CLASSES = (
    CHARACTERDESIGNER_OT_animation_link_import,
    CHARACTERDESIGNER_OT_animation_link_model,
    CHARACTERDESIGNER_OT_animation_link_sync,
    CHARACTERDESIGNER_OT_animation_export_base_pose,
    CHARACTERDESIGNER_OT_animation_export,
    CHARACTERDESIGNER_OT_animation_export_cancel,
    CharacterDesignerAnimationState,
    CHARACTERDESIGNER_OT_animation_unity_import,
    CHARACTERDESIGNER_OT_animation_play_pause,
    CHARACTERDESIGNER_OT_animation_unity_cancel,
    CHARACTERDESIGNER_OT_animation_generate,
    CHARACTERDESIGNER_OT_animation_cancel,
    CHARACTERDESIGNER_OT_animation_import,
    CHARACTERDESIGNER_OT_animation_apply,
    CHARACTERDESIGNER_OT_animation_restore,
    CHARACTERDESIGNER_OT_animation_open_log,
    CHARACTERDESIGNER_PT_animation,
)
