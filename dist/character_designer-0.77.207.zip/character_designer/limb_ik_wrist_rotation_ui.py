"""Edit-pose wrist rotation for owned IK hands and explicit chain resets."""

import bpy
from bpy.props import EnumProperty
from bpy.types import Operator


_KEYMAPS = []


def _limb():
    from . import limb_ik
    return limb_ik


def _backend():
    from . import limb_ik_wrist_rotation
    return limb_ik_wrist_rotation


def _owned_wrist(pose_bone):
    """Cheap tags only; the service authenticates the complete live graph."""
    try:
        armature = pose_bone.id_data
        if armature.type != 'ARMATURE':
            return False
        limb = _limb()
        owner = armature.data.get(limb.ARMATURE_ID_KEY)
        return bool(owner and limb._owned(pose_bone.bone, owner, role='HAND_IK'))
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


class CHARACTERDESIGNER_OT_limb_ik_clear_wrist_rotation(Operator):
    bl_idname = 'character_designer.limb_ik_clear_wrist_rotation'
    bl_label = 'Reset IK Wrist Rotation'
    bl_description = 'Match each IK wrist to its hand orientation in Edit Mode. Pose Mirror includes both hands.'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        if getattr(context, 'mode', None) != 'POSE':
            return False
        try:
            selected = context.selected_pose_bones or ()
            rig = context.object
            if any(obj != rig for obj in getattr(context, 'objects_in_mode', ())):
                return False
            wrists = [pb for pb in selected if _owned_wrist(pb)]
            if (not wrists or any(pb.id_data != rig for pb in selected)
                    or any(any(pb.lock_rotation)
                           or (pb.rotation_mode in {'QUATERNION', 'AXIS_ANGLE'} and pb.lock_rotations_4d and pb.lock_rotation_w)
                           or float(pb.get('ik_fk', 1.)) <= 1e-6 for pb in wrists)):
                return False
            if context.scene.tool_settings.use_keyframe_insert_auto:
                settings = context.scene.tool_settings
                if (context.scene.keying_sets.active is not None
                        or settings.use_keyframe_insert_keyingset or settings.use_keyframe_cycle_aware
                        or settings.auto_keying_mode != 'ADD_REPLACE_KEYS'
                        or context.preferences.edit.use_visual_keying or not rig.animation_data
                        or not rig.animation_data.action):
                    return False
            return True
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            return False

    def execute(self, context):
        try:
            selected = tuple(context.selected_pose_bones or ())
            wrists = tuple(pb for pb in selected if _owned_wrist(pb))
            if (getattr(context, 'mode', None) != 'POSE'
                    or any(pb.id_data != getattr(context, 'object', None) for pb in selected)):
                self.report({'WARNING'}, 'Choose one or both generated IK wrists and controls on the same rig.')
                return {'CANCELLED'}
            if len(wrists) not in (1, 2):
                self.report({'WARNING'}, 'Choose one or both generated IK wrists.')
                return {'CANCELLED'}
            if len(selected) != len(wrists):
                companions = tuple(pb for pb in selected if pb not in wrists)
                from . import controller_transform_clear
                result = controller_transform_clear.reset_mixed_rotation(context, wrists, companions)
            elif len(wrists) == 1:
                result = _backend().reset_wrist_neutral(context, target=wrists[0])
            else:
                result = _backend().reset_wrist_neutral(context, targets=wrists)
            if context.scene.tool_settings.use_keyframe_insert_auto and result['keyed']:
                from . import natural_bind_mode
                names = result.get('targets') or (result['target'],)
                natural_bind_mode.note_rotation_keys(context, context.object, names)
        except Exception as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        self.report({'INFO'}, 'Reset selected rotations.' if len(selected) != len(wrists)
                    else 'Reset wrist rotation to neutral.')
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_reset_selected_pose_chains(Operator):
    bl_idname = 'character_designer.reset_selected_pose_chains'
    bl_label = 'Reset Selected Chains'
    bl_description = ('Return the selected native limb, spine or finger chains to their current Rest-based '
                      'neutral pose, keeping animation and unselected controller inputs')
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        try:
            rig = getattr(context, 'object', None)
            return (getattr(context, 'mode', None) == 'POSE' and rig is not None
                    and rig.type == 'ARMATURE' and bool(context.selected_pose_bones))
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            return False

    def execute(self, context):
        try:
            from . import body_pose_reset, natural_pose_clear
            if natural_pose_clear.body_selected(context):
                natural_pose_clear.clear_body(context)
                self.report({'INFO'}, 'Restored the original pose with Stable IK/FK.')
                return {'FINISHED'}
            result = body_pose_reset.reset_selected(context, context.object)
        except Exception as error:
            self.report({'WARNING'}, str(error))
            return {'CANCELLED'}
        self.report({'INFO'}, f"Reset {len(result['chains'])} selected chains; animation keys kept.")
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_clear_body_transform_channel(Operator):
    bl_idname = 'character_designer.clear_body_transform_channel'
    bl_label = 'Clear Body Control Transform'
    bl_description = 'Clear this channel on the selected body controls'
    bl_options = {'UNDO'}

    channel: EnumProperty(items=(('LOCATION', 'Location', ''), ('SCALE', 'Scale', '')))

    @classmethod
    def poll(cls, context):
        from . import natural_pose_clear
        return natural_pose_clear.body_selected(context)

    def execute(self, context):
        operator = bpy.ops.pose.loc_clear if self.channel == 'LOCATION' else bpy.ops.pose.scale_clear
        return operator('EXEC_DEFAULT', False)


CLASSES = (CHARACTERDESIGNER_OT_limb_ik_clear_wrist_rotation,
           CHARACTERDESIGNER_OT_reset_selected_pose_chains,
           CHARACTERDESIGNER_OT_clear_body_transform_channel)


def _register_keymap():
    if _KEYMAPS:
        return False
    manager = getattr(bpy.context, 'window_manager', None)
    config = getattr(getattr(manager, 'keyconfigs', None), 'addon', None)
    if config is None:
        return False
    km = config.keymaps.get('Pose')
    if km is None:
        km = config.keymaps.new(name='Pose', space_type='EMPTY', region_type='WINDOW')
    if km.space_type != 'EMPTY' or km.region_type != 'WINDOW':
        raise RuntimeError('The Pose keymap has an unexpected editor context.')
    item = km.keymap_items.new(CLASSES[0].bl_idname, 'R', 'PRESS', alt=True, head=True)
    _KEYMAPS.append((km, item))
    return True


def _remove_keymap():
    for km, item in reversed(_KEYMAPS):
        try:
            if any(existing == item for existing in km.keymap_items):
                km.keymap_items.remove(item)
        except ReferenceError:
            pass  # The native keymap has already been removed.
    _KEYMAPS.clear()


def register():
    from . import natural_bind_mode
    added = []
    keymap_added = False
    try:
        for cls in CLASSES:
            if not cls.is_registered:
                bpy.utils.register_class(cls)
                added.append(cls)
        keymap_added = _register_keymap()
        natural_bind_mode.register()
    except Exception:
        if keymap_added:
            _remove_keymap()
        for cls in reversed(added):
            bpy.utils.unregister_class(cls)
        raise


def unregister():
    from . import natural_bind_mode
    natural_bind_mode.unregister()
    _remove_keymap()
    for cls in reversed(CLASSES):
        if cls.is_registered:
            bpy.utils.unregister_class(cls)
