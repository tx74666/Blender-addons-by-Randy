"""Read-only viewport lines. No datablocks, timers, or mesh traversal per frame."""
import bpy
import blf
from mathutils import Vector
from bpy.app.handlers import persistent
from . import body_calibration as service, limb_ik

_handles = []
_KEY = 'character_designer_body_calibration_handlers'


def segments(context):
    rig = context.object
    if not rig or rig.type != 'ARMATURE' or not service.settings(rig).show_directions:
        return [], []
    settings = service.settings(rig)
    kind = 'LEG' if settings.part == 'LEGS' else 'ARM'
    lines, labels = [], []
    world = rig.matrix_world
    def line(a, b, color, dashed=False):
        a, b = world @ Vector(a), world @ Vector(b)
        if dashed:
            for i in range(0, 12, 2):
                lines.append((a.lerp(b, i/12), a.lerp(b, (i+1)/12), color))
        else:
            lines.append((a, b, color))
    def label(point, text):
        labels.append((world @ Vector(point), text))
    def arrow(a, d, size, text, dashed=False, color=(1, .65, .1, 1)):
        if d.length < 1e-8:
            return
        d = d.normalized()
        b = a + d*size
        line(a, b, color, dashed)
        cross = d.orthogonal().normalized()*size*.15
        line(b, b-d*size*.22+cross, color, dashed)
        line(b, b-d*size*.22-cross, color, dashed)
        label(b, text)
    pose = rig.mode == 'POSE'
    evaluated = rig.evaluated_get(context.evaluated_depsgraph_get()) if pose else rig
    inv = limb_ik._validate_inventory(rig) if rig.mode != 'EDIT' else service.edit_inventory(rig)
    if settings.part == 'FINGERS':
        from . import finger_targets
        for key,bones in finger_targets.index(rig).items():
            for bone in bones:
                name = bone.name
                if rig.mode == 'EDIT': center,mat = (bone.head+bone.tail)*.5,bone.matrix
                elif pose:
                    b = evaluated.pose.bones[name]
                    center,mat = (b.head+b.tail)*.5,b.matrix
                else: center,mat = (bone.head_local+bone.tail_local)*.5,bone.matrix_local
                size = max(bone.length*.3,1e-5)
                for i,color in enumerate(((1,.2,.2,1),(.2,1,.2,1),(.3,.5,1,1))):
                    arrow(center,mat.to_3x3().col[i],size,'XYZ'[i],color=color)
                label(center,key+(' [Pose]' if pose else ' [Rest]'))
        return lines,labels
    candidate = service.status(context,rig,settings.part).get('plan',{})
    for chain in service.chains(context, rig, kind):
        s, e, w, bend = service.direction(rig, chain)
        total = (e-s).length+(w-e).length
        size = total*.13
        names = list(chain.names)
        existing = inv['rigs'].get((kind, chain.side))
        if existing and 'target' in existing:
            names.append(existing['target'].name)
        for name in names:
            if rig.mode == 'EDIT':
                b = rig.data.edit_bones.get(name)
                if not b: continue
                center, mat = (b.head+b.tail)*.5, b.matrix
            elif pose:
                b = evaluated.pose.bones[name]
                center, mat = (b.head+b.tail)*.5, b.matrix
            else:
                b = rig.data.bones[name]
                center, mat = (b.head_local+b.tail_local)*.5, b.matrix_local
            for i, color in enumerate(((1,.2,.2,1),(.2,1,.2,1),(.3,.5,1,1))):
                arrow(center, mat.to_3x3().col[i], size*.55, 'XYZ'[i], color=color)
            label(center, name + (' [Pose]' if pose else ' [Rest]'))
        if pose:
            upper, lower = evaluated.pose.bones[chain.upper], evaluated.pose.bones[chain.lower]
            s, e, w = upper.head, lower.head, lower.tail
            raw = limb_ik._project_perpendicular(e-s, w-s)
            from .body_calibration_math import stable_bend
            stable = stable_bend(s,e,w,limb_ik.EPSILON)
            bend = raw.normalized() if stable else None
        if bend is not None:
            arrow(e, bend, size, 'Bend ' + ('Pose' if pose else 'Rest'))
        else:
            label(e, 'Bend: unstable')
        rs,re,rw,_ = service.direction(rig,chain)
        wanted = limb_ik._project_perpendicular(service.target(rig, kind), rw-rs)
        arrow(re, wanted, size*1.5, 'Target [Rest local]', True)
        proposed = next((p for p in candidate.get('limbs',()) if p.get('side') == chain.side and 'joint' in p),None)
        if proposed:
            point = Vector(proposed['joint'])
            line(rs,point,(.2,1,1,1),True)
            line(point,rw,(.2,1,1,1),True)
            line(re,point,(1,1,.2,1),True)
            label(point,f"Candidate: shift {proposed['shift']:.5g}")
        if existing and 'pole' in existing:
            pole = existing['pole'].head if rig.mode == 'EDIT' else evaluated.pose.bones[existing['pole'].name].head
            line(e, pole, (.8,.5,1,1))
            label(pole, 'Pole [evaluated]' if pose else 'Pole [Edit Rest]' if rig.mode == 'EDIT' else 'Pole [current]')
        elif wanted.length > 1e-8:
            planned_joint = Vector(proposed['joint']) if proposed else re
            planned_direction = Vector(proposed['direction']) if proposed else wanted.normalized()
            pole = planned_joint+planned_direction*total*settings.pole_distance
            line(planned_joint, pole, (.8,.5,1,1), True)
            label(pole, 'Not generated: planned Pole')
        if kind == 'ARM':
            try:
                normal,center,_ = service.palm(rig,chain.side)
                arrow(center,normal,size,'Palm [confirmed Rest reference]')
            except ValueError:
                label(rw,'Palm: undefined / needs review')
            if settings.part == 'HANDS' and settings.palm_side == chain.side and settings.palm_object:
                try:
                    normal,center,_ = service._palm_geometry(rig,settings.palm_object,settings.palm_face)
                    arrow(center,normal*(-1 if settings.palm_flip else 1),size*1.2,'Palm candidate: verify side',True)
                except ValueError: pass
    return lines, labels


def _draw(pixel=False):
    context = bpy.context
    if not context.area or context.area.type != 'VIEW_3D': return
    try:
        lines, labels = segments(context)
        if pixel:
            from bpy_extras.view3d_utils import location_3d_to_region_2d
            blf.size(0, 11)
            blf.color(0, 1, 1, 1, 1)
            placed = []
            for position, text in labels:
                p = location_3d_to_region_2d(context.region, context.region_data, position)
                if p is not None:
                    width,height = blf.dimensions(0,text)
                    x,y = max(2,min(p.x+4,context.region.width-width-4)),p.y+4
                    for _ in range(20):
                        if not any(x < a+w+4 and x+width+4 > a and y < b+h+3 and y+height+3 > b for a,b,w,h in placed): break
                        y += height+5
                    placed.append((x,y,width,height))
                    blf.position(0, x,y,0)
                    blf.draw(0, text)
        elif lines:
            import gpu
            from gpu_extras.batch import batch_for_shader
            shader = gpu.shader.from_builtin('SMOOTH_COLOR')
            batch = batch_for_shader(shader, 'LINES', {'pos': [v for a,b,c in lines for v in (a,b)],
                                                       'color': [c for a,b,c in lines for _ in (0,1)]})
            shader.bind()
            batch.draw(shader)
    except (ValueError, RuntimeError, ReferenceError, KeyError, TypeError):
        # Invalid/mid-undo input is reported by Setup; drawing must remain read-only.
        return


@persistent
def _load(_unused):
    register()


def register():
    old = bpy.app.driver_namespace.pop(_KEY, []) or list(_handles)
    for h in old:
        try: bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
        except (ValueError, ReferenceError): pass
    _handles.clear()
    if not bpy.app.background:
        _handles.extend([bpy.types.SpaceView3D.draw_handler_add(_draw, (False,), 'WINDOW', 'POST_VIEW'),
                         bpy.types.SpaceView3D.draw_handler_add(_draw, (True,), 'WINDOW', 'POST_PIXEL')])
    bpy.app.driver_namespace[_KEY] = list(_handles)
    for fn in tuple(bpy.app.handlers.load_post):
        if fn.__module__ == __name__ and fn.__name__ == '_load': bpy.app.handlers.load_post.remove(fn)
    bpy.app.handlers.load_post.append(_load)


def unregister():
    handles = bpy.app.driver_namespace.pop(_KEY, []) or list(_handles)
    for h in handles:
        try: bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
        except (ValueError, ReferenceError): pass
    _handles.clear()
    for fn in tuple(bpy.app.handlers.load_post):
        if fn.__module__ == __name__ and fn.__name__ == '_load': bpy.app.handlers.load_post.remove(fn)
