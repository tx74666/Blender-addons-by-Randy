"""Setup is deliberately separate from animation Controls."""
import bpy
import textwrap
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, PointerProperty, IntProperty, StringProperty
from bpy.types import PropertyGroup, Operator
from . import body_calibration as service

def _redraw(_self, context):
    if context and context.window_manager:
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D': area.tag_redraw()

_AXES = [('X','+X Right',''),('NX','-X Left',''),('Y','+Y Back',''),('NY','-Y Forward',''),
         ('Z','+Z Up',''),('NZ','-Z Down',''),('VECTOR','Custom vector','Armature-local XYZ')]


class CharacterDesignerBodyCalibration(PropertyGroup):
    tab: EnumProperty(items=[('SETUP', 'Setup', ''), ('CONTROLS', 'Controls', '')])
    part: EnumProperty(items=[(p, p.title(), '') for p in service.PARTS])
    preset: EnumProperty(items=[('DEFAULT', 'Default', 'Character local: elbows back, knees forward, palms down'),
                               ('CUSTOM', 'Custom', 'Candidate settings only; use Apply to change Rest')])
    show_directions: BoolProperty(name='Show Directions', default=False, update=_redraw)
    arm_axis: EnumProperty(name='Elbow direction',items=_AXES,default='Y',update=_redraw)
    leg_axis: EnumProperty(name='Knee direction',items=_AXES,default='NY',update=_redraw)
    arm_direction: FloatVectorProperty(name='Elbow target (local)', default=(0, 1, 0), size=3)
    leg_direction: FloatVectorProperty(name='Knee target (local)', default=(0, -1, 0), size=3)
    allow_bend: BoolProperty(name='Allow small bone length change', default=False)
    minimum_bend: FloatProperty(name='Minimum bend (degrees)', default=5, min=1, max=15)
    max_shift: FloatProperty(name='Max joint shift / chain length', default=.1, min=0, max=.5)
    max_length: FloatProperty(name='Max length change / bone length', default=.005, min=0, max=.05)
    pole_distance: FloatProperty(name='Pole distance / chain length', default=.75, min=.25, max=3)
    include_arms: BoolProperty(name='Arms', default=True)
    include_legs: BoolProperty(name='Legs', default=True)
    include_fingers: BoolProperty(name='Validate existing fingers', default=True)
    palm_side: EnumProperty(items=[('L','Left',''),('R','Right','')])
    palm_object: PointerProperty(name='Palm mesh', type=bpy.types.Object, poll=lambda self,obj: obj.type == 'MESH')
    palm_face: IntProperty(name='Face index', default=0, min=0)
    palm_flip: BoolProperty(name='Reverse palm arrow')
    palm_acknowledged: BoolProperty(name='I checked the palm side', default=False)


class CHARACTERDESIGNER_OT_body_calibration(Operator):
    bl_idname = 'character_designer.body_calibration'
    bl_label = 'Body Calibration'
    bl_options = {'REGISTER','UNDO'}
    action: EnumProperty(items=[(p,p.title(),'') for p in ('PREVIEW','APPLY','CONFIRM','PALM')])
    acknowledge: BoolProperty(name='I reviewed the displacement and bone length changes', default=False)
    signature: StringProperty(options={'HIDDEN','SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return bool(context.object and context.object.type == 'ARMATURE' and context.mode in {'OBJECT','POSE','EDIT_ARMATURE'})

    def invoke(self, context, event):
        try:
            rig = context.object
            p = service.plan(context,rig,service.settings(rig).part)
            if self.action == 'APPLY' and p['needs_acknowledgment']:
                self.signature = p['signature']
                self.acknowledge = False
                return context.window_manager.invoke_props_dialog(self, width=470)
        except (ValueError,RuntimeError,KeyError,TypeError) as exc:
            self.report({'WARNING'},str(exc))
            return {'CANCELLED'}
        return self.execute(context)

    def draw(self, context):
        s = service.settings(context.object)
        p = service.plan(context,context.object,s.part)
        self.layout.label(text='The candidate exceeds the suggested micro-adjustment range.')
        _metrics(self.layout,p)
        self.layout.prop(self,'acknowledge')

    def execute(self, context):
        rig = context.object
        s = service.settings(rig)
        try:
            if self.action == 'PREVIEW': service.preview(context,rig,s.part)
            elif self.action == 'PALM':
                service.capture_palm(rig,s.palm_side,s.palm_object,s.palm_face,s.palm_flip,s.palm_acknowledged)
                s.palm_acknowledged = False
            elif self.action == 'CONFIRM': service.confirm(context,rig,s.part)
            else:
                if self.signature and self.signature != service.plan(context,rig,s.part)['signature']:
                    raise ValueError('Candidate changed while confirmation was open; preview again.')
                service.apply(context,rig,s.part,acknowledge=self.acknowledge)
            for window in context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'VIEW_3D': area.tag_redraw()
            self.report({'INFO'}, self.action.title() + ' completed; review the result in Setup.')
            return {'FINISHED'}
        except (ValueError,RuntimeError,KeyError,TypeError,IndexError) as exc:
            self.report({'WARNING'},str(exc))
            return {'CANCELLED'}


def _metrics(layout, plan):
    for item in plan['limbs']:
        if 'shift' not in item: continue
        angle = item['direction_error_degrees']
        layout.label(text=f"{item['side']}: direction {'unstable' if angle is None else f'{angle:.2f} deg'}; shift {item['shift']:.6g}")
        a,b = item['length_changes']
        layout.label(text=f'Length change: {a:+.4%} / {b:+.4%}')
    for error in plan['errors']:
        for line in textwrap.wrap(error,32): layout.label(text=line, icon='ERROR')


def draw(layout, context):
    rig = context.object
    if rig is None or rig.type != 'ARMATURE':
        layout.label(text='Select the character armature.', icon='INFO')
        return True
    s = service.settings(rig)
    layout.prop(s, 'tab', expand=True)
    if s.tab == 'CONTROLS':
        return False
    layout.prop(s, 'preset', expand=True)
    layout.prop(s, 'show_directions', icon='HIDE_OFF' if s.show_directions else 'HIDE_ON')
    for part in service.PARTS:
        row = layout.row(align=True)
        row.prop_enum(s, 'part', part)
        try:
            item = service.status(context, rig, part)
            row.label(text=item['state'].replace('_', ' ').title(),
                      icon='CHECKBOX_HLT' if item['state'] == 'CONFIRMED' else 'CHECKBOX_DEHLT')
        except (ValueError, KeyError, RuntimeError, TypeError) as exc:
            row.label(text=str(exc), icon='ERROR')
    box = layout.box()
    box.label(text=s.part.title() + ' · Armature local / Rest')
    if s.part in {'ARMS', 'LEGS'}:
        box.prop(s, 'include_' + s.part.lower())
        if s.preset == 'CUSTOM':
            axis = 'arm_axis' if s.part == 'ARMS' else 'leg_axis'
            box.prop(s,axis)
            if getattr(s,axis) == 'VECTOR': box.prop(s, 'arm_direction' if s.part == 'ARMS' else 'leg_direction')
            for name in ('allow_bend', 'minimum_bend', 'max_shift', 'max_length', 'pole_distance'):
                box.prop(s, name)
    if s.part == 'FINGERS':
        box.prop(s, 'include_fingers')
    if s.part == 'HANDS':
        box.prop(s,'palm_side',expand=True)
        box.prop(s,'palm_object')
        box.prop(s,'palm_face')
        box.prop(s,'palm_flip')
        box.prop(s,'palm_acknowledged')
        box.operator('character_designer.body_calibration',text='Use Palm Reference').action='PALM'
    box.label(text='Solid: current · Dashed: candidate', icon='INFO')
    item = service.status(context,rig,s.part)
    for line in textwrap.wrap(item['message'],32):
        box.label(text=line,icon='ERROR' if item['state']=='ERROR' else 'INFO')
    if 'plan' in item: _metrics(box,item['plan'])
    row = box.row(align=True)
    row.operator('character_designer.body_calibration',text='Preview').action='PREVIEW'
    row.operator('character_designer.body_calibration',text='Apply Calibration').action='APPLY'
    row = box.row()
    row.enabled = item['state'] in {'READY','CONFIRMED'} or ('plan' in item and not item['plan']['changes'] and not item['plan']['errors'])
    row.operator('character_designer.body_calibration',text='Confirm',icon='CHECKMARK').action='CONFIRM'
    box.label(text='Undo Apply: Ctrl Z')
    box.label(text='Remove controls before')
    box.label(text='recalibrating an existing rig.')
    return True


def register():
    if not hasattr(bpy.types.Object, 'character_designer_body_calibration'):
        bpy.utils.register_class(CharacterDesignerBodyCalibration)
        bpy.utils.register_class(CHARACTERDESIGNER_OT_body_calibration)
        bpy.types.Object.character_designer_body_calibration = PointerProperty(type=CharacterDesignerBodyCalibration)
    from . import body_calibration_overlay
    body_calibration_overlay.register()


def unregister():
    from . import body_calibration_overlay
    body_calibration_overlay.unregister()
    if hasattr(bpy.types.Object, 'character_designer_body_calibration'):
        del bpy.types.Object.character_designer_body_calibration
        bpy.utils.unregister_class(CHARACTERDESIGNER_OT_body_calibration)
        bpy.utils.unregister_class(CharacterDesignerBodyCalibration)
