"""Finish a whole-character transform clear against the rig's original limbs.

An individual shortcut retains Blender's per-channel meaning. A complete
clear is recognized only on the same rig, frame, selection and pose inputs.
The sequence exists only in memory and never adds properties to a .blend.
"""

import bpy


_CHANNELS = frozenset(('LOCATION', 'ROTATION', 'SCALE'))
_pending = None


def _pending_hooks():
    handlers = bpy.app.handlers
    return (handlers.frame_change_pre, handlers.undo_pre, handlers.redo_pre, handlers.load_pre)


def forget(*_event):
    global _pending
    if _pending is not None:
        for hooks in _pending_hooks():
            if forget in hooks:
                hooks.remove(forget)
    _pending = None


def body_selected(context):
    if context.mode != 'POSE':
        return False
    selected = context.selected_pose_bones or ()
    if len(selected) < 9:
        return False
    from . import foot_controls, limb_ik as limb, root_control
    rig = context.object
    if rig is None or rig.type != 'ARMATURE' or context.scene.tool_settings.use_keyframe_insert_auto:
        return False
    owner = rig.data.get(limb.ARMATURE_ID_KEY)
    if (not owner or rig.data.get(limb.SCHEMA_KEY) != limb.DIRECT_PREROLL_SCHEMA
            or not rig.data.get(foot_controls.RECORD_KEY) or any(obj != rig for obj in context.objects_in_mode)):
        return False
    root = False
    controls = set()
    for pb in selected:
        if pb.id_data != rig:
            return False
        bone = pb.bone
        if (bone.get(root_control.OWNER_KEY) == root_control.OWNER_VALUE
                and bone.get(root_control.ROLE_KEY) == 'MASTER'):
            root = True
        if limb._owned(bone, owner):
            controls.add((bone.get(limb.KIND_KEY), bone.get(limb.SIDE_KEY), bone.get(limb.ROLE_KEY)))
    complete = root and all((kind, side, role) in controls for side in ('L', 'R')
                            for kind, target in (('ARM', 'HAND_IK'), ('LEG', 'FOOT_IK'))
                            for role in (target, 'POLE'))
    if not complete:
        return False
    try:
        return set(foot_controls.records(rig)) == {'L', 'R'}
    except ValueError:
        # A damaged owned record belongs to the service preflight. It can
        # report the error to the artist before attempting a bind reset.
        return True


def _pose_inputs(rig):
    from . import control_pose_assets as poses
    return {pb.name: {key: tuple(getattr(pb, key)) if count > 1 else getattr(pb, key)
                      for key, count in poses._FIELDS.items()} for pb in rig.pose.bones}


def _signature(context):
    rig = context.object
    ad = rig.animation_data
    bones = tuple((pb.name, pb.rotation_mode, pb.get('ik_fk'), tuple(pb.lock_location),
                   tuple(pb.lock_rotation), pb.lock_rotation_w, pb.lock_rotations_4d, tuple(pb.lock_scale))
                  for pb in rig.pose.bones)
    active = rig.data.bones.active
    return (context.scene.session_uid, rig.session_uid, rig.data.session_uid, context.view_layer.as_pointer(),
            context.scene.frame_current, context.scene.frame_subframe, rig.pose.use_mirror_x,
            ad.action.session_uid if ad and ad.action else None, ad.action_slot_handle if ad else None,
            active.name if active else None, frozenset(pb.name for pb in context.selected_pose_bones),
            tuple(tuple(row) for row in rig.matrix_world), bones, _pose_inputs(rig))


def _native(context, channel):
    if channel == 'ROTATION':
        from . import natural_bind_graph
        rig = context.object
        if natural_bind_graph.KEY in rig and natural_bind_graph.validate(rig)['enabled']:
            # These public inputs already use the Original Bones zero. They can
            # be cleared in any order while other channels are still posed.
            if bpy.ops.pose.rot_clear('EXEC_DEFAULT', False) != {'FINISHED'}:
                raise ValueError('Blender could not clear the selected rotations.')
            return
        from . import controller_transform_clear, limb_ik_wrist_rotation_ui as ui
        selected = tuple(context.selected_pose_bones)
        wrists = tuple(pb for pb in selected if ui._owned_wrist(pb))
        companions = tuple(pb for pb in selected if pb not in wrists)
        controller_transform_clear.reset_mixed_rotation(context, wrists, companions)
        return
    operator = bpy.ops.pose.loc_clear if channel == 'LOCATION' else bpy.ops.pose.scale_clear
    if operator('EXEC_DEFAULT', False) != {'FINISHED'}:
        raise ValueError('Blender could not clear the selected transform channel.')


def _finish(context, channels, previous):
    from . import natural_bind_graph, natural_bind_mode, natural_limb_inventory, natural_limb_solve
    from . import natural_body_reference, limb_ik_fk, root_control
    rig = context.object
    inventory = natural_limb_inventory.prepare(context, rig)
    selected = {pb.name for pb in context.selected_pose_bones}
    root = root_control.get_record(rig)
    if not root or root['master'] not in selected:
        raise ValueError('Select this rig’s root control to restore the whole body.')
    for entry in inventory['rigs'].values():
        if any(entry[field].name not in selected for field in ('target', 'pole')):
            raise ValueError('Select the actual targets and poles of all four limbs.')
    before = _pose_inputs(rig)
    graph = rig.get(natural_bind_graph.KEY)
    created = False
    restore_calibration = None
    try:
        for channel in channels:
            if channel == 'ROTATION':
                if bpy.ops.pose.rot_clear('EXEC_DEFAULT', False) != {'FINISHED'}:
                    raise ValueError('Blender could not clear the selected rotations.')
            else:
                _native(context, channel)
        natural_body_reference.prepare_body(context, rig, inventory)
        natural_limb_solve.reset_limbs(context, rig, inventory)
        if graph is None:
            natural_bind_graph.install(context, rig, inventory)
            created = True
        else:
            restore_calibration = natural_bind_graph.recalibrate(context, rig, inventory)
        natural_limb_solve.verify_bind(rig, inventory)
        natural_bind_mode.begin_preview(context, rig, previous)
    except Exception:
        if created:
            natural_bind_graph.remove(context, rig)
        elif restore_calibration:
            restore_calibration()
        after = _pose_inputs(rig)
        for name, values in before.items():
            pb = rig.pose.bones[name]
            for field, saved in values.items():
                if saved != after[name][field]:
                    setattr(pb, field, saved)
        limb_ik_fk._update(context, rig)
        raise


def clear_channel(context, channel):
    global _pending
    if channel not in _CHANNELS:
        raise ValueError('Unknown transform channel.')
    before = _signature(context)
    if _pending and _pending[0] == before:
        _, seen, previous = _pending
    else:
        from . import natural_bind_mode
        previous = natural_bind_mode.capture(context, context.object)
        seen = frozenset()
    forget()
    seen = seen | {channel}
    if seen == _CHANNELS:
        _finish(context, (channel,), previous)
        return True
    _native(context, channel)
    _pending = (_signature(context), seen, previous)
    for hooks in _pending_hooks():
        hooks.append(forget)
    return False


def clear_body(context):
    forget()
    if not body_selected(context):
        raise ValueError('Select the root and all four limb targets and poles in Pose Mode.')
    from . import natural_bind_mode
    _finish(context, ('LOCATION', 'SCALE', 'ROTATION'), natural_bind_mode.capture(context, context.object))
