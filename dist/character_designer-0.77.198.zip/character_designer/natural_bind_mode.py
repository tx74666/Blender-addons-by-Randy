"""Keep an unkeyed Original Bones reset local to its current frame and Action."""

import json

import bpy
from bpy.app.handlers import persistent

from . import control_pose_assets, natural_bind_graph as graph, natural_bind_keys as keys


KEY = 'character_designer_unkeyed_limb_bind_v1'
_sessions = {}
_keyed = {}
_known_actions = {}
_applied = {}
_route_inputs = {}
_operators = {}
_loaded_inputs = set()
_bus_owner = object()
_busy = False
_fields = control_pose_assets._FIELDS


def _values(p, field):
    value = getattr(p, field)
    return (value,) if _fields[field] == 1 else tuple(value)


def _assign(p, field, axis, value):
    if _fields[field] == 1:
        setattr(p, field, value)
    else:
        getattr(p, field)[axis] = value


def _binding(rig):
    ad = rig.animation_data
    action = ad.action if ad else None
    return (action.session_uid if action else 0, ad.action_slot_handle if action else 0)


def _frame(scene):
    return (scene.frame_current, scene.frame_subframe)


def _action(rig):
    ad = rig.animation_data
    return ad.action if ad else None


def _animated_nla(rig):
    ad = rig.animation_data
    return bool(ad and ad.use_nla and any(not t.mute and t.strips for t in ad.nla_tracks))


def capture(context, rig):
    """Take the input witness before the first shortcut in a three-channel clear."""
    rec = rig.get(graph.KEY)
    return {
        'scene': context.scene.session_uid, 'rig': rig.session_uid,
        'frame': _frame(context.scene), 'binding': _binding(rig),
        'prior_graph': rec['token'] if rec else '', 'prior_enabled': bool(rec and rec['enabled']),
        'inputs': {p.name: {f: _values(p, f) for f in _fields} for p in rig.pose.bones},
    }


def _same_input(scene, rig, record):
    return (record['scene'] == scene.session_uid and tuple(record['frame']) == _frame(scene)
            and tuple(record['binding']) == _binding(rig))


def _recent_operators():
    wm = bpy.context.window_manager
    return tuple(wm.operators) if wm else ()


def _observe_key_operator(rig, record):
    if not record.get('action') or _action(rig) != record.get('action') or bpy.context.object != rig:
        return
    current = _recent_operators()
    previous = _operators.get(rig.session_uid, set())
    if any(o.as_pointer() not in previous and o.bl_idname in
           {'ANIM_OT_keyframe_insert', 'ANIM_OT_keyframe_insert_by_name'} for o in current):
        record['explicit_key'] = True
    _operators[rig.session_uid] = {o.as_pointer() for o in current}


def _match(scene, rig, record):
    action = _action(rig)
    if scene != record['scene'] or action != record.get('action'):
        return False
    if action:
        return (record['slot'] == rig.animation_data.action_slot_handle
                and tuple(record['frame']) == _frame(scene))
    return not _animated_nla(rig)


def _changes(rig, inputs, previous):
    changes = {(name, field, axis): (old, new) for name, field, axis, old, new in previous}
    for name, fields in inputs.items():
        p = rig.pose.bones[name]
        for field, before in fields.items():
            for axis, (old, new) in enumerate(zip(before, _values(p, field))):
                if old == new:
                    continue
                key = (name, field, axis)
                if key in changes and changes[key][1] == old:
                    old = changes[key][0]
                if old == new:
                    changes.pop(key, None)
                else:
                    changes[key] = (old, new)
    return [[*key, *values] for key, values in changes.items()]


def begin_preview(context, rig, previous):
    """Attach the already-verified graph to the current, unkeyed pose."""
    if previous['rig'] != rig.session_uid or not _same_input(context.scene, rig, previous):
        raise ValueError('The rig, frame or active Action changed during the clear.')
    rec = graph.validate(rig)
    if not rec['enabled']:
        raise ValueError('The bind-relative solver must be active before starting the preview.')
    if previous['prior_graph'] and previous['prior_graph'] != rec['token']:
        raise ValueError('The bind-relative solver changed during the clear.')
    prior = rig.get(KEY)
    if prior and (prior['token'] != rec['token'] or not _match(context.scene, rig, prior)):
        raise ValueError('A different unkeyed bind preview is still active.')
    rows = _changes(rig, previous['inputs'], json.loads(prior['changes']) if prior else ())
    record = {field: previous[field] for field in ('prior_graph', 'prior_enabled')}
    if prior:
        record.update(prior_graph=prior['prior_graph'], prior_enabled=prior['prior_enabled'])
    record.update(token=rec['token'], changes=json.dumps(rows, separators=(',', ':')),
                  scene=context.scene, frame=list(map(float, previous['frame'])), slot=previous['binding'][1])
    if _action(rig):
        record['action'] = _action(rig)
    selection = [p.name for p in context.selected_pose_bones or ()]
    record['key_witness'] = prior['key_witness'] if prior else keys.capture(
        rig, _action(rig), record['slot'], sum(record['frame']), selection, rows)
    old_record = prior.to_dict() if prior else None
    old_session = _sessions.get(rig.session_uid)
    try:
        register()
        rig[KEY] = record
        _sessions[rig.session_uid] = (context.scene, rig)
        _operators.setdefault(rig.session_uid, {o.as_pointer() for o in _recent_operators()})
        if not _action(rig):
            _known_actions.setdefault(rig.session_uid, {a.session_uid for a in bpy.data.actions})
        _watch()
    except BaseException:
        if old_record:
            rig[KEY] = old_record
        elif KEY in rig:
            del rig[KEY]
        if old_session:
            _sessions[rig.session_uid] = old_session
        else:
            _sessions.pop(rig.session_uid, None)
            _known_actions.pop(rig.session_uid, None)
            _operators.pop(rig.session_uid, None)
        if not _sessions and not _keyed:
            _unwatch()
        raise


def _end(scene, rig, record, *, allow_keying):
    rec = graph.validate(rig)
    if record['token'] != rec['token']:
        raise ValueError('The unkeyed bind preview no longer owns the limb graph.')
    action, slot = record.get('action'), record['slot']
    fresh = False
    if not action and _action(rig):
        action = _action(rig)
        fresh = action.session_uid not in _known_actions.get(rig.session_uid, ())
        if not fresh:
            action = None
        else:
            slot = rig.animation_data.action_slot_handle
    recorded = allow_keying and keys.remember(rig, scene, record, action, slot, fresh)
    with bpy.context.temp_override(scene=scene):
        if keys.KEY in rig:
            _keyed[rig.session_uid] = (scene, rig)
            _applied.pop(rig.session_uid, None)
            _route_inputs.pop(rig.session_uid, None)
        elif record['prior_graph']:
            graph.set_enabled(bpy.context, rig, record['prior_enabled'], evaluate=False)
        else:
            graph.remove(bpy.context, rig, evaluate=False)
    if not (recorded and fresh):
        for name, field, axis, old, new in json.loads(record['changes']):
            p = rig.pose.bones.get(name)
            if p and _values(p, field)[axis] == new:
                _assign(p, field, axis, old)
    del rig[KEY]


def _expire(*args, all_sessions=False):
    global _busy
    if _busy:
        return
    _busy = True
    try:
        for uid, (scene, rig) in tuple(_sessions.items()):
            try:
                if KEY in rig:
                    record = rig[KEY]
                    _observe_key_operator(rig, record)
                    if not all_sessions and _match(scene, rig, record):
                        continue
                    _end(scene, rig, record, allow_keying=not all_sessions)
            except ReferenceError:
                pass  # Blender may have removed an object from another window.
            finally:
                if all_sessions or not _alive(rig):
                    _sessions.pop(uid, None)
                    _known_actions.pop(uid, None)
                    _operators.pop(uid, None)
        for uid, (scene, rig) in tuple(_keyed.items()):
            try:
                if keys.KEY not in rig:
                    _keyed.pop(uid, None)
                    _applied.pop(uid, None)
                    _route_inputs.pop(uid, None)
                    continue
                if uid in _sessions:
                    continue
                route_input = (_frame(scene), _binding(rig))
                if _route_inputs.get(uid) == route_input:
                    continue
                target = keys.desired(rig, scene)
                if uid not in _applied or _applied[uid] != target:
                    with bpy.context.temp_override(scene=scene):
                        keys.route(bpy.context, rig, target)
                    _applied[uid] = target
                _route_inputs[uid] = route_input
            except ReferenceError:
                _keyed.pop(uid, None)
                _applied.pop(uid, None)
                _route_inputs.pop(uid, None)
        if not _sessions and not _keyed:
            _unwatch()
    finally:
        _busy = False


def _alive(rig):
    try:
        return KEY in rig
    except ReferenceError:
        return False


def _save(*args):
    # Blender evaluates the old Action again when reading a .blend. Remember
    # the actual unkeyed axes, including the user's edits following the clear.
    for scene, rig in tuple(_sessions.values()):
        record = rig[KEY]
        _observe_key_operator(rig, record)
        if not _match(scene, rig, record):
            continue
        rows = json.loads(record['changes'])
        values = [_values(rig.pose.bones[name], field)[axis] for name, field, axis, _, _ in rows]
        record['saved_values'] = json.dumps(values, separators=(',', ':'))


def _unwatch():
    bpy.msgbus.clear_by_owner(_bus_owner)
    for hooks, callback in _temporary():
        if callback in hooks:
            hooks.remove(callback)


def _temporary():
    handlers = bpy.app.handlers
    return ((handlers.frame_change_pre, _expire), (handlers.depsgraph_update_pre, _expire),
            (handlers.save_pre, _save))


def _watch():
    if _expire in bpy.app.handlers.frame_change_pre:
        return
    for hooks, callback in _temporary():
        hooks.append(callback)
    for key in ('action', 'action_slot_handle'):
        bpy.msgbus.subscribe_rna(key=(bpy.types.AnimData, key), owner=_bus_owner, args=(), notify=_expire)


@persistent
def _invalidate(*args):
    _sessions.clear()
    _keyed.clear()
    _known_actions.clear()
    _applied.clear()
    _route_inputs.clear()
    _operators.clear()
    _loaded_inputs.clear()
    if bpy.app.timers.is_registered(_after_read):
        bpy.app.timers.unregister(_after_read)
    _unwatch()


@persistent
def _recover(*args):
    # Undo and redo replace RNA wrappers. Only an actual restored marker resumes.
    _invalidate()
    for rig in bpy.data.objects:
        for key, sessions in ((KEY, _sessions), (keys.KEY, _keyed)):
            if key not in rig:
                continue
            record = rig[key]
            scene = record.get('scene')
            if scene and scene in tuple(rig.users_scene) and graph.validate(rig)['token'] == record['token']:
                sessions[rig.session_uid] = (scene, rig)
                if key == KEY:
                    _operators[rig.session_uid] = {o.as_pointer() for o in _recent_operators()}
                if key == KEY and not record.get('action'):
                    _known_actions[rig.session_uid] = {a.session_uid for a in bpy.data.actions}
    if _sessions or _keyed:
        _watch()
        _expire()


@persistent
def _load(*args):
    _recover()
    _loaded_inputs.update(uid for uid, (_, rig) in _sessions.items() if 'saved_values' in rig[KEY])
    if _loaded_inputs and not bpy.app.timers.is_registered(_after_read):
        bpy.app.timers.register(_after_read, first_interval=0.0)


def _after_read():
    # Blender first evaluates the restored Action, then applies the saved
    # unkeyed overlay once. Ordinary timeline evaluation has no such hook.
    for uid in tuple(_loaded_inputs):
        session = _sessions.get(uid)
        _loaded_inputs.remove(uid)
        if not session:
            continue
        scene, rig = session
        record = rig[KEY]
        if 'saved_values' not in record or not _match(scene, rig, record):
            continue
        rows = json.loads(record['changes'])
        values = json.loads(record['saved_values'])
        if len(rows) != len(values):
            raise ValueError('The saved neutral-pose inputs are incomplete.')
        for (name, field, axis, _, _), value in zip(rows, values):
            p = rig.pose.bones[name]
            if _values(p, field)[axis] != value:
                _assign(p, field, axis, value)
    return None


def _lifecycle():
    handlers = bpy.app.handlers
    return ((handlers.undo_pre, _invalidate), (handlers.undo_post, _recover),
            (handlers.redo_pre, _invalidate), (handlers.redo_post, _recover),
            (handlers.load_pre, _invalidate), (handlers.load_post, _load))


def register():
    for hooks, callback in _lifecycle():
        if callback not in hooks:
            hooks.append(callback)


def unregister():
    _expire(all_sessions=True)
    _invalidate()
    for hooks, callback in _lifecycle():
        if callback in hooks:
            hooks.remove(callback)
