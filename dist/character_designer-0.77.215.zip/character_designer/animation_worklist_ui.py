"""Explicit workspace/worklist controls, without disk reads during drawing."""

from pathlib import Path
import json
import math
import textwrap

from . import animation_worklist_edit_scene as edit_scene
from . import animation_motion_pins as pins

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty
from bpy.types import Operator, PropertyGroup, UIList
from .controller_animation_ui import CONTROLLER_ANIMATION_CLASSES, draw_controller_animation

from .animation_original_inputs_ui import (
    ORIGINAL_INPUT_CLASSES, draw_original_inputs, has_original_inputs, original_inputs_live,
)


_DRAGS = []
_SCAN_PENDING = None
_LIST_SYNC_PENDING = None
_LIST_SYNC_REVIEW = None
_SIDES = (
    ('SOURCE', 'Source', 'View the linked source Action'),
    ('CUSTOM', 'Custom', 'Edit the local custom Action'),
)
_SCAN_STATES = (
    ('NOT_SCANNED', 'Not Scanned', 'Scan this Custom Action before choosing a batch sync'),
    ('CHANGED', 'Changed', 'The Custom Action differs from its last successful sync'),
    ('UNCHANGED', 'Unchanged', 'The Custom Action matches its last successful sync'),
    ('UNKNOWN', 'Unknown', 'The change proof is incomplete; select explicitly to sync'),
    ('BLOCKED', 'Blocked', 'This entry cannot safely sync until its reported issue is resolved'),
)
_SCAN_LABELS = {state: label for state, label, _description in _SCAN_STATES}


def _backend():
    from . import animation_worklist
    return animation_worklist


def _collection():
    from . import animation_worklist_collection as collection
    return collection


def _reconcile():
    from . import animation_worklist_reconcile
    return animation_worklist_reconcile






def _active_custom_action(context):
    """Display eligibility only; execution reauthenticates the complete Action."""
    item = _selected(_state(context))
    if (item is None or item.side != 'CUSTOM' or not _idle(context)
            or getattr(context, 'mode', 'OBJECT') not in {'OBJECT', 'POSE'}):
        return False
    animation = getattr(item.rig, 'animation_data', None)
    slot = getattr(item, 'custom_slot', None)
    return bool(animation is not None and slot is not None and item.custom_action is not None
                and animation.action == item.custom_action
                and getattr(animation, 'action_slot_handle', None) == slot)


def _state(context):
    scene = getattr(context, 'scene', None)
    return getattr(scene, 'character_designer_animation_worklist', None)


def _idle(_context):
    from .animation import _link_idle
    return not scan_pending() and _link_idle()


def scan_pending():
    """A pending UI scan also blocks native Link/Export entry points."""
    global _SCAN_PENDING, _LIST_SYNC_PENDING
    if (_SCAN_PENDING is not None and _SCAN_PENDING['armed']
            and not bpy.app.timers.is_registered(_SCAN_PENDING['callback'])):
        # Nonpersistent timers disappear on file load. Release the Python lock
        # without touching either the removed scene or the newly loaded scene.
        _release_scan_guard(_SCAN_PENDING)
        _SCAN_PENDING = None
    if (_LIST_SYNC_PENDING is not None and _LIST_SYNC_PENDING['armed']
            and not bpy.app.timers.is_registered(_LIST_SYNC_PENDING['callback'])):
        _LIST_SYNC_PENDING = None
    return _SCAN_PENDING is not None or _LIST_SYNC_PENDING is not None


def _clear_list_sync(*, unregister=True):
    global _LIST_SYNC_PENDING
    pending, _LIST_SYNC_PENDING = _LIST_SYNC_PENDING, None
    if pending is not None and unregister and pending['armed']:
        if bpy.app.timers.is_registered(pending['callback']):
            bpy.app.timers.unregister(pending['callback'])
    return pending


def _clear_list_sync_review():
    global _LIST_SYNC_REVIEW
    review, _LIST_SYNC_REVIEW = _LIST_SYNC_REVIEW, None
    return review


def _list_sync_review(context, *, token=None, workspace_path=None, clear=False):
    """Identify only a currently displayed review, never a cached input proof."""
    review = _LIST_SYNC_REVIEW
    if review is None:
        return None
    try:
        window, scene = review['window'], review['scene']
        settings = _state(context)
        if (getattr(context, 'window', None) != window or context.scene != scene
                or window not in tuple(context.window_manager.windows) or window.scene != scene
                or scene not in tuple(bpy.data.scenes) or settings is None
                or settings.status != review['feedback']
                or settings.collection_status != review['feedback'] or settings.has_error
                or token is not None and token != review['token']
                or workspace_path is not None and workspace_path != review['workspace_path']
                or not _idle(context)):
            return None
    except (ReferenceError, AttributeError):
        return None
    if clear:
        _clear_list_sync_review()
    return review


def _poll_list_sync():
    global _LIST_SYNC_REVIEW
    pending = _clear_list_sync(unregister=False)
    if pending is None:
        return None
    try:
        window, scene = pending['window'], pending['scene']
        if (window not in tuple(bpy.context.window_manager.windows) or window.scene != scene
                or scene not in tuple(bpy.data.scenes)):
            _scan_feedback(pending, 'List sync cancelled: its owning scene changed.')
            return None
        with bpy.context.temp_override(window=window, scene=scene):
            if not _idle(bpy.context):
                raise RuntimeError('Finish the current animation operation before syncing the list.')
            if pending.get('discard_extras', False):
                _reconcile().begin(bpy.context, pending['plan_token'],
                    workspace_path=pending['workspace_path'], discard_extras=True)
            elif pending.get('deprecate_extras', False):
                # begin rechecks the original token against current files/data.
                _reconcile().begin(bpy.context, pending['plan_token'],
                    workspace_path=pending['workspace_path'], deprecate_extras=True)
            else:
                plan = _reconcile().start_or_review(bpy.context, pending['workspace_path'] or None)
                if plan['blocked']:
                    raise ValueError('List sync stopped. ' + ' '.join(
                        entry['name'] + ': ' + entry['reason'] for entry in plan['blocked']))
                if plan['extras']:
                    feedback = 'Review extra animations before syncing. Existing edits are kept.'
                    _scan_feedback(pending, feedback)
                    _LIST_SYNC_REVIEW = dict(window=window, scene=scene, token=plan['token'],
                        workspace_path=plan['workspace_path'], feedback=feedback)
                    bpy.ops.character_designer.worklist_sync_review('INVOKE_DEFAULT',
                        plan_token=plan['token'], workspace_path=plan['workspace_path'],
                        extras_json=json.dumps(plan['extras'], ensure_ascii=False))
            _redraw(bpy.context)
    except Exception as exc:
        _scan_feedback(pending, str(exc), error=True)
    return None


def _defer_list_sync(operator, context, workspace_path='', *, plan_token='', deprecate_extras=False,
                     discard_extras=False):
    """Paint truthful feedback before file validation or native Action creation."""
    global _LIST_SYNC_PENDING
    if scan_pending() or not _idle(context):
        operator.report({'WARNING'}, 'Finish the current animation operation first.')
        return {'CANCELLED'}
    if deprecate_extras and discard_extras:
        operator.report({'ERROR'}, 'Choose either Retire or Discard.')
        return {'CANCELLED'}
    if (deprecate_extras or discard_extras) and (not plan_token or _list_sync_review(context,
            token=plan_token, workspace_path=workspace_path) is None):
        operator.report({'WARNING'}, 'This review is no longer current. Click Sync List again.')
        return {'CANCELLED'}
    pending = dict(window=getattr(context, 'window', None), scene=context.scene,
                   callback=_poll_list_sync, armed=False, workspace_path=workspace_path,
                   plan_token=plan_token, deprecate_extras=deprecate_extras)
    if discard_extras:
        pending['discard_extras'] = True
    try:
        if pending['window'] is None or _state(context) is None:
            raise ValueError('Sync the animation list in its owning Blender window.')
        _LIST_SYNC_PENDING = pending
        _clear_list_sync_review()
        feedback = ('Discarding old entries and syncing... Shared, edited or recovery data are kept.'
                    if discard_extras else
                    'Retiring and syncing... Cancel before this step starts; running checks must finish.'
                    if deprecate_extras else 'Checking Unity list... Existing edits are kept.')
        _scan_feedback(pending, feedback)
        bpy.app.timers.register(pending['callback'], first_interval=.05)
        pending['armed'] = True
    except Exception as exc:
        _clear_list_sync()
        _scan_feedback(pending, str(exc), error=True)
        operator.report({'ERROR'}, str(exc))
        return {'CANCELLED'}
    return {'FINISHED'}


def _scan_feedback(pending, message, error=False):
    try:
        settings = getattr(pending['scene'], 'character_designer_animation_worklist', None)
        if settings is not None:
            settings.status = settings.collection_status = message
            settings.has_error = error
        _redraw(pending['window'])
    except (ReferenceError, AttributeError):
        pass  # The old scene/window may already have been removed.


def _release_scan_guard(pending):
    """Remove only this scan's temporary input-change callback."""
    callback = pending.pop('guard', None)
    callbacks = pending.pop('guard_callbacks', ())
    if callback is not None and callback in callbacks:
        callbacks.remove(callback)


def _clear_pending_scan(*, unregister=True, release_guard=True):
    global _SCAN_PENDING
    pending, _SCAN_PENDING = _SCAN_PENDING, None
    if pending is not None and unregister and pending['armed']:
        callback = pending['callback']
        if bpy.app.timers.is_registered(callback):
            bpy.app.timers.unregister(callback)
    if pending is not None and release_guard:
        _release_scan_guard(pending)
    return pending


def _cancel_pending_scan(message='Scan cancelled; scan again before exporting.'):
    pending = _clear_pending_scan()
    pending_list = _clear_list_sync()
    if pending_list is not None:
        _scan_feedback(pending_list, 'List sync cancelled before it started.')
    if pending is not None:
        _scan_feedback(pending, message)
    return pending is not None or pending_list is not None


def _poll_scan():
    global _SCAN_PENDING
    pending = _clear_pending_scan(unregister=False, release_guard=False)
    if pending is None:
        return None
    try:
        window, scene = pending['window'], pending['scene']
        if (window not in tuple(bpy.context.window_manager.windows) or window.scene != scene
                or scene not in tuple(bpy.data.scenes)):
            _scan_feedback(pending, 'Scan cancelled: its owning window or scene changed.')
            _release_scan_guard(pending)
            return None
        with bpy.context.temp_override(window=window, scene=scene):
            if not _idle(bpy.context):
                raise RuntimeError('Another animation operation started during Scan.')
            collection = _collection()
            callbacks = getattr(getattr(bpy.app, 'handlers', None), 'depsgraph_update_post', None)
            update = getattr(getattr(bpy.context, 'view_layer', None), 'update', None)
            if callbacks is None or not callable(update):
                # Without a trustworthy between-tick signal keep the complete
                # scan synchronous; stale Unchanged rows must never be skipped.
                if 'guard' in pending:
                    raise RuntimeError('The Scan input guard was lost; scan again.')
                collection.scan_changes(bpy.context)
                complete = True
            else:
                # Flush pre-existing edits before the first proof/registration,
                # and subsequent edits while the already-installed guard is on.
                update()
                if 'guard' not in pending:
                    def changed(*_args):
                        if not pending.get('guard_suspended', False):
                            pending['inputs_changed'] = True
                    pending['guard'], pending['guard_callbacks'] = changed, callbacks
                    callbacks.append(changed)
                elif pending['guard'] not in callbacks:
                    raise RuntimeError('The Scan input guard was removed; scan again.')
                if pending.get('inputs_changed', False):
                    raise ValueError('Animation inputs changed during Scan; scan again before exporting.')
                pending['guard_suspended'] = True
                try:
                    if 'scan' not in pending:
                        pending['scan'] = collection.prepare_scan(bpy.context)
                    complete = collection.step_scan(bpy.context, pending['scan'])
                    if not complete:
                        scan = pending['scan']
                        _scan_feedback(pending, 'Scanning animations: ' + str(scan['index']) +
                                       ' / ' + str(len(scan['rows'])) + '. Cancel between animations.')
                    # Own row/status writes are drained in this one synchronous
                    # scope, then every external depsgraph update invalidates.
                    update()
                finally:
                    pending['guard_suspended'] = False
            if not complete:
                _SCAN_PENDING = pending
                return .01
            _release_scan_guard(pending)
            if pending['sync_after']:
                collection.begin_sync_changed(bpy.context, changed_only=True)
            _redraw(bpy.context)
    except Exception as exc:
        _scan_feedback(pending, str(exc), error=True)
    _release_scan_guard(pending)
    return None


def _defer_scan(operator, context, *, sync_after=False):
    """Scan one animation per tick, allowing redraw/Cancel between animations.

    An individual Action still authenticates synchronously. No Operator or
    transient Context is retained by the timer.
    """
    global _SCAN_PENDING
    if scan_pending():
        operator.report({'WARNING'}, 'A scan is already waiting to start.')
        return {'CANCELLED'}
    pending = dict(window=getattr(context, 'window', None), scene=context.scene,
                   callback=_poll_scan, armed=False, sync_after=sync_after)
    try:
        if pending['window'] is None or _state(context) is None or not _idle(context):
            raise RuntimeError('Run the scan in an idle owning Blender window.')
        _SCAN_PENDING = pending
        _scan_feedback(pending, 'Scanning animations... Cancel between animations.')
        bpy.app.timers.register(pending['callback'], first_interval=.05)
        pending['armed'] = True
    except Exception as exc:
        _clear_pending_scan()
        _scan_feedback(pending, str(exc), error=True)
        operator.report({'ERROR'}, str(exc))
        return {'CANCELLED'}
    return {'FINISHED'}


def _armature(_self, obj):
    return obj.type == 'ARMATURE'


def _selected(settings):
    if settings is not None and 0 <= settings.active_index < len(settings.items):
        return settings.items[settings.active_index]
    return None


def _workspace_connection_display(settings):
    """Display the last explicit workspace check, without touching its files.

    A saved path alone is not connection evidence. The backend writes the
    persistent identity only after loading and validating a Unity workspace.
    This is a file exchange, so the checkmark does not promise a live Unity
    process or continuous checks of files that may have changed on disk.
    """
    if not getattr(settings, 'workspace_path', ''):
        return 'Connect', 'FILE_FOLDER'
    if getattr(settings, 'connection_check_failed', False):
        status = getattr(settings, 'status', '')
        if ('another workspace or model revision' in status
                or status.startswith('Review extra animations before syncing.')):
            return 'Sync Required', 'FILE_REFRESH'
        return 'Check Failed', 'ERROR'
    if getattr(settings, 'workspace_identity', ''):
        return 'Connected', 'CHECKMARK'
    return 'Check Connection', 'QUESTION'


def _run_workspace(operator, context, name, *args):
    result = _run(operator, context, name, *args)
    settings = _state(context)
    if settings is not None:
        if result == {'FINISHED'}:
            settings.connection_check_failed = False
        elif name == 'refresh':
            # A failed attempt to choose another workspace leaves the current
            # connection intact; a failed recheck marks the current one.
            settings.connection_check_failed = True
    return result


def _catalog_matches(item, search):
    text = (item.name + ' ' + item.source_name).casefold()
    return all(term in text for term in search.casefold().split())


def _rigging_display(rig):
    if (rig is None or not hasattr(rig, 'get')
            or not rig.get('character_designer_rigging_session_v1')):
        return None
    from . import unity_animation_rigging
    display = getattr(unity_animation_rigging, 'display_state', None)
    return display(rig) if display is not None else None


def _active_side(item, side):
    action = item.source_action if side == 'SOURCE' else item.custom_action
    rig = item.rig
    if getattr(getattr(rig, 'data', None), 'pose_position', 'POSE') == 'REST':
        return False
    if action is None or rig is None or rig.animation_data is None or item.side != side:
        return False
    slot = item.source_slot if side == 'SOURCE' else item.custom_slot
    if rig.animation_data.action == action:
        return rig.animation_data.action_slot_handle == slot
    display = _rigging_display(rig)
    return bool(display and display['rig'] is rig and display['base_action'] is action
                and display['base_slot'] == slot
                and display['source_read_only'] == (side == 'SOURCE')
                and rig.animation_data.use_nla
                and (rig.animation_data.action is None
                     or (rig.animation_data.action == display['input_action']
                         and rig.animation_data.action_slot_handle == display['input_slot'])))


def _worklist_cursor(_settings):
    """Keep UIList scrolling/filtering without a separate active row highlight."""
    return -1


def _ignore_worklist_cursor(_settings, _value):
    # Passive row/keyboard selection never binds an Action or changes its owner.
    pass


def _editable_rigging(context):
    item = _selected(_state(context))
    display = _rigging_display(item.rig) if item is not None else None
    return (item, display) if (display and item.side == 'CUSTOM'
        and display['rig'] is item.rig and display['scene'] is context.scene
        and display['base_action'] is item.custom_action
        and not display['source_read_only']) else (None, None)


def _prepared_rigging_target(context):
    """Cheap display eligibility; execute reauthenticates the actual inputs."""
    settings = _state(context)
    setup = getattr(context.scene, 'character_designer_setup', None)
    main = getattr(setup, 'rig', None)
    rig = getattr(settings, 'rig', None)
    objects = getattr(context.scene, 'objects', None)
    return bool(settings is not None and settings.workspace_path and main is not None
                and rig is main and hasattr(rig, 'get')
                and getattr(rig, 'type', None) == 'ARMATURE' and rig.library is None
                and objects is not None and objects.get(rig.name) is rig
                and rig.get('character_designer_worklist_main_session_v1') is not None)


def _run_rigging(operator, context, *, edit_role=None):
    try:
        item = _selected(_state(context))
        if not _idle(context) or item is None or item.item_id != operator.item_id or item.side != 'CUSTOM':
            raise ValueError('Select the same Custom worklist entry before editing its controls.')
        from . import unity_animation_rigging
        session = unity_animation_rigging.current(item.rig)
        if (session is None or session['rig'] is not item.rig or session['scene'] is not context.scene
                or session['base_action'] is not item.custom_action or session['source_read_only']):
            raise ValueError('This entry has no editable Rigging session in the current scene.')
        _backend().validate_rigging_entry(context, item, session)
        if edit_role is not None:
            unity_animation_rigging.activate(context, session, edit_role=edit_role, enabled=True)
            action = session['base_action'] if edit_role == 'BASE' else session['input_action']
            message = 'Editing: ' + action.name
        else:
            unity_animation_rigging.key_current(context, session)
            message = 'Saved controls to "' + session['input_action'].name + '" at the current frame.'
        saved = _state(context)
        saved.status, saved.has_error = message, False
        operator.report({'INFO'}, message)
    except (ValueError, RuntimeError, OSError, ReferenceError, AttributeError, KeyError) as exc:
        saved = _state(context)
        if saved is not None:
            saved.status, saved.has_error = str(exc), True
        operator.report({'ERROR'}, str(exc))
        _redraw(context)
        return {'CANCELLED'}
    _redraw(context)
    return {'FINISHED'}


def _redraw(context):
    for area in context.screen.areas if context.screen else ():
        if area.type in {'VIEW_3D', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR'}:
            area.tag_redraw()


def _drag_row_height(context):
    height = 20.0 * (context.preferences.system.ui_scale or 1.0)
    view = getattr(getattr(context, 'region', None), 'view2d', None)
    if view is not None:
        # Sidebar zoom is independent of the application DPI/UI scale.
        span = abs(view.region_to_view(0, 1)[1] - view.region_to_view(0, 0)[1])
        if math.isfinite(span) and span > 1e-6:
            height /= span
    return max(1.0, height)


def _run(operator, context, name, *args, **kwargs):
    try:
        getattr(_backend(), name)(context, *args, **kwargs)
    except (ValueError, RuntimeError, OSError, ReferenceError) as exc:
        settings = _state(context)
        if settings is not None:
            settings.status, settings.has_error = str(exc), True
        operator.report({'ERROR'}, str(exc))
        _redraw(context)
        return {'CANCELLED'}
    _redraw(context)
    return {'FINISHED'}


def _run_collection(operator, context, *names):
    try:
        collection = _collection()
        for name in names:
            getattr(collection, name)(context)
    except Exception as exc:
        settings = _state(context)
        if settings is not None:
            settings.status = settings.collection_status = str(exc)
            settings.has_error = True
        operator.report({'ERROR'}, str(exc))
        _redraw(context)
        return {'CANCELLED'}
    _redraw(context)
    return {'FINISHED'}


class CHARACTERDESIGNER_OT_worklist_package_dependencies(Operator):
    bl_idname = 'character_designer.worklist_package_dependencies'
    bl_label = 'Package Editing Files'
    bl_description = ('Copy the linked animation sources and Main Rig recovery inputs into a new folder, '
                      'use the verified copies, then save the blend normally to retain their locations')

    directory: StringProperty(subtype='DIR_PATH')
    filter_folder: BoolProperty(default=True, options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        return settings is not None and bool(settings.workspace_path) and _idle(context)

    def invoke(self, context, _event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        manifest = None
        try:
            backend = _backend()
            package = backend.package_dependencies(context, self.directory)
            manifest = package['manifest_path']
            relocated = backend.rebind_dependencies(context, manifest)
            message = ('Editing files packaged and connected. Save the blend normally to retain their locations. '
                       'Unity publication files remain in their existing workspace.')
            if not relocated.get('portable_paths', False):
                message = ('Editing files packaged with absolute locations. Save the blend first, then package '
                           'on the same drive for portable locations. Unity publication files remain in their existing workspace.')
            settings = _state(context)
            settings.status, settings.has_error = message, False
            self.report({'INFO'}, message)
        except (ValueError, RuntimeError, OSError, ReferenceError) as exc:
            message = str(exc)
            if manifest is not None:
                message += ' The completed package was kept at ' + str(manifest)
            settings = _state(context)
            if settings is not None:
                settings.status, settings.has_error = message, True
            self.report({'ERROR'}, message)
            _redraw(context)
            return {'CANCELLED'}
        _redraw(context)
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_worklist_locate_dependencies(Operator):
    bl_idname = 'character_designer.worklist_locate_dependencies'
    bl_label = 'Locate Editing Files'
    bl_description = 'Reconnect this worklist to a verified editing-files package after moving it'

    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default='character_designer_dependencies.json;*.json', options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        return settings is not None and bool(settings.workspace_path) and _idle(context)

    def invoke(self, context, _event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        try:
            relocated = _backend().rebind_dependencies(context, self.filepath)
            message = 'Editing files connected. Save the blend normally to retain their locations.'
            if not relocated.get('portable_paths', False):
                message += ' Save on the same drive and locate again before moving this workspace.'
            settings = _state(context)
            settings.status, settings.has_error = message, False
            self.report({'INFO'}, message)
        except (ValueError, RuntimeError, OSError, ReferenceError) as exc:
            settings = _state(context)
            if settings is not None:
                settings.status, settings.has_error = str(exc), True
            self.report({'ERROR'}, str(exc))
            _redraw(context)
            return {'CANCELLED'}
        _redraw(context)
        return {'FINISHED'}


class CharacterDesignerAnimationWorklistCatalog(PropertyGroup):
    clip_key: StringProperty(options={'HIDDEN'})
    target_slot_id: StringProperty(options={'HIDDEN'})
    work_item_id: StringProperty(options={'HIDDEN'})
    name: StringProperty(name='Clip')
    source_name: StringProperty(name='Source')
    link_path: StringProperty(subtype='FILE_PATH', options={'HIDDEN'})
    ready: BoolProperty(name='Link Available', default=False,
                        description='Unity has provided a Link; its inputs are verified when added')


class CharacterDesignerAnimationWorklistItem(PropertyGroup):
    current_rig_revision: StringProperty(options={'HIDDEN'})
    retirement_reason: StringProperty(options={'HIDDEN'})
    workspace_path: StringProperty(subtype='FILE_PATH', options={'HIDDEN'})
    workspace_identity: StringProperty(options={'HIDDEN'})
    composition_json: StringProperty(options={'HIDDEN'})
    composition_sha256: StringProperty(options={'HIDDEN'})
    application_role: StringProperty(options={'HIDDEN'})
    edit_scope: StringProperty(options={'HIDDEN'})
    b_edited: BoolProperty(default=False, options={'SKIP_SAVE'})
    composition_changed: BoolProperty(default=False, options={'SKIP_SAVE'})
    effective_inputs_changed: BoolProperty(default=False, options={'SKIP_SAVE'})
    export_needed: BoolProperty(default=False, options={'SKIP_SAVE'})
    item_id: StringProperty(options={'HIDDEN'})
    work_item_id: StringProperty(options={'HIDDEN'})
    new_animation: BoolProperty(default=False, options={'HIDDEN'})
    new_action_id: StringProperty(options={'HIDDEN'})
    clip_key: StringProperty(options={'HIDDEN'})
    name: StringProperty(name='Clip')
    source_action: PointerProperty(type=bpy.types.Action)
    custom_action: PointerProperty(type=bpy.types.Action)
    rig: PointerProperty(type=bpy.types.Object, poll=_armature)
    side: EnumProperty(name='Action', items=_SIDES, default='CUSTOM')
    manifest_path: StringProperty(subtype='FILE_PATH', options={'HIDDEN'})
    export_rig_name: StringProperty(options={'HIDDEN'})
    model_file: StringProperty(subtype='FILE_PATH', options={'HIDDEN'})
    model_sha256: StringProperty(options={'HIDDEN'})
    link_identity: StringProperty(options={'HIDDEN'})
    source_file: StringProperty(subtype='FILE_PATH', options={'HIDDEN'})
    source_hash: StringProperty(options={'HIDDEN'})
    source_slot: IntProperty(default=0, options={'HIDDEN'})
    custom_slot: IntProperty(default=0, options={'HIDDEN'})
    source_data: PointerProperty(type=bpy.types.Armature)
    custom_data: PointerProperty(type=bpy.types.Armature)
    last_synced_receipt: StringProperty(options={'HIDDEN'})
    source_baseline_receipt: StringProperty(options={'HIDDEN'})
    scan_state: EnumProperty(name='Changes', items=_SCAN_STATES, default='NOT_SCANNED',
                             options={'SKIP_SAVE'})
    scan_reason: StringProperty(options={'SKIP_SAVE'})
    sync_selected: BoolProperty(name='Sync', default=False, options={'SKIP_SAVE'},
                                description='Include this entry in the next collection sync')


class CharacterDesignerAnimationWorklistState(PropertyGroup):
    composition_workspace_path: StringProperty(name='Composition Library', subtype='FILE_PATH')
    composition_workspace_identity: StringProperty(options={'HIDDEN'})
    composition_catalog: CollectionProperty(type=CharacterDesignerAnimationWorklistCatalog)
    composition_catalog_index: IntProperty(default=-1, min=-1)
    composition_base_item_id: StringProperty(name='A Work Copy', options={'HIDDEN'})
    catalog: CollectionProperty(type=CharacterDesignerAnimationWorklistCatalog)
    items: CollectionProperty(type=CharacterDesignerAnimationWorklistItem)
    retired_items: CollectionProperty(type=CharacterDesignerAnimationWorklistItem)
    # Source/Custom cells activate entries; passive list selection/file load never swaps Actions.
    active_index: IntProperty(default=-1, min=-1)
    list_cursor: IntProperty(default=-1, min=-1, options={'HIDDEN', 'SKIP_SAVE'},
                             get=_worklist_cursor, set=_ignore_worklist_cursor)
    catalog_index: IntProperty(default=-1, min=-1)
    search: StringProperty(name='Search Clips', options={'TEXTEDIT_UPDATE'})
    workspace_path: StringProperty(name='Workspace', subtype='FILE_PATH')
    workspace_id: StringProperty(options={'HIDDEN'})
    prepare_request_id: StringProperty(options={'HIDDEN'})
    prepared_work_item_ids: StringProperty(options={'HIDDEN'})
    workspace_identity: StringProperty(options={'HIDDEN'})
    connection_check_failed: BoolProperty(default=False, options={'HIDDEN'})
    target_name: StringProperty(name='Character')
    target_guid: StringProperty(options={'HIDDEN'})
    model_file: StringProperty(subtype='FILE_PATH', options={'HIDDEN'})
    model_sha256: StringProperty(options={'HIDDEN'})
    rig: PointerProperty(type=bpy.types.Object, poll=_armature)
    show_catalog: BoolProperty(name='Clip Browser', default=True)
    show_advanced: BoolProperty(name='Advanced', default=False, options={'SKIP_SAVE'})
    controller_auto_reduce: BoolProperty(name='Automatically Simplify Keys', default=True,
        options={'SKIP_SAVE'}, description='Remove extra controller keys after playback verification; turn off to keep all editable samples')
    controller_show_advanced: BoolProperty(name='Playback Tolerance', default=False, options={'SKIP_SAVE'})
    controller_position_tolerance_mm: FloatProperty(name='Position (mm)', default=1., min=.001, max=1.,
        precision=3, options={'SKIP_SAVE'}, description='Maximum playback position error in millimeters; smaller values keep more detail')
    controller_rotation_tolerance_degrees: FloatProperty(name='Rotation (degrees)', default=.25, min=.001, max=.25,
        precision=3, options={'SKIP_SAVE'}, description='Maximum playback rotation error in degrees; smaller values keep more detail')
    status: StringProperty(options={'SKIP_SAVE'})
    has_error: BoolProperty(options={'SKIP_SAVE'})
    collection_status: StringProperty(options={'SKIP_SAVE'})
    collection_feedback: BoolProperty(default=False, options={'SKIP_SAVE'})
    scan_completed: BoolProperty(default=False, options={'SKIP_SAVE'})


class CHARACTERDESIGNER_OT_worklist_connect(Operator):
    bl_idname = 'character_designer.worklist_connect'
    bl_label = 'Connect Workspace'
    bl_description = 'Choose or change the connected Unity animation workspace'
    bl_options = {'REGISTER'}
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default='character_animation_workspace.json;*.json', options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return _state(context) is not None and _idle(context)

    @classmethod
    def description(cls, context, _properties):
        settings = _state(context)
        if settings is None or not settings.workspace_path:
            return 'Choose a Unity animation workspace or a readable .workspace.json entry'
        label, _icon = _workspace_connection_display(settings)
        if label == 'Connected':
            status = ('Workspace validated at the last successful Connect or Refresh. '
                      'Use Sync List to check its files again.')
        elif label == 'Check Failed':
            status = 'The last check failed. Existing animations and edits are kept.'
        else:
            status = 'A workspace path is saved, but has no validated connection identity. Use Sync List to check it.'
        return status + '\nClick to choose another workspace.\n' + settings.workspace_path

    def invoke(self, context, _event):
        if not self.filepath:
            settings = _state(context)
            saved_path = settings.workspace_path
            source = Path(saved_path) if saved_path else None
            if (source is not None and source.name == 'character_animation_workspace.json'
                    and len(source.parents) >= 5 and source.parents[2].name == 'Workspaces'
                    and source.parents[3].name == 'CharacterTuning'):
                exchange = source.parents[4]
            else:
                from .animation import unity_exchange_folder
                exchange = Path(unity_exchange_folder(context))
            entries = exchange / 'Animations'
            try:
                has_entries = entries.is_dir()
            except OSError:
                has_entries = False
            if has_entries:
                self.filepath = str(entries) + '/'
            elif saved_path:
                self.filepath = saved_path
            else:
                self.filepath = str(exchange / 'character_animation_workspace.json')
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if _state(context).items or _state(context).rig:
            return _defer_list_sync(self, context, self.filepath)
        return _run_workspace(self, context, 'connect', self.filepath)


class CHARACTERDESIGNER_OT_worklist_add_prepared_animation(Operator):
    bl_idname = 'character_designer.worklist_add_prepared_animation'
    bl_label = 'Add Prepared Animation'
    bl_description = ('Choose a Unity workspace JSON for one prepared Rigging animation; '
                      'keep this Main Rig, workspace and existing entries')
    bl_options = {'REGISTER'}
    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default='character_animation_workspace.json;*.workspace.json;*.json',
                               options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return _prepared_rigging_target(context) and _idle(context)

    def invoke(self, context, _event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if not _prepared_rigging_target(context) or not _idle(context):
            message = 'Use the same adopted Main Rig before adding a prepared Rigging animation.'
            settings = _state(context)
            if settings is not None:
                settings.status, settings.has_error = message, True
            self.report({'ERROR'}, message)
            _redraw(context)
            return {'CANCELLED'}
        return _run(self, context, 'attach_prepared_rigging_work', self.filepath)


class CHARACTERDESIGNER_OT_worklist_refresh(Operator):
    bl_idname = 'character_designer.worklist_refresh'
    bl_label = 'Refresh Workspace'
    bl_description = 'Refresh clip metadata and Link availability; keep the worklist and custom edits'

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        return settings is not None and bool(settings.workspace_path) and _idle(context)

    def execute(self, context):
        return _defer_list_sync(self, context)


class CHARACTERDESIGNER_OT_worklist_sync_list(Operator):
    bl_idname = 'character_designer.worklist_sync_list'
    bl_label = 'Sync List'
    bl_description = ('Sync the Unity animation list to this Main Rig; '
                      'review extra entries before retiring them, keeping all Actions and drafts')

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        return settings is not None and bool(settings.workspace_path) and _idle(context)

    def execute(self, context):
        return _defer_list_sync(self, context)


class CHARACTERDESIGNER_OT_worklist_sync_review(Operator):
    bl_idname = 'character_designer.worklist_sync_review'
    bl_label = 'Review Extra Animations'
    bl_description = 'Retire extra worklist entries, or go back without changing animations'
    plan_token: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    workspace_path: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    extras_json: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def invoke(self, context, _event):
        if not self.plan_token or _list_sync_review(context,
                token=self.plan_token, workspace_path=self.workspace_path) is None:
            return {'CANCELLED'}
        return context.window_manager.invoke_popup(self, width=480)

    def draw(self, _context):
        layout = self.layout
        extras = json.loads(self.extras_json)
        layout.label(text=str(len(extras)) + ' local entries are outside the current Unity list.', icon='INFO')
        for entry in extras:
            layout.label(text=entry['name'], icon='ACTION')
            for line in textwrap.wrap(entry['reason'], width=62):
                layout.label(text=line)
        layout.separator()
        layout.label(text='Retire keeps Source, Custom and their work records.')
        layout.label(text='Discard removes the old entries and unused, unchanged data.')
        layout.label(text='Edited drafts, shared Actions and recovery data are kept.')
        row = layout.row(align=True)
        confirm = row.operator('character_designer.worklist_sync_confirm', text='Retire and Sync', icon='FILE_BACKUP')
        confirm.plan_token, confirm.workspace_path = self.plan_token, self.workspace_path
        discard = row.operator('character_designer.worklist_sync_discard_confirm', text='Discard and Sync', icon='TRASH')
        discard.plan_token, discard.workspace_path = self.plan_token, self.workspace_path
        row.operator('character_designer.worklist_sync_back', text='Back', icon='LOOP_BACK')

    def execute(self, _context):
        return {'CANCELLED'}


class CHARACTERDESIGNER_OT_worklist_sync_confirm(Operator):
    bl_idname = 'character_designer.worklist_sync_confirm'
    bl_label = 'Retire and Sync'
    bl_description = 'Keep extra entries in Retired Animations, then sync the Unity list'
    plan_token: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    workspace_path: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        return _defer_list_sync(self, context, self.workspace_path,
                                plan_token=self.plan_token, deprecate_extras=True)


class CHARACTERDESIGNER_OT_worklist_sync_discard_confirm(Operator):
    bl_idname = 'character_designer.worklist_sync_discard_confirm'
    bl_label = 'Discard and Sync'
    bl_description = ('Discard the reviewed old entries and their unused, unchanged Actions, '
                      'then import the new list; keep edited or shared data and recovery records')
    plan_token: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})
    workspace_path: StringProperty(options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context):
        return _defer_list_sync(self, context, self.workspace_path,
                                plan_token=self.plan_token, discard_extras=True)


class CHARACTERDESIGNER_OT_worklist_sync_back(Operator):
    bl_idname = 'character_designer.worklist_sync_back'
    bl_label = 'Back'
    bl_description = 'Return without changing the worklist or any Action'

    def execute(self, context):
        review = _list_sync_review(context, clear=True)
        if review is None:
            return {'CANCELLED'}
        _scan_feedback(review, 'List sync cancelled. Existing animations were kept.')
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_worklist_restore_retired(Operator):
    bl_idname = 'character_designer.worklist_restore_retired'
    bl_label = 'Restore Retired Animation'
    bl_description = 'Restore this complete local work record without rebinding it to a new source'
    item_id: StringProperty(options={'HIDDEN'})

    def execute(self, context):
        try:
            _reconcile().restore_retired(context, self.item_id)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        _redraw(context)
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_worklist_discard_retired(Operator):
    bl_idname = 'character_designer.worklist_discard_retired'
    bl_label = 'Discard Retired Animation'
    bl_description = ('Remove this retired entry and its unused, unchanged Actions; '
                      'keep edited drafts and data required by other work or recovery')
    bl_options = {'REGISTER', 'UNDO'}
    item_id: StringProperty(options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return _state(context) is not None and _idle(context)

    def execute(self, context):
        try:
            result = _reconcile().discard_retired(context, self.item_id)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, _state(context).status)
        for detail in result['kept_actions']:
            self.report({'INFO'}, detail['name'] + ': ' + detail['reason'])
        _redraw(context)
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_worklist_start_from_current(Operator):
    bl_idname = 'character_designer.worklist_start_from_current'
    bl_label = 'Use Current Character'
    bl_description = ('Replace the disconnected Main Rig record with the character in this scene. '
                      'Keep the current pose, Action and keys')
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from .animation_worklist_target import start_from_current
        try:
            start_from_current(context)
        except (ValueError, RuntimeError, OSError, ReferenceError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        _redraw(context)
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_worklist_use_main_rig(Operator):
    bl_idname = 'character_designer.worklist_use_main_rig'
    bl_label = 'Edit Animations'
    bl_description = ('Continue editing connected animations with this character and its existing controllers; '
                      'keep a recovery snapshot of the character before animation editing')
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        setup = getattr(context.scene, 'character_designer_setup', None)
        return (settings is not None and bool(settings.workspace_path)
                and getattr(setup, 'rig', None) is not None and _idle(context)
                and getattr(context, 'mode', 'OBJECT') in {'OBJECT', 'POSE'})

    def execute(self, context):
        return _run(self, context, 'adopt_main_rig')


class CHARACTERDESIGNER_OT_worklist_restore_main_rig(Operator):
    bl_idname = 'character_designer.worklist_restore_main_rig'
    bl_label = 'Restore Main Rig'
    bl_description = ('Exit animation editing and restore the state before Edit Animations; keep local drafts. '
                      'Use Rest Pose to view the resting model instead')
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        rig = getattr(settings, 'rig', None)
        return (rig is not None and hasattr(rig, 'get')
                and rig.get('character_designer_worklist_main_session_v1') is not None and _idle(context)
                and getattr(context, 'mode', 'OBJECT') in {'OBJECT', 'POSE'})

    def execute(self, context):
        return _run(self, context, 'restore_main_rig')


class CHARACTERDESIGNER_OT_worklist_pose_position(Operator):
    bl_idname = 'character_designer.worklist_pose_position'
    bl_label = 'Show Rest Pose or Animation Pose'
    bl_description = ('Use Rest Pose for neutral, editable posing with the previous animation retained; '
                      'choose Pose to return to that animation. Bone rest data stays unchanged')
    bl_options = {'REGISTER', 'UNDO'}

    position: EnumProperty(items=(('REST', 'Rest Pose', 'Start or reset a neutral, editable pose isolated from the animation'),
                                 ('POSE', 'Pose', 'Show the current animation pose')))

    @classmethod
    def poll(cls, context):
        from . import animation_rest_pose
        return _idle(context) and animation_rest_pose.can_show(context)

    def execute(self, context):
        from . import animation_rest_pose, animation_pose_test
        try:
            if self.position == 'REST':
                animation_rest_pose.show_rest(context)
            else:
                animation_rest_pose.show_pose(context)
        except (ValueError, RuntimeError, AttributeError, ReferenceError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        _redraw(context)
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_worklist_base_pose(Operator):
    bl_idname = 'character_designer.worklist_base_pose'
    bl_label = 'Reset to Base Pose'
    bl_description = ('Return to the neutral Body pose and keep posing; keep the previous animation '
                      'and any keyed test drafts. Click again to reset the test pose. '
                      'Use Object or Pose Mode; selecting a control bone is not required')
    bl_options = {'REGISTER', 'UNDO'}

    finish: BoolProperty(default=False, options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        from . import animation_pose_test
        allowed = _idle(context) and animation_pose_test.can_start(context)
        if (not allowed and getattr(context, 'mode', '') not in {'OBJECT', 'POSE'}
                and hasattr(cls, 'poll_message_set')):
            cls.poll_message_set('Finish Edit Mode and use Object or Pose Mode; '
                                 'a control bone does not need to be selected.')
        return allowed

    def execute(self, context):
        from . import animation_pose_test
        try:
            if self.finish:
                result = animation_pose_test.finish(context)
                message = ('Previous animation restored; keyed test drafts are kept.'
                           if result.get('changed', True) else
                           'No Base Pose test is active; the animation was left unchanged.')
            else:
                result = animation_pose_test.start_or_reset(context)
                message = 'Base Pose ready. Rotate the controls; click Base Pose again to reset.'
        except (ValueError, RuntimeError, AttributeError, ReferenceError, TypeError, KeyError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, message)
        _redraw(context)
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_worklist_keep_base_pose_draft(Operator):
    bl_idname = 'character_designer.worklist_keep_base_pose_draft'
    bl_label = 'Keep Draft and Exit Test'
    bl_description = ('Keep an outdated Base Pose draft and its recovery record, then leave the test '
                      'without applying the old rig pose. Select an animation for the current rig next')
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        from . import animation_pose_test
        if not _idle(context) or not animation_pose_test.can_start(context):
            return False
        setup = getattr(context.scene, 'character_designer_setup', None)
        worklist = getattr(context.scene, 'character_designer_animation_worklist', None)
        rig = getattr(setup, 'rig', None) or getattr(worklist, 'rig', None)
        return animation_pose_test.active(rig)

    def execute(self, context):
        from . import animation_pose_test
        try:
            animation_pose_test.keep_stale_draft(context)
        except (ValueError, RuntimeError, AttributeError, ReferenceError, TypeError, KeyError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, 'Old draft and current pose snapshot kept. '
                             'Choose an animation for the current rig, or start a new Base Pose.')
        _redraw(context)
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_worklist_use_current_revision(Operator):
    bl_idname = 'character_designer.worklist_use_current_revision'
    bl_label = 'Use Current Rig'
    bl_description = ('Keep the previous animation versions and create local editable versions '
                      'of their motion curves for the current rig')
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        return (settings is not None and bool(settings.items) and _idle(context)
                and getattr(context, 'mode', '') in {'OBJECT', 'POSE'})

    def execute(self, context):
        return _run(self, context, 'use_current_rig_version')


class CHARACTERDESIGNER_OT_worklist_add(Operator):
    bl_idname = 'character_designer.worklist_add'
    bl_label = 'Add to Worklist'
    bl_description = 'Verify this clip Link and prepare its Source and Custom Actions on the shared rig'
    bl_options = {'REGISTER'}
    clip_key: StringProperty(options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return _state(context) is not None and _idle(context)

    def execute(self, context):
        return _run(self, context, 'add', self.clip_key)


class CHARACTERDESIGNER_OT_worklist_add_ready(Operator):
    bl_idname = 'character_designer.worklist_add_ready'
    bl_label = 'Sync List'
    bl_description = (
        'Sync animations prepared in Unity. Use this workspace\'s animation rig when available; '
        'otherwise create a separate animation scene and import the character. '
        'Keep existing custom edits and the active animation')

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        return settings is not None and bool(settings.workspace_path) and _idle(context)

    def execute(self, context):
        return _run_collection(self, context, 'begin_add_ready')


class CHARACTERDESIGNER_OT_worklist_scan_changes(Operator):
    bl_idname = 'character_designer.worklist_scan_changes'
    bl_label = 'Scan Changes'
    bl_description = 'Check full Custom key data one animation at a time; Cancel between animations'

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        return settings is not None and bool(settings.items) and _idle(context)

    def execute(self, context):
        return _defer_scan(self, context)


class CHARACTERDESIGNER_OT_worklist_register_new(Operator):
    bl_idname = 'character_designer.worklist_register_new'
    bl_label = 'Register New Action'
    bl_description = 'Add the local new Action on this workspace rig; no original clip or target purpose is invented'

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        return settings is not None and settings.rig is not None and bool(settings.workspace_path) and _idle(context)

    def execute(self, context):
        try:
            from .animation_worklist_new import register
            register(context)
        except (ValueError, RuntimeError, OSError, ReferenceError) as exc:
            settings = _state(context)
            settings.status, settings.has_error = str(exc), True
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        _redraw(context)
        return {'FINISHED'}


class CHARACTERDESIGNER_OT_worklist_sync_changed(Operator):
    bl_idname = 'character_designer.worklist_sync_changed'
    bl_label = 'Export Changes'
    bl_description = 'Check all imported animations and export only confirmed changes to Unity'

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        return settings is not None and bool(settings.items) and _idle(context)

    def execute(self, context):
        # Always recheck edits. The primary export ignores old checkbox state
        # and publishes only animations with a complete change comparison.
        return _defer_scan(self, context, sync_after=True)


class CHARACTERDESIGNER_OT_worklist_cancel_collection(Operator):
    bl_idname = 'character_designer.worklist_cancel_collection'
    bl_label = 'Cancel Collection'
    bl_description = 'Stop the collection batch; keep completed updates. Cancel scans between animations.'

    @classmethod
    def poll(cls, context):
        return scan_pending() or _collection().running()

    def execute(self, context):
        if _cancel_pending_scan():
            return {'FINISHED'}
        return _run_collection(self, context, 'cancel')


class CHARACTERDESIGNER_OT_worklist_activate(Operator):
    bl_idname = 'character_designer.worklist_activate'
    bl_label = 'Activate Worklist Action'
    bl_options = {'REGISTER'}
    item_id: StringProperty(options={'HIDDEN'})
    side: EnumProperty(items=_SIDES, default='CUSTOM', options={'HIDDEN'})

    @classmethod
    def description(cls, _context, properties):
        settings = _state(_context)
        item = next((row for row in getattr(settings, 'items', ())
                     if row.item_id == getattr(properties, 'item_id', '')), None)
        if item is not None and getattr(item, 'current_rig_revision', ''):
            return ('View this current-rig version\'s starting motion' if properties.side == 'SOURCE'
                    else 'Edit this motion on the current rig')
        return ('View the original animation'
                if properties.side == 'SOURCE' else 'Edit your version of this animation')

    @classmethod
    def poll(cls, context):
        return _state(context) is not None and _idle(context)

    def execute(self, context):
        settings = _state(context)
        rig = getattr(settings, 'rig', None)
        if settings is not None:
            # A previous collection cancellation is not this cell's outcome.
            settings.collection_feedback = False
        get = getattr(rig, 'get', None)
        restored = get('character_designer_worklist_main_restored_v1') if callable(get) else None
        needs_resume = (type(restored) in (bool, int) and restored == 1
                        and get('character_designer_worklist_main_session_v1') is None)
        return _run(self, context, 'resume_and_activate' if needs_resume else 'activate',
                    self.item_id, side=self.side)


class CHARACTERDESIGNER_OT_worklist_remove(Operator):
    bl_idname = 'character_designer.worklist_remove'
    bl_label = 'Remove from Worklist'
    bl_description = 'Remove only this list entry; keep its Actions, source files, character and Unity assets'
    bl_options = {'REGISTER', 'UNDO'}
    item_id: StringProperty(options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return _state(context) is not None and _idle(context)

    def execute(self, context):
        return _run(self, context, 'remove', self.item_id)


class CHARACTERDESIGNER_OT_worklist_move(Operator):
    bl_idname = 'character_designer.worklist_move'
    bl_label = 'Move Worklist Entry'
    bl_description = 'Change only the saved worklist order'
    bl_options = {'REGISTER', 'UNDO'}
    item_id: StringProperty(options={'HIDDEN'})
    delta: IntProperty(default=0, options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        return _state(context) is not None and _idle(context)

    def execute(self, context):
        return _run(self, context, 'move', self.item_id, self.delta)


class CHARACTERDESIGNER_OT_worklist_drag_handle(Operator):
    bl_idname = 'character_designer.worklist_drag_handle'
    bl_label = 'Drag Selected Entry'
    bl_description = 'Select an entry, then drag vertically inside this handle; release inside it to reorder'
    bl_options = {'UNDO', 'INTERNAL'}
    item_id: StringProperty(options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        return (_selected(settings) is not None and len(settings.items) > 1
                and _idle(context) and not _DRAGS)

    def invoke(self, context, event):
        # A single tall native button keeps both endpoints inside one hit rect.
        # Blender invokes it on release and exposes the matching press position.
        if event.type != 'LEFTMOUSE' or event.value != 'RELEASE':
            return {'CANCELLED'}
        selected = _selected(_state(context))
        if selected is None or selected.item_id != self.item_id or not _idle(context):
            return {'CANCELLED'}
        press_y = getattr(event, 'mouse_prev_press_y', None)
        if press_y is None:
            return {'CANCELLED'}
        self._row_height = _drag_row_height(context)
        self._delta = round((press_y - event.mouse_y) / self._row_height)
        if not self._delta:
            return {'CANCELLED'}
        return _run(self, context, 'move', self.item_id, self._delta)


def stop_worklist_ui():
    """Stop owned collection work and pointer moves during add-on refresh."""
    _cancel_pending_scan('Scan stopped before reload or file load.')
    _clear_list_sync_review()
    _collection().stop()
    for operator in tuple(_DRAGS):
        operator._cancelled = True
        operator._finish()


class CHARACTERDESIGNER_OT_worklist_drag(Operator):
    bl_idname = 'character_designer.worklist_drag'
    bl_label = 'Move Entry'
    bl_description = 'Click, move the pointer vertically, then click to confirm the position; Esc cancels'
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING', 'INTERNAL'}
    item_id: StringProperty(options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        settings = _state(context)
        return settings is not None and len(settings.items) > 1 and _idle(context) and not _DRAGS

    def _finish(self):
        workspace = getattr(self, '_workspace', None)
        if workspace is not None:
            try:
                workspace.status_text_set(None)
            except (ReferenceError, RuntimeError):
                pass
        if self in _DRAGS:
            _DRAGS.remove(self)

    def _hint(self):
        if self._workspace is not None:
            self._workspace.status_text_set(
                f'Move {self._name}: position {self._start + 1} to {self._destination + 1}. '
                'Move the pointer vertically; click to confirm; Esc to cancel.')

    def invoke(self, context, event):
        # Native operator buttons invoke on release. This is click-move-click,
        # not a press-drag gesture; keep the stable operator ID for saved callers.
        settings = _state(context)
        self._ids = tuple(item.item_id for item in settings.items)
        if self.item_id not in self._ids or len(set(self._ids)) != len(self._ids):
            self.report({'ERROR'}, 'The worklist changed; choose the entry again.')
            return {'CANCELLED'}
        self._scene = context.scene
        self._start = self._ids.index(self.item_id)
        self._destination = self._start
        self._name = settings.items[self._start].name
        self._mouse_y = event.mouse_y
        self._row_height = _drag_row_height(context)
        self._workspace = context.workspace
        self._cancelled = False
        _DRAGS.append(self)
        self._hint()
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if self._cancelled or event.type in {'ESC', 'RIGHTMOUSE'}:
            self._finish()
            return {'CANCELLED'}
        settings = _state(context)
        if (context.scene != self._scene or settings is None
                or tuple(item.item_id for item in settings.items) != self._ids or not _idle(context)):
            self._finish()
            self.report({'WARNING'}, 'The scene or worklist changed; the move was cancelled.')
            return {'CANCELLED'}
        if event.type == 'MOUSEMOVE':
            offset = round((self._mouse_y - event.mouse_y) / self._row_height)
            self._destination = min(len(self._ids) - 1, max(0, self._start + offset))
            self._hint()
        elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self._finish()
            if self._destination == self._start:
                return {'CANCELLED'}
            return _run(self, context, 'move', self.item_id, self._destination - self._start)
        return {'RUNNING_MODAL'}

    def cancel(self, _context):
        self._finish()


def _worklist_send_key(item):
    return f'{item.rig.session_uid}:{item.custom_action.session_uid}:{item.custom_slot}:{item.item_id}'


class CHARACTERDESIGNER_OT_worklist_sync(Operator):
    bl_idname = 'character_designer.worklist_sync'
    bl_label = 'Sync Current to Unity'
    bl_description = 'Export the active Custom Action as a new Unity candidate for Preview and Apply'
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        item = _selected(_state(context))
        if (item is None or getattr(item, 'current_rig_revision', '')
                or not _active_side(item, 'CUSTOM') or not _idle(context)):
            return False
        expected = getattr(context, 'cd_worklist_send_key', '')
        return not expected or expected == _worklist_send_key(item)

    def execute(self, context):
        if not self.poll(context):
            self.report({'ERROR'}, 'Select the current editable Unity list entry again before sending.')
            return {'CANCELLED'}
        return _run(self, context, 'sync')






class CHARACTERDESIGNER_OT_worklist_rigging_edit(Operator):
    bl_idname = 'character_designer.worklist_rigging_edit'
    bl_label = 'Edit Rigging Action'
    bl_description = 'Choose the actual Action that receives native edits; Base uses Blender keying'
    bl_options = {'REGISTER', 'UNDO'}
    item_id: StringProperty(options={'HIDDEN'})
    edit_role: EnumProperty(items=(('BASE', 'Base', 'Edit the base Action'),
                                   ('RIGGING', 'Controls', 'Edit the Target/Hint controls Action')),
                            default='BASE', options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        item, _display = _editable_rigging(context)
        return item is not None and _idle(context)

    def execute(self, context):
        return _run_rigging(self, context, edit_role=self.edit_role)


class CHARACTERDESIGNER_OT_worklist_save_controls(Operator):
    bl_idname = 'character_designer.worklist_save_controls'
    bl_label = 'Save Controls'
    bl_description = 'Key the current effective Target/Hint inputs into their controls Action; does not export'
    bl_options = {'REGISTER', 'UNDO'}
    item_id: StringProperty(options={'HIDDEN'})

    @classmethod
    def poll(cls, context):
        item, display = _editable_rigging(context)
        return bool(item is not None and display['enabled'] and display['edit_role'] == 'RIGGING'
                    and _idle(context))

    def execute(self, context):
        return _run_rigging(self, context)


class CHARACTERDESIGNER_UL_animation_catalog(UIList):
    def filter_items(self, _context, data, propname):
        if not data.search.strip():
            return [], []
        flags = [self.bitflag_filter_item if _catalog_matches(item, data.search) else 0
                 for item in getattr(data, propname)]
        return flags, []

    def draw_filter(self, _context, _layout):
        pass  # The shared search field filters name and source, with no display sorting.

    def draw_item(self, context, layout, data, item, _icon, _active_data,
                  _active_propname, _index=0, _flt_flag=0):
        row = layout.row(align=True)
        row.label(text=item.name, icon='ACTION')
        if item.source_name:
            row.label(text=item.source_name)
        included = any(entry.clip_key == item.clip_key for entry in data.items)
        if included:
            row.label(text='Added', icon='CHECKMARK')
        elif not item.ready:
            row.label(text='Prepare in Unity', icon='INFO')
        else:
            controls = row.row(align=True)
            controls.enabled = _idle(context)
            controls.operator('character_designer.worklist_add', text='', icon='ADD').clip_key = item.clip_key


class CHARACTERDESIGNER_UL_animation_worklist(UIList):
    def filter_items(self, context, data, propname):
        return pins.filter_rows(self, context, data, propname)

    def draw_filter(self, _context, layout):
        layout.prop(self, 'filter_name', text='', icon='VIEWZOOM')

    def draw_item(self, context, layout, _data, item, _icon, _active_data,
                  _active_propname, _index=0, _flt_flag=0):
        row = layout.row(align=True)
        action = item.custom_action
        edit = row.row(align=True)
        edit.enabled = (_idle(context) and getattr(context, 'mode', 'OBJECT') in {'OBJECT', 'POSE'}
                        and action is not None and action.library is None)
        activate = edit.operator('character_designer.worklist_activate', text=item.name, icon='EDITMODE_HLT',
                                emboss=True, depress=(_active_data.active_index == _index
                                                      and _active_side(item, 'CUSTOM')))
        activate.item_id, activate.side = item.item_id, 'CUSTOM'
        pins.draw_pin(row, context.scene, item)


def _draw_worklist_actions(layout, context, settings):
    column = layout.column(align=True)
    column.enabled = _idle(context) and getattr(context, 'mode', 'OBJECT') in {'OBJECT', 'POSE'}
    column.template_list('CHARACTERDESIGNER_UL_animation_worklist', 'actions',
                         settings, 'items', settings, 'list_cursor', rows=5, maxrows=5)




def motion_picker_available(context):
    settings = _state(context)
    return bool(settings and settings.workspace_path and (settings.items or settings.catalog))


def draw_motion_picker(layout, context):
    from .animation_local_motion_pins import draw_local_actions
    settings = _state(context)
    if settings is None:
        return
    scene = context.scene
    only = pins.pinned_only(scene)
    edit_scene.draw_return(layout, context)
    bar = layout.row(align=True)
    for label, flag in (('All', False), ('Pinned', True)):
        bar.operator('character_designer.motion_set_view', text=label, depress=only == flag).pinned_only = flag
    local = draw_local_actions(layout, context, pinned_only=only)
    rows = settings.items if settings.items else settings.catalog
    if only and not any(pins.is_pinned(scene, item) for item in rows):
        if not local:
            layout.label(text='Pin motions in All.', icon='INFO')
        return
    if settings.items:
        _draw_worklist_actions(layout, context, settings)
    elif rows:
        layout.template_list('CHARACTERDESIGNER_UL_prepared_motions', 'prepared', settings, 'catalog',
                             settings, 'catalog_index', rows=5, maxrows=5)


def _draw_rigging(layout, context, item):
    if item is not None and has_original_inputs(item.rig):
        return
    display = _rigging_display(item.rig) if item is not None else None
    action = item.source_action if item is not None and item.side == 'SOURCE' else getattr(item, 'custom_action', None)
    if (not display or display['rig'] is not item.rig or display['scene'] is not context.scene
            or display['base_action'] is not action
            or display['source_read_only'] != (item.side == 'SOURCE')):
        return
    box = layout.box()
    box.label(text='Rigging', icon='ARMATURE_DATA')
    box.label(text='Base: ' + display['base_action'].name, icon='ACTION')
    box.label(text='Controls: ' + display['input_action'].name, icon='ACTION')
    actual = item.rig.animation_data.action if item.rig.animation_data else None
    editing = actual.name if actual is not None else 'Preview only'
    if display['source_read_only']:
        editing += ' (read-only)'
    box.label(text='Editing: ' + editing)
    row = box.row(align=True)
    row.enabled = _idle(context) and not display['source_read_only']
    for role, label in (('BASE', 'Edit Base'), ('RIGGING', 'Edit Controls')):
        operator = row.operator('character_designer.worklist_rigging_edit', text=label,
                                depress=display['tweak_enabled'] and display['edit_role'] == role)
        operator.item_id, operator.edit_role = item.item_id, role
    save = box.row()
    save.enabled = row.enabled and display['enabled'] and display['edit_role'] == 'RIGGING'
    save.operator('character_designer.worklist_save_controls', text='Save Controls', icon='KEY_HLT').item_id = item.item_id


def _draw_worklist_pose(box, context, *, recovery_only):
    from . import animation_rest_pose, animation_pose_test
    try:
        display_rig = animation_rest_pose.get_rig(context)
    except (ValueError, AttributeError, ReferenceError):
        display_rig = None
    if display_rig is not None:
        recovery_needed = animation_pose_test.active(display_rig) or display_rig.data.pose_position == 'REST'
        if recovery_needed != recovery_only:
            return
        pose_row = box.row(align=True)
        pose_row.enabled = _idle(context) and getattr(context, 'mode', '') in {'OBJECT', 'POSE'}
        testing = animation_pose_test.active(display_rig)
        natural = animation_pose_test.natural_active(display_rig)
        rest = pose_row.operator('character_designer.worklist_pose_position', text='Rest Pose',
                                 depress=natural or display_rig.data.pose_position == 'REST')
        rest.position = 'REST'
        if testing and not natural:
            pose_row.operator('character_designer.worklist_base_pose', text='Return to Animation',
                              icon='ACTION').finish = True
        else:
            show = pose_row.operator('character_designer.worklist_pose_position', text='Pose',
                                     depress=not natural and display_rig.data.pose_position == 'POSE')
            show.position = 'POSE'
        if testing:
            recovery = box.row()
            recovery.enabled = _idle(context)
            recovery.operator('character_designer.worklist_keep_base_pose_draft',
                              text='Keep Draft / Exit Test', icon='FILE_BACKUP')


def _draw_worklist_connection(box, context, settings, *, advanced):
    connection_label, connection_icon = _workspace_connection_display(settings)
    # Saved local actions need no refresh. Only setup or a failed check needs
    # these controls on the main page; they always remain available in one place.
    needs_setup = bool(settings.workspace_path and (
        connection_label != 'Connected' or not (settings.items or edit_scene.editing_scene(context.scene))))
    if (not advanced) != needs_setup:
        return
    header = box.row(align=True)
    header.operator_context = 'INVOKE_DEFAULT'
    if not settings.workspace_path:
        connection_label = 'Connect Unity Action List'
    elif connection_label == 'Connected':
        connection_label = getattr(settings, 'target_name', '') or 'Unity Action List'
    header.operator('character_designer.worklist_connect', text=connection_label, icon=connection_icon)
    if settings.workspace_path:
        local_current = any(getattr(item, 'current_rig_revision', '') for item in settings.items)
        update = header.row(align=True)
        update.enabled = _idle(context) and not local_current
        update.operator('character_designer.worklist_sync_list', text='Sync List', icon='FILE_REFRESH')


def _draw_empty_list(box, context, settings, main):
    ready = [entry for entry in getattr(settings, 'catalog', ()) if entry.ready]
    fixed = sum(bool(getattr(entry, 'target_slot_id', '')) for entry in ready)
    label = str(len(ready)) + ' prepared in Unity'
    if fixed and fixed != len(ready):
        label += ' (' + str(fixed) + ' character slots)'
    editor = edit_scene.editing_scene(context.scene)
    if not editor:
        box.label(text=label + ' · 0 local actions', icon='INFO')
    from . import animation_worklist_target as target
    if main is not None and target.is_adopted(main) and target.REFS not in main:
        box.operator('character_designer.worklist_start_from_current', text='Use Current Character', icon='ARMATURE_DATA')
    if not settings.catalog:
        return
    if ready and main is None and settings.rig is None and not any(obj.type == 'ARMATURE' for obj in context.scene.objects):
        row = box.row()
        row.enabled = _idle(context)
        row.operator('character_designer.worklist_add_ready', text='Import Prepared Motions', icon='IMPORT')
    draw_motion_picker(box, context)


def draw_worklist(layout, context, *, include_original_inputs=True, include_tools=True):
    if include_original_inputs:
        draw_original_inputs(layout, context)
    settings = _state(context)
    if settings is None:
        layout.label(text='Animation workspace is unavailable.', icon='ERROR')
        return
    box = layout.column()
    box.enabled = not original_inputs_live(context)
    _draw_worklist_connection(box, context, settings, advanced=False)
    busy = scan_pending() or _collection().running()
    _draw_worklist_pose(box, context, recovery_only=True)
    if settings.workspace_path:
        setup = getattr(context.scene, 'character_designer_setup', None)
        main = getattr(setup, 'rig', None)
        rig = getattr(settings, 'rig', None)
        if (main is not None and not (rig is not None and hasattr(rig, 'get')
                and (rig.get('character_designer_worklist_main_session_v1') is not None
                     or rig.get('character_designer_worklist_current_base_v1')))):
            row = box.row(align=True)
            row.enabled = _idle(context)
            row.operator('character_designer.worklist_use_main_rig', text='Edit Animations', icon='ARMATURE_DATA')
        local_current = any(getattr(item, 'current_rig_revision', '') for item in settings.items)
        if local_current:
            box.label(text='Current Rig: local animation versions', icon='ACTION')
            box.label(text='Prepare matching Unity sources before exporting.', icon='INFO')
        elif (settings.items and main is not None and callable(getattr(getattr(main, 'data', None), 'get', None))
                and main.data.get('character_designer_current_leg_rest_acceptance_v1') is not None):
            row = box.row()
            row.enabled = _idle(context)
            row.operator('character_designer.worklist_use_current_revision', text='Use Current Rig', icon='ARMATURE_DATA')
        if settings.items:
            draw_motion_picker(box, context)
            item = _selected(settings)
            send = box.row()
            send.enabled = (item is not None and not getattr(item, 'current_rig_revision', '')
                            and _active_side(item, 'CUSTOM') and _idle(context))
            set_key = getattr(send, 'context_string_set', None)
            if send.enabled and set_key is not None:
                set_key('cd_worklist_send_key', _worklist_send_key(item))
            send.operator('character_designer.worklist_sync', text='Send Selected to Unity', icon='EXPORT')
        else:
            _draw_empty_list(box, context, settings, main)
        _draw_rigging(box, context, _selected(settings))
        from . import animation_composition
        if hasattr(rig, "get") and rig.get(animation_composition.SESSION) is not None:
            from .animation_composition_ui import draw_composition
            draw_composition(box, context)
    if busy:
        box.operator('character_designer.worklist_cancel_collection', text='Cancel', icon='CANCEL')
    unresolved = any(
        item.scan_state in {'UNKNOWN', 'BLOCKED'} for item in settings.items)
    show_status = (settings.has_error or busy) and bool(settings.status)
    if not show_status and settings.status.startswith('Synced '):
        from .animation_physics_ui import wrapped_label
        if settings.show_advanced:
            wrapped_label(box, context, settings.status, icon='CHECKMARK')
        else:
            wrapped_label(box, context, 'Last send: preview the candidate in Unity.', icon='CHECKMARK')
            if '. Omitted: ' in settings.status:
                wrapped_label(box, context, 'Omitted: ' + settings.status.split('. Omitted: ', 1)[1])
    if show_status:
        width = max(24, int(getattr(context.region, 'width', 300) / (7 * (context.preferences.system.ui_scale or 1.0))) - 6)
        for index, line in enumerate(textwrap.wrap(settings.status, width=width)):
            box.label(text=line, icon=('ERROR' if settings.has_error else 'INFO') if index == 0 else 'BLANK1')
    if ((busy or unresolved or getattr(settings, 'collection_feedback', False)) and settings.collection_status
            and (not show_status or settings.collection_status != settings.status)):
        width = max(24, int(getattr(context.region, 'width', 300) / (7 * (context.preferences.system.ui_scale or 1.0))) - 6)
        for index, line in enumerate(textwrap.wrap(settings.collection_status, width=width)):
            box.label(text=line, icon='INFO' if index == 0 else 'BLANK1')
    selected = _selected(settings)
    if (unresolved and selected is not None and selected.scan_state in {'UNKNOWN', 'BLOCKED'}
            and selected.scan_reason and selected.scan_reason != settings.collection_status):
        width = max(24, int(getattr(context.region, 'width', 300) / (7 * (context.preferences.system.ui_scale or 1.0))) - 6)
        for index, line in enumerate(textwrap.wrap(selected.scan_reason, width=width)):
            box.label(text=line, icon=('ERROR' if selected.scan_state == 'BLOCKED' else 'INFO') if index == 0 else 'BLANK1')

    if include_tools:
        draw_worklist_tools(layout, context)


def draw_worklist_tools(layout, context):
    settings = _state(context)
    if settings is None:
        return
    layout.prop(settings, 'show_advanced', text='Advanced', emboss=False,
                icon='TRIA_DOWN' if settings.show_advanced else 'TRIA_RIGHT')
    if not settings.show_advanced:
        return
    from .control_pose_capture import draw as draw_pose_capture
    draw_pose_capture(layout, context)
    box = layout.column()
    box.enabled = not original_inputs_live(context)
    _draw_worklist_connection(box, context, settings, advanced=True)
    _draw_worklist_pose(box, context, recovery_only=False)
    if not settings.workspace_path:
        return
    rig = getattr(settings, 'rig', None)
    local_current = any(getattr(item, 'current_rig_revision', '') for item in settings.items)
    batch = box.row()
    batch.enabled = _idle(context) and not local_current
    batch.operator('character_designer.worklist_sync_changed', text='Export Changes', icon='EXPORT')
    if _prepared_rigging_target(context):
        prepared = box.row()
        prepared.enabled = _idle(context) and not local_current
        prepared.operator_context = 'INVOKE_DEFAULT'
        prepared.operator('character_designer.worklist_add_prepared_animation',
                          text='Add Prepared Animation', icon='ADD')
    if settings.items:
        draw_controller_animation(box, context)
    from . import animation_composition
    if not hasattr(rig, "get") or rig.get(animation_composition.SESSION) is None:
        from .animation_composition_ui import draw_composition
        draw_composition(box, context)
    files = box.row(align=True)
    files.enabled = _idle(context)
    files.operator('character_designer.worklist_package_dependencies', text='Package Editing Files', icon='PACKAGE')
    files.operator('character_designer.worklist_locate_dependencies', text='Locate Editing Files', icon='FILE_FOLDER')
    selected = _selected(settings)
    if (selected is not None and selected.side == 'CUSTOM'
            and selected.rig is not None and selected.custom_action is not None):
        export_base = box.row()
        export_base.enabled = _idle(context) and _active_custom_action(context)
        capture = export_base.operator('character_designer.animation_export_base_pose',
                                       text='Capture Export Base Pose', icon='POSE_HLT')
        capture.rig_name = selected.rig.name
        capture.action_name = selected.custom_action.name
        capture.clear = False
        if ('character_designer_animation_export_base_v1' in selected.custom_action
                or 'character_designer_animation_export_base_v1_count' in selected.custom_action):
            clear_base = box.row()
            clear_base.enabled = export_base.enabled
            clear = clear_base.operator('character_designer.animation_export_base_pose',
                                        text='Clear Export Base Pose', icon='X')
            clear.rig_name = selected.rig.name
            clear.action_name = selected.custom_action.name
            clear.clear = True
    base = box.operator('character_designer.worklist_base_pose', text='Base Pose',
                        icon='LOOP_BACK')
    base.finish = False
    box.operator('character_designer.worklist_register_new', text='New Action', icon='ACTION')
    retired = getattr(settings, 'retired_items', ())
    if retired:
        archive = box.box()
        archive.label(text='Retired Animations (' + str(len(retired)) + ')', icon='FILE_BACKUP')
        for item in retired:
            row = archive.row(align=True)
            row.label(text=item.name, icon='ACTION')
            restore = row.operator('character_designer.worklist_restore_retired', text='Restore')
            restore.item_id = item.item_id
            discard = row.operator('character_designer.worklist_discard_retired', text='Discard', icon='TRASH')
            discard.item_id = item.item_id
    if (rig is not None and hasattr(rig, 'get')
            and rig.get('character_designer_worklist_main_session_v1') is not None):
        box.operator('character_designer.worklist_restore_main_rig',
                     text='Restore Main Rig', icon='LOOP_BACK')


WORKLIST_CLASSES = (
    *ORIGINAL_INPUT_CLASSES,
    *CONTROLLER_ANIMATION_CLASSES,
    CharacterDesignerAnimationWorklistCatalog,
    CharacterDesignerAnimationWorklistItem,
    CharacterDesignerAnimationWorklistState,
    CHARACTERDESIGNER_OT_worklist_package_dependencies,
    CHARACTERDESIGNER_OT_worklist_locate_dependencies,
    CHARACTERDESIGNER_OT_worklist_connect,
    CHARACTERDESIGNER_OT_worklist_add_prepared_animation,
    CHARACTERDESIGNER_OT_worklist_refresh,
    CHARACTERDESIGNER_OT_worklist_sync_list,
    CHARACTERDESIGNER_OT_worklist_sync_review,
    CHARACTERDESIGNER_OT_worklist_sync_confirm,
    CHARACTERDESIGNER_OT_worklist_sync_discard_confirm,
    CHARACTERDESIGNER_OT_worklist_sync_back,
    CHARACTERDESIGNER_OT_worklist_restore_retired,
    CHARACTERDESIGNER_OT_worklist_discard_retired,
    CHARACTERDESIGNER_OT_worklist_start_from_current,
    CHARACTERDESIGNER_OT_worklist_use_main_rig,
    CHARACTERDESIGNER_OT_worklist_restore_main_rig,
    CHARACTERDESIGNER_OT_worklist_pose_position,
    CHARACTERDESIGNER_OT_worklist_base_pose,
    CHARACTERDESIGNER_OT_worklist_keep_base_pose_draft,
    CHARACTERDESIGNER_OT_worklist_use_current_revision,
    CHARACTERDESIGNER_OT_worklist_add,
    CHARACTERDESIGNER_OT_worklist_add_ready,
    CHARACTERDESIGNER_OT_worklist_scan_changes,
    CHARACTERDESIGNER_OT_worklist_register_new,
    CHARACTERDESIGNER_OT_worklist_sync_changed,
    CHARACTERDESIGNER_OT_worklist_cancel_collection,
    CHARACTERDESIGNER_OT_worklist_activate,
    CHARACTERDESIGNER_OT_worklist_remove,
    CHARACTERDESIGNER_OT_worklist_move,
    CHARACTERDESIGNER_OT_worklist_drag_handle,
    CHARACTERDESIGNER_OT_worklist_drag,
    CHARACTERDESIGNER_OT_worklist_sync,
    CHARACTERDESIGNER_OT_worklist_rigging_edit,
    CHARACTERDESIGNER_OT_worklist_save_controls,
    CHARACTERDESIGNER_UL_animation_catalog,
    CHARACTERDESIGNER_UL_animation_worklist,
    *edit_scene.CLASSES,
    *pins.CLASSES,
)
