"""Ordered existing-ring allocation for the shared finger joint workflow.

Original rows are never removed. Centers have priority over support reuse, and
every allocation is checked with all remaining rows and targets in their final
order. Data transfer remains on the immutable captured surface rails.
"""
from functools import lru_cache
import math

from mathutils import Vector

from . import finger_layout as layout, finger_ring_slide as slide


def fill_between(pair):
    """Read the new toggle while preserving an older saved zero-between choice."""
    legacy = bool(getattr(pair, 'between', 1))
    if (hasattr(pair, 'fill_between') and hasattr(pair, 'is_property_set') and
            not pair.is_property_set('fill_between')):
        return legacy
    return bool(getattr(pair, 'fill_between', legacy))


def _allocate(ts, rings, protected):
    """Globally match ordered rows and targets, giving centers first priority.

The dynamic program emits a kept source row, a new target, or a reused row.
Strictly ordered emissions make crossing/collapse impossible, including when
adjacent old rows both move. Per-column supports emit their full time envelope;
they can be inserted but cannot deform a reused scalar source row.
"""
    spans = [(min(r.get('times', [r['t']])), max(r.get('times', [r['t']]))) for r in rings]
    size, count = len(ts), len(rings)

    @lru_cache(maxsize=None)
    def visit(i, j, last):
        previous = ts[i-1] if last == 0 else spans[j-1][1] if last == 1 else -math.inf
        if i == size and j == count:
            return (0, 0., 0, 0.), ()
        choices = []
        if i < size and ts[i] > previous+layout.EPS:
            tail = visit(i+1, j, 0)
            if tail is not None: choices.append(tail)
        if j < count and spans[j][0] > previous+layout.EPS:
            center = rings[j]['kind'].startswith('JOINT')
            tail = visit(i, j+1, 1)
            if tail is not None:
                score = list(tail[0]); score[0 if center else 2] += 1
                choices.append((tuple(score), (None,)+tail[1]))
            uniform = 'times' not in rings[j]
            if (0 < i < size-1 and uniform and
                    (i not in protected or abs(ts[i]-rings[j]['t']) < layout.EPS)):
                tail = visit(i+1, j+1, 1)
                if tail is not None:
                    score = list(tail[0]); score[1 if center else 3] += abs(ts[i]-rings[j]['t'])
                    choices.append((tuple(score), (i,)+tail[1]))
        if not choices: return None
        return min(choices, key=lambda value: (value[0], tuple(size if x is None else x for x in value[1])))

    result = visit(0, 0, -1)
    if result is None:
        raise ValueError('Asymmetric support crosses an existing or protected ring. Reduce width/spacing, or use equal spacing.')
    return result[1]


def _ring(source, rows, ts, t, kind, joint, flank, *, times=None):
    points, band, fraction = layout._sample(source, rows, ts, t)
    ring = dict(t=t, kind=kind, joint=joint, flank=flank, points=points,
                band=band, fraction=fraction, blocked=False)
    if times is not None:
        ring['times'] = times
        ring['points'] = [layout._sample(source, rows, ts, value)[0][i] for i, value in enumerate(times)]
    return ring


def build_plan(obj, source, recipe, pair):
    rows, ts = recipe['rings'], recipe['positions']
    if (len(rows) < 3 or len(rows) != len(ts) or not rows[0] or
            any(len(row) != len(rows[0]) for row in rows) or
            any(not math.isfinite(t) for t in ts) or
            any(b-a <= layout.EPS for a, b in zip(ts, ts[1:]))):
        raise ValueError('Prepared surface rows are invalid; prepare this finger again.')
    ordered = sorted(enumerate(pair.joints), key=lambda item: item[1].position)
    if not ordered: raise ValueError('Prepare at least one joint marker.')
    varying = any(abs(j.inner_spacing-j.outer_spacing) > 1e-6 for _, j in ordered)
    axis = bend = None
    if varying:
        if not recipe.get('normal'):
            raise ValueError('Asymmetric spacing needs this finger\'s bend side.')
        normal = Vector(recipe['normal'])*(1 if recipe.get('flip_bend') else -1)
        axis = Vector(recipe['tip'])-Vector(recipe['root'])
        if axis.length <= layout.EPS: raise ValueError('The prepared finger axis is degenerate.')
        axis.normalize()
        bend = normal-axis*normal.dot(axis)
        if bend.length <= layout.EPS: raise ValueError('The prepared bend side is parallel to the finger.')
        bend.normalize()
    rings, intervals = [], []
    for joint_id, joint in ordered:
        values = (joint.position, joint.width, joint.inner_spacing, joint.outer_spacing)
        if any(not math.isfinite(value) for value in values) or min(values[1:]) <= 0:
            raise ValueError('Joint widths and spacing must be finite positive values.')
        outer = joint.width*max(joint.inner_spacing, joint.outer_spacing)
        if joint.position-outer <= ts[0]+layout.EPS or joint.position+outer >= ts[-1]-layout.EPS:
            raise ValueError(f'Joint {joint_id+1} support region crosses the protected root/tip. Reduce width or move the marker.')
        if intervals and joint.position-outer <= intervals[-1][1]+.002:
            raise ValueError('Joint support/weight regions overlap; separate the markers or reduce widths.')
        intervals.append((joint.position-outer, joint.position+outer))
        center_points = layout._sample(source, rows, ts, joint.position)[0]
        center = sum(center_points, Vector())/len(center_points)
        asymmetric = abs(joint.inner_spacing-joint.outer_spacing) > 1e-6
        for flank in (-1, 0, 1):
            times = None
            t = joint.position+flank*joint.width*joint.inner_spacing
            if flank and asymmetric:
                times = []
                for point in center_points:
                    radial = point-center-axis*(point-center).dot(axis)
                    mix = .5+.5*radial.normalized().dot(bend)
                    factor = joint.outer_spacing+(joint.inner_spacing-joint.outer_spacing)*mix
                    times.append(joint.position+flank*joint.width*factor)
                t = sum(times)/len(times)
            rings.append(_ring(source, rows, ts, t, 'JOINT_'+str(joint_id+1) if not flank else 'SUPPORT',
                               joint_id, flank, times=times))
    rings.sort(key=lambda ring: ring['t'])
    protected = set(recipe['protected_rows']) if 'protected_rows' in recipe else slide.protected_rows(source, rows)
    assignments = _allocate(ts, rings, protected)
    moves, used = {}, set()
    for ring, row in zip(rings, assignments):
        if row is None:
            ring['allocation'] = 'NEW'
            continue
        ring.update(reuse=row, source_row=row, source_t=ts[row])
        used.add(row)
        if abs(ts[row]-ring['t']) < layout.EPS:
            # Preserve an exact authored section, including protected seams.
            ring['t'] = ts[row]
            ring['points'], ring['band'], ring['fraction'] = layout._sample(source, rows, ts, ts[row])
            ring['allocation'] = 'REUSED'
        else:
            moves[row] = ring['t']
            ring['allocation'] = 'MOVED'
    positions = [moves.get(i, t) for i, t in enumerate(ts)]
    between_gaps = []
    for (left_id, _), (right_id, _) in zip(ordered, ordered[1:]):
        left = next(r for r in rings if r['joint'] == left_id and r['flank'] == 1)
        right = next(r for r in rings if r['joint'] == right_id and r['flank'] == -1)
        a, b = max(left.get('times', [left['t']])), min(right.get('times', [right['t']]))
        ordinary = [i for i, t in enumerate(positions) if i not in used and a+layout.EPS < t < b-layout.EPS]
        added = not ordinary and fill_between(pair)
        if added:
            ring = _ring(source, rows, ts, (a+b)*.5, 'BETWEEN', -1, 0)
            ring['allocation'] = 'NEW'
            rings.append(ring)
        between_gaps.append(dict(left_joint=left_id, right_joint=right_id,
                                 ordinary_count=len(ordinary), ordinary_rows=ordinary, added=bool(added)))
    rings.sort(key=lambda ring: ring['t'])
    plan = dict(obj=obj, rows=rows, positions=ts, rings=rings, moves=moves,
                protected_rows=protected, sliding=True, joint_reuse=True, defined=True,
                root=[source.vertices[i].co.copy() for i in rows[0]],
                tip=[source.vertices[i].co.copy() for i in rows[-1]], between_gaps=between_gaps,
                allocation_counts={kind: sum(r['allocation'] == kind for r in rings) for kind in ('REUSED', 'MOVED', 'NEW')})
    # Validate all insertion bands now, while planning is still read-only.
    slide.split_plan(plan, source)
    return plan
