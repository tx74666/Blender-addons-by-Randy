"""Animation-page physics controls; drawing reads saved metadata only."""

from bpy.props import BoolProperty, EnumProperty, StringProperty
from bpy.types import Operator


def _service():
    from . import animation_physics
    return animation_physics


def _target_token(rig):
    return str(rig.as_pointer()) if rig is not None else ""


def _capture_target(operator, state):
    rig = state.get("rig")
    operator.target_name = rig.name if rig is not None else ""
    operator.target_pointer = _target_token(rig)
    return operator


def _checked_target(operator, context):
    state = _service().status(context)
    if not state.get("valid", False):
        raise ValueError(state.get("message") or "Physics settings need review before changing them.")
    rig = state.get("rig")
    if (rig is None or rig.name != operator.target_name
            or _target_token(rig) != operator.target_pointer):
        raise ValueError("The current character changed. Use its Physics controls again.")
    return state


def _run(operator, context, action):
    try:
        _checked_target(operator, context)
        action()
    except (ValueError, RuntimeError, ReferenceError, TypeError, KeyError) as error:
        operator.report({"ERROR"}, str(error))
        return {"CANCELLED"}
    area = getattr(context, "area", None)
    if area is not None:
        area.tag_redraw()
    return {"FINISHED"}


class CHARACTERDESIGNER_OT_animation_physics_set(Operator):
    bl_idname = "character_designer.animation_physics_set"
    bl_label = "Set Animation Physics"
    bl_description = "Enable or pause this character's physics while retaining its setup and modes"
    bl_options = {"REGISTER", "UNDO"}

    component: EnumProperty(items=(
        ("ALL", "All Physics", "This character's master physics switch"),
        ("SKIRT", "Skirt", "This character's skirt physics"),
        ("HAIR", "Hair", "This character's hair physics"),
    ), default="ALL")
    enabled: BoolProperty(default=True)
    target_name: StringProperty(options={"HIDDEN"})
    target_pointer: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        def apply():
            if self.component == "ALL":
                _service().set_enabled(context, self.enabled)
            else:
                _service().set_component(context, self.component, self.enabled)
        return _run(self, context, apply)


class CHARACTERDESIGNER_OT_animation_physics_skirt_mode(Operator):
    bl_idname = "character_designer.animation_physics_skirt_mode"
    bl_label = "Set Skirt Motion Mode"
    bl_description = "Change the existing skirt motion mode without creating another setup"
    bl_options = {"REGISTER", "UNDO"}

    source_name: StringProperty(options={"HIDDEN"})
    source_owner: StringProperty(options={"HIDDEN"})
    mode: EnumProperty(items=(
        ("AUTOMATIC", "Automatic", "Use this skirt's automatic motion"),
        ("MANUAL", "Manual", "Use this skirt's manual motion mode"),
    ), default="MANUAL")
    target_name: StringProperty(options={"HIDDEN"})
    target_pointer: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        return _run(self, context, lambda: _service().set_skirt_mode(
            context, self.source_name, self.mode, expected_owner=self.source_owner))


class CHARACTERDESIGNER_OT_animation_physics_start_hair(Operator):
    bl_idname = "character_designer.animation_physics_start_hair"
    bl_label = "Start Hair Preview"
    bl_description = "Start this character's Hair physics preview using its existing strand settings"
    bl_options = {"REGISTER", "UNDO"}

    target_name: StringProperty(options={"HIDDEN"})
    target_pointer: StringProperty(options={"HIDDEN"})

    def execute(self, context):
        return _run(self, context, lambda: _service().start_hair_preview(context))


def _checkbox(layout, state, *, component, label, checked, enabled):
    row = layout.row(align=True)
    row.enabled = enabled
    operator = row.operator(
        CHARACTERDESIGNER_OT_animation_physics_set.bl_idname, text=label,
        icon="CHECKBOX_HLT" if checked else "CHECKBOX_DEHLT", emboss=False)
    operator.component = component
    operator.enabled = not checked
    _capture_target(operator, state)


def draw(layout, context):
    """Draw permissions separately from backend activity or stored skirt mode."""
    box = layout.box()
    box.label(text="Physics", icon="PHYSICS")
    try:
        state = _service().status(context)
    except (ValueError, RuntimeError, ReferenceError, TypeError, KeyError) as error:
        box.label(text=str(error), icon="ERROR")
        return
    rig = state.get("rig")
    if not state.get("valid", False):
        box.label(text=state.get("message") or "Physics settings need review.", icon="INFO")
        return
    enabled = bool(state.get("enabled", True))
    editable = rig is not None and context.mode in {"OBJECT", "POSE"}
    dresses = state.get("dresses", ())
    hair = state.get("hair", {})
    _checkbox(box, state, component="ALL", label="Enable Physics", checked=enabled,
              enabled=editable)
    if rig is None:
        box.label(text=state.get("message") or "Choose the character's Main Rig first.", icon="INFO")
        return
    box.label(text="Character: " + rig.name)
    components = box.column(align=True)
    _checkbox(components, state, component="SKIRT", label="Skirt",
              checked=bool(state.get("skirt_enabled", True)),
              enabled=editable and enabled and bool(dresses))
    _checkbox(components, state, component="HAIR", label="Hair",
              checked=bool(state.get("hair_enabled", True)),
              enabled=editable and enabled and bool(hair.get("sources")))
    if not enabled:
        box.label(text="Enable Physics is off. Saved modes are retained.", icon="INFO")
    if state.get("message"):
        box.label(text=state["message"], icon="INFO")
    skirt_enabled = enabled and bool(state.get("skirt_enabled", True))
    for dress in dresses:
        column = box.column(align=True)
        column.label(text="Skirt: " + dress.get("name", dress["source"]))
        row = column.row(align=True)
        can_change = editable and (skirt_enabled or dress.get("can_change_mode_paused", False))
        for mode, label in (("AUTOMATIC", "Automatic"), ("MANUAL", "Manual")):
            choice = row.row(align=True)
            choice.enabled = can_change and (mode == "MANUAL" or dress.get("available", False))
            operator = choice.operator(
                CHARACTERDESIGNER_OT_animation_physics_skirt_mode.bl_idname,
                text=label, depress=dress.get("mode") == mode)
            operator.source_name = dress["source"]
            operator.source_owner = dress.get("owner", "")
            operator.mode = mode
            _capture_target(operator, state)
        if not skirt_enabled and not dress.get("can_change_mode_paused", False):
            column.label(text="Enable skirt physics before changing its mode.", icon="INFO")
        if dress.get("message"):
            column.label(text=dress["message"], icon="INFO")
    if not dresses:
        box.label(text="No skirt setup on this character.", icon="INFO")
    if hair.get("sources"):
        paused = bool(hair.get("paused", False))
        running = bool(hair.get("running", hair.get("active", False) and not paused))
        if paused:
            box.label(text="Hair physics paused.")
        elif running:
            box.label(text="Hair preview active.")
        else:
            box.label(text="Hair preview inactive.")
        if not running:
            row = box.row(align=True)
            row.enabled = (editable and enabled and bool(state.get("hair_enabled", True))
                           and bool(hair.get("available", False)))
            operator = row.operator(CHARACTERDESIGNER_OT_animation_physics_start_hair.bl_idname,
                                    text="Resume Hair Preview" if paused else "Start Hair Preview",
                                    icon="PLAY")
            _capture_target(operator, state)
    else:
        box.label(text="No initialized Hair motion on this character.", icon="INFO")
    if hair.get("message"):
        box.label(text=hair["message"], icon="INFO")


PHYSICS_CLASSES = (
    CHARACTERDESIGNER_OT_animation_physics_set,
    CHARACTERDESIGNER_OT_animation_physics_skirt_mode,
    CHARACTERDESIGNER_OT_animation_physics_start_hair,
)
