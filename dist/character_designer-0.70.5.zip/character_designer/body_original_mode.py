"""Explicit, persistent direct posing of native bones through Body Controls."""
import json

import bpy
from . import bone_display as display, bone_collections as groups, limb_ik, limb_ik_fk as match
from . import control_pose_assets as poses

SESSION = 'character_designer_body_original_mode_v1'
_CHANNELS = ('location', 'rotation_euler', 'rotation_quaternion', 'rotation_axis_angle', 'scale')
_LOCKS = ('lock_rotation', 'lock_rotation_w', 'lock_rotations_4d')


def active(rig):
    return bool(rig and rig.type == 'ARMATURE' and SESSION in rig)


def _update(context, rig):
    match._update(context, rig)


def _pose(rig):
    return {name: rig.pose.bones[name].matrix.copy() for name in poses.native_rest(rig)}


def _channels(rig):
    return {pb.name: {'mode': pb.rotation_mode,
                     'channels': {key: list(getattr(pb, key)) for key in _CHANNELS},
                     'ik_fk': pb.get('ik_fk')}
            for pb in rig.pose.bones}


def _restore_channels(rig, state):
    for name, entry in state.items():
        pb = rig.pose.bones[name]
        pb.rotation_mode = entry['mode']
        for key, values in entry['channels'].items():
            setattr(pb, key, values)
        if entry['ik_fk'] is not None:
            pb['ik_fk'] = entry['ik_fk']


def _locks(rig, names):
    return {name: {key: list(value) if hasattr(value, '__len__') else value
                   for key in _LOCKS for value in (getattr(rig.pose.bones[name], key),)}
            for name in names}


def _restore_locks(rig, state):
    for name, fields in state.items():
        for key, value in fields.items():
            setattr(rig.pose.bones[name], key, value)


def _owned_sources(rig, names):
    """Resolve exact validated ownership records, never prefixes or proximity."""
    from . import torso_controls, spine_ik_fk, eye_controls, root_control, foot_controls
    inventory = limb_ik._validate_inventory(rig)
    if any(match.VERSION_KEY not in rig.pose.bones[entry['target'].name].bone for entry in inventory['rigs'].values()):
        raise ValueError('Update this legacy Body setup before using Original mode.')
    entries = {(pb.name, con.name): con for pb, con, _record in limb_ik._owned_constraint_records(rig)
               if pb.name in names}
    records = [module.validate(rig) for module in (torso_controls, spine_ik_fk, eye_controls, root_control)]
    records.extend(foot_controls.records(rig).values())
    for record in records:
        for entry in record['constraints'] if record else ():
            if entry['owner'] in names:
                entries[(entry['owner'], entry['name'])] = rig.pose.bones[entry['owner']].constraints[entry['name']]
    return [{'bone': bone, 'name': name, 'type': con.type, 'mute': con.mute}
            for (bone, name), con in sorted(entries.items())]


def _resolve(rig, entries):
    result = []
    for entry in entries:
        pb = rig.pose.bones.get(entry['bone'])
        con = pb.constraints.get(entry['name']) if pb else None
        if con is None or con.type != entry['type']:
            raise ValueError('An Original mode constraint was changed or removed; undo that edit before returning.')
        result.append((con, entry))
    return result


def _verify(rig, desired):
    errors = {name: poses._difference(matrix, rig.pose.bones[name].matrix) for name, matrix in desired.items()}
    worst = max(errors, key=errors.get)
    if not all(limb_ik._matrix_is_finite(rig.pose.bones[name].matrix) for name in desired) or errors[worst] > 4e-4:
        raise ValueError(f'Original mode could not preserve {worst} ({errors[worst]:.4g}); the switch was rolled back.')
    return errors[worst]


def _bake_sources(context, rig, desired, entries):
    changed = {entry['bone'] for entry in entries}
    # convert_local_to_pose respects unusual inheritance flags and connected parents;
    # the PoseBone.matrix setter does not reliably reproduce these native frames.
    for _attempt in range(4):
        for name in sorted(desired, key=lambda n: len(rig.pose.bones[n].parent_recursive)):
            pb = rig.pose.bones[name]
            if name not in changed and any(not con.mute for con in pb.constraints):
                continue
            if name not in changed and poses._difference(pb.matrix, desired[name]) < 1e-7:
                continue
            kwargs = {'parent_matrix': pb.parent.matrix, 'parent_matrix_local': pb.parent.bone.matrix_local} if pb.parent else {}
            pb.matrix_basis = pb.bone.convert_local_to_pose(desired[name], pb.bone.matrix_local, invert=True, **kwargs)
            _update(context, rig)
        if max(poses._difference(rig.pose.bones[name].matrix, matrix) for name, matrix in desired.items()) < 3e-5:
            break


def _require(context, rig):
    display._editable(rig)
    if context.mode not in {'OBJECT', 'POSE'}:
        raise ValueError('Finish the current edit or weight session, then switch Original in Object or Pose Mode.')
    if rig.override_library or rig.name not in context.view_layer.objects:
        raise ValueError('Choose a local character rig in this view layer.')
    if context.scene.get('character_designer_weight_workspace_v1', {}).get('rig') == rig:
        raise ValueError('Use Back to Controls to finish Edit Weights first.')


def enter(context, rig):
    _require(context, rig)
    if active(rig):
        raise ValueError('This rig is already in Original mode.')
    original = rig.data.collections_all.get('Original')
    if original is None or original.get(groups.GROUP_KEY) != 'Original':
        raise ValueError('Organize this character\'s Bone Collections first.')
    names = set(original.bones.keys())
    if not names or any(rig.data.bones[name].get(limb_ik.OWNER_KEY) in limb_ik.GENERATED_CONTROL_OWNERS for name in names):
        raise ValueError('Original must contain the native character bones only.')
    entries = _owned_sources(rig, names)
    if rig.animation_data:
        prefixes = tuple(rig.pose.bones[name].path_from_id() + '.' + prop for name in names for prop in _CHANNELS)
        if any(not curve.mute and curve.data_path.startswith(prefixes) for curve in rig.animation_data.drivers):
            raise ValueError('A native transform driver still controls Original; preserve or adjust that driver before direct posing.')
    _update(context, rig)
    desired = _pose(rig)
    before = _channels(rig)
    checkpoint = display._checkpoint(display._affected(context, rig))
    ctx = limb_ik._capture_context(context, rig)
    locks = _locks(rig, names)
    saved = None
    try:
        # Recover a legacy display-only isolation before starting this explicit session.
        display.restore_view(rig)
        saved = {'version': 1, 'rest': poses.native_rest(rig), 'bones': sorted(rig.data.bones.keys()),
                 'names': sorted(names), 'constraints': entries, 'channels': before, 'locks': locks,
                 'display': display._snapshot(rig),
                 'pose': {name: [list(row) for row in matrix] for name, matrix in desired.items()}}
        rig[SESSION] = json.dumps(saved, separators=(',', ':'))
        limb_ik._mode_set(context, rig, 'POSE')
        for con, entry in _resolve(rig, entries):
            con.mute = True
        _update(context, rig)
        _bake_sources(context, rig, desired, entries)
        _verify(rig, desired)
        saved['entered_channels'] = _channels(rig)
        rig[SESSION] = json.dumps(saved, separators=(',', ':'))
        rig.data.show_bone_custom_shapes = False
        rig.data.display_type = 'OCTAHEDRAL'
        # Solo is an explicit output of this button; native visibility never triggers it.
        for collection in rig.data.collections_all:
            collection.is_solo = collection == original
        original.is_visible = True
        for bone in rig.data.bones:
            display._set_hidden(rig, bone, bone.name not in names)
            if bone.name in names:
                bone.hide_select = False
                pb = rig.pose.bones[bone.name]
                pb.lock_rotation = (False, False, False)
                pb.lock_rotation_w = pb.lock_rotations_4d = False
        groups._FRAME_CACHE.clear()
        display._completed(rig)
    except Exception:
        for con, entry in _resolve(rig, entries):
            con.mute = entry['mute']
        _restore_channels(rig, before)
        _restore_locks(rig, locks)
        display._rollback(checkpoint)
        rig.pop(SESSION, None)
        limb_ik._restore_context(context, rig, ctx)
        _update(context, rig)
        raise
    return {'bones': len(names), 'constraints': len(entries)}


def leave(context, rig):
    _require(context, rig)
    if not active(rig):
        return False
    saved = json.loads(rig[SESSION])
    if saved['bones'] != sorted(rig.data.bones.keys()) or saved['rest'] != poses.native_rest(rig):
        raise ValueError('The skeleton was structurally edited in Original mode; undo that edit before returning.')
    relations = _resolve(rig, saved['constraints'])
    _update(context, rig)
    desired = _pose(rig)
    current_channels = _channels(rig)
    edited = any(current_channels[name] != saved['entered_channels'][name] for name in desired)
    checkpoint = (_channels(rig), display._snapshot(rig), _locks(rig, saved['names']),
                  [(con, con.mute) for con, _entry in relations])
    try:
        _restore_channels(rig, saved['channels'])
        _restore_locks(rig, saved['locks'])
        for con, entry in relations:
            con.mute = entry['mute']
        _update(context, rig)
        limb_ik._validate_inventory(rig)
        changed = {name for name in desired if poses._difference(desired[name], rig.pose.bones[name].matrix) > 1e-7}
        if changed and edited:
            poses._match(context, rig, desired, changed, preserve_modes=True)
        _update(context, rig)
        _verify(rig, desired)
        display._restore(rig, saved['display'])
        rig.pop(SESSION)
        groups._FRAME_CACHE.clear()
        groups._frame_visibility(context.scene)
        display._completed(rig)
    except Exception:
        channels, view, locks, mutes = checkpoint
        _restore_channels(rig, channels)
        _restore_locks(rig, locks)
        for con, muted in mutes:
            con.mute = muted
        display._restore(rig, view)
        rig[SESSION] = json.dumps(saved, separators=(',', ':'))
        _update(context, rig)
        raise
    return True


class CHARACTERDESIGNER_OT_body_original_mode(bpy.types.Operator):
    bl_idname = 'character_designer.body_original_mode'
    bl_label = 'Original'
    bl_description = 'Pose native bones directly, then return to the saved body controls while keeping the pose'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        try:
            return display.character_rig(context) is not None and context.mode in {'OBJECT', 'POSE'}
        except (ValueError, ReferenceError):
            return False

    def execute(self, context):
        try:
            rig = display.character_rig(context)
            if active(rig):
                leave(context, rig)
                self.report({'INFO'}, 'Body controls restored; current pose kept.')
            else:
                enter(context, rig)
                self.report({'INFO'}, 'Original mode: rotate native bones in Pose Mode. Use Back to Controls to return.')
            return {'FINISHED'}
        except (ValueError, RuntimeError, KeyError, TypeError, ReferenceError) as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}


def draw(layout, context):
    rig = display.character_rig(context)
    if rig is None:
        return False
    running = active(rig)
    if not running and groups.body_collection(rig) is None:
        return False
    layout.operator('character_designer.body_original_mode',
                    text='Back to Controls' if running else 'Original',
                    icon='LOOP_BACK' if running else 'BONE_DATA', depress=running)
    if running:
        layout.label(text='Original · Pose Mode', icon='INFO')
        from . import control_weight_paint
        layout.operator('character_designer.control_weights',
                        text='Back to Original' if control_weight_paint.active(context) else 'Edit Weights',
                        icon='LOOP_BACK' if control_weight_paint.active(context) else 'WPAINT_HLT')
    return running


BODY_ORIGINAL_CLASSES = (CHARACTERDESIGNER_OT_body_original_mode,)
