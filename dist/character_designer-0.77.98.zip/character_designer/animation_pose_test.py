"""An owned, persistent Body-pose sandbox; never edit the previous Action.

Only the scratch Action and the rig's token own the session. No handlers or
process-local cache are needed after Undo, save or reload. A keyed scratch is
retained as an ordinary draft instead of being cleared by Reset or Finish.
"""

from contextlib import contextmanager
import hashlib
import json
import uuid

import bpy


TOKEN_KEY = 'character_designer_base_pose_test_v1'
SESSION_KEY = 'character_designer_base_pose_test_session_v1'
REFS_KEY = 'character_designer_base_pose_test_refs_v1'
_TRANSFORMS = ('location', 'rotation_euler', 'rotation_quaternion',
               'rotation_axis_angle', 'scale')
_PROPERTIES = ('ik_fk', 'uniform_scale')
_ANIMATION = ('use_nla', 'action_blend_type', 'action_influence', 'action_extrapolation')


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(',', ':'), allow_nan=False)


def _digest(value):
    return hashlib.sha256(_encoded(value).encode('utf-8')).hexdigest()


def _pack(payload):
    return _encoded({'payload': payload, 'sha256': _digest(payload)})


def _unpack(raw):
    try:
        envelope = json.loads(raw)
        payload = envelope['payload']
        valid = (set(envelope) == {'payload', 'sha256'}
                 and envelope['sha256'] == _digest(payload)
                 and payload['version'] == 1
                 and uuid.UUID(hex=payload['token']).hex == payload['token']
                 and uuid.UUID(hex=payload['action_id']).hex == payload['action_id'])
    except (ValueError, TypeError, KeyError, OverflowError) as exc:
        raise ValueError('The Base Pose recovery record is invalid; it was preserved.') from exc
    _require(valid, 'The Base Pose recovery record changed; it was preserved.')
    return payload


def active(rig):
    """An invalid token still requires recovery, rather than starting over it."""
    return rig is not None and TOKEN_KEY in rig


def _rig(context):
    from . import animation_rest_pose
    return animation_rest_pose.get_rig(context)


def _pose_owner(rig):
    """Prove isolation for existing pose/display changes, never rig rebuilding.

    ID references from retained Actions do not evaluate another pose. A second
    actual Object binding does, including hidden or unlinked Objects. Old
    recovery records are kept as-is and gain no restoration permission here.
    """
    try:
        if (rig.type != 'ARMATURE' or rig.library or rig.data.library
                or rig.override_library or rig.data.override_library
                or not rig.is_editable or not rig.data.is_editable):
            return False
        bound = [obj for obj in bpy.data.objects
                 if obj.type == 'ARMATURE' and obj.data == rig.data]
        return len(bound) == 1 and bound[0] == rig
    except (AttributeError, ReferenceError, TypeError):
        return False


def _admission(context, rig):
    from . import animation_composition, body_original_mode, forearm_twist
    from . import unity_animation
    _require(context.mode in {'OBJECT', 'POSE'},
             'Finish the current Edit operation before testing a Base Pose.')
    _require(rig.type == 'ARMATURE' and not rig.library and not rig.data.library
             and not rig.override_library and rig.is_editable and rig.data.is_editable,
             'Base Pose needs one local, single-user Main Rig.')
    _require(_pose_owner(rig),
             'Another Object shares this Main Rig data; Base Pose left it unchanged.')
    _require(context.scene.objects.get(rig.name) == rig
             and context.view_layer.objects.get(rig.name) == rig,
             'Return to the Main Rig scene and view layer before testing a Pose.')
    _require(not rig.animation_data or not rig.animation_data.use_tweak_mode,
             'Exit NLA Tweak Mode before testing a Base Pose; its strip was kept.')
    _require(not animation_composition.active(rig),
             'Close Composition before testing a Base Pose; its drafts are kept.')
    _require(not body_original_mode.active(rig),
             'Return from Original mode before testing a Base Pose.')
    _require(unity_animation.active_preview(rig) is None,
             'Restore the Unity animation preview before testing a Base Pose.')
    _require('character_designer_rigging_session_v1' not in rig,
             'Close the live Rigging input preview before testing a Base Pose.')
    preview = getattr(forearm_twist, '_SESSION', None)
    _require(not preview or preview.get('armature') != rig,
             'Confirm or cancel Forearm calibration before testing a Base Pose.')
    _require(not rig.hide_viewport and rig.visible_get(view_layer=context.view_layer),
             'Show the Main Rig in this view layer before testing a Base Pose.')


def can_start(context):
    """Cheap UI admission only; execute authenticates the complete saved owner."""
    try:
        if context.mode not in {'OBJECT', 'POSE'}:
            return False
        main = getattr(getattr(context.scene, 'character_designer_setup', None), 'rig', None)
        work = getattr(getattr(context.scene, 'character_designer_animation_worklist', None), 'rig', None)
        if main is not None and work is not None and main != work:
            return False
        rig = main if main is not None else work
        return bool(rig is not None and rig.type == 'ARMATURE'
                    and not rig.library and not rig.data.library and not rig.override_library
                    and context.view_layer.objects.get(rig.name) == rig
                    and 'character_designer_composition_session_v1' not in rig
                    and 'character_designer_body_original_mode_v1' not in rig
                    and 'character_designer_rigging_session_v1' not in rig)
    except (AttributeError, ReferenceError, TypeError, KeyError):
        return False


def _structure(rig):
    return _digest({
        'data': rig.data.name_full,
        'bones': {b.name: [b.parent.name if b.parent else None, float(b.length),
                           [float(v) for row in b.matrix_local for v in row],
                           b.use_connect, b.inherit_scale, b.use_inherit_rotation,
                           b.use_local_location] for b in rig.data.bones},
        'constraints': {p.name: [[c.name, c.type,
                                 getattr(getattr(c, 'target', None), 'name_full', None),
                                 getattr(c, 'subtarget', None)] for c in p.constraints]
                        for p in rig.pose.bones}})


def _selection(bone):
    return bool((bone if hasattr(bone, 'select') else bone.bone).select)


def _capture(context, rig):
    from . import bone_display, limb_ik_fk, animation_rest_pose
    ad = rig.animation_data
    old_action = ad.action if ad else None
    old_slot = ad.action_slot if old_action else None
    _require(old_action is None or old_slot is not None,
             'The current Action has no unambiguous slot; its binding was kept.')
    refs = {'rig': rig}
    if old_action is not None:
        refs['previous_action'] = old_action
    if context.object is not None:
        refs['active_object'] = context.object
    for index, obj in enumerate(context.selected_objects):
        refs['selected_' + str(index)] = obj
    state = {
        'scene': context.scene.name_full, 'view_layer': context.view_layer.name,
        'had_animation': ad is not None, 'had_action': old_action is not None,
        'slot': old_slot.identifier if old_slot else None,
        'slot_handle': int(old_slot.handle) if old_slot else None,
        'animation': {name: getattr(ad, name) for name in _ANIMATION} if ad else {},
        'pose_position': rig.data.pose_position,
        'rest_marker': rig.get(animation_rest_pose.PREVIEW_KEY),
        'frame': int(context.scene.frame_current), 'subframe': float(context.scene.frame_subframe),
        'autokey': bool(context.scene.tool_settings.use_keyframe_insert_auto),
        'mode': context.object.mode if context.object else 'OBJECT',
        'selected_count': len(context.selected_objects),
        'reference_names': {name: value.name_full for name, value in refs.items()},
        'active_bone': rig.data.bones.active.name if rig.data.bones.active else None,
        'bone_selection': {pb.name: _selection(pb) for pb in rig.pose.bones},
        'bone_collections': {bone.name: [collection.name for collection in bone.collections]
                             for bone in rig.data.bones},
        'pose': {pb.name: {'rotation_mode': pb.rotation_mode,
                           'channels': {name: list(getattr(pb, name)) for name in _TRANSFORMS},
                           'properties': {name: pb[name] for name in _PROPERTIES if name in pb}}
                 for pb in rig.pose.bones},
        'constraints': {pb.name: {con.name: {'mute': bool(con.mute),
                                           **({'pole_angle': float(con.pole_angle)}
                                              if con.type == 'IK' else {})}
                                  for con in pb.constraints} for pb in rig.pose.bones},
        'pole_metadata': limb_ik_fk._leg_pole_metadata(rig),
        'display': bone_display._snapshot(rig),
    }
    # Check serializability before any Action, mode or pose change.
    _encoded(state)
    return state, refs


def _object_mode(context):
    if context.object is not None and context.object.mode != 'OBJECT':
        result = bpy.ops.object.mode_set(mode='OBJECT')
        _require('FINISHED' in result, 'Blender could not finish the current Pose Mode.')


def _enter_pose(context, rig):
    _object_mode(context)
    for obj in tuple(context.selected_objects):
        obj.select_set(False)
    rig.select_set(True)
    context.view_layer.objects.active = rig
    result = bpy.ops.object.mode_set(mode='POSE')
    _require('FINISHED' in result, 'Blender could not enter Main Rig Pose Mode.')


def _slot(action, identifier, handle):
    matches = [slot for slot in action.slots
               if slot.identifier == identifier and int(slot.handle) == handle
               and slot.target_id_type == 'OBJECT']
    _require(len(matches) == 1, 'The saved Action slot changed; recovery data was kept.')
    return matches[0]


def _validate_restore(context, rig, state, refs):
    _require(context.scene.name_full == state['scene']
             and context.view_layer.name == state['view_layer'],
             'Return to the scene and view layer where Base Pose was started.')
    _require(refs.get('rig') == rig, 'The Base Pose recovery belongs to another rig.')
    _require(set(refs) == set(state['reference_names'])
             and all(refs[name] is not None and refs[name].name_full == expected
                     for name, expected in state['reference_names'].items()),
             'A saved Base Pose ID reference was renamed or reassigned; recovery was kept.')
    _require(set(state['pose']) == set(rig.pose.bones.keys()),
             'The rig bones changed; Base Pose recovery was kept.')
    for key in ('active_object', *('selected_' + str(i) for i in range(state['selected_count']))):
        obj = refs.get(key)
        if key == 'active_object' and obj is None:
            continue
        _require(obj is not None and context.view_layer.objects.get(obj.name) == obj,
                 'An original selection object is unavailable; recovery was kept.')
    previous = refs.get('previous_action')
    _require((previous is not None) == state['had_action'],
             'The previous Action reference changed; recovery was kept.')
    if previous is not None:
        _slot(previous, state['slot'], state['slot_handle'])
    for name, constraints in state['constraints'].items():
        pb = rig.pose.bones[name]
        _require(set(constraints) == set(pb.constraints.keys()),
                 'Rig constraints changed; recovery was kept.')
    _require(all(rig.data.collections_all.get(name) is not None
                 for names in state['bone_collections'].values() for name in names),
             'An original Bone Collection was renamed or removed; recovery was kept.')


def _restore(context, rig, state, refs):
    # ToolSettings is not part of native Undo. Never persistently change the
    # artist's current AutoKey choice; automatic insertion is suspended only
    # while restoring raw channels and the Action binding.
    autokey = context.scene.tool_settings.use_keyframe_insert_auto
    context.scene.tool_settings.use_keyframe_insert_auto = False
    try:
        _restore_disabled(context, rig, state, refs)
    finally:
        context.scene.tool_settings.use_keyframe_insert_auto = autokey


def _restore_disabled(context, rig, state, refs):
    from . import animation_rest_pose, bone_display, limb_ik_fk
    _validate_restore(context, rig, state, refs)
    _object_mode(context)
    context.scene.tool_settings.use_keyframe_insert_auto = False
    previous = refs.get('previous_action')
    ad = rig.animation_data_create()
    ad.action = previous
    if previous is not None:
        ad.action_slot = _slot(previous, state['slot'], state['slot_handle'])
    for name, value in state['animation'].items():
        setattr(ad, name, value)
    rig.data.pose_position = state['pose_position']
    if state['rest_marker'] is None:
        rig.pop(animation_rest_pose.PREVIEW_KEY, None)
    else:
        rig[animation_rest_pose.PREVIEW_KEY] = state['rest_marker']
    context.scene.frame_set(state['frame'], subframe=state['subframe'])
    for name, saved in state['pose'].items():
        pb = rig.pose.bones[name]
        pb.rotation_mode = saved['rotation_mode']
        for prop, values in saved['channels'].items():
            setattr(pb, prop, values)
        for prop in _PROPERTIES:
            if prop in saved['properties']:
                pb[prop] = saved['properties'][prop]
            elif prop in pb:
                del pb[prop]
    for name, constraints in state['constraints'].items():
        for con_name, saved in constraints.items():
            con = rig.pose.bones[name].constraints[con_name]
            con.mute = saved['mute']
            if 'pole_angle' in saved:
                con.pole_angle = saved['pole_angle']
    limb_ik_fk._restore_leg_pole_metadata(rig, state['pole_metadata'])
    context.view_layer.update()
    bone_display._restore(rig, state['display'])
    # Display matching can reassign an existing Body membership, changing only
    # its order alongside _Internal. Preserve the original ordered membership,
    # without replacing Collections or accepting a different membership set.
    for name, expected in state['bone_collections'].items():
        bone = rig.data.bones[name]
        current = [collection.name for collection in bone.collections]
        _require(set(current) == set(expected),
                 'Bone Collection membership changed; Base Pose recovery was kept.')
        if current != expected:
            for collection in tuple(bone.collections):
                collection.unassign(bone)
            for collection in expected:
                rig.data.collections_all[collection].assign(bone)
            _require([collection.name for collection in bone.collections] == expected,
                     'Blender could not restore Bone Collection order; recovery was kept.')
    for pb in rig.pose.bones:
        (pb if hasattr(pb, 'select') else pb.bone).select = state['bone_selection'][pb.name]
    rig.data.bones.active = rig.data.bones.get(state['active_bone'] or '')
    for obj in tuple(context.selected_objects):
        obj.select_set(False)
    for index in range(state['selected_count']):
        refs['selected_' + str(index)].select_set(True)
    context.view_layer.objects.active = refs.get('active_object')
    if state['mode'] == 'POSE':
        result = bpy.ops.object.mode_set(mode='POSE')
        _require('FINISHED' in result, 'Blender could not restore the original Pose Mode.')
    if not state['had_animation'] and not ad.drivers and not ad.nla_tracks and ad.action is None:
        rig.animation_data_clear()


def _has_content(action):
    """An FCurve is authored content even when all its key points were removed."""
    if len(getattr(action, 'pose_markers', ())):
        return True
    if any(key not in {SESSION_KEY, REFS_KEY} for key in action.keys()):
        return True
    for layer in action.layers:
        for strip in layer.strips:
            if strip.type != 'KEYFRAME':
                return True
            for bag in strip.channelbags:
                if len(bag.fcurves):
                    return True
    return bool(getattr(action, 'fcurves', ())) if not action.is_action_layered else False


def _record(context, rig):
    token = rig.get(TOKEN_KEY)
    _require(isinstance(token, str), 'The Base Pose token is invalid; recovery was kept.')
    candidates = []
    for action in bpy.data.actions:
        if SESSION_KEY not in action:
            continue
        refs = action.get(REFS_KEY, {})
        if refs.get('rig') != rig:
            continue
        record = _unpack(action[SESSION_KEY])
        if record['token'] == token:
            candidates.append((action, record, refs))
    _require(len(candidates) == 1, 'The Base Pose owner is missing or ambiguous; all drafts were kept.')
    action, record, refs = candidates[0]
    _require(_structure(rig) == record['structure'],
             'The rig Rest or control graph changed; Base Pose recovery was kept.')
    _require(len(action.slots) == 1, 'The test Action has foreign slots; it was kept.')
    slot = _slot(action, record['slot'], record['slot_handle'])
    ad = rig.animation_data
    _require(ad is not None and ad.action == action and ad.action_slot == slot,
             'The active Action binding changed; the test draft and recovery were kept.')
    _require(action.users - int(action.use_fake_user) == 1,
             'Another user now owns the test Action; its draft and recovery were kept.')
    _require(not action.library and not action.asset_data,
             'The test Action became linked or an asset; recovery was kept.')
    _validate_restore(context, rig, record['before'], refs)
    return action, record, refs


def _new_action(rig, record, refs):
    action = bpy.data.actions.new('Base Pose Test')
    try:
        slot = action.slots.new(id_type='OBJECT', name=rig.name)
        payload = {**record, 'action_id': uuid.uuid4().hex,
                   'slot': slot.identifier, 'slot_handle': int(slot.handle)}
        action[SESSION_KEY] = _pack(payload)
        action[REFS_KEY] = dict(refs)
        return action, payload
    except Exception:
        if action.users == 0:
            bpy.data.actions.remove(action)
        raise


def _retire(action):
    """Never destroy authored test curves, even on a successful Finish."""
    authored = _has_content(action)
    _require(action.users - int(action.use_fake_user) == 0,
             'The detached test Action gained a foreign user; recovery was kept.')
    if authored:
        action.use_fake_user = True
        action.name = 'Pose Test Draft'
    action.pop(SESSION_KEY, None)
    action.pop(REFS_KEY, None)
    if not authored:
        action.use_fake_user = False
        if action.users == 0:
            bpy.data.actions.remove(action)
    return action if authored else None


def _neutral(context, rig):
    from . import control_pose_assets as poses, control_pose_capture as capture
    from . import forearm_original_inventory, limb_ik_fk, limb_ik
    controls = limb_ik._validate_inventory(rig)
    for entry in controls['rigs'].values():
        target = rig.pose.bones[entry['target'].name]
        _require(target.bone.get(limb_ik_fk.VERSION_KEY) == limb_ik_fk.VERSION,
                 'Update this limb control graph before testing Base Pose.')
        for pb, constraint, record in entry['entries']:
            if limb_ik_fk.is_switch_constraint(rig, pb, constraint, record):
                limb_ik_fk.validate_constraint_influence(rig, pb, constraint, record)
    inventory = forearm_original_inventory.validate(rig)
    names = capture._resolve_names(rig, inventory, 'ALL_BODY', True)
    capture._validate_channels(rig, names, inventory)
    values = {name: {'location': dict(enumerate((0., 0., 0.))),
                     'rotation_quaternion': dict(enumerate((1., 0., 0., 0.))),
                     'scale': dict(enumerate((1., 1., 1.)))} for name in names}
    metadata = {'version': 1, 'source_object': rig.name, 'source_slot': 'OB' + rig.name,
                'rest': poses.native_rest(rig), 'scope': 'ALL_BODY',
                'names': names, 'include_fingers': True}
    desired = poses.desired_pose(rig, values, metadata)
    for name in names:
        _require(poses._difference(desired[name], rig.data.bones[name].matrix_local) <= 2e-6,
                 'This Body hierarchy cannot represent native Base Pose without changing its Rest.')
    poses.apply_channels(context, rig, values, metadata=metadata, _pose_only_owner=True)
    limb_ik_fk._update(context, rig)
    for name in names:
        _require(poses._difference(rig.pose.bones[name].matrix, desired[name]) <= 4e-4,
                 'Blender could not match the exact Base Pose; the attempt was rolled back.')


def start_or_reset(context):
    """Enter editable Pose display or reset it; return any retained keyed draft."""
    from . import animation_rest_pose, unity_animation
    rig = _rig(context)
    _admission(context, rig)
    repeated = active(rig)
    previous = record = refs = None
    if repeated:
        previous, record, refs = _record(context, rig)
    attempt, attempt_refs = _capture(context, rig)
    autokey = context.scene.tool_settings.use_keyframe_insert_auto
    if not repeated:
        record = {'version': 1, 'token': uuid.uuid4().hex,
                  'structure': _structure(rig), 'before': attempt}
        refs = attempt_refs
    fresh = previous is None or _has_content(previous)
    action = previous
    try:
        unity_animation._set_playing(context, False)
        if fresh:
            action, record = _new_action(rig, record, refs)
        context.scene.tool_settings.use_keyframe_insert_auto = False
        ad = rig.animation_data_create()
        ad.action = action
        ad.action_slot = _slot(action, record['slot'], record['slot_handle'])
        ad.use_nla, ad.action_blend_type, ad.action_influence = False, 'REPLACE', 1.0
        ad.action_extrapolation = 'HOLD'
        rig.data.pose_position = 'POSE'
        rig.pop(animation_rest_pose.PREVIEW_KEY, None)
        _enter_pose(context, rig)
        context.view_layer.update()
        _neutral(context, rig)
        rig[TOKEN_KEY] = record['token']
    except Exception:
        _restore(context, rig, attempt, attempt_refs)
        if fresh and action is not None and action != previous:
            _retire(action)
        if not repeated:
            rig.pop(TOKEN_KEY, None)
        raise
    finally:
        context.scene.tool_settings.use_keyframe_insert_auto = autokey
    draft = _retire(previous) if fresh and previous is not None else None
    return {'rig': rig, 'reset': repeated, 'draft': draft}


def finish(context):
    """Restore the first entry checkpoint; retain a keyed test as a local draft."""
    rig = _rig(context)
    _admission(context, rig)
    if not active(rig):
        return {'rig': rig, 'draft': None, 'changed': False}
    action, record, refs = _record(context, rig)
    attempt, attempt_refs = _capture(context, rig)
    try:
        _restore(context, rig, record['before'], refs)
    except Exception:
        _restore(context, rig, attempt, attempt_refs)
        raise
    draft = _retire(action)
    rig.pop(TOKEN_KEY, None)
    return {'rig': rig, 'draft': draft, 'changed': True}


@contextmanager
def suspended_for_operation(context, rig):
    """Temporarily restore the original binding; commit exit only on success.

    An operation that rejects restores the exact test pose/draft instead. Its
    caller remains responsible for rolling back its own unrelated mutations.
    """
    if not active(rig):
        yield
        return
    _admission(context, rig)
    action, record, refs = _record(context, rig)
    attempt, attempt_refs = _capture(context, rig)
    try:
        _restore(context, rig, record['before'], refs)
        yield
    except Exception:
        _restore(context, rig, attempt, attempt_refs)
        raise
    else:
        _retire(action)
        rig.pop(TOKEN_KEY, None)
